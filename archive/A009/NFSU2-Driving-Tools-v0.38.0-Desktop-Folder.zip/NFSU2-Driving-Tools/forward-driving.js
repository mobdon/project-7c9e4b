/* Session lifecycle for the optional owned native forward sampler and cap.
 * A published request is not a native application acknowledgement. */
(function(root){
  'use strict';
  const Profiles=root.__NFSU2_FORWARD_NATIVE_CONFIG__||(typeof require==='function'?require('./forward-native-config.js'):null);
  const PIN='ed47e9bdd94a336d8d6bd52bebcc6f130b40ffb6d692f0fc728b8785db02178c';
  const finite=(n,a,b)=>typeof n==='number'&&Number.isFinite(n)&&n>=a&&n<=b;
  const local=name=>{if(typeof require!=='function')return null;try{return require('./'+name+'.js');}catch{return null;}};
  const snapshot=(forwardState,extra={})=>Object.freeze({forwardState,forwardSamples:0,forwardHorizon:0,forwardPriorityTurns:0,
    forwardRequestedTarget:undefined,forwardLeaseTicks:0,forwardCaptured:false,forwardNativeApplied:false,forwardLiveVerified:false,...extra});
  function policySettings(policy){
    if(!policy||typeof policy!=='object')return null;
    const p={lateralAcceleration:policy.lateralAcceleration,brakingDeceleration:policy.brakingDeceleration,
      cornerFactor:policy.cornerFactor??.8,sharpMargin:policy.sharpMargin??15,reactionSeconds:policy.reactionSeconds??.6,
      marginDistance:policy.marginDistance??8,maxSpacing:policy.maxSpacing??20};
    if(!finite(p.lateralAcceleration,.5,12)||!finite(p.brakingDeceleration,.5,12)||!finite(p.cornerFactor,.6,.95)||
      !finite(p.sharpMargin,0,25)||!finite(p.reactionSeconds,.1,2)||!finite(p.marginDistance,0,30)||!finite(p.maxSpacing,1,25))return null;
    return p;
  }
  class Controller{
    constructor(memory,{installed=false,verified=false,moduleHash,moduleIdentity=null,geometry=null,publisher=null}={}){
      this.memory=memory;this.installed=installed===true;this.verified=verified===true&&!!Profiles?.select?.(moduleHash);this.moduleIdentity=moduleIdentity;
      const Geometry=root.__NFSU2_FORWARD_GEOMETRY__||local('forward-geometry');
      const Clamp=root.__NFSU2_FORWARD_CLAMP__||local('forward-clamp');
      this.pacing=root.__NFSU2_FORWARD_PACING__||local('forward-pacing');
      this.geometry=geometry||(Geometry?.Controller?new Geometry.Controller(memory,{installed:this.installed,verified:this.verified,moduleHash,moduleIdentity}):null);
      this.publisher=publisher||(Clamp?.Publisher&&this.geometry?new Clamp.Publisher(this.geometry,{installed:this.installed,moduleIdentity}):null);
      this.key=null;this.pendingRequest=null;this.published=false;this.ownerSequence=null;
    }
    revoke(){
      // The cap occupies a subordinate part of the geometry claim. Revoke it
      // before clearing the geometry receipt or invalidating that owner.
      try{this.publisher?.stop();}catch{}
      try{this.geometry?.stop();}catch{}
      this.pendingRequest=null;this.published=false;this.ownerSequence=null;
    }
    stop(){this.revoke();this.key=null;return snapshot('off');}
    invalidate(){this.stop();try{this.geometry?.invalidate();}catch{}this.verified=false;return snapshot('off');}
    update({enabled=false,safe=false,offline=false,ordinaryRace=false,allowNetwork=false,aiState=null,handbackPending=false,expectedPace,identity,policy}={}){
      if(enabled!==true)return this.stop();
      const unknown=()=>{this.stop();return snapshot('unknown');};
      if(!this.installed||!this.verified||!this.moduleIdentity||!this.geometry||!this.publisher||
        typeof this.pacing?.windowFromCapture!=='function'||typeof this.pacing?.plan!=='function')return unknown();
      if(safe!==true||(offline!==true&&allowNetwork!==true)||ordinaryRace!==true||aiState?.active!==true||aiState?.owned!==true||
        aiState?.switching===true||handbackPending===true){this.stop();return snapshot('waiting');}
      const settings=policySettings(policy);
      if(!settings||typeof identity!=='string'||!identity||identity.length>256||!finite(expectedPace,.75,3)||
        Math.abs(expectedPace*100-Math.round(expectedPace*100))>1e-5)return unknown();
      const key=JSON.stringify([identity,allowNetwork===true,Math.round(expectedPace*100),...Object.values(settings)]);
      if(this.key!==key){this.revoke();this.key=key;}
      // A caller may expose its current command generation. The native probe
      // independently validates it for every request and publication too.
      const observedSequence=aiState.ownerSequence;
      if(observedSequence!==undefined&&(!Number.isInteger(observedSequence)||observedSequence<=0||observedSequence>0xffffffff||(observedSequence&1)))return unknown();
      if(this.ownerSequence!==null&&observedSequence!==undefined&&observedSequence!==this.ownerSequence){this.revoke();this.key=key;}
      try{
        if(this.pendingRequest!==null){
          const capture=this.geometry.poll();
          if(capture?.status==='waiting')return snapshot('waiting');
          const request=this.pendingRequest;this.pendingRequest=null;
          if(capture?.status!=='captured'||capture.request!==request||capture.pace!==expectedPace||
            !Number.isInteger(capture.ownerSequence)||capture.ownerSequence<=0||capture.ownerSequence>0xffffffff||(capture.ownerSequence&1)||
            (observedSequence!==undefined&&capture.ownerSequence!==observedSequence))return unknown();
          const window=this.pacing.windowFromCapture(capture),plan=window?.available===true?this.pacing.plan(window,settings):null;
          if(plan?.available!==true||!Array.isArray(window.samples)||window.samples.length<3||window.samples.length>48||
            !finite(plan.horizonDistance,0,184.01)||!Number.isInteger(plan.priorityTurns)||plan.priorityTurns<0||plan.priorityTurns>24)return unknown();
          const result=this.publisher.publish({capture,window,policy:settings});
          if(result?.status!=='armed'||result.request!==request||!finite(result.cap,0,150)||
            !Number.isInteger(result.maxAgeTicks)||result.maxAgeTicks<1||result.maxAgeTicks>400)return unknown();
          this.published=true;this.ownerSequence=capture.ownerSequence;
          // Do not request another capture here: changing the native request
          // immediately revokes the cap just published. The next update starts
          // a fresh transaction. Lease/fallback gaps are intentionally allowed.
          return snapshot('armed',{forwardSamples:window.samples.length,forwardHorizon:plan.horizonDistance,
            forwardPriorityTurns:plan.priorityTurns,forwardRequestedTarget:result.cap,forwardLeaseTicks:result.maxAgeTicks,forwardCaptured:true});
        }
        if(this.published){this.revoke();this.key=key;}
        const result=this.geometry.request({expectedPace,allowNetwork:allowNetwork===true});
        if(result?.status!=='waiting'||!Number.isInteger(result.request)||result.request<=0||(result.request&1))return unknown();
        this.pendingRequest=result.request;this.ownerSequence=observedSequence??null;
        return snapshot('requested');
      }catch{return unknown();}
    }
  }
  const api=Object.freeze({Controller,PIN});root.__NFSU2_FORWARD_DRIVING__=api;
  if(typeof module==='object'&&module.exports)module.exports=api;
})(globalThis);

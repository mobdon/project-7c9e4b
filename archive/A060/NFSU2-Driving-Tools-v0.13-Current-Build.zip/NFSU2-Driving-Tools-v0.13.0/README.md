# NFSU2 Driving Tools: experimental v0.13.0

Unpacked Chrome / Edge / Brave extension for https://nfsu2.xyz/.

## v0.13.0: current-build compatibility and signature diagnostics

This release adds the exact game module for revision **78e2bb69**, while retaining the reviewed **2f0ddd3b** and **6f4f1e4e** profiles. It verifies the downloaded binary, not just its version label. The compact menu uses a constructed stylesheet that works with the site's strict style policy.

**A game crash was reported with v0.11. Its cause remains unresolved. This update is not a confirmed crash fix and has not been live-gameplay tested.** Back up your save, keep the previous extension folder, and test one feature at a time in solo play.

### Available on 78e2bb69 and 2f0ddd3b

- Native player autopilot, automatic native event reconstruction, normal racer skill field set to 9, and experimental drag physics handoff.
- Separate free-roam/race pace controls and experimental free-roam corner-speed assist.
- Independent solo-only **Wall pass-through** and **Car no-clip** switches.
- Experimental native dyno search, explicit Apply and guarded Restore.
- Unlimited equipped NOS, power boost, limiter control, grip, manual drag assist, solo drift input and read-only tester.

Automatic AI, both pace opt-ins, corner assist, both collision filters, power boost, limiter removal, extra grip, dyno and Online/LAN permission start off after reload. Factors are retained. A future unknown build stays disabled. Both revision and the downloaded module's exact size/SHA-256 must match a reviewed profile before memory tools can run. Native hooks also refuse cold occupied command regions.

## Feature status on the exact current build

| Control | Implemented | What was verified / remaining limit |
| --- | --- | --- |
| Native AI + event switching | Yes | On/Off handback, reused-pointer subtype/track transitions and native mappings tested. Not every race's live behavior or opponent-equivalent initialization. |
| Skill 9 | Yes | Actual native skill getter tested; normal field set to 9, sentinels preserved. Drag's decision-time use of the field remains unproved. |
| Automatic drag | Yes, experimental | Native driver3/physics1 handoff and rollback tested. Launching, shifts, lanes and finishing not live-verified. |
| Free-roam / race pace up to 3× | Yes, separate opt-ins | Native hook and 2–3× bounds/non-compounding tested. This is target-speed scaling, not a promised speed multiplier or stable driving. Drag stays neutral. |
| Free-roam corner assist | Yes, experimental | Actual current corner helper, route ownership, guards and output scaling tested. Not a proven steering/avoidance fix. |
| Wall pass-through / Car no-clip | Yes, independent solo-only switches | Current contact wrapper, categories, filter composition and fallback tested. Live map/traffic coverage unverified. |
| Dyno search / Apply / Restore | Yes, experimental | Current native mappings/calculations, transactional guard/search behavior tested. Full live frontend/save and downstream rebuild behavior unverified. |
| NOS / power / limiter / grip | Yes, experimental | Exact mappings, native NOS, bounds, restoration and controlled competing-writer tests. Hardened but not lifetime-synchronized; freezes unresolved. |
| Manual drag / drift toggle / tester | Yes | Input/state and UI tests. Manual drag still requires you to steer; drift is not perfect-drift automation; tester is incomplete. |
| Crash log + manual JSON export | Yes | Sanitization, retention, effective tool state, export simulation and no-tools memory invariance tested. Real browser export not verified; a freeze may leave no final error. |

Unknown binaries stay disabled. On the older 6f4f1e4e binary, the car no-clip filter is disabled because that hook was only mapped for the current build. No game assets are bundled.

## Signature scanning and build updates

The loader performs a read-only scan against two reviewed sets of 34 typed function fingerprints. It reports unique, ambiguous and missing matches in local diagnostics, plus the actual module hash. The menu retains the full compatibility explanation rather than truncating it. AI and Dyno now give the same explicit unavailable-build reason instead of suggesting the wrong tuning screen.

**Signature matches do not automatically authorize a new game version.** Matching functions alone do not establish callees, dispatch tables, host addresses, scratch ownership or live behavior. Even 34/34 matches on a different binary leave tools disabled until an exact compatibility profile has been reviewed. This is update diagnosis, not a promise that future game updates will work automatically. Scanner failure does not override the independent exact-binary gate.

## Automatic AI race-type switching

Turn on **AI driver → Automatic driver** once per page. It automatically selects:

- **Non-drag races and free roam:** the existing native player autopilot.
- **Drag:** experimental native racer AI with the verified drag physics type. It waits until GO and full driving physics are available.
- **Changing mode:** requests native AI OFF, waits for the game thread to acknowledge it, confirms ownership is released, the human driver is restored and any failed-acquisition latch is cleared, then requests the new mode. Player, car, race, track, drag/drift/URL/StreetX flags, forced native mode flags and race/free-roam changes are checked, including when object pointers are reused.

There is no separate drag-AI checkbox. The main switch explicitly enables automatic selection, including experimental drag. **You still start events yourself. This does not select races, restart them, navigate career menus, buy upgrades or choose a GPS destination.** It includes the separate experimental free-roam corner-speed and dyno-search tools described below. They are off by default.

The extension requests the game's native player autopilot, not a new steering bot. The native constructor chooses a distinct drift behavior and a shared ordinary/drag/StreetX behavior; its update code contains drag-specific branches. Circuit, sprint, URL and outrun do not have separately proven opponent-equivalent implementations here. The player racer identity stays unchanged. “Level 9” means the ordinary native skill field is set to 9; values 254/255 are preserved. We have not proved that drag's launch, shifting or lane decisions consume that field.

**Live drag driving remains unverified.** Correct driver/physics status does not prove that it shifts, steers, avoids traffic or finishes. It may crash, stop or miss checkpoints. Back up your progress and test solo first. No guaranteed routes, perfect drift, wins or completed races.

### Quick start

1. Back up your save with the game's **Download backup** button.
2. Keep your previous extension folder for rollback. Disable its extension card before loading this version.
3. Extract this ZIP. In `chrome://extensions` (Edge: `edge://extensions`), enable Developer mode and choose **Load unpacked**. Select **NFSU2-Driving-Tools-v0.13.0**, containing `manifest.json`.
4. Reload the game and check version **0.13.0**. Only one version should be enabled.
5. Start a solo event yourself. Open Driving tools with **F8**, then enable **Automatic driver** in a non-drag event. For your first drag test, leave power, grip, NOS, custom pace, collision filters and manual Drag assist off.
6. Enter other supported events normally. AI requests native handback/reconstruction automatically when the event changes. Turn AI off before using manual drag assist. Other selected settings are kept.

Chrome 111+ or a compatible current Chromium browser is required. This is not a Firefox or mobile-browser build. No build tools or Node installation are needed to install the extension.

### Take control and pause

- **F7 / Take control:** disables automatic AI until you explicitly turn it on again. Arrow/WASD keys and Space also take control outside the extension menu. This remains off across later race-type changes.
- Controller axes do not trigger takeover; use F7 or the Take control button.
- Taking control also pauses synthetic manual-drag throttle until you toggle manual Drag assist again.
- **F9 / Stop:** clears automatic AI, both collision filters, Online/LAN permission, custom pace, NOS, power, limiter, grip and manual drag. Slider values are retained. Drift and the read-only tester keep their own switches.
- Menus, loading, unfocused/hidden tabs and unsupported states pause tools without clearing choices. They resume when a supported driving state returns, unless you took manual control.
- **Automatic AI, wall pass-through, car no-clip, corner assist, both pace opt-ins, power boost, limiter removal, extra grip, dyno tuner and Online/LAN permission start OFF after every page reload.** Other settings use same-tab session storage. Closing the tab normally ends those saved choices. Storage may be unavailable or affected by browser restore behavior.
- If the page stops updating, native AI hands back within 180 game frames. A frozen game cannot process a handback. Disable the extension and reload if it freezes.

## Compact menu

The menu starts as a **170 × 29 px** collapsed toolbar and opens to a **244 px** drawer with a 390 px maximum scroll panel. **F8** opens/closes it. Sections start folded, only one main section opens at a time, and longer sections scroll. Help and detailed status are tucked away; no control was removed. **F7 / Take control** and **F9 / Stop** remain keyboard shortcuts, with buttons in the open toolbar.

## Independent controls

### AI and pace

The native AI switch uses player-only skill **9**, the highest normal native value. It restores the original value when the same racer still exists. Special sentinels are left unchanged and are not claimed as level 9. It does not alter other racers or commandeer an AI driver the extension did not acquire.

**Free-roam pace:** 0.75×–3.00× for native free roam only, default off / 1.00×. Its factor is saved, but its switch starts off after reload.

**Race / outrun pace:** a separate 0.75×–3.00× opt-in, default off / 1.00×. Its value is saved, but its switch starts off after reload. Your faster free-roam choice does not carry into races.

Both adjust the native target-speed factor, not engine power, steering or road paths. **2–3× pace is especially experimental: severe overspeed, missed turns/checkpoints and instability are possible.** No real driving at those factors has been verified. Drag, dyno and unknown categories use neutral 1.00×. The choices remain selected while ineligible and resume only in their own category. F7 leaves them dormant; F9 clears both switches. They never turn AI on by themselves.

### Free-roam corner-speed assist

A separate, experimental opt-in reduces the native planner's curvature-limited speed for upcoming free-roam corners. It does not replace steering or road paths. Its bounded factor is **0.60–0.95**, starting at **0.80**. Straight/gentle segments retain their native speed cap. This factor is a tuning hypothesis, not a measured optimum.

It applies only to the current, owned AI driver's private main route in native free roam. Races, outruns, drag, drift and the Dyno Shop are excluded. Changing its enabled state or factor rebuilds AI through a full native OFF/manual/ON handoff, because the game caches route speed caps. Free-roam/race transitions also rebuild before rearming.

It may help turn entry but cannot repair a bad route, prevent crashes, guarantee a clean corner or improve lap times. More power, grip or pace may undermine it. Live braking, route rebuilding and handling improvements remain unverified. Start conservatively and keep F7 available.

### Dyno auto tuner

An independent search tool for the **solo Performance Tuning main screen**, with installed ECU/turbo tuning capability. Start with a backed-up save. The tuner is off on reload and never purchases upgrades, enters events or forces a profile save.

1. Enable the tuner and choose **peak power (kW)** or **peak torque (Nm)**.
2. **Find tune** tests up to 120 bounded coordinate-search trials. Each trial restores your original live setup before returning. The resulting best candidate is not automatically applied.
3. **Apply best** is a separate action and must reproduce the exact measured setup on the same car, mode and installed parts. Use the game's own dyno to check it.
4. **Restore** requires the same live car, mode, parts and exact last-applied tune. It restores the prior baseline. Normal game controls govern saving.

This maximizes one measured native peak value, not acceleration, usable power band, gearing, cornering, drift or lap time. It is not a global optimum. A larger peak can worsen real driving. Live setup repeatability, Apply/Restore and save/reload behavior remain unverified.

Cancel, F9, closing the panel, blur, a hidden tab, leaving the page or disabling the tuner cancels ongoing work. Driving effects are paused during search/apply/restore, with their selections retained. **F9 does not undo a tune already applied.** Re-enable the tuner and use Restore previous while its guarded baseline remains valid.

Trials are game-thread transactions and restore the copied ride before acknowledgment. Invalid identities, parts, setup or network state fail closed. If acknowledgment times out, further writes stop and the result is explicitly uncertain; reload before retrying. A native trap can interrupt cleanup, so crash-safe save recovery is not promised.

### Power and handling

- **Unlimited NOS:** refills an already equipped kit while driving; does not install a kit or force native AI to activate NOS.
- **Power boost:** 1.0×–3.0× engine and nitrous torque. Starts at 1.5×. Repeated updates do not compound. More power can worsen wheelspin and handling.
- **Remove stock limiter:** removes the stock MPH governor while enabled. Gearing, drag and redline still limit speed. Upgraded cars may already lack that governor.
- **Extra grip:** 1.0×–2.0× all four tyre-force factors. Starts at 1.3×. It is not auto-steering, yaw damping, corner avoidance or guaranteed handling. High grip can cause abrupt behavior or rollover. It pauses in drift mode/races.
- Power and grip restore only fields still owned by the extension. They wait for three matching samples before applying to rebuilt car data. Changed external tuning is preserved rather than overwritten. Pause/off restores owned values when the original live objects remain valid.
- **Drift assist:** uses the game's real drift-event input and waits for its handling confirmation. Solo free roam only, with game menus closed. It is not perfect-drift automation. Power/grip restore before the native tuning rebuild; settings stay selected. Drift uses its own switch, including after F9.

### Wall / barrier pass-through

**Handling & collisions → Wall pass-through** is independent of AI and **solo-only**, even with Online/LAN tools allowed. Turn **Free roam with others** off, or use a solo race.

Only contacts between your car and verified near-vertical static track polygons are skipped, using the native wall threshold `abs(normal.z) < 0.1`. Ground, ceilings, ramps/slopes and movable props retain the original collision path. Cars retain it unless the independent Car no-clip option is enabled. Sloped faces and movable barrier props remain solid. This is not unrestricted flight or universal noclip. The game's native Ghost setting affects cars, not walls; the extension leaves that setting unchanged.

A selected checkbox is not proof of contact filtering. Its status first says Armed, then counts contacts actually skipped by the native hook. Test a plain vertical wall and neon barrier at low speed; verify ground/ramp and car collisions yourself. Coverage has not been live-verified.

You may leave the drivable map, miss checkpoints or get stuck inside scenery. Native recovery may reposition you after a reset. **Turn it off only when clear of a wall.** Off/F9/reload restores the original collision path. It does not change shared map objects or body collision flags.

### Car no-clip

**Handling & collisions → Car no-clip** is separate from Wall pass-through and is solo-only. It matches confirmed native car collision bodies paired with the current local player's car, whether driven manually or by AI. It does not skip collisions between other cars. Walls, ground and props retain their normal path unless the wall option separately applies.

It starts off after reload and reports Armed until a supported contact is actually skipped. Turn it off only once clear of other cars. F9 stops it. No body flags or shared map objects are changed. Native constructor/category and current wrapper tests pass, but real traffic/racer collisions have not been live-verified.

### Manual drag assist

A separate, optional throttle / RPM-threshold shift / NOS helper **while you steer**. Uses default Arrow Up, Left Shift and Left Alt bindings. Set shift RPM for your car; 6500 is only a starting point, not learned perfect shifting.

Manual drag assist never runs while automatic drag AI is requested, including countdown and failed/unavailable AI. It will not silently substitute synthetic inputs. With Automatic AI off, manual drag waits for native ownership to clear and a human driver to be confirmed. Countdown permits throttle only; shifts and NOS wait for GO. It does not choose lanes or avoid obstacles. F7/manual takeover pauses it until its switch is toggled again.

### Diagnostics

#### Local crash log

Open **Driving tools → Session & diagnostics → Crash log → Export crash log**. This downloads `nfsu2-driving-tools-diagnostics.json` on your computer. Nothing is automatically sent or uploaded. **Clear log** removes this tab's retained diagnostic history; recording then continues.

The logger starts when this extension page loads. It records recent tool choices/factors, sampled game mode and driver state, page/game-worker lifecycle, classified errors, numeric WebAssembly function/offset locations and line numbers from known script files. It does not capture raw console logs, error messages, URLs, credentials, names, saves, keyboard input or network traffic. It never changes game memory or enables a tool.

The newest **180 events, limited to 64 KiB of stored JSON**, are kept in same-tab session storage. State is sampled on changes (at most four times a second) and every five seconds while driving; rapid repeated page errors are capped. Older entries are discarded and the file reports the count. Export soon after a problem. Reloading the same tab normally retains the log; closing the tab, clearing site data, browser recovery behavior or blocked/full storage can lose it. The menu reports when the log is memory-only. The site's own scripts can access this same-origin session storage, so it is not an extension-private vault.

**Capture limits:** this cannot recover crashes that happened before the logger was installed. A full browser/tab/GPU crash, freeze or forced close may prevent any final event. This is a history of observations, not a complete crash dump or proof of the crash's cause; the last snapshot may precede the failure. Free-text errors are deliberately omitted for privacy, so unfamiliar errors appear as `other`. Also export the game's own **Download log** for native game details. This logger does not fix the reported crash or establish that the game is safe.


The read-only traffic/barrier tester reads nearby car objects and the enabled barrier-line table. It is incomplete: it does not fully classify traffic/racers, shapes, props, road geometry, elevation or safe lanes. No detected obstacle does not imply a safe road.

## Online / LAN

Online/LAN remains blocked by default for existing tools. The separate **Session mode → Allow Online/LAN tools** switch is per-page and starts off on reload. It does not activate individual tools. It never overrides either collision filter's solo restriction, drag physics requirements, pause checks or one-local-player checks.

Online modifications may affect racers, trigger integrity checks, invalidate results or cause moderation/bans. Follow the site's rules and prefer solo play or an explicitly permitted private test. This extension does not bypass server restrictions. Turning off the session switch stops AI/synthetic keys and restores owned tuning when possible, while keeping selections for solo. NOS already refilled is not drained. F9 clears the permission.

## Validation and known limits

**456 automated tests pass, zero skipped.** The latest-build native-focused selection passes 86 tests. Automated checks cover exact binary identity, four-hook function/section preservation, native handoff and heartbeat behavior, event-subtype transitions, occupied-mailbox refusal, unowned-memory preservation, memory-reuse rejection, restored tuning on replacement, stale-worker events and crashes in secondary game threads. Separate probes execute actual current-build NOS/input/status, native dyno functions, race constructor/skill accessor, catchup, corner helper and contact wrapper code. Many dependencies are stubbed or use synthetic state. These are not a full game simulation or live gameplay.

All three exact supported modules validate and compile after patching. On 78e2bb69, only functions **4653, 21213, 21263 and 22470** change. On 2f0ddd3b, only **4653, 21213, 21262 and 22430** change. Every other function body and section is preserved byte-for-byte. Original corner instructions and the complete original contact wrapper tail are preserved. On 6f4f1e4e, the older hook set remains unchanged and the new car filter is unavailable. Authored builders reproduce the shipped payloads.

No successful live drag race, wall/car test, cornering improvement, real-car dyno improvement or online race is claimed. The menu passes simulated DOM checks. The strict-CSP Chromium regression test could not run because this environment blocks Chromium startup; no real-browser visual verification is claimed.

The v0.11 crash remains undiagnosed. Controlled interleaving tests did expose stale-state and competing-writer hazards in power, grip and NOS. This release rechecks live state/identity at each field, uses exact-value atomic updates/restoration, rejects out-of-domain power values and avoids unchanged-value rewrites. These are experimental mitigations, not full lifetime synchronization: the native game can still destroy/reuse an object before updating its pointer. No elimination of that residual race or the reported freezes is claimed. The current game-thread gcall ABI, dispatch mapping and hook-local layout match the reviewed native binary; that does not establish the absence of timing, lifetime or gameplay faults. Stop using a feature if the game becomes unstable, preserve the crash log and reload before retesting.

Exact supported profiles:

- **78e2bb69:** 38,170,601 bytes, SHA-256 `df7b930bb293ffdf975f0735d93e0797d51bd137d0cbeabcaff87fc5a693c759`. Latest reviewed profile. Main hook 21213, dispatch 21726, gcall 21740, pace wrapper 21263, contact wrapper 22470; exact native bodies and relocated wrappers are checked offline.
- **2f0ddd3b:** 36,872,934 bytes, SHA-256 `5e33ad2cb4c4cc6893dee7cbd4d6e9bfb0f59a349d218fddbb5e3331ca69bc34`. Expanded experimental feature support listed above. The native gcall function was mapped from old index 21725 to current index 21739 and verified to preserve the same CPU ABI; actual dispatch tables and native AI bodies were checked independently.
- **6f4f1e4e:** 37,839,055 bytes, SHA-256 `ee5d281a3109240d5db25dc3921e1044672cf6d650eb58c3baa089b54fe2941f`. Retains the older combined experimental feature set.

An independent probe executes actual current-build input/status initialization, status writing and the NOS reader in isolated memory: 22 assertions pass. This verifies the mailbox formats and NOS interpretation, not a real gameplay session. A separate native gcall binary comparison verifies that its only body change is the dispatcher call relocation.

## Privacy, implementation and rollback

The extension matches only `https://nfsu2.xyz/*`. No account, history, debugger or broad website permissions. It stores its own preferences and a bounded, sanitized diagnostic history in namespaced same-tab session-storage entries. Nothing is uploaded. Its only added request is a same-origin `/game.json` compatibility read; it inspects the game's own module response during loading. No analytics, remote code or game assets are bundled.

- AI calls native `Player::AutoPilotOn`, `AutoPilotOff` and `SetInputMode(2)` through the game's existing CPU-preserving game-thread dispatcher. It never invokes native game functions concurrently from the page thread.
- Normal drag opponents use driver type 3 / physics type 1, while player autopilot initially asks for physics type 3. The retained drag handoff corrects only the eligible local car, verifies both types and rolls back on failure.
- The page's automatic AI switch supplies the exact drag-permission word only when drag is detected. The native permission and full-physics checks are still required. The pace hook never modifies drag.
- Mode switching publishes OFF and verifies the native heartbeat acknowledgement, cleared ownership and restored manual driver before rearming. Identity, native subtype/track flags and race/free-roam mode are part of that comparison. Native Off/On rebuilds the private driver route.
- Command memory stays at `0x00d0d100` (92 bytes) and walls at `0x00d0d180` (40 bytes), under sequence locks. Cars use `0x00d0d1c0` (40 bytes). The corner record is at `0x00d0d200` (36 bytes), and dyno uses `0x00d0d300..0x00d0d4ff`. These do not overlap. Native scalar-reference/allocator analysis supports using these gaps, but exclusive allocation has not been formally proved and unknown computed writes remain a risk. Cold empty/owned checks and post-attachment ownership guards reduce, not eliminate, that risk. The combined patch targets the main-loop bridge, player pace, wall-contact resolver and corner-speed helper.
- Wall filtering prefixes `sub_005b2610` and preserves the full original resolver for every rejected contact. Body type/vtable, reciprocal car/face pointers, finite unit normals and pair identities are checked. Native `roam_game_online_here()` always blocks wall filtering during multiplayer free roam.

For rollback, disable v0.13.0, enable your preserved previous version and reload. The previous version remains subject to its own build-compatibility checks. Memory effects do not survive reload; saved ordinary preferences may. Never run both versions together.

### Source references

- Public pinned source: https://github.com/th0mk/nfsu2-web/tree/6f4f1e4e92f5f3ddf6f6d165b7f7075a95ab7fe3
- `runtime/career.c`, `runtime/guest.h`: native handoff, return-to-input and game-thread calls.
- `runtime/catchup.c`: native skill, player target-speed calculation.
- `runtime/game.h`, `runtime/web/status_web.c`: driving/countdown/paused states and drag type.
- `runtime/roam.c`, `runtime/roam_game.c`: collision wrapper, native Ghost scope and multiplayer state.
- `runtime/walls.c`: native barrier lines.
- `runtime/mprace.c`, `runtime/drift.c`: per-car torque, limiter, drift and tyre data.
- Reconstructed collision classifications, independently checked against the exact executable: https://github.com/troikoss/speed-re/tree/892e5c31d77c751acd123330eda15c157c4f1b1f/src/Speed/Indep/Src/Physics/Collision

No upstream files were modified. This is unofficial and not affiliated with the site or Electronic Arts. No game executable, assets or reconstructed third-party code are in the ZIP.

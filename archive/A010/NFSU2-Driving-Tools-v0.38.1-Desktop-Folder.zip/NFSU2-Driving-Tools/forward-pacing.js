/* Pure speed advice for a verified, ordered native query window.
 * This module does not read/write game memory or acquire driving control. */
(function(root){
  'use strict';
  const Geometry=root.__NFSU2_RACE_WINDOW_GEOMETRY__||(typeof require==='function'?require('./race-window-geometry.js'):null);
  const finite=(n,a,b)=>typeof n==='number'&&Number.isFinite(n)&&n>=a&&n<=b;
  const unknown=reason=>({available:false,reason,wholeRaceChecked:false});
  const Profiles=root.__NFSU2_FORWARD_NATIVE_CONFIG__||(typeof require==='function'?require('./forward-native-config.js'):null);
  const PIN='ed47e9bdd94a336d8d6bd52bebcc6f130b40ffb6d692f0fc728b8785db02178c';
  // Native f2078 uses the at/after anchor and its predecessor. Under the
  // sampler's pinned CW037f, delta and ratio are stored as float32 before
  // the double multiply/add is rounded to the output float32 vector.
  function interpolate(anchors,distance){
    const index=anchors.findIndex(p=>p.distance>=distance);
    if(index<0||distance<anchors[0].distance)return null;
    if(index===0)return anchors[0].xyz.slice();
    const a=anchors[index-1],b=anchors[index],t=Math.fround((distance-a.distance)/(b.distance-a.distance));
    return a.xyz.map((x,i)=>Math.fround(x+t*Math.fround(b.xyz[i]-x)));
  }
  // Local interpolation uses up to48 points, retaining native knots and spacing8.
  // The raw native mailbox still has at most24 anchors and <=184.01 route units.
  function windowFromCapture(capture,{spacing=8,maxSamples=48}={}){
    if(capture?.status!=='captured'||!Profiles?.select?.(capture.moduleHash)||capture.source!=='owned-native-forward-query-v1'||capture.sampling!=='native-node-anchors-linear-v1'||capture.postConstructionVerified!==true||capture.forwardOrderVerified!==true||capture.horizontalAxes!=='xy'||capture.controlWord!==0x37f||!Number.isInteger(capture.request)||capture.request<=0||(capture.request&1))return unknown('verified-native-anchor-capture-required');
    if(!finite(spacing,1,20)||!Number.isInteger(maxSamples)||maxSamples<3||maxSamples>48)return unknown('bounded-resampling-policy-required');
    const anchors=capture.points,progress=capture.progress,end=capture.end;
    const maxHorizon=Profiles.select(capture.moduleHash).runtime.maxHorizon||184;
    if(!Array.isArray(anchors)||anchors.length<2||anchors.length>24||!finite(progress,-1e6,1e6)||!finite(end,-1e6,1e6)||Math.fround(end-progress)<16||end-progress>maxHorizon+.01||!anchors.every((p,i)=>p&&finite(p.distance,-1e6,1e6)&&p.distance===Math.fround(p.distance)&&Array.isArray(p.xyz)&&p.xyz.length===3&&p.xyz.every(n=>finite(n,-1e6,1e6)&&n===Math.fround(n))&&(!i||p.distance>anchors[i-1].distance))||progress<anchors[0].distance||end>anchors.at(-1).distance)return unknown('bounded-ordered-native-anchors-required');
    const boundaries=anchors.map(p=>p.distance).filter(d=>d>progress&&d<end);boundaries.push(end);
    const samples=[{distance:0,xyz:interpolate(anchors,progress)}];let current=progress;
    for(const boundary of boundaries){
      const from=current,steps=Math.ceil((boundary-from)/spacing);
      for(let i=1;i<=steps;i++){
        const absolute=i===steps?boundary:Math.fround(from+(boundary-from)*i/steps);
        const relative=Math.fround(absolute-progress);
        if(relative<=samples.at(-1).distance)return unknown('native-distance-resolution-exhausted');
        samples.push({distance:relative,xyz:interpolate(anchors,absolute)});current=absolute;
        if(samples.length===maxSamples)break;
      }
      if(samples.length===maxSamples)break;
    }
    if(samples.length<3||samples.some(p=>!p.xyz||!p.xyz.every(Number.isFinite)))return unknown('insufficient-forward-anchor-window');
    return {available:true,moduleHash:capture.moduleHash,source:capture.source,request:capture.request,pathKind:'selected-road-centerline',unitSystem:'native-world-units-per-second',siCalibrated:false,orderVerified:true,postConstructionVerified:true,horizontalAxes:'xy',nativeUnitScaleVerified:capture.nativeUnitScaleVerified===true,controlWord:0x37f,sampling:capture.sampling,resolutionVerified:false,wholeRaceChecked:false,nativeAnchorCount:anchors.length,progress,physicalSpeed:capture.physical?.speed,samples};
  }
  function plan(window,{lateralAcceleration,brakingDeceleration,cornerFactor=.8,sharpMargin=15,reactionSeconds=.6,marginDistance=8,maxSpacing=20}={}){
    if(!Geometry||window?.source!=='owned-native-forward-query-v1'||window.orderVerified!==true||window.nativeUnitScaleVerified!==true||window.horizontalAxes!=='xy'||window.postConstructionVerified!==true||window.pathKind!=='selected-road-centerline')return unknown('verified-forward-centerline-required');
    if(!finite(lateralAcceleration,.5,12)||!finite(brakingDeceleration,.5,12)||!finite(cornerFactor,.6,.95)||!finite(sharpMargin,0,25)||!finite(reactionSeconds,0,2)||!finite(marginDistance,0,30)||!finite(maxSpacing,1,25))return unknown('bounded-physical-policy-required');
    if(!finite(window.physicalSpeed,0,500))return unknown('verified-current-native-speed-required');
    const samples=window.samples;
    if(!Array.isArray(samples)||samples.length<3||samples.length>48)return unknown('bounded-forward-samples-required');
    if(!samples.every((p,i)=>p&&finite(p.distance,0,10000)&&Array.isArray(p.xyz)&&p.xyz.length===3&&p.xyz.every(n=>finite(n,-1e6,1e6))&&(i===0?p.distance===0:p.distance>samples[i-1].distance&&p.distance-samples[i-1].distance<=maxSpacing)))return unknown('invalid-distance-order-or-spacing');
    // Route coordinates remain interpolation/binding parameters. Braking uses
    // measured XY chords, capped by each route step to preserve the released
    // horizon bound without ever crediting more than the measured path.
    const pathDistances=[0],brakingDistances=[0];
    for(let i=1;i<samples.length;i++){
      const a=samples[i-1],b=samples[i],step=b.distance-a.distance,chord=Math.hypot(b.xyz[0]-a.xyz[0],b.xyz[1]-a.xyz[1]);
      if(chord<1e-4||chord>maxSpacing||chord/step<.5||chord/step>1.1)return unknown('unverified-native-unit-spacing');
      if(Math.abs(b.xyz[2]-a.xyz[2])/chord>.25)return unknown('grade-outside-horizontal-policy');
      pathDistances.push(pathDistances[i-1]+chord);
      brakingDistances.push(Math.min(b.distance,brakingDistances[i-1]+Math.min(chord,step)));
    }
    const points=samples.map(p=>p.xyz.slice(0,2));
    const geometry=Geometry.inspectPolyline({source:'native-race-route',orderVerified:true,coverage:'bounded-forward-window',points},{maxSegmentLength:maxSpacing,maxStraightGap:20});
    if(geometry.status!=='measured'||geometry.corners.some(c=>c.reversal||c.curvature===null))return unknown('incomplete-or-reversing-geometry');
    const priority=new Set(geometry.priorityCorners.flatMap(run=>run.indices));
    // Infinity is internal absence of a measured corner constraint, never a
    // published target. A straight excerpt does not impose a fixed ceiling.
    const caps=samples.map(()=>Infinity),curveCaps=samples.map(()=>Infinity);
    for(const c of geometry.corners){
      if(c.curvature<=0)continue;
      const speed=Math.sqrt(lateralAcceleration/c.curvature)*cornerFactor*(priority.has(c.index)?1-sharpMargin/100:1);
      caps[c.index]=curveCaps[c.index]=speed;
    }
    // The excerpt ends because observation is bounded, not because the road
    // ends. Never turn that boundary into a zero-speed obstacle. Unknown
    // continuation leaves native driving in charge rather than certifying it.
    const routeHorizon=samples.at(-1).distance,pathHorizon=pathDistances.at(-1),horizon=brakingDistances.at(-1);
    // A corner can arrive before the end of the measured window. Account for
    // response time and margin to each target too, rather than only to the
    // horizon. A target at the current sample applies its curve cap directly.
    for(let i=0;i<caps.length;i++)for(let j=i+1;j<caps.length;j++){
      if(!Number.isFinite(curveCaps[j]))continue;
      const usable=Math.max(0,brakingDistances[j]-brakingDistances[i]-marginDistance);
      const delayedEntry=Math.sqrt((brakingDeceleration*reactionSeconds)**2+curveCaps[j]**2+2*brakingDeceleration*usable)-brakingDeceleration*reactionSeconds;
      caps[i]=Math.min(caps[i],Math.max(curveCaps[j],delayedEntry));
    }
    for(let i=caps.length-2;i>=0;i--)caps[i]=Math.min(caps[i],Math.sqrt(caps[i+1]**2+2*brakingDeceleration*(brakingDistances[i+1]-brakingDistances[i])));
    const hasCornerConstraint=curveCaps.some(Number.isFinite),reactionHorizon=window.physicalSpeed*reactionSeconds+marginDistance;
    const reason=!hasCornerConstraint?'no-observed-corner-constraint':horizon<=reactionHorizon?'insufficient-observed-reaction-horizon':!finite(caps[0],Number.MIN_VALUE,150)?'no-supported-positive-corner-target':'measured-corner-constraint';
    const override=reason==='measured-corner-constraint',targetCap=override?Math.fround(caps[0]):null;
    return {available:true,override,targetCap,reason,source:window.source,pathKind:window.pathKind,unitSystem:'native-world-units-per-second',siCalibrated:false,advisoryOnly:true,wholeRaceChecked:false,horizonDistance:horizon,brakingHorizonDistance:horizon,routeHorizonDistance:routeHorizon,pathHorizonDistance:pathHorizon,reactionHorizonDistance:reactionHorizon,brakingDistanceBasis:'sum-of-min-horizontal-chord-and-route-step',priorityTurns:geometry.priorityCorners.length,
      samples:samples.map((p,i)=>({distance:p.distance,routeDistance:p.distance,pathDistance:pathDistances[i],brakingDistance:brakingDistances[i],curveSpeed:Number.isFinite(curveCaps[i])?curveCaps[i]:null,entrySpeed:Number.isFinite(caps[i])?caps[i]:null,priority:priority.has(i)})),
      assumptions:{lateralAcceleration,brakingDeceleration,cornerFactor,sharpMargin,reactionSeconds,marginDistance},
      notice:'Selected road centerline, not the final racing line. Assumed acceleration limits and sampled horizontal geometry; no physical speed-cap, grip, braking or race-result guarantee.'};
  }
  const NATIVE_POLICY_HASH='14074507a84d43365610feae3a8fad80f4637b891e2ed03239460b104f986cbd';
  function nativePolicyValid(capture,p){
    return p?.available===true&&p.source==='exact-native-grade-policy-v1'&&p.moduleHash===NATIVE_POLICY_HASH&&capture?.moduleHash===p.moduleHash&&p.request===capture.request&&Number.isInteger(p.request)&&p.request>0&&!(p.request&1)&&p.gravity===Math.fround(9.8)&&p.straightCap===60&&p.lateralAcceleration===p.grip*p.gravity&&
      [[3.7,12],[3.4,10.6],[3.1,9.3],[2.8,8],[3,10],[3,9],[3,8],[2,6]].some(([g,a])=>p.grip===Math.fround(g)&&p.brakingDeceleration===Math.fround(a));
  }
function planNative(capture,policy,{pace=1,cornerFactor=1,sharpMargin=0,brakingFactor=1,reactionSeconds=0,marginDistance=0}={}){
 const unknown=reason=>({available:false,override:false,reason});
 if(!nativePolicyValid(capture,policy))return unknown('verified-native-policy-required');
 if(capture?.status!=='captured'||capture.moduleHash!==NATIVE_POLICY_HASH||capture.source!=='owned-native-forward-query-v1'||capture.postConstructionVerified!==true||capture.forwardOrderVerified!==true||capture.nativeUnitScaleVerified!==true||capture.horizontalAxes!=='xy'||policy?.available!==true||policy.moduleHash!==capture.moduleHash)return unknown('verified-owned-native-capture-and-policy-required');
 if(!Number.isFinite(pace)||pace<.75||pace>2||!Number.isFinite(brakingFactor)||brakingFactor<.5||brakingFactor>1||!Number.isFinite(reactionSeconds)||reactionSeconds<0||reactionSeconds>2||!Number.isFinite(marginDistance)||marginDistance<0||marginDistance>30)return unknown('bounded-policy-required');
 const points=capture.points,progress=capture.progress,end=capture.end;
 const maxHorizon=Profiles.select(capture.moduleHash).runtime.maxHorizon||184;
 if(!Array.isArray(points)||points.length<2||points.length>24||!Number.isFinite(progress)||!Number.isFinite(end)||end-progress<16||end-progress>maxHorizon+.01||points[0].distance>progress||points.at(-1).distance<end||!points.every((p,i)=>p&&Number.isFinite(p.distance)&&Array.isArray(p.xyz)&&p.xyz.length===3&&p.xyz.every(Number.isFinite)&&(!i||p.distance>points[i-1].distance)))return unknown('ordered-bounded-native-knots-required');
 const geometry=Geometry.inspectPolyline({source:'native-race-route',orderVerified:true,coverage:'bounded-forward-window',points:points.map(p=>p.xyz.slice(0,2))},{maxSegmentLength:maxHorizon+.01,maxStraightGap:20});
 if(geometry.status!=='measured'||geometry.corners.some(c=>c.reversal||c.curvature===null))return unknown('incomplete-or-reversing-native-knots');
 const distances=new Map();let measured=0;
 for(let i=1;i<points.length;i++){
  const a=points[i-1],b=points[i],step=b.distance-a.distance,chord=Math.hypot(b.xyz[0]-a.xyz[0],b.xyz[1]-a.xyz[1]);
  if(chord/step<.5||chord/step>1.1||Math.abs(b.xyz[2]-a.xyz[2])/chord>.25)return unknown('unverified-native-unit-spacing');
  if(b.distance<progress)continue;
  measured+=Math.min(chord,step)*(b.distance-Math.max(a.distance,progress))/step;distances.set(i,measured);
 }
 const priority=new Set(geometry.priorityCorners.flatMap(c=>c.indices)),a=policy.brakingDeceleration*brakingFactor,constraints=[];
 let target=Infinity;
 for(const c of geometry.corners){
  if(points[c.index].distance>end||c.curvature<=0)continue;
  if(!Number.isFinite(cornerFactor)||cornerFactor<.6||cornerFactor>1||!Number.isFinite(sharpMargin)||sharpMargin<0||sharpMargin>25)return unknown('invalid-native-curve-policy');
  const past=points[c.index].distance<progress;
  if(past){
   const h=capture.physical?.heading,out=[points[c.index+1].xyz[0]-points[c.index].xyz[0],points[c.index+1].xyz[1]-points[c.index].xyz[1]],length=Array.isArray(h)?Math.hypot(h[0],h[1]):NaN,ol=Math.hypot(...out);
   // Authored exit policy: retain a measured apex while heading still crosses
   // the outgoing native segment. Progress past a vertex alone is not exit.
   if(!Number.isFinite(length)||length<.5||length>1.5)return unknown('verified-exit-heading-required');
   if((h[0]*out[0]+h[1]*out[1])/(length*ol)>=Math.cos(15*Math.PI/180))continue;
  }
  const curve=Math.sqrt(policy.lateralAcceleration/c.curvature)*cornerFactor*(priority.has(c.index)?1-sharpMargin/100:1);
  const distance=past?0:distances.get(c.index),usable=Math.max(0,distance-marginDistance),entry=Math.max(curve,Math.sqrt((a*reactionSeconds)**2+curve*curve+2*a*usable)-a*reactionSeconds);
  target=Math.min(target,entry);constraints.push({index:c.index,distanceNative:distance,curvature:c.curvature,angleDegrees:c.angleDegrees,priority:priority.has(c.index),curveSpeed:curve,entrySpeed:entry});
 }
 const override=constraints.length>0&&Number.isFinite(target)&&target>0&&target<=150;
 return{available:true,override,targetCap:override?Math.fround(target):null,reason:constraints.length?'measured-native-knot-bend':'no-observed-speed-limiting-bend',constraints,priorityTurns:geometry.priorityCorners.length,nativeKnots:points.length,horizonDistance:end-progress,wholeRaceChecked:false,advisoryOnly:true,liveVerified:false,
  assumptions:{nativeGrip:policy.grip,lateralAcceleration:policy.lateralAcceleration,brakingDeceleration:a,cornerFactor,sharpMargin,reactionSeconds,marginDistance},notice:'Native planner tables are planning assumptions, not measured tire force or actual braking.'};
}
  const api=Object.freeze({plan,planNative,windowFromCapture,nativePolicyValid});root.__NFSU2_FORWARD_PACING__=api;if(typeof module==='object'&&module.exports)module.exports=api;
})(globalThis);

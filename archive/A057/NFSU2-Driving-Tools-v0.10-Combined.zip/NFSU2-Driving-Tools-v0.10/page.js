(() => {
  'use strict';
  if (location.origin !== 'https://nfsu2.xyz' || window.top !== window || window.__nfsu2DrivingTools) return;
  Object.defineProperty(window, '__nfsu2DrivingTools', { value: true });
  const AI = globalThis.__NFSU2_AI__;
  const Walls = globalThis.__NFSU2_WALLS__;
  AI?.install();
  let wall = null;
  let dyno = null, dynoEnabled = false, dynoText = 'OFF · back up progress before testing';
  let ai = null, dragTakenOver = false, dragRace = false;
  const { Engine, StableGate, supportedRevision } = globalThis.__NFSU2_DRIVING_CORE__;
  delete globalThis.__NFSU2_DRIVING_CORE__;
  let engine = null, statusPtr = 0, inputPtr = 0, supported = false, revision = '', visible = false;
  let host, ui, note, live, timer, driftPending = null, driftNeedsReapply = false;
  const powerGate=new StableGate(), gripGate=new StableGate();
  let lastShift = 0, shiftTimer = 0, lastPulse = 0, lastScan = 0;
  const held = new Set(), physicallyHeld = new Set();
  const prefs = { cornerAssist: false, cornerFactor: 0.8, racePace: false, racePaceFactor: 1, walls: false, online: false, ai: false, aiPace: false, paceFactor: 1, nos: false, drag: false, rpm: 6500, tester: false, boost: false, power: 1.5, unlimit: false, grip: false, gripFactor: 1.3, drift: null };
  const STORAGE_KEY='nfsu2-driving-tools-v1';
  try {
    const saved=JSON.parse(sessionStorage.getItem(STORAGE_KEY)||'null');
    if(saved && typeof saved==='object') {
      for(const name of ['aiPace','nos','drag','tester','boost','unlimit','grip']) if(typeof saved[name]==='boolean') prefs[name]=saved[name];
      for(const [name,min,max] of [['racePaceFactor',0.75,1.5],['cornerFactor',0.6,0.95],['paceFactor',0.75,1.5],['rpm',3000,10000],['power',1,3],['gripFactor',1,2]]) if(Number.isFinite(saved[name])) prefs[name]=Math.max(min,Math.min(max,saved[name]));
      if(typeof saved.drift==='boolean') prefs.drift=saved.drift;
    }
  } catch { /* storage disabled: choices still persist between races in this page */ }
  const savePrefs=()=>{try{sessionStorage.setItem(STORAGE_KEY,JSON.stringify(prefs));}catch{}};
  const message = text => { if (note) {note.textContent=text;const summary=ui.querySelector('#status-summary');summary.title=text;} };
  const NativeWorker = window.Worker;
  // Observe only the known game worker; AI validates its patched module separately.
  window.Worker = new Proxy(NativeWorker, {
    construct(Target, args, NewTarget) {
      const worker = Reflect.construct(Target, args, NewTarget);
      let url; try { url = new URL(String(args[0]), location.href); } catch { return worker; }
      if (url.origin !== location.origin || url.pathname !== '/host/game-worker.js') return worker;
      const send = worker.postMessage;
      worker.postMessage = function (m, ...rest) {
        if (m && m.mod instanceof WebAssembly.Module && m.memory instanceof WebAssembly.Memory && m.slot === 0) {
          if (!engine || engine.memory !== m.memory) { dyno?.cancel(); dyno = globalThis.__NFSU2_DYNO__?.Controller ? new globalThis.__NFSU2_DYNO__.Controller(m.memory, AI?.isPatchedModule?.(m.mod)===true) : null; dyno?.setEnabled(dynoEnabled); wall?.stop(); wall = Walls?.Controller ? new Walls.Controller(m.memory, AI.isPatchedModule(m.mod)) : null; ai?.stop(); ai = AI?.Controller ? new AI.Controller(m.memory, AI.isPatchedModule(m.mod)) : null; engine = new Engine(m.memory); statusPtr = 0; inputPtr = 0; driftPending = null; driftNeedsReapply=typeof prefs.drift==='boolean'; powerGate.reset(); gripGate.reset(); }
        }
        return Reflect.apply(send, this, [m, ...rest]);
      };
      worker.addEventListener('message', event => {
        const m = event.data;
        if (m?.t === 'register' && m.kind === 3 && Number.isSafeInteger(m.ptr)) inputPtr = m.ptr;
        if (m?.t === 'register' && m.kind === 5 && Number.isSafeInteger(m.ptr)) statusPtr = m.ptr;
        if (m?.t === 'exit' || m?.t === 'trap') {suspend('Game stopped. Enabled choices are kept for the next game.');ai=null;wall=null;dyno=null;engine=null;statusPtr=0;inputPtr=0;}
      });
      return worker;
    }
  });
  // A different game revision must be reviewed before writing its memory.
  fetch('/game.json', { cache: 'no-store', credentials: 'omit' }).then(r => {
    if (!r.ok) throw new Error('Build information unavailable');
    return r.json();
  }).then(info => {
    revision = String(info.rev || 'unknown'); supported = revision === supportedRevision;
    if (!supported) message('Game updated: memory tools disabled until this extension is updated.');
  }).catch(() => message('Could not check game version. Memory tools stay disabled.'));

  function key(code, down) {
    const keyName = { ArrowUp: 'ArrowUp', ShiftLeft: 'Shift', AltLeft: 'Alt' }[code] || code;
    window.dispatchEvent(new KeyboardEvent(down ? 'keydown' : 'keyup', { code, key: keyName,
      location: /Left$/.test(code) ? 1 : 0, bubbles: true, cancelable: true }));
  }
  function hold(code, down) {
    if (down && !held.has(code)) { if (!physicallyHeld.has(code)) { held.add(code); key(code, true); } }
    else if (!down && held.delete(code) && !physicallyHeld.has(code)) key(code, false);
  }
  function release() { clearTimeout(shiftTimer); for (const code of [...held]) hold(code, false); }
  function suspend(why) {
    dyno?.cancel();
    wall?.stop(); ai?.stop(); release(); powerGate.reset(); gripGate.reset();
    try {if(engine){const state=engine.state();engine.restorePerformance(state);engine.restoreGrip(state);}} catch { /* no stale pointer writes */ }
    if(why) message(why);
  }
  function stop(why = 'Driving controls off. F9 cleared driving assists and the Online/LAN opt-in.') {
    dynoEnabled=false;dyno?.setEnabled(false);if(ui)ui.querySelector('#dyno-enable').checked=false;
    prefs.cornerAssist=false;prefs.racePace=false;prefs.walls=false;prefs.online=false;prefs.ai=false;prefs.aiPace=false;prefs.nos=false;prefs.drag=false;prefs.boost=false;prefs.unlimit=false;prefs.grip=false;savePrefs();suspend();
    if(ui) for(const id of ['corner-assist','race-pace','walls','online','ai','ai-pace','nos','drag','boost','unlimit','grip']) ui.querySelector('#'+id).checked=false;
    message(why);
  }
  function takeControl() {
    prefs.ai=false; ai?.stop(); dragTakenOver=true; release(); savePrefs();
    if(ui) {ui.querySelector('#ai').checked=false;ui.querySelector('#ai-state').textContent='Manual control · native AI off';}
    message('Returning control to you. Native AI is off on the next game frame. Toggle drag assist again if you want assisted throttle.');
  }
  window.addEventListener('keydown', e => {
    if (!e.isTrusted) return;
    // Range controls keep their native arrow/Space behavior without taking over the car.
    if(host && e.composedPath?.().includes(host) && !['F7','F8','F9','Escape'].includes(e.code)) return;
    physicallyHeld.add(e.code);
    if(e.code==='F7') {e.preventDefault();takeControl();}
    else if(prefs.ai && ['ArrowLeft','ArrowRight','ArrowUp','ArrowDown','KeyW','KeyA','KeyS','KeyD','Space'].includes(e.code)) takeControl();
    if (e.code === 'F8') { e.preventDefault(); setPanel(!visible); }
    if (e.code === 'Escape' && visible) setPanel(false);
    if (e.code === 'F9') { e.preventDefault(); stop(); }
  }, true);
  window.addEventListener('keyup', e => { if (e.isTrusted) physicallyHeld.delete(e.code); }, true);
  window.addEventListener('blur', () => { physicallyHeld.clear(); suspend('Paused while unfocused. Enabled tools resume when you return to a supported driving mode.'); });
  document.addEventListener('visibilitychange', () => { if (document.hidden) suspend('Paused while the tab is hidden. Your enabled choices are kept.'); });
  window.addEventListener('pagehide', () => { savePrefs(); suspend(); clearInterval(timer); });

  function setDrift(wanted) {
    if (driftPending) return false;
    const state = engine?.state(), counters = engine && statusPtr ? engine.status(statusPtr) : null;
    if (!supported || !state?.ready || !state.driving || state.network || !counters || (counters.drive & 3) !== 2 || !Number.isFinite(counters.drift) || document.hidden || document.querySelector('dialog[open]')) {
      message('Drift assist only works while driving solo free roam with the game menus closed.'); return false;
    }
    if (!!(counters.drift & 1) === wanted) return true;
    // Rebuilding the native drift setup must not inherit our power multiplier.
    engine.restorePerformance(state);engine.restoreGrip(state);powerGate.reset();gripGate.reset();
    if (!engine.driftTap(inputPtr)) { message('Drift request not sent: the game input mailbox is unavailable, inactive, typing, or full.'); return false; }
    driftPending = { wanted, until: performance.now() + 3000 };
    ui.querySelector('#drift').disabled = true;
    message('Drift request sent. Waiting for the game to confirm its handling state…');
    return true;
  }
  function tick() {
    updateDynoUI();
    if(dyno?.busy) {wall?.stop();ai?.stop();release();return;}
    if (!engine) { if (live) live.textContent = 'Waiting for game. Reload after installing, then press Play.'; return; }
    try {
      const s = engine.state(), counters = statusPtr ? engine.status(statusPtr) : null;
      dragRace=!!(s.ready && s.drag);
      const driveStatus = counters && Number.isFinite(counters.drive) ? counters.drive & 3 : 0;
      const canInput = supported && s.ready && (!s.network || prefs.online) && driveStatus !== 0 && !document.hidden && document.hasFocus() && !document.querySelector('dialog[open]');
      const safe = canInput && s.driving;
      const nativeRaceType=s.ready?engine.u32(0x89e7b0):null;
      const roamProfile=!dragRace && driveStatus===2 && nativeRaceType===0;
      const raceProfile=!dragRace && (nativeRaceType===1 || nativeRaceType===7);
      const requestedPace=roamProfile && prefs.aiPace?prefs.paceFactor:raceProfile && prefs.racePace?prefs.racePaceFactor:1;
      // Drop synthetic input before publishing a native drag handoff request.
      const dragAIRequested = prefs.ai && dragRace;
      if (dragAIRequested) release();
      const aiState = ai?.update({enabled:prefs.ai,safe,state:s,mode:driveStatus,pace:requestedPace,allowNetwork:prefs.online,allowDragAI:dragAIRequested,cornerAssist:prefs.cornerAssist,cornerFactor:prefs.cornerFactor}) || {available:false,active:false,status:'Native game AI · experimental',reason:'Reload with the native AI module installed.'};
      const wallState=wall?.update({enabled:prefs.walls,safe,state:s}) || {requested:false,hits:0,reason:'Reload with the wall-contact module installed.'};
      let nos = false;
      if (safe && prefs.nos) nos = engine.refill(s,prefs.online);
      let tune={active:false},grip={active:false};
      if(safe && !driftPending && (prefs.boost || prefs.unlimit)) {
        const info=engine.performanceInfo(s),patch=engine.performancePatch;
        if(patch && (!info || patch.car!==s.car || patch.race!==s.race || patch.pi!==info.pi)) {engine.restorePerformance(s);powerGate.reset();}
        if(!info)powerGate.reset();
        if(info && (engine.performancePatch || powerGate.accept([s.car,s.race,info.pi,...info.values]))) {
          tune=engine.tunePerformance(s,prefs.boost?prefs.power:1,prefs.unlimit,prefs.online);
          if(tune.changed){powerGate.reset();message(tune.reason);}
        }
      } else {engine.restorePerformance(s);powerGate.reset();}
      if(safe && !driftPending && prefs.grip) {
        const info=engine.gripInfo(s),patch=engine.gripPatch;
        if(patch && (!info || patch.car!==s.car || patch.race!==s.race || patch.physics!==info.physics || patch.wheels.some((w,i)=>w!==info.wheels[i]))) {engine.restoreGrip(s);gripGate.reset();}
        if(!info)gripGate.reset();
        if(info && (engine.gripPatch || gripGate.accept([s.car,s.race,info.physics,...info.wheels,...info.values]))) {
          grip=engine.tuneGrip(s,prefs.gripFactor,prefs.online);
          if(grip.changed){gripGate.reset();message(grip.reason);}
        }
      } else {engine.restoreGrip(s);gripGate.reset();}
      const manualDriver = s.ready && engine.u32(s.car+0x24)===1 && !aiState.active && (!ai || !aiState.available || (aiState.ready && !aiState.owned));
      const dragCountdown = dragRace && engine.u32(s.race)===3;
      const activeDrag = canInput && (s.driving || dragCountdown) && prefs.drag && !dragAIRequested && dragRace && manualDriver && !dragTakenOver;
      const now = performance.now();
      if (activeDrag) {
        hold('ArrowUp', true);
        if (s.driving && prefs.nos && nos && s.gear >= 3) hold('AltLeft', true); else hold('AltLeft', false);
        if (s.driving && s.rpm >= prefs.rpm && s.gear >= 2 && s.gear < 7 && now - lastShift > 650) {
          lastShift = now; hold('ShiftLeft', true);
          shiftTimer = setTimeout(() => hold('ShiftLeft', false), 85);
        }
        // Refresh synthetic held keys after a game's own input-release event.
        if (now - lastPulse > 500) { lastPulse = now; for (const code of held) if (code !== 'ShiftLeft') key(code, true); }
      } else release();
      if (live) live.textContent = !supported ? `Unsupported game build ${revision || '(checking)'}. Memory tools disabled.` : !s.ready ? s.reason : s.network && !prefs.online ? 'Online/LAN tools paused. Enable Allow Online/LAN tools in Session mode.' : !driveStatus ? 'Waiting for driving HUD.' : `${s.network ? 'Online/LAN opt-in' : 'Game linked'} · ${Math.round(s.rpm)} RPM${prefs.nos ? nos ? ' · NOS refilling' : ' · NOS unavailable/paused' : ''}${tune.active ? ` · Power ${tune.power.toFixed(1)}×${tune.unlimit ? ' · Governor off' : ''}` : (prefs.boost || prefs.unlimit) ? ' · Power controls waiting/unavailable' : ''}${grip.active ? ` · Grip ${grip.factor.toFixed(1)}×` : prefs.grip ? ' · Grip paused/unavailable' : ''}${prefs.drag ? activeDrag ? dragCountdown ? ' · Drag countdown throttle' : ' · Drag throttle/shifting · you steer' : dragTakenOver ? ' · Drag paused for manual control' : dragRace && !manualDriver ? ' · Drag waiting for native handback' : ' · Drag assist paused/waiting' : ''}`;
      if (ui) {
        if(live)live.title=live.textContent;
        const enabled=[prefs.cornerAssist,prefs.racePace,prefs.walls,prefs.ai,prefs.aiPace,prefs.nos,prefs.boost,prefs.unlimit,prefs.grip,prefs.drag,prefs.tester,!!(counters?.drift & 1)].filter(Boolean).length;
        ui.querySelector('#enabled').textContent=enabled ? `${enabled} selected` : 'Ready';
        ui.querySelector('#walls-state').textContent=prefs.walls?wallState.reason:'OFF · resets after reload';
        ui.querySelector('#online-state').textContent = prefs.online ? 'ON this page · experimental · F9 disables' : 'OFF · resets on every page reload';
        ui.querySelector('#ai-state').textContent = prefs.ai && s.network && !prefs.online ? 'Paused online · enable Session mode opt-in' : prefs.ai ? [dragRace ? 'Auto · drag AI' : 'Auto · native AI', aiState.status || 'Native game AI · experimental', aiState.reason].filter(Boolean).join(' · ') : 'Highest native skill · experimental · off';
        ui.querySelector('#ai-pace-state').textContent = !prefs.aiPace ? 'Off · free roam only' : dragRace ? 'Paused in drag · native pace unchanged' : !roamProfile ? `${prefs.paceFactor.toFixed(2)}× saved · waiting for free roam` : !prefs.ai || !aiState.active ? `${prefs.paceFactor.toFixed(2)}× selected · waiting for AI` : Number.isFinite(aiState.paceApplied) ? `${aiState.paceApplied.toFixed(2)}× confirmed` : `${prefs.paceFactor.toFixed(2)}× requested`;
        ui.querySelector('#race-pace-state').textContent = !prefs.racePace ? 'Off · normal race pace' : !raceProfile ? `${prefs.racePaceFactor.toFixed(2)}× saved · waiting for race / outrun` : !prefs.ai || !aiState.active ? `${prefs.racePaceFactor.toFixed(2)}× selected · waiting for AI` : Number.isFinite(aiState.paceApplied) ? `${aiState.paceApplied.toFixed(2)}× confirmed` : `${prefs.racePaceFactor.toFixed(2)}× requested`;
        ui.querySelector('#corner-state').textContent = !prefs.cornerAssist ? 'Off · free roam only' : !roamProfile ? 'Waiting for free roam' : !prefs.ai || !aiState.active ? 'Waiting for automatic AI' : Number.isFinite(aiState.cornerApplied) ? `${aiState.cornerApplied.toFixed(2)}× corner-speed cap confirmed` : 'Requested · waiting for game confirmation';
        ui.querySelector('#drag-ai-state').textContent = !prefs.ai ? 'Enable Automatic driver in AI driver' : dragRace ? aiState.active ? 'Active · native driver / physics confirmed' : safe ? 'Auto-selected · waiting for native confirmation' : 'Auto-selected · waits for GO / supported driving state' : 'Automatic · waiting for a drag race';
        ui.querySelector('#drag-state').textContent = activeDrag ? dragCountdown ? 'Countdown throttle · shifts wait for GO' : 'Throttle + shifting active · you steer' : prefs.drag ? dragAIRequested ? 'Paused while automatic drag AI is requested' : dragTakenOver ? 'Paused by manual takeover · toggle to resume' : dragRace && !manualDriver ? 'Waiting for native AI to release the car' : s.network && !prefs.online ? 'Paused online · enable Session mode opt-in' : 'Waiting for drag driving state' : 'Throttle + shifting · you steer';
        ui.querySelector('#grip-state').textContent=grip.active ? `Tyre-force multiplier ${grip.factor.toFixed(1)}× applied` : prefs.grip ? (grip.reason || 'Waiting for driving state') : 'More tyre grip · start at 1.3×';
        if (prefs.tester && supported && s.ready && now - lastScan > 250) {
          lastScan = now;
          const h = engine.hazards(s), close = h?.cars[0];
          ui.querySelector('#hazards').textContent = h ? `${h.scannedCars} car objects read. ${close ? `Nearest ahead: ${close.ahead.toFixed(0)} m, side offset ${close.side.toFixed(1)} m.` : 'No nearby car detected ahead.'} ${h.barrierAhead !== null ? `Barrier line ahead: ${h.barrierAhead.toFixed(0)} m.` : 'No crossing barrier line detected.'} Props and general obstacles: NOT detected.` : 'Detector waiting for valid car coordinates.';
        }
        const driftKnown = counters && Number.isFinite(counters.drift);
        const drift = driftKnown ? !!(counters.drift & 1) : null;
        const driftActive = driftKnown && !!(counters.drift & 2);
        if (driftPending && driftKnown && drift === driftPending.wanted && (!drift || driftActive)) {
          message(drift ? 'Drift assist ON: confirmed by the game’s handling state.' : 'Drift assist OFF: confirmed by the game.'); driftPending=null;
        } else if (driftPending && now > driftPending.until) {
          message('The game did not confirm drift assist. Use solo free roam (not a race or co-op), close menus, then try again.'); driftPending=null;
        }
        ui.querySelector('#drift').disabled = !!driftPending;
        if(driftNeedsReapply && !driftPending && safe && driveStatus===2 && driftKnown) {driftNeedsReapply=false;if(!setDrift(prefs.drift))message('Drift request could not be sent. Toggle it again in free roam.');}
        if(driftKnown && !driftPending && !driftNeedsReapply) {
          ui.querySelector('#drift').checked=drift;
          if(typeof prefs.drift==='boolean' && prefs.drift!==drift){prefs.drift=drift;savePrefs();}
        }
        for(const id of ['ai-state','ai-pace-state','race-pace-state','corner-state','grip-state','walls-state','drag-state','drag-ai-state','online-state']) {const node=ui.querySelector('#'+id);node.title=node.textContent;}
        ui.querySelector('#drift-state').textContent = driftNeedsReapply ? 'Choice saved · waiting for solo free roam' : driftPending ? 'Waiting for confirmation…' : driftActive ? 'Game confirms drift handling ON' : drift ? 'Selected, but not active in this game mode' : 'Free roam only · not perfect-drift automation';
      }
    } catch { stop('Runtime changed or is unavailable. Reload the game before retrying.'); engine = null; }
  }
  function setPanel(open) {
    visible=!!open;
    if(host)host.style.width=visible?'244px':'170px';
    if(!visible && dyno?.busy)dyno.cancel();
    if(!ui) return;
    ui.querySelector('#tools-panel').hidden=!visible;
    ui.querySelector('#min').setAttribute('aria-expanded',String(visible));
    ui.querySelector('#chevron').textContent=visible ? '▴' : '▾';
  }
  function updateDynoUI() {
    if(!ui)return;
    const busy=!!dyno?.busy,ready=!!(dynoEnabled && supported && dyno?.canUse() && !document.hidden && document.hasFocus());
    ui.querySelector('#dyno-find').disabled=!ready || busy || !!dyno?.applied;
    ui.querySelector('#dyno-cancel').disabled=!busy;
    ui.querySelector('#dyno-apply').disabled=!ready || busy || !dyno?.outcome?.improved || !!dyno?.applied;
    ui.querySelector('#dyno-restore').disabled=!ready || busy || !dyno?.applied;
    ui.querySelector('#dyno-goal').disabled=busy;
    ui.querySelector('#dyno-state').textContent=dynoText;
  }
  async function runDyno(action) {
    if(!dynoEnabled || !dyno || dyno.busy)return;
    suspend();
    dyno.setEnabled(true);
    try {
      if(action==='find') {
        dynoText='Searching · original setup is restored after each trial';updateDynoUI();
        const r=await dyno.find({goal:ui.querySelector('#dyno-goal').value,onProgress:p=>{dynoText=`Searching ${p.evaluations}/${p.budget} trials · Cancel or F9 to stop`;updateDynoUI();}});
        const power=r.goal==='peakPower',field=power?'peakPowerKw':'peakTorqueNm',unit=power?'kW':'Nm';
        dynoText=`${r.baselineResult[field].toFixed(1)} → ${r.bestResult[field].toFixed(1)} ${unit} · ${r.evaluations} trials. Original kept. ${r.improved?'Apply best to use this tune.':'No improvement found.'}`;
      } else if(action==='apply') {await dyno.apply();dynoText='Best tune applied and confirmed. Restore previous is available for this car and mode. Save using the game’s own controls.';}
      else {await dyno.restore();dynoText='Previous tune restored and confirmed.';}
    } catch(error) {dynoText=error?.message || 'Dyno tuner stopped. Reload before retrying.';}
    updateDynoUI();
  }
  function mount() {
    host = document.createElement('div'); host.id = 'nfsu2-driving-tools'; host.dataset.nfsu2Ui = '';
    host.addEventListener('keydown', e => e.stopPropagation());
    host.addEventListener('keyup', e => e.stopPropagation());
    Object.assign(host.style, { position: 'fixed', top: '8px', right: '8px', zIndex: '2147483647', width: '170px', maxWidth: 'calc(100vw - 16px)' });
    ui = host.attachShadow({ mode: 'closed' });
    ui.innerHTML = `<style>
:host{color-scheme:dark}*{box-sizing:border-box}[hidden]{display:none!important}button,input,select{font:inherit}button,summary{cursor:pointer}button,input,select,summary{-webkit-tap-highlight-color:transparent}button:focus-visible,input:focus-visible,select:focus-visible,summary:focus-visible{outline:2px solid #8cdbb5;outline-offset:2px}
.shell{font:11px/1.4 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;color:#dde9e5;filter:drop-shadow(0 5px 14px #0005)}button{color:inherit}.launcher{width:100%;height:29px;display:flex;align-items:center;gap:7px;padding:0 9px;background:#141e24;border:1px solid #50645e;border-radius:5px;color:#e3eee8;text-align:left}.mark{width:6px;height:6px;background:#9be8bc;border-radius:2px;box-shadow:0 0 8px #9be8bc35;flex:none}.title{font-size:11px;font-weight:650;white-space:nowrap}.badge{font-size:9px;color:#9bb4aa;margin-left:auto;white-space:nowrap}.arrow{color:#9bb4aa;font-size:10px;flex:none}.launcher[aria-expanded=true]{border-radius:5px 5px 0 0;border-bottom-color:#2a3b3b}
.panel{border:1px solid #50645e;border-top:0;border-radius:0 0 5px 5px;background:#141e24;max-height:calc(100vh - 48px);max-height:min(390px,calc(100dvh - 48px));overflow-y:auto;scrollbar-width:thin;scrollbar-color:#4e6860 #141e24}.toolbar{display:flex;align-items:center;gap:5px;padding:6px 8px;border-bottom:1px solid #2a3b3b;position:sticky;top:0;z-index:2;background:#141e24}.toolbar button{height:24px;flex:1;border:1px solid #3d5550;border-radius:3px;background:#20332f;font-size:10px}.toolbar button.stop{border-color:#60494c;background:#32272b;color:#e3afb3}.toolbar kbd{margin-left:4px;font-size:9px;color:#8eaaa0}.toolbar .stop kbd{color:#bc9095}.version{font-size:8px;color:#789289;line-height:1;white-space:nowrap;padding-left:2px}
.group{border:0;border-bottom:1px solid #263737}.group>summary{display:flex;align-items:center;gap:8px;list-style:none;min-height:26px;padding:5px 9px;color:#c3d5ce;font-weight:550;font-size:11px}.group>summary::-webkit-details-marker,.help>summary::-webkit-details-marker{display:none}.group>summary::after{content:'›';font-size:13px;line-height:1;color:#78978c;margin-left:auto;transform:rotate(0deg)}.group[open]>summary{background:#1d2e2d;color:#a7e8c2}.group[open]>summary::after{transform:rotate(90deg);color:#9be8bc}.section-icon{display:inline-flex;width:13px;justify-content:center;align-items:center;color:#789c8d;font-size:10px;font-weight:700}.group-body{padding:3px 9px 7px;background:#101a20}
.row{display:flex;align-items:center;justify-content:space-between;gap:8px;min-height:26px;padding:4px 0;margin:0;color:#d1dfd9}.row>span:first-child{min-width:0;flex:1}.row small,.state{display:block;max-width:100%;margin:1px 0 0;color:#849d93;font-size:9px;font-weight:400;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.row small{max-width:184px}.row-main{font-weight:550}.row input[type=checkbox]{appearance:none;width:25px;height:14px;margin:0;flex:none;border:1px solid #4d665b;border-radius:8px;background:#263a33;position:relative;cursor:pointer}.row input[type=checkbox]::before{content:'';position:absolute;left:2px;top:2px;width:8px;height:8px;background:#8ba69b;border-radius:50%}.row input[type=checkbox]:checked{background:#6cb68c;border-color:#8bcda7}.row input[type=checkbox]:checked::before{transform:translateX(11px);background:#10291f}
.slider{display:grid;grid-template-columns:1fr 40px;gap:0 6px;align-items:center;margin:0;padding:1px 0 5px;color:#9db6aa;font-size:9px}.slider>span{display:contents}.slider output{grid-column:2;grid-row:1;text-align:right;color:#bfe9cf;font:600 10px ui-monospace,SFMono-Regular,Consolas,monospace}.slider input{grid-column:1 / -1;width:100%;height:14px;margin:1px 0 0;accent-color:#91d3ad;cursor:pointer}.slider:has(input:disabled){opacity:.5}input:disabled,button:disabled,select:disabled{opacity:.4;cursor:default}
.help{margin:3px 0 1px;border-top:1px solid #263737;padding-top:2px}.help>summary{font-size:9px;list-style:none;display:flex;gap:5px;align-items:center;padding:4px 0;color:#839f92}.help>summary::before{content:'+';font:11px ui-monospace,monospace;color:#a4c3b2}.help[open]>summary::before{content:'−'}.help[open]>summary{color:#adcfba}.help p,.fine{font-size:9px;line-height:1.45;color:#90a89c;margin:4px 0}.warn{color:#c3b391}.help .row{font-size:10px}.inline-readout{padding:5px 6px;margin:4px 0;background:#1a2a2b;border-radius:3px;font-size:9px;color:#a6c3b3}.inline-readout strong{font-size:9px;font-weight:500;color:#badbc8}.inline-readout .state{white-space:normal;line-height:1.4}
select{max-width:140px;padding:4px 6px;border:1px solid #3c5549;border-radius:3px;background:#1c2e27;color:#c5dfce;font-size:10px}.dyno-buttons{display:grid;grid-template-columns:1fr 1fr;gap:5px;margin:6px 0}.dyno-buttons button{padding:5px 6px;border:1px solid #3e5b4c;border-radius:3px;background:#22372a;font-size:10px}.dyno-buttons button:nth-child(n+3){background:#192822;color:#a9c6b4}.dyno-buttons button:disabled{background:#192322}#dyno-state{white-space:normal;overflow-wrap:anywhere;max-height:62px;overflow:auto;font-size:9px;line-height:1.45;color:#a8c9b5}
.status{margin:0;padding:0 8px;background:#121b20}.status>summary{display:flex;gap:6px;align-items:center;padding:5px 0;list-style:none;min-height:24px;cursor:pointer}.status>summary::before{content:'';width:4px;height:4px;border-radius:50%;background:#759d86;flex:none}.status>summary::after{content:'ⓘ';font-size:10px;margin-left:auto;color:#708d7b}.status[open]>summary{border-bottom:1px solid #293c32}#live{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:9px;color:#8fafa0;margin:0;flex:1;min-width:0}#note{margin:5px 0;color:#c5b591;font-size:10px;line-height:1.45;overflow-wrap:anywhere}.keys{font-size:9px;color:#708d7c;margin:4px 0 7px}.keys kbd{font:inherit;color:#a1c0ab}#hazards{font-size:9px;line-height:1.4;color:#a8c7b5;background:#1a2a23;padding:6px;border-radius:3px;overflow-wrap:anywhere}
@media(prefers-reduced-motion:no-preference){.row input[type=checkbox]::before{transition:transform .12s}.group>summary{transition:background .12s}}
</style>
<div class="shell">
<button id="min" class="launcher" aria-expanded="false" aria-controls="tools-panel" title="Driving tools · F8"><span class="mark" aria-hidden="true"></span><span class="title">Driving tools</span><span id="enabled" class="badge">Ready</span><span id="chevron" class="arrow" aria-hidden="true">▾</span></button>
<div id="tools-panel" class="panel" hidden>
<div class="toolbar"><button id="take-control" title="Return to manual control">Manual <kbd>F7</kbd></button><button id="stop" class="stop" title="Stop driving assists">Stop <kbd>F9</kbd></button><span class="version">0.10</span></div>
<details id="group-driver" class="group"><summary><span class="section-icon" aria-hidden="true">A</span>AI driver</summary><div class="group-body">
<label class="row row-main"><span>Automatic driver<small id="ai-state">Auto-swaps race / free-roam / drag AI</small></span><input id="ai" type="checkbox" aria-describedby="ai-auto-risk"></label>
<details class="help"><summary>Free-roam tuning</summary>
<label class="row"><span>Corner assist<small id="corner-state">Off · experimental · free roam only</small></span><input id="corner-assist" type="checkbox" aria-describedby="corner-risk"></label>
<label class="slider"><span>Planned corner speed <output id="corner-value" for="corner-factor">0.80×</output></span><input id="corner-factor" aria-label="Planned corner speed" type="range" value="0.8" min="0.6" max="0.95" step="0.05"></label>
<label class="row"><span>Free-roam pace<small id="ai-pace-state">Off · normal pace</small></span><input id="ai-pace" type="checkbox" aria-describedby="ai-pace-help"></label>
<label class="slider"><span>Target-speed factor <output id="pace-value" for="pace-factor">1.00×</output></span><input id="pace-factor" aria-label="Free-roam pace factor" type="range" value="1" min="0.75" max="1.5" step="0.05"></label>
<p id="corner-risk" class="fine">Lower corner factor = slower planned turns. Resets the native driver when changed. Experimental, not a proven steering fix.</p><p id="ai-pace-help" class="fine warn">Higher pace can worsen corners. Neither control changes race or drag pace.</p>
</details>
<details class="help"><summary>Race / outrun tuning</summary>
<label class="row"><span>Custom race pace<small id="race-pace-state">Off · 1.00× is normal</small></span><input id="race-pace" type="checkbox"></label>
<label class="slider"><span>Race target-speed factor <output id="race-pace-value" for="race-pace-factor">1.00×</output></span><input id="race-pace-factor" aria-label="Race and outrun pace factor" type="range" value="1" min="0.75" max="1.5" step="0.05"></label><p class="fine warn">Higher pace may cause crashes. Drag keeps normal native pace.</p>
</details>
<details class="help"><summary>Driver limits &amp; takeover</summary><p id="ai-auto-risk">One switch automatically swaps native / drag AI. Drag is unverified and may stop or crash. Back up progress. Driver starts off after reload.</p><p>Start events yourself. F7 or driving keys outside this panel return control. Pauses in menus and when unfocused. No guaranteed routes, wins or career automation. Online/LAN requires its separate opt-in.</p></details>
</div></details>
<details id="group-power" class="group"><summary><span class="section-icon" aria-hidden="true">P</span>Power &amp; speed</summary><div class="group-body">
<label class="row"><span>Unlimited NOS</span><input id="nos" type="checkbox"></label>
<label class="row"><span>Engine power boost</span><input id="boost" type="checkbox"></label>
<label class="slider"><span>Power multiplier <output id="power-value" for="power">1.5×</output></span><input id="power" aria-label="Power multiplier" type="range" value="1.5" min="1" max="3" step="0.1"></label>
<label class="row"><span>Remove stock limiter</span><input id="unlimit" type="checkbox"></label>
<details class="help"><summary>Limits</summary><p>More power may worsen wheelspin and handling. Gearing, drag and redline still limit speed. NOS only refills an equipped kit; it does not force AI to activate it.</p></details>
</div></details>
<details id="group-handling" class="group"><summary><span class="section-icon" aria-hidden="true">H</span>Handling &amp; walls</summary><div class="group-body">
<label class="row"><span>Extra grip<small id="grip-state">Start at 1.3×</small></span><input id="grip" type="checkbox"></label>
<label class="slider"><span>Grip multiplier <output id="grip-value" for="grip-factor">1.3×</output></span><input id="grip-factor" aria-label="Grip multiplier" type="range" value="1.3" min="1" max="2" step="0.1"></label>
<label class="row"><span>Drift assist<small id="drift-state">Solo free roam only</small></span><input id="drift" type="checkbox"></label>
<label class="row"><span>Wall pass-through<small id="walls-state">Off · solo only</small></span><input id="walls" type="checkbox" aria-describedby="walls-risk"></label>
<details class="help"><summary>Handling &amp; wall risks</summary><p id="walls-risk">Experimental · solo only. Near-vertical static walls and barriers only. Ground, slopes, cars and movable props remain solid. May leave the map or miss checkpoints. Turn off only when clear of walls. Back up progress. F9 stops it.</p><p>High grip can cause abrupt handling or rollover and pauses in drift. Drift uses the game’s mode, not perfect-drift automation. Wall pass-through starts off after reload.</p></details>
</div></details>
<details id="group-drag" class="group"><summary><span class="section-icon" aria-hidden="true">D</span>Drag racing</summary><div class="group-body">
<div class="inline-readout"><strong>Automatic drag AI</strong><span id="drag-ai-state" class="state">Use Automatic driver above</span></div>
<label class="row"><span>Manual drag assist<small id="drag-state">Throttle + shifts · you steer</small></span><input id="drag" type="checkbox"></label>
<label class="slider"><span>Shift at RPM <output id="rpm-value" for="rpm">6500</output></span><input id="rpm" aria-label="Shift RPM" type="range" value="6500" min="3000" max="10000" step="100"></label>
<details class="help"><summary>Drag limits &amp; controls</summary><p id="drag-ai-risk">Automatic drag AI is not live-verified. Back up your progress. Starts after GO and full physics; may miss shifts, crash or stop. F7 takes control.</p><p>Manual assist stays paused while automatic AI is requested. It uses Arrow Up / Left Shift / Left Alt. You steer and avoid obstacles. Pick shift RPM for your car. F7 pauses assisted throttle until toggled again.</p></details>
</div></details>
<details id="group-dyno" class="group"><summary><span class="section-icon" aria-hidden="true">T</span>Dyno tuner</summary><div class="group-body">
<label class="row"><span>Enable dyno tuner<small>Solo · off after reload</small></span><input id="dyno-enable" type="checkbox" aria-describedby="dyno-risk"></label>
<p id="dyno-risk" class="fine warn">Back up progress first. Not live-tested.</p>
<label class="row"><span>Optimize</span><select id="dyno-goal" aria-label="Dyno tuning goal"><option value="peakPower">Peak power</option><option value="peakTorque">Peak torque</option></select></label>
<div class="dyno-buttons"><button id="dyno-find" disabled>Find tune</button><button id="dyno-cancel" disabled>Cancel</button><button id="dyno-apply" disabled>Apply best</button><button id="dyno-restore" disabled>Restore</button></div>
<p id="dyno-state" role="status">Off · original tune kept</p>
<details class="help"><summary>How it works</summary><p>Open the game’s Performance Tuning main screen and leave it there. Searches native ECU/turbo tuning with up to 120 trials; original setup stays until Apply best. Results optimize peak power or torque, not lap time.</p><p>Cancel, close menu, blur, hidden tab or F9 stops search. An applied tune stays applied. Restore is only available for the same unchanged car, mode and parts. Driving effects pause during search.</p></details>
</div></details>
<details id="group-diagnostics" class="group"><summary><span class="section-icon" aria-hidden="true">S</span>Session &amp; diagnostics</summary><div class="group-body">
<label class="row"><span>Traffic / barrier tester</span><input id="tester" type="checkbox"></label><p id="hazards" hidden></p>
<p class="fine">Read-only, incomplete obstacle detection.</p>
<details id="group-session" class="help"><summary>Online / LAN opt-in</summary><label class="row"><span>Allow network tools<small id="online-state">Off · resets on reload</small></span><input id="online" type="checkbox" aria-describedby="online-risk"></label><p id="online-risk" class="fine warn">May affect other racers, trigger integrity checks, invalidate results or lead to a ban. Follow server rules. This does not bypass server restrictions.</p><p>Allows selected NOS, power, limiter, grip, AI/pace and drag tools. Walls stay solo-only; drift stays free-roam-only.</p></details>
</div></details>
<details class="status" id="status-details"><summary id="status-summary" title="Show full status and notices"><span id="live" role="status">Waiting for game</span></summary><p id="note" role="status">Experimental. Back up progress before testing.</p><p class="keys"><kbd>F8</kbd> menu · <kbd>Esc</kbd> close<br>Drift and tester keep their own switches.</p></details>
</div></div>
`;
    note = ui.querySelector('#note'); live = ui.querySelector('#live');
    ui.querySelector('#race-pace').addEventListener('change',e=>{prefs.racePace=e.target.checked;message(prefs.racePace?'Race / outrun pace enabled independently. Higher pace can worsen corners. Drag and dyno remain at normal pace.':'Race / outrun pace returned to normal.');});
    ui.querySelector('#corner-assist').addEventListener('change',e=>{prefs.cornerAssist=e.target.checked;message(prefs.cornerAssist?'Free-roam corner assist requested. The native driver will reset before using the new planned speed. This is experimental, not a proven steering fix.':'Free-roam corner assist off. Native driver reset requested.');});
    ui.querySelector('#dyno-enable').addEventListener('change',e=>{dynoEnabled=e.target.checked;dyno?.setEnabled(dynoEnabled);dynoText=dynoEnabled?'Open the solo Performance Tuning main screen.':(dyno?.applied?'OFF · applied tune kept. Re-enable to restore previous.':'OFF · back up progress before testing');updateDynoUI();});
    ui.querySelector('#dyno-find').addEventListener('click',()=>runDyno('find'));
    ui.querySelector('#dyno-apply').addEventListener('click',()=>runDyno('apply'));
    ui.querySelector('#dyno-restore').addEventListener('click',()=>runDyno('restore'));
    ui.querySelector('#dyno-cancel').addEventListener('click',()=>{dyno?.cancel();dynoText='Cancelling · waiting for the game';updateDynoUI();});
    ui.querySelector('#online').addEventListener('change', e => {prefs.online=e.target.checked;if(!prefs.online)suspend();message(prefs.online ? 'Online/LAN tools allowed on this page. Experimental: server checks may flag changes or reject results. F9 disables this mode.' : 'Online/LAN tools paused. Other selections are kept for solo play.');});
    ui.querySelector('#ai').addEventListener('change', e => {prefs.ai=e.target.checked;release();if(!prefs.ai)ai?.stop();message(prefs.ai ? 'Automatic AI requested: native AI for other races/free roam, experimental drag AI for drag. Drag waits for GO. Start events yourself. F7 or driving keys take control; online still needs its separate opt-in.' : 'Native AI off.');});
    ui.querySelector('#take-control').addEventListener('click',takeControl);
    ui.querySelector('#ai-pace').addEventListener('change', e => { prefs.aiPace=e.target.checked; message(prefs.aiPace ? 'Custom AI pace enabled for native AI only. Higher pace may worsen cornering and cause crashes. Start at 1.00×.' : 'Custom AI pace off. Native AI will use its normal target-speed factor.'); });
    ui.querySelector('#walls').addEventListener('change', e => {prefs.walls=e.target.checked;if(!prefs.walls)wall?.stop();message(prefs.walls?'Wall pass-through requested. Solo only: turn Free roam with others off, or use a solo race. Near-vertical static walls only; keep a save backup.':'Wall pass-through off. Normal wall collisions resume.');});
    ui.querySelector('#nos').addEventListener('change', e => { prefs.nos = e.target.checked; });
    ui.querySelector('#grip').addEventListener('change', e => { prefs.grip=e.target.checked; message(prefs.grip ? 'Extra grip enabled. Start at 1.3×; it pauses during drift. Too much grip can cause abrupt handling or rollover.' : 'Extra grip off. Original wheel factors are restored.'); });
    ui.querySelector('#boost').addEventListener('change', e => { prefs.boost=e.target.checked; message('Power boost is experimental. Start at 1.5×; turn it off if wheelspin or handling gets worse.'); });
    ui.querySelector('#unlimit').addEventListener('change', e => { prefs.unlimit=e.target.checked; });
    ui.querySelector('#drag').addEventListener('change', e => { prefs.drag = e.target.checked; dragTakenOver=false; if (!prefs.drag) release(); else message('Experimental drag assist enabled. You must steer. Default keyboard bindings required.'); });
    ui.querySelector('#tester').addEventListener('change', e => { prefs.tester = e.target.checked; ui.querySelector('#hazards').hidden = !prefs.tester; ui.querySelector('#hazards').textContent = 'Waiting for a supported game and driving state…'; });
    ui.querySelector('#drift').addEventListener('change', e => { const wanted = e.target.checked; prefs.drift=wanted;savePrefs();const state=engine && statusPtr ? engine.status(statusPtr) : null;if(!state || (state.drive & 3)!==2){driftNeedsReapply=true;message('Drift choice saved. It will be requested when solo free roam is available.');}else setDrift(wanted); const status=engine && statusPtr ? engine.status(statusPtr) : null; e.target.checked=driftNeedsReapply ? !!prefs.drift : !!(status?.drift & 1); });
    ui.querySelector('#stop').addEventListener('click', () => stop());
    ui.querySelector('#min').addEventListener('click', () => setPanel(!visible));
    const groupIds=['group-driver','group-power','group-handling','group-drag','group-dyno','group-diagnostics'];
    for(const id of groupIds) ui.querySelector('#'+id).addEventListener('toggle',()=>{
      if(ui.querySelector('#'+id).open) for(const other of groupIds) if(other!==id) ui.querySelector('#'+other).open=false;
    });
    for(const id of ['nos','drag','tester','boost','unlimit','grip']) ui.querySelector('#'+id).checked=prefs[id];
    ui.querySelector('#ai-pace').checked=prefs.aiPace;
    for(const [id,name,output,min,max,step,fallback,digits,suffix] of [
      ['race-pace-factor','racePaceFactor','race-pace-value',0.75,1.5,0.05,1,2,'×'],
      ['corner-factor','cornerFactor','corner-value',0.6,0.95,0.05,0.8,2,'×'],
      ['pace-factor','paceFactor','pace-value',0.75,1.5,0.05,1,2,'×'],
      ['power','power','power-value',1,3,0.1,1.5,1,'×'],
      ['grip-factor','gripFactor','grip-value',1,2,0.1,1.3,1,'×'],
      ['rpm','rpm','rpm-value',3000,10000,100,6500,0,'']
    ]) {
      const input=ui.querySelector('#'+id),value=ui.querySelector('#'+output);
      const update=()=>{
        const raw=Number(input.value),bounded=Number.isFinite(raw)&&input.value!==''?Math.max(min,Math.min(max,raw)):fallback;
        prefs[name]=Number((min+Math.round((bounded-min)/step)*step).toFixed(digits));
        input.value=prefs[name];value.textContent=prefs[name].toFixed(digits)+suffix;
        input.setAttribute('aria-valuetext',prefs[name].toFixed(digits)+(suffix?' times':' RPM'));
      };
      input.value=prefs[name];update();
      input.addEventListener('input',()=>{update();savePrefs();});
      input.addEventListener('change',update);
    }
    if(typeof prefs.drift==='boolean') ui.querySelector('#drift').checked=prefs.drift;
    ui.querySelector('#hazards').hidden=!prefs.tester;
    ui.addEventListener('change',savePrefs);
    const parent = document.fullscreenElement || document.body; parent.append(host);
    document.addEventListener('fullscreenchange', () => { (document.fullscreenElement || document.body).append(host); });
    updateDynoUI();
    timer = setInterval(tick, 50);
  }
  if (document.body) mount(); else document.addEventListener('DOMContentLoaded', mount, { once: true });
})();

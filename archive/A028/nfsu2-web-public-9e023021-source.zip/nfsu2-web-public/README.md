# Need for Speed: Underground 2 in the browser

> [!IMPORTANT]
> This repository is archived. nfsu2.xyz keeps running and getting updates, but from 9 November 2026 development
> continues privately.
>
> With how development works now I don't have the time and energy to also run this as an open-source project and
> properly review all outside contributions. I've also seen people present this work and my updates as their own, and
> I want to build future updates and projects on this code without them being copied the same way.
>
> The code here stays available under the MIT license: you're free to use, change and share it. Please keep the
> license notices and credit this project, the projects it's based on (NFSU2Recomp in particular) and the authors of
> the included mods and translations, all listed in the README.
>
> Issues and pull requests stay readable here but won't get replies. Thanks to everyone who contributed translations,
> fixes and features. Questions, bug reports, suggestions and new translations:
> [Discord](https://discord.gg/25zXmQ2Ua9).

A fan project that runs the PC game *Need for Speed: Underground 2* (2004) in Google Chrome and Firefox. The game's
x86 code is translated to C ahead of time and compiled to WebAssembly. Direct3D 9 runs on WebGPU and the sound on
Web Audio. You bring your own copy of the game.

Based on [NFSU2Recomp](https://github.com/TalhaMudo/NFSU2Recomp) by Talha Müderrisoğlu, the original x86 → C static
recompiler for NFSU2. This project was forked from
[its MIT-licensed version of 16 October 2026](https://github.com/TalhaMudo/NFSU2Recomp/tree/3d187ce7e5f1b99c0580866da4dbaa6d59dd23c7)
and uses only code from that version.

> Not affiliated with or endorsed by Electronic Arts. This repository contains none of the game's code or data.

![The start page: Play, the controls, your saves and Online](docs/web/start-page.png)

## What you need

- **The game:** your own PC copy, patched to v1.2 (North America), with this exact `SPEED2.EXE` (other versions
  will not work): 4,800,512 bytes, SHA-256 `f9dd86c054878ce6276beb07c1fd61874f7a1e4bf1f241b084c65b73e24168a7`.
- **To build:** an Apple Silicon Mac (the tested setup) or Linux, Python 3, Node.js 20 or newer, Rust
  ([rustup](https://rustup.rs)), and [wasi-sdk](https://github.com/WebAssembly/wasi-sdk/releases) 34 for that system
  unpacked into `deps/`. On Windows,
  build in WSL 2 with the clone in the Linux file system (`~/nfsu2-web`): under `/mnt/c` it builds much slower.
- **To play:** the latest Google Chrome, or Firefox where it has WebGPU (Windows, macOS).

## Build

```sh
python3 -m venv .venv && .venv/bin/pip install -r requirements.txt
web/gen.sh "/path/to/Need for Speed Underground 2/SPEED2.EXE"   # translate the game's code to C (into gen/)
web/build.sh                                                    # compile it to out/web/nfsu2.wasm
```

The generated C and the compiled module are made from the game, so they are never committed (`.gitignore`).

## Play

```sh
web/start.sh --data "/path/to/Need for Speed Underground 2"
```

Open **http://localhost:8080/** in Chrome or Firefox and press **Play**. The start page has the settings, your saves
and the controls. The player's guide is [docs/web/PLAYING.md](docs/web/PLAYING.md). The game plays in any of its
thirteen languages, in Brazilian Portuguese, in Polish, in Turkish, in Hungarian, in Ukrainian, in Czech, in Slovak or in Greek; the
dubbed voices and movies and the Portuguese, Polish, Hungarian, Ukrainian, Czech and Slovak text come from mods (Czech's
with this repository's own texts for what it left in German or empty, `tools/lang/czech.json`), the Turkish text is this repository's own translation
(`tools/lang/turkish.json`, with a mod's fonts), the Greek text a contributor's (`tools/lang/greek.json`, with Greek
letters drawn into the game's fonts by `tools/greekfont`), as language packs. The menus and HUD can be redrawn at four times
their size, from a mod as a texture pack.

To play with friends, run the server behind HTTPS (other PCs need a secure context): `web/deploy/` has a Docker setup.
Everyone who plays from the same server can meet in free roam.

## How it works

- **`tools/`:** a Python lifter (Capstone) turns every function of `SPEED2.EXE` into C.
- **`runtime/`:** Windows, Direct3D 9, DirectSound and DirectInput, reimplemented. `runtime/web/` holds the browser
  parts.
- **`web/src/`:** the page. It runs the game's threads as workers on one shared memory, draws with WebGPU and plays
  sound through an AudioWorklet.
- **`web/server-rs/`:** the server, in Rust: serves the page, the module and your game folder, and connects players
  for multiplayer.

The same tree still builds the native macOS version
(`./gen.sh`, `./build.sh && ./link.sh`, `./run.sh`).

## Credits

Based on Talha Müderrisoğlu's [NFSU2Recomp](https://github.com/TalhaMudo/NFSU2Recomp) (its MIT version, see the
top), the static recompilation of NFSU2 for Apple Silicon, which in turn follows the method of
[N64: Recompiled](https://github.com/N64Recomp/N64Recomp) and [XenonRecomp](https://github.com/hedge-dev/XenonRecomp).
The language packs are built from KyoriAsh's [Multi 13 languages mod](https://nfsmods.xyz/mod/5749) (with Lee-Ryo's
Thai support, whose patch `runtime/language.c` follows), from TraduMix's and MixMods' Brazilian Portuguese
translation (Fyro, Beater, Kerlyston F.; Junior_Djjr, SideWinder, Elyzandro), from PLProjekt's Polish translation
(Daniel Graszka, MaDeR, Marcin Piech, Nati, Mateusz Wilkowski, alter), from VileStuff's
[English Subtitles Fixed](https://nfsmods.xyz/mod/5286), from muntazam's
[Turkish translation](https://www.moddb.com/mods/need-for-speed-underground-2-turkish-translation-patch) (its fonts), from
GameHunter's [Hungarian translation](http://www.gamehunter.hu/2010/08/need-for-speed-underground-2-pc.html)
(L_zooltan), from Clark X.'s [Ukrainian translation](https://kuli.com.ua/need-for-speed-underground-2), from ROXOR's and
PINĎA & syn's Czech translation and from MixerX's Slovak one ([abcgames.cz](https://www.abcgames.cz/?p=preklady_zobraz&id=7774)). The texture packs are built from LunicAura106's
[Upscaled HUD](https://nfsmods.xyz/mod/4319) and JeansBig's [Detailed Map](https://nfsmods.xyz/mod/4485), the
uncensored songs from xGMVx's [Uncensored & Restored Soundtrack](https://nfsmods.xyz/mod/3649). Split screen is
BirdSentinel (Zack)'s port of mihaits'
[NFSU2-SplitScreen](https://github.com/mihaits/NFSU2-SplitScreen). Other changes follow what these mods found out
about the game: ThirteenAG's, Aero_'s and xan1242's [Widescreen Fixes Pack](https://nfsmods.xyz/mod/3327), dstudnicki's
[NFSU2 High FPS Audio Fix](https://github.com/dstudnicki/NFSU2HighFPSAudioFix), the ExOpts Team's
[NFSU2 Extra Options](https://nfsmods.xyz/mod/290), MaxHwoy's [Show Hidden Races Mod](https://nfsmods.xyz/mod/1583),
thelink2012's [Visual Reputation Remover](https://nfsmods.xyz/mod/2773) and Archie (AR4I)'s
[Stance Mod](https://nfsmods.xyz/mod/1687). The start page's Mods tab lists them all.
Built with the help of Claude Code.

## License

MIT ([LICENSE](LICENSE)). *Need for Speed* and *Need for Speed: Underground 2* are trademarks of Electronic Arts Inc.

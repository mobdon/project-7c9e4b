/* Session-only reductions of the owned adaptive driver's pace request.
 * Distances are observations from the existing wall/car reader. They are not
 * a road centerline, a physical speed limit, or proof of complete coverage. */
(function(root){
  'use strict';
  const finite=(n,lo,hi)=>typeof n==='number'&&Number.isFinite(n)&&n>=lo&&n<=hi;
  function clearanceEnvelope({hazards,speedMps,brakingMps2=4,reactionSeconds=.6,marginM=8}={}){
    if(!finite(speedMps,0,500)||!finite(brakingMps2,.5,12)||!finite(reactionSeconds,0,2)||!finite(marginM,0,30))return {available:false};
    if(!hazards||!Array.isArray(hazards.cars)||hazards.cars.length>96)return {available:false};
    let distance=null,source=null;
    const accept=(d,s)=>{if(finite(d,0,150)&&(distance===null||d<distance)){distance=d;source=s;}};
    if(hazards.barrierAhead!==null&&hazards.barrierAhead!==undefined)accept(hazards.barrierAhead,'barrier');
    for(const car of hazards.cars)if(car&&finite(car.side,-2.5,2.5))accept(car.ahead,'vehicle');
    // No intersection gives no permission to accelerate: the reader's scan
    // is partial and can miss road curvature, height, shapes and moving cars.
    if(distance===null)return {available:true,observed:false};
    const availableM=Math.max(0,distance-marginM-speedMps*reactionSeconds);
    return {available:true,observed:true,source,distanceM:distance,targetMps:Math.sqrt(2*brakingMps2*availableM)};
  }
  // Wall guard: how fast can the car be going and still either steer away
  // from, or stop before, the barrier its heading currently points at?
  // A wall met at a shallow angle only needs a small steering correction, so
  // it allows high speed; a wall met head-on needs a real turn or braking.
  // Distances and speeds are the game's native units (metres, m/s).
  const WALL=Object.freeze({lateralMps2:14,brakingMps2:10,reactionSeconds:.35,endMarginM:6,minPace:.75,recoverPerSecond:.5});
  function wallEnvelope({hazards,speedMps,lateralMps2=WALL.lateralMps2,brakingMps2=WALL.brakingMps2,reactionSeconds=WALL.reactionSeconds,endMarginM=WALL.endMarginM}={}){
    if(!finite(speedMps,0,500)||!finite(lateralMps2,2,40)||!finite(brakingMps2,1,20)||!finite(reactionSeconds,0,2))return {available:false};
    if(!hazards||hazards.barrierAhead===null||hazards.barrierAhead===undefined||!finite(hazards.barrierAhead,0,150))return {available:true,observed:false};
    const distance=hazards.barrierAhead,sin=finite(hazards.barrierSin,0,1)?hazards.barrierSin:1;
    const travel=Math.max(0,distance-speedMps*reactionSeconds);
    // Brake option: stop short of the wall.
    const brake=Math.sqrt(2*brakingMps2*Math.max(0,travel-endMarginM));
    // Turn option: turning radius r swings the heading parallel to the wall
    // after r(1-cos a) of sideways room; the room is (travel-margin)*sin a.
    // The side rays already include the car's half-width.
    const cos=Math.sqrt(Math.max(0,1-sin*sin)),room=Math.max(0,travel-endMarginM)*sin,bend=1-cos;
    const turn=bend<1e-6?Infinity:room<=0?0:Math.sqrt(lateralMps2*room/bend);
    const targetMps=Math.max(brake,turn);
    return {available:true,observed:true,source:'barrier',distanceM:distance,incidenceSin:sin,targetMps};
  }
  // Reduces only the live pace multiplier, never the planning pace, so the
  // native route/corner records are not rebuilt. Reduce at once, recover
  // gradually so a boosted straight still returns to the selected pace.
  class WallGuard {
    constructor(){this.reset();}
    reset(){this.key=null;this.at=null;this.factor=1;}
    update({enabled=false,identity,now,speedMps,hazards,pace=1,brakingFactor=.75,cornerFactor=.8}={}){
      if(enabled!==true||typeof identity!=='string'||!identity||!finite(pace,.75,3)){this.reset();return {active:false,state:'off',pace:null};}
      if(this.key!==identity){this.key=identity;this.at=null;this.factor=1;}
      const dt=finite(now,0,Number.MAX_SAFE_INTEGER)&&this.at!==null&&now>=this.at?Math.min(500,now-this.at)/1000:0;
      if(finite(now,0,Number.MAX_SAFE_INTEGER))this.at=now;
      const b=finite(brakingFactor,.5,1)?brakingFactor/.75:1,c=finite(cornerFactor,.6,.95)?cornerFactor/.8:1;
      const wall=wallEnvelope({hazards,speedMps,brakingMps2:WALL.brakingMps2*b,lateralMps2:WALL.lateralMps2*c});
      let target=1,state='clear';
      if(wall.observed&&finite(speedMps,3,500)&&wall.targetMps<speedMps){
        target=Math.max(WALL.minPace/pace,this.factor*wall.targetMps/speedMps);state='wall-limited';
      }
      this.factor=Math.min(1,target<this.factor?target:this.factor+WALL.recoverPerSecond*dt/pace);
      // 0.05 steps: fewer native pace rewrites while easing back to full pace.
      const live=this.factor>=.999?pace:Math.max(WALL.minPace,Math.min(pace,Math.floor(pace*this.factor*20+1e-9)/20));
      return {active:true,state:live<pace?state==='clear'?'recovering':state:'clear',pace:live,selectedPace:pace,wall};
    }
  }
  class Pacing {
    constructor(){this.reset();}
    reset(){this.key=null;this.at=null;this.timingReady=false;this.pace=1;this.wall?.reset();}
    update({enabled=false,ceiling=1.3,identity,now,evidence={},speedMps,hazards,brakingMps2=4,nativeFallback=false}={}){
      if(enabled!==true){this.reset();return {active:false,state:'off',pace:null};}
      if(!finite(ceiling,1,2)||typeof identity!=='string'||!identity||identity.length>256){this.reset();return {active:false,state:'invalid',pace:1};}
      const sameOwner=this.key===identity,validTime=finite(now,0,Number.MAX_SAFE_INTEGER);
      const continuous=sameOwner&&this.timingReady&&validTime&&this.at!==null&&now>=this.at&&now-this.at<=500;
      if(!sameOwner){this.pace=1;this.key=identity;this.at=null;this.timingReady=false;}
      // A timing interruption discards boost, never a same-owner slowdown.
      // Otherwise a missing scan after 501 ms can jump 0.75x straight to 1x.
      else if(!continuous)this.pace=Math.min(this.pace,1);
      const dt=continuous?Math.min(500,now-this.at)/1000:0;
      const currentRoute=evidence.active===true&&evidence.owned===true&&evidence.cornerMode===3&&evidence.cornerGuardMask===0&&evidence.cornerRouteOwned===true&&finite(evidence.cornerRouteNodes,2,40);
      // Old hit counters cannot stand in for current route records. On 4715
      // those counters remain zero while a 2x request otherwise stays active.
      const currentCorners=currentRoute&&finite(evidence.cornerPlannerCorners,1,5)&&Number.isInteger(evidence.cornerPlannerUsable)&&evidence.cornerPlannerUsable>0&&evidence.cornerPlannerUsable<=evidence.cornerPlannerCorners&&finite(evidence.cornerApplied,0,1)&&evidence.cornerHits>0&&evidence.brakingHits>0;
      // Road-race fallback keeps the user's selected native pace. Missing
      // optional corner records are not a slower speed limit. The existing
      // native driver still handles its route, braking and corner compensation;
      // partial heading-ray observations remain diagnostics, not an additional
      // uncalibrated physical speed controller. City slowing uses its own policy.
      // Wall pathing fix: v0.38.1 dropped every clearance reduction here, so a
      // boosted car kept full pace straight into barriers. Keep the selected
      // pace, but back off when the barrier the car is pointing at cannot be
      // steered around or braked for at the current speed.
      if(nativeFallback===true){
        if(!this.wall)this.wall=new WallGuard();
        const guard=this.wall.update({enabled:true,identity,now,speedMps,hazards,pace:ceiling,brakingFactor:brakingMps2/4});
        const live=guard.active?guard.pace:ceiling;
        this.key=identity;this.at=null;this.timingReady=false;this.pace=live;
        return {active:true,state:live<ceiling?'clearance-limited':currentCorners?'native-route':'native-fallback',pace:live,ceiling,currentCorners,clearance:clearanceEnvelope({hazards,speedMps,brakingMps2}),wall:guard.wall};
      }
      let target=currentCorners?ceiling:1,state=currentCorners?'native-route':'coverage-unknown';
      const clearance=clearanceEnvelope({hazards,speedMps,brakingMps2});
      if(clearance.observed&&speedMps>1&&clearance.targetMps<speedMps){
        const reduction=Math.min(target,Math.max(.75,Math.min(this.pace,target)*clearance.targetMps/speedMps));
        if(reduction<target){target=reduction;state='clearance-limited';}
      }
      // Reduce immediately; regain only 0.10x per second. A delayed timer or
      // replacement owner cannot jump straight back to the selected ceiling.
      this.pace=Math.max(.75,Math.min(target,this.pace+.1*dt));
      // Invalid/backwards samples earn no recovery time. Keep the high-water
      // timestamp so clock rollback cannot credit the same interval twice;
      // the first fresh sample after an interruption only reestablishes time.
      if(validTime&&(this.at===null||now>=this.at)){this.at=now;this.timingReady=true;}
      else this.timingReady=false;
      return {active:true,state,pace:Math.round(this.pace*100)/100,ceiling,currentCorners,clearance};
    }
  }
  const api=Object.freeze({Pacing,clearanceEnvelope,wallEnvelope,WallGuard,WALL});
  root.__NFSU2_DYNAMIC_PACING__=api;
  if(typeof module==='object'&&module.exports)module.exports=api;
})(globalThis);

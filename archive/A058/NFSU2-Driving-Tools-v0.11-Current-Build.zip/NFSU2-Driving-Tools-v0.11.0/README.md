# NFSU2 Driving Tools: experimental v0.11.0

Unpacked Chrome / Edge / Brave extension for https://nfsu2.xyz/.

## v0.11.0: verified support for the current build

This release recognizes the exact game module for revision **2f0ddd3b**, not just its version label. The compact menu uses a constructed stylesheet that works with the site's strict style policy.

### Available on 2f0ddd3b

- Unlimited equipped NOS, power boost, stock limiter control and grip.
- Native AI driver in non-drag races and free roam, including manual takeover, highest normal skill and heartbeat handback.
- Manual drag throttle/shifting while you steer, with Automatic driver turned off.
- Solo free-roam drift input, read-only tester and normal session controls.

**Custom AI pace, corner-speed assist, wall pass-through, dyno tuning and automatic drag AI remain disabled on this build.** The menu marks these as not yet verified. Their descriptions below apply to the supported older **6f4f1e4e** module. Saved choices for unavailable tools do not activate them.

For a first test, back up your save and start solo. Test NOS first, then native AI with power, grip and drag assist off. Keep F7 ready. This is an evidence-backed compatibility update, not a claim of successful live driving: actual game functions, binary preservation and synthetic lifecycle tests were checked, but live gameplay has not been verified.

Both metadata revision and the downloaded module's exact size/SHA-256 must match a reviewed profile before memory tools can run. A future unknown build still fails closed. Current AI also refuses to initialize over an already occupied command-memory region.

## Automatic AI race-type switching

Turn on **AI driver → Automatic driver** once per page. It automatically selects:

- **Non-drag races and free roam:** the existing native player autopilot.
- **Drag:** experimental native racer AI with the verified drag physics type. It waits until GO and full driving physics are available.
- **Changing mode:** requests native AI OFF, waits for the game thread to acknowledge it, confirms ownership is released, the human driver is restored and any failed-acquisition latch is cleared, then requests the new mode. Player, car, race, drag/non-drag and race/free-roam changes are checked, including when object pointers are reused.

There is no separate drag-AI checkbox. The main switch explicitly enables automatic selection, including experimental drag. **You still start events yourself. This does not select races, restart them, navigate career menus, buy upgrades or choose a GPS destination.** It includes the separate experimental free-roam corner-speed and dyno-search tools described below. They are off by default.

**Live drag driving remains unverified.** Correct driver/physics status does not prove that it shifts, steers, avoids traffic or finishes. It may crash, stop or miss checkpoints. Back up your progress and test solo first. No guaranteed routes, perfect drift, wins or completed races.

### Quick start

1. Back up your save with the game's **Download backup** button.
2. Keep your previous extension folder for rollback. Disable its extension card before loading this version.
3. Extract this ZIP. In `chrome://extensions` (Edge: `edge://extensions`), enable Developer mode and choose **Load unpacked**. Select **NFSU2-Driving-Tools-v0.11.0**, containing `manifest.json`.
4. Reload the game and check version **0.11.0**. Only one version should be enabled.
5. Start a solo event yourself. Open Driving tools with **F8**, then enable **Automatic driver** in a non-drag event. Automatic drag AI is unavailable on 2f0ddd3b. On the older supported build, for your first drag test, leave power, grip, NOS, custom pace and manual Drag assist off.
6. Enter other supported events normally. On the older build, AI swaps automatically; on 2f0ddd3b it hands back for drag. Turn AI off before using manual drag assist. Other selected settings are kept.

Chrome 111+ or a compatible current Chromium browser is required. This is not a Firefox or mobile-browser build. No build tools or Node installation are needed to install the extension.

### Take control and pause

- **F7 / Take control:** disables automatic AI until you explicitly turn it on again. Arrow/WASD keys and Space also take control outside the extension menu. This remains off across later race-type changes.
- Controller axes do not trigger takeover; use F7 or the Take control button.
- Taking control also pauses synthetic manual-drag throttle until you toggle manual Drag assist again.
- **F9 / Stop:** clears automatic AI, wall pass-through, Online/LAN permission, custom pace, NOS, power, limiter, grip and manual drag. Slider values are retained. Drift and the read-only tester keep their own switches.
- Menus, loading, unfocused/hidden tabs and unsupported states pause tools without clearing choices. They resume when a supported driving state returns, unless you took manual control.
- **Automatic AI, wall pass-through, corner assist, race-pace opt-in, dyno tuner and Online/LAN permission start OFF after every page reload.** Other settings use same-tab session storage. Closing the tab normally ends those saved choices. Storage may be unavailable or affected by browser restore behavior.
- If the page stops updating, native AI hands back within 180 game frames. A frozen game cannot process a handback. Disable the extension and reload if it freezes.

## Compact menu

The menu starts as a **170 × 29 px** collapsed toolbar and opens to a **244 px** drawer with a 390 px maximum scroll panel. **F8** opens/closes it. Sections start folded, only one main section opens at a time, and longer sections scroll. Help and detailed status are tucked away; no control was removed. **F7 / Take control** and **F9 / Stop** remain keyboard shortcuts, with buttons in the open toolbar.

## Independent controls

### AI and pace

The native AI switch uses player-only skill **9**, the highest normal native value. It restores the original value when the same racer still exists. Special sentinels are left unchanged and are not claimed as level 9. It does not alter other racers or commandeer an AI driver the extension did not acquire.

**Free-roam pace:** preserves the previous custom-pace switch and value, now explicitly for native free roam only. Default is off / 1.00×. Its enabled choice and value are saved in the same tab.

**Race / outrun pace:** a separate 0.75×–1.50× opt-in, default off / 1.00×. Its value is saved, but its switch starts off after reload. Your faster free-roam choice does not carry into races.

Both adjust the native target-speed factor, not engine power, steering or road paths. Higher pace may worsen corners. Drag, dyno and unknown categories use neutral 1.00×. The choices remain selected while ineligible and resume only in their own category. F7 leaves them dormant; F9 clears both switches. They never turn AI on by themselves.

### Free-roam corner-speed assist

A separate, experimental opt-in reduces the native planner's curvature-limited speed for upcoming free-roam corners. It does not replace steering or road paths. Its bounded factor is **0.60–0.95**, starting at **0.80**. Straight/gentle segments retain their native speed cap. This factor is a tuning hypothesis, not a measured optimum.

It applies only to the current, owned AI driver's private main route in native free roam. Races, outruns, drag, drift and the Dyno Shop are excluded. Changing its enabled state or factor rebuilds AI through a full native OFF/manual/ON handoff, because the game caches route speed caps. Free-roam/race transitions also rebuild before rearming.

It may help turn entry but cannot repair a bad route, prevent crashes, guarantee a clean corner or improve lap times. More power, grip or pace may undermine it. Live braking, route rebuilding and handling improvements remain unverified. Start conservatively and keep F7 available.

### Dyno auto tuner

An independent search tool for the **solo Performance Tuning main screen**, with installed ECU/turbo tuning capability. Start with a backed-up save. The tuner is off on reload and never purchases upgrades, enters events or forces a profile save.

1. Enable the tuner and choose **peak power (kW)** or **peak torque (Nm)**.
2. **Find tune** tests up to 120 bounded coordinate-search trials. Each trial restores your original live setup before returning. The resulting best candidate is not automatically applied.
3. **Apply best** is a separate action and must reproduce the exact measured setup on the same car, mode and installed parts. Use the game's own dyno to check it.
4. **Restore** requires the same live car, mode, parts and exact last-applied tune. It restores the prior baseline. Normal game controls govern saving.

This maximizes one measured native peak value, not acceleration, usable power band, gearing, cornering, drift or lap time. It is not a global optimum. A larger peak can worsen real driving. Live setup repeatability, Apply/Restore and save/reload behavior remain unverified.

Cancel, F9, closing the panel, blur, a hidden tab, leaving the page or disabling the tuner cancels ongoing work. Driving effects are paused during search/apply/restore, with their selections retained. **F9 does not undo a tune already applied.** Re-enable the tuner and use Restore previous while its guarded baseline remains valid.

Trials are game-thread transactions and restore the copied ride before acknowledgment. Invalid identities, parts, setup or network state fail closed. If acknowledgment times out, further writes stop and the result is explicitly uncertain; reload before retrying. A native trap can interrupt cleanup, so crash-safe save recovery is not promised.

### Power and handling

- **Unlimited NOS:** refills an already equipped kit while driving; does not install a kit or force native AI to activate NOS.
- **Power boost:** 1.0×–3.0× engine and nitrous torque. Starts at 1.5×. Repeated updates do not compound. More power can worsen wheelspin and handling.
- **Remove stock limiter:** removes the stock MPH governor while enabled. Gearing, drag and redline still limit speed. Upgraded cars may already lack that governor.
- **Extra grip:** 1.0×–2.0× all four tyre-force factors. Starts at 1.3×. It is not auto-steering, yaw damping, corner avoidance or guaranteed handling. High grip can cause abrupt behavior or rollover. It pauses in drift mode/races.
- Power and grip restore only fields still owned by the extension. They wait for three matching samples before applying to rebuilt car data. Changed external tuning is preserved rather than overwritten. Pause/off restores owned values when the original live objects remain valid.
- **Drift assist:** uses the game's real drift-event input and waits for its handling confirmation. Solo free roam only, with game menus closed. It is not perfect-drift automation. Power/grip restore before the native tuning rebuild; settings stay selected. Drift uses its own switch, including after F9.

### Wall / barrier pass-through

**Handling & walls → Wall pass-through** is independent of AI and **solo-only**, even with Online/LAN tools allowed. Turn **Free roam with others** off, or use a solo race.

Only contacts between your car and verified near-vertical static track polygons are skipped, using the native wall threshold `abs(normal.z) < 0.1`. Ground, ceilings, ramps/slopes, cars and movable props retain the original collision path. Sloped faces and movable barrier props remain solid. This is not unrestricted flight or universal noclip. The game's native Ghost setting affects cars, not walls; the extension leaves that setting unchanged.

A selected checkbox is not proof of contact filtering. Its status first says Armed, then counts contacts actually skipped by the native hook. Test a plain vertical wall and neon barrier at low speed; verify ground/ramp and car collisions yourself. Coverage has not been live-verified.

You may leave the drivable map, miss checkpoints or get stuck inside scenery. Native recovery may reposition you after a reset. **Turn it off only when clear of a wall.** Off/F9/reload restores the original collision path. It does not change shared map objects or body collision flags.

### Manual drag assist

A separate, optional throttle / RPM-threshold shift / NOS helper **while you steer**. Uses default Arrow Up, Left Shift and Left Alt bindings. Set shift RPM for your car; 6500 is only a starting point, not learned perfect shifting.

Manual drag assist never runs while automatic drag AI is requested, including countdown and failed/unavailable AI. It will not silently substitute synthetic inputs. With Automatic AI off, manual drag waits for native ownership to clear and a human driver to be confirmed. Countdown permits throttle only; shifts and NOS wait for GO. It does not choose lanes or avoid obstacles. F7/manual takeover pauses it until its switch is toggled again.

### Diagnostics

The read-only traffic/barrier tester reads nearby car objects and the enabled barrier-line table. It is incomplete: it does not fully classify traffic/racers, shapes, props, road geometry, elevation or safe lanes. No detected obstacle does not imply a safe road.

## Online / LAN

Online/LAN remains blocked by default for existing tools. The separate **Session mode → Allow Online/LAN tools** switch is per-page and starts off on reload. It does not activate individual tools. It never overrides wall pass-through's solo restriction, drag physics requirements, pause checks or one-local-player checks.

Online modifications may affect racers, trigger integrity checks, invalidate results or cause moderation/bans. Follow the site's rules and prefer solo play or an explicitly permitted private test. This extension does not bypass server restrictions. Turning off the session switch stops AI/synthetic keys and restores owned tuning when possible, while keeping selections for solo. NOS already refilled is not drained. F9 clears the permission.

## Validation and known limits

**180 automated tests pass, zero skipped**, including 73 core/UI tests and eight current-profile tests. They cover exact binary identity, function/section preservation, native handoff and heartbeat behavior, occupied-mailbox refusal, unavailable capabilities, memory-reuse rejection, restoration on replacement stale-worker events and crashes in secondary game threads. Other tests retain coverage for the older combined feature set. These are not a full game simulation or live gameplay.

Both exact supported modules validate and compile after patching. On 2f0ddd3b, only function 21213 changes; every other function body and every other section is preserved byte-for-byte. On 6f4f1e4e, only functions 4653, 21213, 21262 and 22720 change. The new authored AI-prefix builder reproduces its output byte-for-byte.

No successful live drag race, wall/barrier test, cornering improvement, real-car dyno improvement or online race is claimed. The menu fix has passed simulated DOM checks. A strict-CSP Chromium regression test is written to check computed styles, controls, layout, shortcuts and continued blocking of inline styles, but it could not run in this environment: Chromium startup is blocked by local socket permissions, including after an approved retry. No real-browser visual or live-gameplay verification is claimed for v0.11.0.

Exact supported profiles:

- **2f0ddd3b:** 36,872,934 bytes, SHA-256 `5e33ad2cb4c4cc6893dee7cbd4d6e9bfb0f59a349d218fddbb5e3331ca69bc34`. Scoped feature support listed above. The native gcall function was mapped from old index 21725 to current index 21739 and verified to preserve the same CPU ABI; actual dispatch tables and native AI bodies were checked independently.
- **6f4f1e4e:** 37,839,055 bytes, SHA-256 `ee5d281a3109240d5db25dc3921e1044672cf6d650eb58c3baa089b54fe2941f`. Retains the older combined experimental feature set.

An independent probe executes actual current-build input/status initialization, status writing and the NOS reader in isolated memory: 22 assertions pass. This verifies the mailbox formats and NOS interpretation, not a real gameplay session. A separate native gcall binary comparison verifies that its only body change is the dispatcher call relocation.

## Privacy, implementation and rollback

The extension matches only `https://nfsu2.xyz/*`. No account, history, debugger or broad website permissions. It stores only its own preferences in a namespaced session-storage entry. Its only added request is a same-origin `/game.json` compatibility read; it inspects the game's own module response during loading. No analytics, remote code or game assets are bundled.

- AI calls native `Player::AutoPilotOn`, `AutoPilotOff` and `SetInputMode(2)` through the game's existing CPU-preserving game-thread dispatcher. It never invokes native game functions concurrently from the page thread.
- Normal drag opponents use driver type 3 / physics type 1, while player autopilot initially asks for physics type 3. The retained drag handoff corrects only the eligible local car, verifies both types and rolls back on failure.
- The page's automatic AI switch supplies the exact drag-permission word only when drag is detected. The native permission and full-physics checks are still required. The pace hook never modifies drag.
- Mode switching publishes OFF and verifies the native heartbeat acknowledgement, cleared ownership and restored manual driver before rearming. Identity and race/free-roam mode are part of that comparison. Native Off/On rebuilds the private driver route.
- Command memory stays at `0x00d0d100` (92 bytes) and walls at `0x00d0d180` (40 bytes), under sequence locks. The corner record is at `0x00d0d200` (36 bytes), and dyno uses `0x00d0d300..0x00d0d4ff`. These do not overlap. The combined patch targets the main-loop bridge, player pace, wall-contact resolver and corner-speed helper.
- Wall filtering prefixes `sub_005b2610` and preserves the full original resolver for every rejected contact. Body type/vtable, reciprocal car/face pointers, finite unit normals and pair identities are checked. Native `roam_game_online_here()` always blocks wall filtering during multiplayer free roam.

For rollback, disable v0.11.0, enable your preserved previous version and reload. The previous version remains subject to its own build-compatibility checks. Memory effects do not survive reload; saved ordinary preferences may. Never run both versions together.

### Source references

- Public pinned source: https://github.com/th0mk/nfsu2-web/tree/6f4f1e4e92f5f3ddf6f6d165b7f7075a95ab7fe3
- `runtime/career.c`, `runtime/guest.h`: native handoff, return-to-input and game-thread calls.
- `runtime/catchup.c`: native skill, player target-speed calculation.
- `runtime/game.h`, `runtime/web/status_web.c`: driving/countdown/paused states and drag type.
- `runtime/roam.c`, `runtime/roam_game.c`: collision wrapper, native Ghost scope and multiplayer state.
- `runtime/walls.c`: native barrier lines.
- `runtime/mprace.c`, `runtime/drift.c`: per-car torque, limiter, drift and tyre data.
- Reconstructed collision classifications, independently checked against the exact executable: https://github.com/troikoss/speed-re/tree/892e5c31d77c751acd123330eda15c157c4f1b1f/src/Speed/Indep/Src/Physics/Collision

No upstream files were modified. This is unofficial and not affiliated with the site or Electronic Arts. No game executable, assets or reconstructed third-party code are in the ZIP.

/* Local, schema-only diagnostics. No console interception, requests or uploads. */
(function (root) {
  'use strict';
  const KEY = 'nfsu2-driving-tools-diagnostics-v1';
  const MAX_EVENTS = 180, MAX_BYTES = 65536, MAX_ERROR_INPUT = 16384;
  const EVENTS = new Set(['page-start','game-boot','game-register','game-trap','game-exit','worker-error','page-error','promise-rejection','engine-error','identity-change','state','tools','pause','resume','page-hide','manual','stop','export','clear','build','build-error','patch-state','dyno-action','dyno-error']);
  const FLAGS = ['ready','driving','network','safe','hidden','focused','aiActive','aiOwned','handbackPending','dynoBusy','dynoEnabled','wallRequested','carRequested','onlineTrafficRequested','onlinePlayersRequested','cornerRequested','cornerMemoryBlocked','cornerDriftBlocked','powerActive','gripActive','limiterRemoved','carChanged','raceChanged','playerChanged','sessionCurrent','supported','signatureExact','signatureFailed'];
  const NUMBERS = {signatureTotal:[0,128],signatureUnique:[0,128],signatureMissing:[0,128],signatureAmbiguous:[0,128],moduleBytes:[0,4294967295],slot:[0,1024],tid:[0,1e6],code:[-2147483648,2147483647],kind:[0,100],generation:[0,1e6],memoryMiB:[0,65536],hud:[0,3],flow:[0,100],raceType:[0,100],racePhase:[0,100],driverKind:[0,100],physicsKind:[0,100],wallHits:[0,1e9],carHits:[0,1e9],trafficHits:[0,1e9],playerHits:[0,1e9],cornerHits:[0,4294967295],cornerApplied:[0,1],effectivePower:[1,3],effectiveGrip:[1,2],requestedPace:[0.5,3],gameTicks:[0,4294967295],pageHeartbeat:[0,4294967295],nativeHeartbeatAck:[0,4294967295]};
  const TOOL_FLAGS = ['ai','aiPace','cornerAssist','racePace','walls','cars','traffic','players','online','nos','drag','tester','boost','unlimit','grip','drift','dynoEnabled'];
  const TOOL_NUMBERS = {paceFactor:[0.75,3],racePaceFactor:[0.75,3],cornerFactor:[0.6,0.95],cornerMargin:[0,25],power:[1,3],gripFactor:[1,2],rpm:[3000,10000]};
  const ERROR_KINDS = new Set(['memory-bounds','unreachable','indirect-call','integer-divide','invalid-conversion','stack-overflow','out-of-memory','type-error','reference-error','syntax-error','other']);
  const PHASES = new Set(['idle','preparing','ready','unavailable','waiting','active','failed','unsupported']);
  const PATCH_CODES = new Set(['module-size','module-hash','module-read','module-layout','module-compile']);
  const REASONS = new Set(['blur','hidden','page-hide','manual','stop','game-stopped','build-unavailable','metadata','find','apply','restore','cancel','unknown']);
  const read = (value, key) => { try { return value == null ? undefined : value[key]; } catch { return undefined; } };
  const str = value => typeof value === 'string' ? value.slice(0,MAX_ERROR_INPUT) : '';
  const number = (value, limits) => typeof value === 'number' && Number.isFinite(value) && value >= limits[0] && value <= limits[1] ? Math.round(value*1000)/1000 : undefined;
  function fields(value, flags, numbers) {
    const out = {};
    for (const key of flags) if (typeof read(value,key) === 'boolean') out[key] = read(value,key);
    for (const [key,limits] of Object.entries(numbers)) { const v = number(read(value,key),limits); if (v !== undefined) out[key] = v; }
    return out;
  }
  function errorInfo(error, stack) {
    const message = str(typeof error === 'string' ? error : read(error,'message'));
    const name = str(read(error,'name'));
    const text = `${name} ${message}`.toLowerCase();
    const errorKind = /out of bounds|bounds check|outside.*memory/.test(text) ? 'memory-bounds'
      : /unreachable/.test(text) ? 'unreachable'
      : /indirect call|signature mismatch|null function|table index/.test(text) ? 'indirect-call'
      : /divide by zero|integer overflow/.test(text) ? 'integer-divide'
      : /invalid conversion/.test(text) ? 'invalid-conversion'
      : /call stack|stack overflow/.test(text) ? 'stack-overflow'
      : /out of memory|allocation failed|memory allocation/.test(text) ? 'out-of-memory'
      : /typeerror/.test(text) ? 'type-error'
      : /referenceerror/.test(text) ? 'reference-error'
      : /syntaxerror/.test(text) ? 'syntax-error' : 'other';
    const source = str(stack === undefined ? read(error,'stack') : stack);
    // Keep only numeric wasm locations and known local source basenames/line numbers.
    // Never retain error text, URLs, arguments, file paths, arbitrary function names or query strings.
    const wasmFrames = [...source.matchAll(/wasm-function\[(\d{1,7})\]:(0x[0-9a-f]{1,12}|\d{1,12})(?![\da-f])/gi)].slice(0,12).map(m=>`wasm-function[${m[1]}]:${m[2]}`);
    const jsFrames = [...source.matchAll(/(?:^|[/\\\s(])((?:page|ai|core|diagnostics|current-profile|latest-profile|signatures|signature-profile|signature-profile-latest|dyno|dyno-core|walls|cars|game-worker)\.js):(\d{1,7}):(\d{1,7})(?!\d)/g)].slice(0,8).map(m=>`${m[1]}:${m[2]}:${m[3]}`);
    return {errorKind,wasmFrames,jsFrames};
  }
  function sanitize(value) {
    const out = fields(value,FLAGS,NUMBERS);
    for(const key of ['revision','reportedRevision','candidateRevision','signatureReference']){
      const revision=read(value,key);
      if(typeof revision==='string'&&/^(?:[a-f0-9]{8,40}|unknown)$/.test(revision))out[key]=revision;
    }
    const moduleHash=read(value,'moduleHash');
    if(typeof moduleHash==='string'&&/^[a-f0-9]{64}$/.test(moduleHash))out.moduleHash=moduleHash;
    if(PATCH_CODES.has(read(value,'patchCode')))out.patchCode=read(value,'patchCode');
    const version = read(value,'version');
    if (typeof version === 'string' && /^\d{1,3}\.\d{1,3}\.\d{1,3}$/.test(version)) out.version = version;
    for (const [key,allowed] of [['phase',PHASES],['reason',REASONS],['errorKind',ERROR_KINDS]]) if (allowed.has(read(value,key))) out[key] = read(value,key);
    if (read(value,'tools')) out.tools = fields(read(value,'tools'),TOOL_FLAGS,TOOL_NUMBERS);
    if (read(value,'error') !== undefined || read(value,'stack') !== undefined) Object.assign(out,errorInfo(read(value,'error'),read(value,'stack')));
    // Revalidate persisted records too, never trust same-origin storage or its fields.
    else for (const [key,re,max] of [['wasmFrames',/^wasm-function\[\d{1,7}\]:(?:0x[0-9a-f]{1,12}|\d{1,12})$/i,12],['jsFrames',/^(?:page|ai|core|diagnostics|current-profile|latest-profile|signatures|signature-profile|signature-profile-latest|dyno|dyno-core|walls|cars|game-worker)\.js:\d{1,7}:\d{1,7}$/,8]]) {
      const a=read(value,key);if(Array.isArray(a))out[key]=a.slice(0,max).filter(v=>typeof v==='string'&&re.test(v));
    }
    return out;
  }
  function create({storage=null,clock=()=>Date.now(),version='0.16.0'}={}) {
    let events=[],dropped=0,persistence=storage?'same-tab':'memory-only',lastSnapshot='',lastSample=0;
    const bursts=new Map();
    const now=()=>{try{const n=clock();return Number.isFinite(n)&&n>=0?Math.floor(n):0;}catch{return 0;}};
    const packed=()=>({schema:1,dropped,events});
    const bound=()=>{while(events.length>MAX_EVENTS || JSON.stringify(packed()).length>MAX_BYTES){events.shift();dropped++;}};
    const persist=()=>{bound();if(storage)try{storage.setItem(KEY,JSON.stringify(packed()));persistence='same-tab';}catch{persistence='memory-only';}};
    try {
      const raw=storage?.getItem(KEY);
      if(typeof raw==='string'&&raw.length<=MAX_BYTES){
        const saved=JSON.parse(raw);
        if(saved?.schema===1&&Array.isArray(saved.events)){
          dropped=Number.isSafeInteger(saved.dropped)&&saved.dropped>=0?saved.dropped:0;
          events=saved.events.slice(-MAX_EVENTS).filter(e=>EVENTS.has(read(e,'event'))).map(e=>({at:number(read(e,'at'),[0,8640000000000000])??0,event:read(e,'event'),data:sanitize(read(e,'data'))}));
        }
      }
    } catch { persistence='memory-only'; }
    const record=(event,data={})=>{try{if(!EVENTS.has(event))return false;const at=now();if(['page-error','promise-rejection','worker-error','engine-error','dyno-error'].includes(event)){const burst=bursts.get(event);if(burst&&at-burst.at<1000){if(burst.count++>=8){dropped++;return false;}}else bursts.set(event,{at,count:1});}events.push({at,event,data:sanitize(data)});persist();return true;}catch{return false;}};
    const snapshot=(data={})=>{try{const clean=sanitize(data),stable={...clean};delete stable.gameTicks;delete stable.pageHeartbeat;delete stable.nativeHeartbeatAck;const key=JSON.stringify(stable),t=now();if(lastSnapshot && t-lastSample < (key===lastSnapshot?5000:250))return;lastSnapshot=key;lastSample=t;record('state',clean);}catch{}};
    const exportText=()=>JSON.stringify({format:'NFSU2 Driving Tools local diagnostics',schema:1,exportedAt:now(),persistence,dropped,limits:{maxEvents:MAX_EVENTS,maxStoredBytes:MAX_BYTES},capture:'Tool selections, sampled game mode/status, page and game-worker lifecycle, classified errors, numeric wasm locations and known script line numbers. No raw logs, messages, URLs, credentials, saves, names, keyboard input or network traffic. Same-origin page scripts can access this same-tab storage. Browser/tab/GPU failures may prevent a final event; absence of an error does not show that the game was healthy. Not a game crash dump.',events},null,2)+'\n';
    const clear=()=>{events=[];dropped=0;lastSnapshot='';lastSample=0;bursts.clear();record('clear');};
    record('page-start',{version});
    return Object.freeze({record,snapshot,exportText,clear,status:()=>({events:events.length,dropped,persistence})});
  }
  const api=Object.freeze({create,errorInfo,KEY,MAX_EVENTS,MAX_BYTES});
  root.__NFSU2_DIAGNOSTICS__=api;
  if(typeof module==='object'&&module.exports)module.exports=api;
})(globalThis);

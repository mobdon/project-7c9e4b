# v0.16.0 · Current build and online player no-clip

## Changes

- Adds exact revision **93af6ccb**, size 38,205,596, SHA-256 128e2b5816a8eace4b768aec920318a1613da8235801a361e2009e96550be1d6. Previous exact profiles are retained; unknown binaries still fail closed.
- Maps and recompiles the authored native hooks against the reviewed dispatcher, guest-call ABI and collision helpers. The genuine native status capacity increased from 48 to 64; only the new verified profile enables the 64-entry reader.
- Retains v0.15 native AI/event switching, normal skill 9, guarded opponent drag selection, drift physics choice and native NOS decisions. This is the game's native driver, not an external steering bot.
- Adds **Online player no-clip**, separate from NPC traffic and off by default, on the two newest reviewed profiles. Exact native player-slot matches 0..2 qualify; no-match traffic requires its own switch and driver 4. Online free roam only; races, outruns and LAN remain excluded. Category counters, native ghost behavior and normal collision fallback are preserved.
- Adds the new 34-anchor read-only diagnostic signature set. Matching signatures never enables an unknown module.
- Existing menu layout, five-mode dyno search/Apply/Restore, adaptive corner controls, separate pace, power/grip/NOS controls and local manual-export crash logger remain. The unfinished full tuner and drift-recovery research are not included.

## Verification and limits

The final v0.16 release-folder suite passes **1,430/1,430 tests, zero failures and zero skips**. Independent overlapping review passes **628 scoped cases**. Authored contact/profile generators reproduce byte-for-byte and all extension JavaScript passes syntax checks. Public metadata rechecked at **2026-11-09 19:11 UTC** still identifies revision 93af6ccb and the exact pinned size/module.

The exact new patched module compiles and changes only eight intended bodies: 3174,4653,7395,17404,19277,21213,21263,22508. All other bodies and non-code sections remain byte-identical. Native input/status/NOS execution passes 89 assertions, including all 64 native slots and overflow refusal. Actual gcall 21741 preserves its 344-byte CPU snapshot and guest stack in a controlled dispatcher fixture. Independent production collision tests pass 24 cases with actual current helpers and the compiled contact hook.

Automated tests are isolated fixtures and binary proofs, not live gameplay. No live multiplayer collision/synchronization, full native AI graphs, race outcomes or real-browser export are verified. Reported freezes and the residual page-thread tuning object-lifetime race remain unresolved. The scratch area has exclusion evidence but no formal reservation. Back up the save, keep v0.15 for rollback, start with 1× pace and power/grip off, and enable one feature at a time. F7 returns control; F9 stops tools.

---

# v0.15.0 · Native opponent AI paths

## Changes on exact build 78e2bb69 only

- **Opponent drag action:** allows the native initializer to select actual opponent “Win drag race” action 2 for the extension's requested and owned player car. It does not change racer identity, global difficulty, native action pointers or vtables directly. A confirmed player action 3 may be upgraded once through the initializer; NULL initializes lazily and recovery 11/other actions are left to the game. Status confirms id and vtable; pending is not success.
- **Native drift physics:** corrects normal unmarked player drift events to driver 3/physics 1 through the native setter, preserving drag-first mode precedence. Invalid driver state or failed correction rolls back to manual control. Existing mode/identity/heartbeat/network guards and full event handback remain.
- **Native nitrous decisions:** permits the owned player to reach native request/cancellation logic for recognized drag goal 2, observed road goal 1 in actual race types 1/7, and observed chase goal 5 only in Outrun 7. It never selects chase goal 5 or enables this new path in free roam 0. Native tactical/skill/availability/resource conditions remain intact; no refill or forced activation is added. The separate Unlimited NOS control remains unchanged.
- Cancellation uses the same authorized owned race scope without a new-start goal requirement, so recovery/NULL goal transitions cannot suppress native cancellation. New starts remain strictly goal-gated.

## Limits

**Force-only drag and the special 1099 combination are unsupported by the new opponent path.** It requires the actual native drag flag. This is not full opponent equivalence, a distinct specialist AI for every race, or a fastest-driver claim. No live race benchmark, reliable launch/shift/lane behavior, race completion, winning or crash-freedom is proven. Temporary/recovery actions are not forced. Native full allocator/configuration and cancellation execution, plus the complete skill/resource graph, remain unverified.

The reported freezes remain unresolved. Back up the save, preserve v0.14, enable only one extension version and reload the game. Begin with normal 1× pace and unrelated power/grip changes off. F7 returns control. Unknown game binaries stay disabled, and older exact supported profiles retain their previous behavior.

## Preserved v0.14 features

Guarded five-slot dyno Find/Apply/Restore and Store/Save guidance; adaptive free-roam corner margin and honest hit/status logging; separate online NPC traffic no-clip; solo collision switches; separate free-roam/race pace; NOS refill, power, limiter, grip, manual drag, drift input, read-only tester, signature scanner and sanitized local crash-log export are retained. Corner assistance remains free-roam-only and drag bypasses custom pace. No game assets, extracted binaries or research files are included.

## Verification

The final v0.15 release-folder suite passed **897/897 tests, zero failures and zero skips** after integration and version changes. Independent review passed **390 selected overlapping tests** on the frozen implementation. Authored drag-selector, owned-NOS and latest-profile builders reproduce byte-for-byte; all extension JavaScript passes syntax checks. Production JavaScript matches the frozen reviewed candidate except version labels. Additional bounded native downstream proof passed 56 cases with controlled skill/resource boundaries. These are not live gameplay or full end-to-end native graph benchmarks.

Only eight intended current-build bodies change: 3174, 4653, 7395, 17404, 19277, 21213, 21263 and 22470. All other function bodies and non-code sections remain identical. Older exact profiles retain their existing hooks. Strict-CSP browser visuals remain unverified because Chromium startup was blocked in this environment.

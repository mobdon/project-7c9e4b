/* Native game AI bridge, pinned to one exact module. All injected instructions are
 * authored here; game bytes are obtained only by the game's own normal loader.
 * See tools/ai-bridge.wat and README for the source-backed handoff and skill path. */
(function (root) {
  'use strict';
  if (root.__NFSU2_AI__) return;
  const BASE=0xd0d100, MAGIC=0x3749414e;
  const HASH='ee5d281a3109240d5db25dc3921e1044672cf6d650eb58c3baa089b54fe2941f';
  const SIZE=37839055, TARGET=21213-37, PACE_TARGET=21262-37, WALL_TARGET=22720-37;
  const BRIDGE=Uint8Array.from([14,4,127,1,125,1,127,1,124,11,127,1,123,3,127,1,124,5,127,1,123,1,127,1,123,32,127,1,125,2,64,32,0,40,2,16,40,2,0,65,245,168,224,2,71,13,0,65,156,162,195,6,65,206,130,165,186,3,54,2,0,65,128,162,195,6,40,2,0,65,206,130,165,186,3,71,13,0,65,152,162,195,6,40,2,0,33,37,65,176,162,195,6,40,2,0,65,1,106,33,38,32,37,65,172,162,195,6,40,2,0,71,4,64,65,0,33,38,11,65,172,162,195,6,32,37,54,2,0,65,176,162,195,6,32,38,54,2,0,65,132,162,195,6,40,2,0,33,36,32,36,65,1,113,32,38,65,180,1,73,113,13,0,65,128,128,192,6,40,2,0,33,32,65,152,130,164,4,40,2,0,33,34,65,0,33,33,65,0,33,40,65,0,33,35,2,64,65,164,169,153,4,40,2,0,65,6,71,13,0,32,32,65,128,128,4,79,32,32,65,128,224,255,191,2,73,32,32,173,63,0,173,66,16,134,66,128,32,125,84,113,113,69,13,0,32,32,40,2,4,33,33,32,33,65,128,128,4,79,32,33,65,128,224,255,191,2,73,32,33,173,63,0,173,66,16,134,66,128,32,125,84,113,113,69,13,0,32,33,40,2,36,33,40,32,34,65,128,128,4,79,32,34,65,128,224,255,191,2,73,32,34,173,63,0,173,66,16,134,66,128,32,125,84,113,113,69,13,0,32,32,40,2,16,65,0,71,13,0,65,176,128,192,6,40,2,0,65,1,71,13,0,32,34,40,2,0,65,4,71,13,0,65,212,162,195,6,40,2,0,65,1,71,4,64,65,248,128,148,4,40,2,0,65,136,4,113,13,1,65,148,212,153,4,40,2,0,13,1,65,244,211,153,4,40,2,0,13,1,65,233,158,167,4,45,0,0,13,1,11,65,216,207,167,4,45,0,0,4,64,65,216,162,195,6,40,2,0,65,1,71,13,1,32,33,40,2,40,65,1,71,13,1,32,33,45,0,192,11,69,13,1,11,32,38,65,179,1,75,13,0,32,36,65,1,113,13,0,65,140,162,195,6,40,2,0,32,32,71,13,0,65,144,162,195,6,40,2,0,32,33,71,13,0,65,148,162,195,6,40,2,0,32,34,71,13,0,65,136,162,195,6,40,2,0,65,1,79,65,136,162,195,6,40,2,0,65,2,77,113,33,35,32,36,65,132,162,195,6,40,2,0,71,4,64,65,0,33,35,11,11,65,164,162,195,6,40,2,0,33,39,32,39,4,64,32,35,65,160,162,195,6,40,2,0,32,32,70,32,39,32,33,70,65,168,162,195,6,40,2,0,32,34,70,32,40,65,3,70,113,113,113,113,69,4,64,65,164,169,153,4,40,2,0,65,6,70,32,33,65,128,128,4,79,32,33,65,128,224,255,191,2,73,32,33,173,63,0,173,66,16,134,66,128,32,125,84,113,113,65,160,162,195,6,40,2,0,32,32,70,32,39,32,33,70,113,113,113,4,64,65,192,162,195,6,40,2,0,65,128,128,4,79,65,192,162,195,6,40,2,0,65,128,224,255,191,2,73,65,192,162,195,6,40,2,0,173,63,0,173,66,16,134,66,128,32,125,84,113,113,32,33,40,2,20,65,192,162,195,6,40,2,0,70,113,4,64,65,192,162,195,6,40,2,0,45,0,129,18,65,9,70,4,64,65,192,162,195,6,40,2,0,65,196,162,195,6,40,2,0,58,0,129,18,11,11,32,40,65,3,70,4,64,32,0,65,144,222,254,2,32,32,65,0,65,0,16,221,169,1,65,184,162,195,6,65,2,54,2,0,32,0,65,240,184,129,3,32,32,65,1,65,184,162,195,6,16,221,169,1,11,11,65,160,162,195,6,65,0,54,2,0,65,164,162,195,6,65,0,54,2,0,65,168,162,195,6,65,0,54,2,0,65,192,162,195,6,65,0,54,2,0,65,180,162,195,6,65,0,54,2,0,65,204,162,195,6,65,0,54,2,0,65,208,162,195,6,65,0,54,2,0,65,0,33,40,11,11,65,136,162,195,6,40,2,0,69,4,64,65,200,162,195,6,65,0,54,2,0,11,32,35,65,164,162,195,6,40,2,0,69,113,4,64,32,40,65,1,70,65,200,162,195,6,40,2,0,32,33,71,113,4,64,2,64,32,33,40,2,20,33,41,32,41,65,128,128,4,79,32,41,65,128,224,255,191,2,73,32,41,173,63,0,173,66,16,134,66,128,32,125,84,113,113,69,13,0,32,41,65,128,128,4,79,32,41,65,128,224,255,191,2,73,32,41,173,63,0,173,66,16,134,66,128,32,125,84,113,113,4,64,32,41,45,0,129,18,65,9,77,4,64,65,192,162,195,6,32,41,54,2,0,65,196,162,195,6,32,41,45,0,129,18,54,2,0,32,41,65,9,58,0,129,18,11,11,32,0,65,160,220,254,2,32,32,65,0,65,0,16,221,169,1,65,216,207,167,4,45,0,0,32,33,40,2,36,65,3,70,113,4,64,65,184,162,195,6,65,1,54,2,0,32,0,65,160,141,253,2,32,33,65,1,65,184,162,195,6,16,221,169,1,11,32,33,40,2,36,65,3,70,65,216,207,167,4,45,0,0,69,32,33,40,2,40,65,1,70,114,113,4,64,65,160,162,195,6,32,32,54,2,0,65,164,162,195,6,32,33,54,2,0,65,168,162,195,6,32,34,54,2,0,65,180,162,195,6,65,1,54,2,0,5,32,33,40,2,36,65,3,70,4,64,32,0,65,144,222,254,2,32,32,65,0,65,0,16,221,169,1,65,184,162,195,6,65,2,54,2,0,32,0,65,240,184,129,3,32,32,65,1,65,184,162,195,6,16,221,169,1,11,65,192,162,195,6,40,2,0,65,128,128,4,79,65,192,162,195,6,40,2,0,65,128,224,255,191,2,73,65,192,162,195,6,40,2,0,173,63,0,173,66,16,134,66,128,32,125,84,113,113,32,33,40,2,20,65,192,162,195,6,40,2,0,70,113,4,64,65,192,162,195,6,40,2,0,45,0,129,18,65,9,70,4,64,65,192,162,195,6,40,2,0,65,196,162,195,6,40,2,0,58,0,129,18,11,11,65,192,162,195,6,65,0,54,2,0,65,200,162,195,6,32,33,54,2,0,65,180,162,195,6,65,3,54,2,0,11,11,11,11,11,2,64,32,0,40,2,16,40,2,0,65,245,168,224,2,71,13,0,65,160,166,195,6,65,196,178,185,194,3,54,2,0,65,128,166,195,6,40,2,0,65,196,178,185,194,3,71,13,0,65,132,166,195,6,254,16,2,0,33,42,32,42,69,13,0,32,42,65,164,166,195,6,40,2,0,70,13,0,32,42,65,1,113,13,0,65,2,33,43,65,0,33,44,65,0,33,45,2,64,65,140,166,195,6,254,16,2,0,65,1,71,4,64,65,1,33,43,12,1,11,65,136,166,195,6,40,2,0,33,46,32,46,65,1,73,32,46,65,4,75,114,4,64,65,4,33,43,12,1,11,65,164,207,142,4,45,0,0,65,1,71,4,64,65,2,33,43,12,1,11,65,176,128,192,6,40,2,0,65,1,71,4,64,65,2,33,43,12,1,11,65,248,128,148,4,40,2,0,65,136,4,113,4,64,65,2,33,43,12,1,11,65,148,212,153,4,40,2,0,4,64,65,2,33,43,12,1,11,65,244,211,153,4,40,2,0,4,64,65,2,33,43,12,1,11,65,233,158,167,4,45,0,0,4,64,65,2,33,43,12,1,11,65,196,137,142,4,40,2,0,33,47,32,47,65,128,128,4,79,32,47,65,128,224,255,191,2,73,32,47,173,63,0,173,66,16,134,66,128,32,125,84,113,113,69,4,64,65,2,33,43,12,1,11,32,47,40,2,8,33,47,32,47,65,128,128,4,79,32,47,65,128,224,255,191,2,73,32,47,173,63,0,173,66,16,134,66,128,32,125,84,113,113,69,4,64,65,2,33,43,12,1,11,32,47,40,2,228,1,33,47,32,47,65,128,128,4,79,32,47,65,128,224,255,191,2,73,32,47,173,63,0,173,66,16,134,66,128,32,125,84,113,113,69,4,64,65,2,33,43,12,1,11,32,47,40,2,12,33,47,32,47,65,128,128,4,79,32,47,65,128,224,255,191,2,73,32,47,173,63,0,173,66,16,134,66,128,32,125,84,113,113,69,4,64,65,2,33,43,12,1,11,32,47,45,0,0,65,213,0,71,4,64,65,2,33,43,12,1,11,32,47,45,0,1,65,201,0,71,4,64,65,2,33,43,12,1,11,32,47,45,0,2,65,223,0,71,4,64,65,2,33,43,12,1,11,32,47,45,0,3,65,208,0,71,4,64,65,2,33,43,12,1,11,32,47,45,0,4,65,229,0,71,4,64,65,2,33,43,12,1,11,32,47,45,0,5,65,242,0,71,4,64,65,2,33,43,12,1,11,32,47,45,0,6,65,230,0,71,4,64,65,2,33,43,12,1,11,32,47,45,0,7,65,239,0,71,4,64,65,2,33,43,12,1,11,32,47,45,0,8,65,242,0,71,4,64,65,2,33,43,12,1,11,32,47,45,0,9,65,237,0,71,4,64,65,2,33,43,12,1,11,32,47,45,0,10,65,225,0,71,4,64,65,2,33,43,12,1,11,32,47,45,0,11,65,238,0,71,4,64,65,2,33,43,12,1,11,32,47,45,0,12,65,227,0,71,4,64,65,2,33,43,12,1,11,32,47,45,0,13,65,229,0,71,4,64,65,2,33,43,12,1,11,32,47,45,0,14,65,196,0,71,4,64,65,2,33,43,12,1,11,32,47,45,0,15,65,249,0,71,4,64,65,2,33,43,12,1,11,32,47,45,0,16,65,238,0,71,4,64,65,2,33,43,12,1,11,32,47,45,0,17,65,239,0,71,4,64,65,2,33,43,12,1,11,32,47,45,0,18,65,223,0,71,4,64,65,2,33,43,12,1,11,32,47,45,0,19,65,205,0,71,4,64,65,2,33,43,12,1,11,32,47,45,0,20,65,193,0,71,4,64,65,2,33,43,12,1,11,32,47,45,0,21,65,201,0,71,4,64,65,2,33,43,12,1,11,32,47,45,0,22,65,206,0,71,4,64,65,2,33,43,12,1,11,32,47,45,0,23,65,46,71,4,64,65,2,33,43,12,1,11,32,47,45,0,24,65,230,0,71,4,64,65,2,33,43,12,1,11,32,47,45,0,25,65,238,0,71,4,64,65,2,33,43,12,1,11,32,47,45,0,26,65,231,0,71,4,64,65,2,33,43,12,1,11,32,47,45,0,27,65,0,71,4,64,65,2,33,43,12,1,11,65,192,202,142,4,40,2,0,33,48,32,48,65,128,128,4,79,32,48,65,128,224,255,191,2,73,32,48,173,63,0,173,66,16,134,66,128,32,125,84,113,113,69,4,64,65,2,33,43,12,1,11,65,192,184,142,4,40,2,0,33,49,32,49,65,128,128,4,79,32,49,65,128,224,255,191,2,73,32,49,173,63,0,173,66,16,134,66,128,32,125,84,113,113,69,4,64,65,2,33,43,12,1,11,65,188,204,142,4,40,2,0,33,50,32,50,65,4,75,4,64,65,2,33,43,12,1,11,65,204,204,142,4,40,2,0,65,0,71,4,64,65,2,33,43,12,1,11,65,128,128,192,6,40,2,0,33,47,32,47,65,128,128,4,79,32,47,65,128,224,255,191,2,73,32,47,173,63,0,173,66,16,134,66,128,32,125,84,113,113,69,4,64,65,2,33,43,12,1,11,32,47,40,2,4,33,51,32,51,65,128,128,4,79,32,51,65,128,224,255,191,2,73,32,51,173,63,0,173,66,16,134,66,128,32,125,84,113,113,69,4,64,65,2,33,43,12,1,11,32,51,40,2,16,33,52,32,52,65,128,128,4,79,32,52,65,128,224,255,191,2,73,32,52,173,63,0,173,66,16,134,66,128,32,125,84,113,113,69,4,64,65,2,33,43,12,1,11,32,48,32,52,65,132,7,106,71,4,64,65,2,33,43,12,1,11,32,48,40,2,8,33,53,32,53,32,52,65,240,5,106,71,4,64,65,2,33,43,12,1,11,32,48,40,2,12,32,52,65,192,0,106,71,4,64,65,2,33,43,12,1,11,32,52,42,2,176,4,67,0,0,200,66,96,32,52,42,2,184,4,67,0,96,234,70,93,32,52,42,2,184,4,32,52,42,2,176,4,94,113,113,69,4,64,65,6,33,43,12,1,11,32,0,40,2,16,65,112,113,65,160,2,107,33,54,32,54,65,128,128,4,79,32,54,65,128,224,255,191,2,73,32,54,173,63,0,173,66,16,134,66,128,32,125,84,113,113,69,4,64,65,2,33,43,12,1,11,35,0,33,55,32,55,65,128,192,0,73,32,55,173,63,0,173,66,16,134,86,114,4,64,65,2,33,43,12,1,11,32,55,65,128,32,107,33,56,32,56,36,0,65,1,33,44,32,56,65,224,20,106,65,128,167,195,6,65,128,2,252,10,0,0,32,42,65,132,166,195,6,254,16,2,0,71,4,64,65,1,33,43,12,1,11,65,0,33,57,3,64,32,48,65,20,106,32,57,106,45,0,0,65,200,1,75,4,64,65,4,33,43,12,2,11,32,57,65,1,106,33,57,32,57,65,41,73,13,0,11,32,46,65,1,71,4,64,65,144,166,195,6,40,2,0,32,49,71,4,64,65,3,33,43,12,2,11,65,148,166,195,6,40,2,0,32,48,71,4,64,65,3,33,43,12,2,11,65,152,166,195,6,40,2,0,32,50,71,4,64,65,3,33,43,12,2,11,65,156,166,195,6,40,2,0,32,53,71,4,64,65,3,33,43,12,2,11,65,0,33,57,3,64,32,48,65,20,106,32,57,106,45,0,0,32,56,65,224,20,106,65,0,106,32,57,106,45,0,0,71,4,64,65,3,33,43,12,3,11,32,57,65,1,106,33,57,32,57,65,41,73,13,0,11,65,0,33,57,3,64,32,53,32,57,106,45,0,0,32,56,65,224,20,106,65,144,1,106,32,57,106,45,0,0,71,4,64,65,3,33,43,12,3,11,32,57,65,1,106,33,57,32,57,65,192,0,73,13,0,11,11,32,56,65,224,2,106,32,52,65,240,17,252,10,0,0,65,1,33,45,65,0,33,58,32,56,32,0,65,216,2,252,10,0,0,32,56,32,48,54,2,4,32,56,32,54,54,2,16,32,54,65,128,225,230,2,54,2,0,32,54,65,23,54,2,4,32,56,65,128,225,230,2,16,207,169,1,32,56,40,2,0,65,255,1,113,4,64,65,1,33,58,11,32,56,32,0,65,216,2,252,10,0,0,32,56,32,48,54,2,4,32,56,32,54,54,2,16,32,54,65,128,225,230,2,54,2,0,32,54,65,24,54,2,4,32,56,65,128,225,230,2,16,207,169,1,32,56,40,2,0,65,255,1,113,4,64,32,58,65,2,114,33,58,11,32,46,65,2,79,32,46,65,3,77,113,4,64,65,0,33,57,3,64,32,56,65,224,20,106,65,48,106,32,57,106,45,0,0,33,59,32,59,65,200,1,75,4,64,65,4,33,43,12,3,11,32,59,32,56,65,224,20,106,65,0,106,32,57,106,45,0,0,71,4,64,32,57,65,23,73,4,64,65,4,33,43,12,4,11,32,58,32,57,65,32,73,4,127,65,1,5,65,2,11,113,69,4,64,65,5,33,43,12,4,11,11,32,57,65,1,106,33,57,32,57,65,41,73,13,0,11,65,23,33,60,3,64,32,56,65,224,20,106,65,48,106,32,60,106,45,0,0,33,59,32,59,32,56,65,224,20,106,32,60,106,45,0,0,71,4,64,32,60,65,32,73,4,127,65,23,5,65,24,11,33,61,32,60,32,61,65,23,70,4,127,65,23,5,65,32,11,107,33,62,32,48,65,20,106,32,60,106,45,0,0,33,63,32,48,65,20,106,32,60,106,32,59,58,0,0,32,56,32,0,65,216,2,252,10,0,0,32,56,32,48,54,2,4,32,56,32,54,54,2,16,32,54,65,192,252,236,2,54,2,0,32,54,32,61,54,2,4,32,54,32,62,54,2,8,32,54,65,0,54,2,12,32,56,65,192,252,236,2,16,207,169,1,32,56,65,200,0,106,32,56,40,2,136,1,65,7,113,65,3,116,106,43,3,0,182,33,64,32,48,65,20,106,32,60,106,32,63,58,0,0,32,64,139,67,165,212,104,83,93,69,4,64,65,6,33,43,12,4,11,32,56,32,0,65,216,2,252,10,0,0,32,56,32,48,54,2,4,32,56,32,54,54,2,16,32,54,65,240,140,237,2,54,2,0,32,54,32,64,188,54,2,4,32,54,32,61,54,2,8,32,54,32,62,54,2,12,32,54,65,0,54,2,16,32,56,65,240,140,237,2,16,207,169,1,11,32,60,65,1,106,33,60,32,60,65,41,73,13,0,11,11,32,56,32,0,65,216,2,252,10,0,0,32,56,32,52,65,16,106,54,2,4,32,56,32,54,54,2,16,32,54,65,224,173,237,2,54,2,0,32,54,32,56,65,128,23,106,54,2,4,32,54,65,0,54,2,8,32,56,65,224,173,237,2,16,207,169,1,65,200,166,195,6,32,56,65,200,0,106,32,56,40,2,136,1,65,7,113,65,3,116,106,43,3,0,182,56,2,0,65,208,166,195,6,32,56,65,128,23,106,42,2,0,56,2,0,32,56,32,0,65,216,2,252,10,0,0,32,56,32,52,65,16,106,54,2,4,32,56,32,54,54,2,16,32,54,65,144,176,237,2,54,2,0,32,54,32,56,65,128,23,106,54,2,4,32,54,65,0,54,2,8,32,56,65,144,176,237,2,16,207,169,1,65,204,166,195,6,32,56,65,200,0,106,32,56,40,2,136,1,65,7,113,65,3,116,106,43,3,0,182,67,0,0,122,68,148,56,2,0,65,212,166,195,6,32,56,65,128,23,106,42,2,0,56,2,0,65,200,166,195,6,42,2,0,67,0,0,0,0,94,65,200,166,195,6,42,2,0,67,0,80,195,71,93,113,69,4,64,65,6,33,43,12,1,11,65,204,166,195,6,42,2,0,67,0,0,0,0,94,65,204,166,195,6,42,2,0,67,0,80,195,71,93,113,69,4,64,65,6,33,43,12,1,11,65,144,169,195,6,32,48,65,20,106,65,41,252,10,0,0,65,172,166,195,6,32,49,54,2,0,65,176,166,195,6,32,48,54,2,0,65,180,166,195,6,32,50,54,2,0,65,184,166,195,6,32,53,54,2,0,65,188,166,195,6,32,58,54,2,0,65,192,169,195,6,32,53,65,192,0,252,10,0,0,32,46,65,3,70,4,64,65,0,33,57,3,64,32,48,65,20,106,32,57,106,45,0,0,32,56,65,224,20,106,65,224,0,106,32,57,106,45,0,0,71,4,64,65,3,33,43,12,3,11,32,57,65,1,106,33,57,32,57,65,41,73,13,0,11,65,140,166,195,6,254,16,2,0,65,1,71,4,64,65,1,33,43,12,2,11,32,42,65,132,166,195,6,254,16,2,0,71,4,64,65,1,33,43,12,2,11,65,2,33,45,32,56,32,0,65,216,2,252,10,0,0,32,56,65,192,184,142,4,54,2,4,32,56,32,54,54,2,16,32,54,65,160,251,195,2,54,2,0,32,56,65,160,251,195,2,16,207,169,1,32,56,32,0,65,216,2,252,10,0,0,32,56,65,192,184,142,4,54,2,4,32,56,32,54,54,2,16,32,54,65,208,251,195,2,54,2,0,32,56,65,208,251,195,2,16,207,169,1,65,0,33,57,3,64,32,48,65,20,106,32,57,106,45,0,0,32,56,65,224,20,106,65,224,0,106,32,57,106,45,0,0,71,4,64,65,3,33,43,12,3,11,32,57,65,1,106,33,57,32,57,65,41,73,13,0,11,65,0,33,45,11,32,46,65,4,70,4,64,65,0,33,57,3,64,32,56,65,224,20,106,65,48,106,32,57,106,45,0,0,65,200,1,75,4,64,65,4,33,43,12,3,11,32,57,65,23,73,4,64,32,56,65,224,20,106,65,48,106,32,57,106,45,0,0,32,56,65,224,20,106,32,57,106,45,0,0,71,4,64,65,4,33,43,12,4,11,11,32,57,65,1,106,33,57,32,57,65,41,73,13,0,11,65,140,166,195,6,254,16,2,0,65,1,71,4,64,65,1,33,43,12,2,11,32,42,65,132,166,195,6,254,16,2,0,71,4,64,65,1,33,43,12,2,11,32,48,65,20,106,32,56,65,224,20,106,65,48,106,65,41,252,10,0,0,65,2,33,45,32,56,32,0,65,216,2,252,10,0,0,32,56,65,192,184,142,4,54,2,4,32,56,32,54,54,2,16,32,54,65,160,251,195,2,54,2,0,32,56,65,160,251,195,2,16,207,169,1,32,56,32,0,65,216,2,252,10,0,0,32,56,65,192,184,142,4,54,2,4,32,56,32,54,54,2,16,32,54,65,208,251,195,2,54,2,0,32,56,65,208,251,195,2,16,207,169,1,65,0,33,57,3,64,32,48,65,20,106,32,57,106,45,0,0,32,56,65,224,20,106,65,48,106,32,57,106,45,0,0,71,4,64,65,3,33,43,12,3,11,32,57,65,1,106,33,57,32,57,65,41,73,13,0,11,65,0,33,45,65,144,169,195,6,32,48,65,20,106,65,41,252,10,0,0,11,65,0,33,43,11,32,45,4,64,32,52,32,56,65,224,2,106,65,240,17,252,10,0,0,32,45,65,2,70,4,64,32,56,32,0,65,216,2,252,10,0,0,32,56,65,192,184,142,4,54,2,4,32,56,32,54,54,2,16,32,54,65,160,251,195,2,54,2,0,32,56,65,160,251,195,2,16,207,169,1,32,56,32,0,65,216,2,252,10,0,0,32,56,65,192,184,142,4,54,2,4,32,56,32,54,54,2,16,32,54,65,208,251,195,2,54,2,0,32,56,65,208,251,195,2,16,207,169,1,11,11,32,44,4,64,32,55,36,0,11,65,168,166,195,6,32,43,54,2,0,65,164,166,195,6,32,42,254,23,2,0,11,11]);
  const PACE=Uint8Array.from([2,6,127,1,125,32,0,40,2,4,33,1,32,0,16,154,126,32,1,16,141,166,1,2,64,65,128,162,195,6,40,2,0,65,206,130,165,186,3,71,13,0,65,156,162,195,6,40,2,0,65,206,130,165,186,3,71,13,0,65,132,162,195,6,40,2,0,33,5,32,5,65,1,113,13,0,65,176,162,195,6,40,2,0,65,180,1,79,13,0,65,136,162,195,6,40,2,0,65,1,79,65,136,162,195,6,40,2,0,65,2,77,113,69,13,0,65,180,162,195,6,40,2,0,65,1,71,13,0,65,164,169,153,4,40,2,0,65,6,71,13,0,65,176,128,192,6,40,2,0,65,1,71,13,0,65,212,162,195,6,40,2,0,65,1,71,4,64,65,248,128,148,4,40,2,0,65,136,4,113,13,1,65,148,212,153,4,40,2,0,13,1,65,244,211,153,4,40,2,0,13,1,65,233,158,167,4,45,0,0,13,1,11,65,216,207,167,4,45,0,0,13,0,65,128,128,192,6,40,2,0,33,2,32,2,65,128,128,4,79,32,2,65,128,224,255,191,2,73,32,2,173,63,0,173,66,16,134,66,128,32,125,84,113,113,69,13,0,32,2,65,160,162,195,6,40,2,0,71,13,0,32,2,65,140,162,195,6,40,2,0,71,13,0,32,2,40,2,16,13,0,32,2,40,2,4,33,3,32,3,65,128,128,4,79,32,3,65,128,224,255,191,2,73,32,3,173,63,0,173,66,16,134,66,128,32,125,84,113,113,69,13,0,32,3,65,164,162,195,6,40,2,0,71,13,0,32,3,65,144,162,195,6,40,2,0,71,13,0,32,3,40,2,36,65,3,71,13,0,32,1,65,128,128,4,79,32,1,65,128,224,255,191,2,73,32,1,173,63,0,173,66,16,134,66,128,32,125,84,113,113,69,13,0,32,3,40,2,44,32,1,71,13,0,32,1,40,2,4,32,3,71,13,0,65,152,130,164,4,40,2,0,33,4,32,4,65,128,128,4,79,32,4,65,128,224,255,191,2,73,32,4,173,63,0,173,66,16,134,66,128,32,125,84,113,113,69,13,0,32,4,65,168,162,195,6,40,2,0,71,13,0,32,4,65,148,162,195,6,40,2,0,71,13,0,32,4,40,2,0,65,4,71,13,0,65,188,162,195,6,40,2,0,33,6,32,6,65,203,0,79,32,6,65,172,2,77,113,69,13,0,32,1,42,2,240,14,33,7,32,7,67,0,0,0,0,96,32,7,67,0,0,128,64,95,113,69,13,0,32,5,65,132,162,195,6,40,2,0,71,13,0,32,6,65,228,0,71,4,64,32,1,32,7,32,6,179,67,0,0,200,66,149,148,56,2,240,14,11,65,204,162,195,6,32,6,54,2,0,65,208,162,195,6,65,208,162,195,6,40,2,0,65,1,106,54,2,0,11,11]);
  const WALL=Uint8Array.from([2,15,127,4,125,2,64,65,128,163,195,6,40,2,0,65,206,152,221,194,3,71,13,0,65,128,162,195,6,40,2,0,65,206,130,165,186,3,71,13,0,65,156,162,195,6,40,2,0,65,206,130,165,186,3,71,13,0,65,132,163,195,6,40,2,0,33,2,65,132,162,195,6,40,2,0,33,3,32,2,32,3,114,65,1,113,13,0,65,136,163,195,6,40,2,0,65,1,71,13,0,65,176,162,195,6,40,2,0,65,180,1,79,13,0,65,152,163,195,6,65,0,54,2,0,65,164,169,153,4,40,2,0,65,6,71,13,0,65,176,128,192,6,40,2,0,65,1,71,13,0,65,248,128,148,4,40,2,0,65,136,4,113,65,148,212,153,4,40,2,0,65,244,211,153,4,40,2,0,114,114,65,233,158,167,4,45,0,0,16,249,176,1,114,114,4,64,65,152,163,195,6,65,2,54,2,0,12,1,11,65,128,128,192,6,40,2,0,33,4,32,4,65,128,128,4,79,32,4,65,128,224,255,191,2,73,32,4,173,63,0,173,66,16,134,66,128,32,125,84,113,113,69,13,0,32,4,65,140,163,195,6,40,2,0,71,13,0,32,4,40,2,16,13,0,32,4,40,2,4,33,5,32,5,65,128,128,4,79,32,5,65,128,224,255,191,2,73,32,5,173,63,0,173,66,16,134,66,128,32,125,84,113,113,69,13,0,32,5,65,144,163,195,6,40,2,0,71,13,0,65,152,130,164,4,40,2,0,33,6,32,6,65,128,128,4,79,32,6,65,128,224,255,191,2,73,32,6,173,63,0,173,66,16,134,66,128,32,125,84,113,113,69,13,0,32,6,65,148,163,195,6,40,2,0,71,13,0,32,6,40,2,0,65,4,71,13,0,32,5,40,2,60,33,7,32,7,65,128,128,4,79,32,7,65,128,224,255,191,2,73,32,7,173,63,0,173,66,16,134,66,128,32,125,84,113,113,69,13,0,32,7,45,0,17,13,0,32,7,40,2,176,2,32,5,71,13,0,32,0,40,2,4,33,8,32,8,65,128,128,4,79,32,8,65,128,224,255,191,2,73,32,8,173,63,0,173,66,16,134,66,128,32,125,84,113,113,69,13,0,32,8,40,2,12,33,9,32,8,40,2,16,33,10,32,9,32,7,70,4,64,32,10,33,11,5,32,10,32,7,71,13,1,32,9,33,11,11,32,11,65,128,128,4,79,32,11,65,128,224,255,191,2,73,32,11,173,63,0,173,66,16,134,66,128,32,125,84,113,113,69,13,0,32,11,45,0,17,65,3,71,13,0,32,11,40,2,0,65,168,197,232,3,71,13,0,32,11,45,0,18,13,0,32,11,40,2,96,33,12,32,12,65,128,128,4,79,32,12,65,128,224,255,191,2,73,32,12,173,63,0,173,66,16,134,66,128,32,125,84,113,113,69,13,0,32,12,40,2,16,32,11,71,13,0,32,12,42,2,112,33,16,32,12,42,2,116,33,17,32,12,42,2,120,33,18,32,18,139,67,205,204,204,61,93,69,13,0,32,16,32,16,148,32,17,32,17,148,146,32,18,32,18,148,146,33,19,32,19,67,102,102,102,63,96,32,19,67,205,204,140,63,95,113,69,13,0,32,8,40,2,20,33,13,32,13,65,128,128,4,79,32,13,65,128,224,255,191,2,73,32,13,173,63,0,173,66,16,134,66,128,32,125,84,113,113,69,13,0,32,13,40,2,184,4,32,9,71,13,0,32,13,40,2,188,4,32,10,71,13,0,65,132,193,128,4,40,2,0,33,14,32,14,65,2,71,13,0,32,0,40,2,16,33,15,32,15,65,128,128,4,79,32,15,65,128,224,255,191,2,73,32,15,173,63,0,173,66,16,134,66,128,32,125,84,113,113,69,13,0,32,2,65,132,163,195,6,40,2,0,71,13,0,32,3,65,132,162,195,6,40,2,0,71,13,0,32,13,40,2,192,4,65,1,73,4,64,32,13,65,1,54,2,192,4,11,65,152,163,195,6,65,1,54,2,0,65,156,163,195,6,65,156,163,195,6,40,2,0,65,1,106,54,2,0,65,160,163,195,6,32,5,54,2,0,32,0,32,15,40,2,0,54,2,32,32,0,32,15,65,4,106,54,2,16,15,11,11]);
  const CORNER={"pre":[6,2,127,3,124,4,127,2,125,14,127,6,124,2,64,65,128,162,195,6,40,2,0,65,206,130,165,186,3,71,13,0,65,156,162,195,6,40,2,0,65,206,130,165,186,3,71,13,0,65,128,164,195,6,40,2,0,65,195,156,201,146,3,71,13,0,65,132,164,195,6,40,2,0,65,1,71,13,0,65,132,162,195,6,40,2,0,33,17,32,17,65,1,113,13,0,65,176,162,195,6,40,2,0,65,180,1,79,13,0,65,136,162,195,6,40,2,0,65,2,71,13,0,65,176,207,167,4,40,2,0,13,0,65,180,162,195,6,40,2,0,65,1,71,13,0,65,164,169,153,4,40,2,0,65,6,71,13,0,65,176,128,192,6,40,2,0,65,1,71,13,0,65,216,207,167,4,45,0,0,13,0,65,217,207,167,4,45,0,0,13,0,65,132,130,164,4,40,2,0,13,0,65,212,162,195,6,40,2,0,65,1,71,4,64,65,248,128,148,4,40,2,0,65,136,4,113,13,1,65,148,212,153,4,40,2,0,13,1,65,244,211,153,4,40,2,0,13,1,65,233,158,167,4,45,0,0,13,1,11,32,0,40,2,16,33,18,32,18,65,128,128,4,79,32,18,65,240,255,255,191,2,77,32,18,173,63,0,173,66,16,134,66,16,125,88,113,113,69,13,0,32,18,40,2,0,65,187,209,136,2,71,13,0,32,0,40,2,12,33,19,32,19,65,128,128,4,79,32,19,65,128,224,255,191,2,77,32,19,173,63,0,173,66,16,134,66,128,32,125,88,113,113,69,13,0,32,19,65,164,162,195,6,40,2,0,71,13,0,32,19,65,144,162,195,6,40,2,0,71,13,0,32,19,40,2,36,65,3,71,13,0,65,128,128,192,6,40,2,0,33,20,32,20,65,128,128,4,79,32,20,65,128,224,255,191,2,77,32,20,173,63,0,173,66,16,134,66,128,32,125,88,113,113,69,13,0,32,20,65,160,162,195,6,40,2,0,71,13,0,32,20,65,140,162,195,6,40,2,0,71,13,0,32,20,40,2,4,32,19,71,13,0,32,20,40,2,16,13,0,32,19,40,2,44,33,22,32,22,65,128,128,4,79,32,22,65,128,224,255,191,2,77,32,22,173,63,0,173,66,16,134,66,128,32,125,88,113,113,69,13,0,32,22,40,2,4,32,19,71,13,0,32,0,40,2,24,32,22,40,2,232,13,71,13,0,32,0,40,2,24,32,22,65,240,6,106,71,13,0,65,152,130,164,4,40,2,0,33,21,32,21,65,128,128,4,79,32,21,65,128,224,255,191,2,77,32,21,173,63,0,173,66,16,134,66,128,32,125,88,113,113,69,13,0,32,21,65,168,162,195,6,40,2,0,71,13,0,32,21,65,148,162,195,6,40,2,0,71,13,0,32,21,40,2,0,65,4,71,13,0,65,136,164,195,6,40,2,0,33,23,32,23,65,60,79,32,23,65,223,0,77,113,69,13,0,65,164,164,195,6,40,2,0,33,25,32,25,65,25,75,13,0,32,18,42,2,4,187,33,26,32,18,42,2,8,187,153,33,27,32,18,42,2,12,187,33,28,32,26,68,0,0,0,0,0,0,0,0,100,32,26,68,0,0,0,0,0,0,52,64,101,113,69,13,0,32,27,68,0,0,0,0,0,0,0,0,102,32,27,68,0,0,0,0,0,0,36,64,101,113,69,13,0,32,28,68,0,0,0,0,0,0,0,0,100,32,28,68,0,0,0,0,0,192,98,64,101,113,69,13,0,32,27,32,26,65,184,163,233,3,42,2,0,187,162,32,28,32,28,162,163,101,13,0,32,17,65,132,162,195,6,40,2,0,71,13,0,65,1,33,16,11,11],"post":[6,2,127,3,124,4,127,2,125,14,127,6,124,2,64,32,16,69,13,0,32,17,65,132,162,195,6,40,2,0,71,13,0,32,0,40,2,32,65,187,209,136,2,71,13,0,32,0,40,2,16,32,18,65,4,106,71,13,0,32,0,65,200,0,106,32,0,40,2,136,1,65,7,113,65,3,116,106,33,24,32,24,43,3,0,33,29,32,29,68,0,0,0,0,0,0,0,0,100,32,29,32,28,99,113,69,13,0,32,29,32,23,184,68,0,0,0,0,0,0,89,64,163,162,33,30,32,25,4,64,68,0,0,0,0,0,0,240,63,32,29,32,28,163,161,33,31,32,30,68,0,0,0,0,0,0,240,63,32,25,184,68,0,0,0,0,0,0,89,64,163,32,31,162,161,162,33,30,11,32,24,32,30,57,3,0,65,140,164,195,6,32,19,54,2,0,65,144,164,195,6,65,144,164,195,6,40,2,0,65,1,106,54,2,0,65,148,164,195,6,32,29,182,56,2,0,65,152,164,195,6,32,30,182,56,2,0,65,156,164,195,6,32,27,182,56,2,0,65,160,164,195,6,32,23,54,2,0,65,168,164,195,6,32,25,54,2,0,11,11],"originalTypes":["i32","i32","f64","f64","f64","i32","i32","i32","i32","f32","f32","i32","i32","i32","i32"],"totalLocals":31,"index":4653,"commandBase":13685248,"commandMagic":844254787};
  const patchState={phase:'idle',reason:'Waiting for game module.'};
  const CURRENT=root.__NFSU2_CURRENT_PROFILE__ || (typeof require==='function'?require('./current-profile.js'):null);
  const LEGACY=Object.freeze({revision:'6f4f1e4e',size:SIZE,hash:HASH,capabilities:Object.freeze({legacy:true,ai:true,pace:true,corner:true,walls:true,dyno:true,dragAI:true})});
  const LATEST=root.__NFSU2_LATEST_PROFILE__ || (typeof require==='function'?require('./latest-profile.js'):null);
  const NEXT=root.__NFSU2_NEXT_PROFILE__ || (typeof require==='function'?require('./next-profile.js'):null);
  const profileForSize=size=>[LEGACY,CURRENT,LATEST,NEXT].find(p=>p&&p.size===size)||null;
  const patched=new WeakMap();
  let installed=false,loadGeneration=0;
  const read=(b,p)=>{let value=0,shift=0,x;do{if(p.i>=b.length || shift>28)throw Error('Invalid module integer');x=b[p.i++];value|=(x&127)<<shift;shift+=7;}while(x&128);return value>>>0;};
  const leb=n=>{const a=[];do{let v=n&127;n>>>=7;if(n)v|=128;a.push(v);}while(n);return Uint8Array.from(a);};
  function join(...parts){const out=new Uint8Array(parts.reduce((n,b)=>n+b.length,0));let p=0;for(const b of parts){out.set(b,p);p+=b.length;}return out;}
  function locals(b){const p={i:0},n=read(b,p),types=[];for(let i=0;i<n;i++){const count=read(b,p),type=b[p.i++];if(count>10000)throw Error('Invalid local count');for(let k=0;k<count;k++)types.push(type);}return {end:p.i,types};}
  function patchCornerBody(old) {
    const pre=Uint8Array.from(CORNER.pre),post=Uint8Array.from(CORNER.post),before=locals(old),prefix=locals(pre),suffix=locals(post);
    const expected=CORNER.originalTypes.map(t=>({i32:127,f32:125,f64:124}[t]));
    if(before.types.length!==expected.length || before.types.some((t,i)=>t!==expected[i]) || prefix.types.length!==CORNER.totalLocals || suffix.types.length!==CORNER.totalLocals || old[old.length-1]!==11)
      throw Error('Native corner planner layout changed.');
    return join(pre.subarray(0,pre.length-1),old.subarray(before.end,old.length-1),post.subarray(suffix.end));
  }
  async function patchBytes(input) {
    const bytes=input instanceof Uint8Array ? input : new Uint8Array(input);
    const profile=profileForSize(bytes.length);
    if(!profile)throw Object.assign(Error('Game module size changed. Native AI disabled.'),{patchCode:'module-size'});
    const hash=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes)),b=>b.toString(16).padStart(2,'0')).join('');
    if(hash!==profile.hash)throw Object.assign(Error('Game module changed. Native AI disabled.'),{patchCode:'module-hash',moduleHash:hash});
    if(profile!==LEGACY)return patchCurrent(bytes,profile);
    const p={i:8};let output=null;
    while(p.i<bytes.length){
      const start=p.i,id=bytes[p.i++],size=read(bytes,p),bodyStart=p.i,end=bodyStart+size;
      if(end>bytes.length)throw Error('Invalid module section');
      if(id===10){
        const n=read(bytes,p),pieces=[bytes.subarray(bodyStart,p.i)];let changed=0;
        for(let i=0;i<n;i++){
          const sizeAt=p.i,bodyLen=read(bytes,p),fnStart=p.i,fnEnd=fnStart+bodyLen;
          if(fnEnd>end)throw Error('Invalid game function');
          if(i===CORNER.index-37){
            const fn=patchCornerBody(bytes.subarray(fnStart,fnEnd));pieces.push(leb(fn.length),fn);changed++;
          }else if(i===TARGET){
            const old=bytes.subarray(fnStart,fnEnd),a=locals(old),b=locals(BRIDGE);
            if(a.types.length!==31 || b.types.length!==64 || a.types.some((v,k)=>v!==b.types[k]) || old[old.length-1]!==11 || BRIDGE[BRIDGE.length-1]!==11)
              throw Error('Native AI hook layout changed.');
            const fn=join(BRIDGE.subarray(0,BRIDGE.length-1),old.subarray(a.end));
            pieces.push(leb(fn.length),fn);changed++;
          }else if(i===PACE_TARGET){
            const old=bytes.subarray(fnStart,fnEnd);
            if(locals(old).types.length!==1 || old[old.length-1]!==11 || PACE[PACE.length-1]!==11)
              throw Error('Native AI pace hook layout changed.');
            pieces.push(leb(PACE.length),PACE);changed++;
          }else if(i===WALL_TARGET){
            const old=bytes.subarray(fnStart,fnEnd),a=locals(old),b=locals(WALL);
            if(a.types.length!==1 || a.types[0]!==127 || b.types.length!==19 || b.types[0]!==127 || old[old.length-1]!==11 || WALL[WALL.length-1]!==11)
              throw Error('Wall contact hook layout changed.');
            const fn=join(WALL.subarray(0,WALL.length-1),old.subarray(a.end));
            pieces.push(leb(fn.length),fn);changed++;
          }else pieces.push(bytes.subarray(sizeAt,fnEnd));
          p.i=fnEnd;
        }
        if(changed!==4 || p.i!==end)throw Error('Native AI hooks were not found.');
        const section=join(...pieces);
        output=join(bytes.subarray(0,start),Uint8Array.of(10),leb(section.length),section,bytes.subarray(end));
        break;
      }
      p.i=end;
    }
    if(!output)throw Error('Native AI hook was not found.');
    return output;
  }
  function patchDragSelector(old,config) {
    const a=locals(old),off=config.offset;
    if(old.length!==config.originalLength || a.types.length!==4 || a.types.some(t=>t!==127) || old[off]!==65 || old[off+1]!==3)
      throw Error('Native drag selector layout changed.');
    // The exact module hash pins the site; preserve every other native instruction.
    return join(Uint8Array.of(1,config.locals,127),old.subarray(a.end,off),Uint8Array.from(config.expression),old.subarray(off+2));
  }
  function patchOwnedNosBody(old,config) {
    const a=locals(old),off=config.offset,expected=config.originalTypes.map(t=>({i32:127,f32:125,f64:124}[t]));
    if(old.length!==config.originalLength || a.types.length!==expected.length || a.types.some((t,i)=>t!==expected[i]) || old[off-3]!==65 || old[off-2]!==2 || old[off-1]!==71)
      throw Error('Native nitrous gate layout changed.');
    // Keep the original type2 comparison, then optionally accept the guarded owned player.
    return join(Uint8Array.from(config.header),old.subarray(a.end,off),Uint8Array.from(config.expression),old.subarray(off));
  }
  function patchCurrent(bytes,profile) {
    const bridge=Uint8Array.from(profile.bridge),p={i:8};
    while(p.i<bytes.length){
      const start=p.i,id=bytes[p.i++],size=read(bytes,p),begin=p.i,end=begin+size;
      if(end>bytes.length)throw Error('Invalid current module section');
      if(id===10){
        const n=read(bytes,p),pieces=[bytes.subarray(begin,p.i)];let changed=0;
        for(let i=0;i<n;i++){
          const at=p.i,len=read(bytes,p),body=p.i,stop=body+len;
          if(stop>end)throw Error('Invalid current function');
          const nos=profile.capabilities.ownedNativeNos && profile.ownedNos.find(c=>c.target===i);
          if(nos){
            const fn=patchOwnedNosBody(bytes.subarray(body,stop),nos);pieces.push(leb(fn.length),fn);changed++;
          }else if(profile.capabilities.opponentDrag && i===profile.dragSelector.target){
            const fn=patchDragSelector(bytes.subarray(body,stop),profile.dragSelector);pieces.push(leb(fn.length),fn);changed++;
          }else if(i===profile.target){
            const old=bytes.subarray(body,stop),a=locals(old),b=locals(bridge);
            if(a.types.length!==31||b.types.length!==profile.locals||a.types.some((v,k)=>v!==b.types[k])||old[old.length-1]!==11||bridge[bridge.length-1]!==11)throw Error('Current AI hook layout changed.');
            const fn=join(bridge.subarray(0,bridge.length-1),old.subarray(a.end));pieces.push(leb(fn.length),fn);changed++;
          }else if(profile.capabilities.pace && i===profile.pace.target){
            const old=bytes.subarray(body,stop),replacement=Uint8Array.from(profile.pace.bridge);
            if(locals(old).types.length!==1||old[old.length-1]!==11||replacement[replacement.length-1]!==11)throw Error('Current pace hook layout changed.');
            pieces.push(leb(replacement.length),replacement);changed++;
          }else if(profile.capabilities.corner && i===CORNER.index-37){
            const fn=patchCornerBody(bytes.subarray(body,stop));pieces.push(leb(fn.length),fn);changed++;
          }else if(profile.capabilities.walls && i===profile.wall.target){
            const old=bytes.subarray(body,stop),replacement=Uint8Array.from(profile.wall.bridge),a=locals(old),b=locals(replacement);
            if(a.types.length!==1||a.types[0]!==127||b.types.length!==19||b.types[0]!==127||old[old.length-1]!==11||replacement[replacement.length-1]!==11)throw Error('Current wall hook layout changed.');
            const fn=join(replacement.subarray(0,replacement.length-1),old.subarray(a.end));pieces.push(leb(fn.length),fn);changed++;
          }else pieces.push(bytes.subarray(at,stop));
          p.i=stop;
        }
        if(changed!==1+(profile.capabilities.ownedNativeNos?profile.ownedNos.length:0)+Number(!!profile.capabilities.opponentDrag)+Number(profile.capabilities.pace)+Number(profile.capabilities.corner)+Number(profile.capabilities.walls)||p.i!==end)throw Error('Current AI hook was not found.');
        const section=join(...pieces);return join(bytes.subarray(0,start),Uint8Array.of(10),leb(section.length),section,bytes.subarray(end));
      }
      p.i=end;
    }
    throw Error('Current code section was not found.');
  }
  function install() {
    if(installed || typeof WebAssembly.compileStreaming!=='function')return;
    installed=true;
    const nativeStreaming=WebAssembly.compileStreaming, nativeCompile=WebAssembly.compile;
    WebAssembly.compileStreaming=async function(source,options){
      const response=await source;
      let url;try{url=new URL(response.url);}catch{return nativeStreaming.call(WebAssembly,response,options);}
      if(url.origin!==location.origin || url.pathname!=='/game.wasm')return nativeStreaming.call(WebAssembly,response,options);
      const generation=++loadGeneration,state={phase:'preparing',reason:'Preparing native AI bridge.'};
      // Concurrent loads keep independent facts; only the newest observed load publishes diagnostics.
      const publish=()=>{if(generation!==loadGeneration)return;for(const key of Object.keys(patchState))delete patchState[key];Object.assign(patchState,state);};
      publish();
      let stage='module-read';
      try{
        const bytes=await response.clone().arrayBuffer();
        state.moduleBytes=bytes.byteLength;
        const candidate=profileForSize(bytes.byteLength);
        if(candidate)state.candidateRevision=candidate.revision;
        // Read-only fingerprint coverage. It never grants compatibility or changes hooks.
        const scanner=root.__NFSU2_SIGNATURES__,references=[root.__NFSU2_SIGNATURE_PROFILE__,root.__NFSU2_SIGNATURE_PROFILE_LATEST__,root.__NFSU2_SIGNATURE_PROFILE_NEXT__].filter(Boolean);
        if(scanner?.scanAll&&references.length)try{
          const result=await scanner.scanAll(bytes,references),summary=result.bestReference;
          state.moduleHash=summary.moduleSha256;
          Object.assign(state,{signatureReference:summary.referenceRevision,signatureExact:summary.referenceModuleMatches,signatureTotal:summary.anchors,signatureUnique:summary.unique,signatureAmbiguous:summary.ambiguous,signatureMissing:summary.missing});
        }catch{state.signatureFailed=true;}
        stage='module-layout';
        const changed=await patchBytes(bytes);
        stage='module-compile';
        const module=await nativeCompile.call(WebAssembly,changed,options);
        const profile=profileForSize(bytes.byteLength);patched.set(module,profile);state.phase='ready';state.revision=profile.revision;state.reason='Verified game module · native AI bridge loaded.';
        publish();return module;
      }catch(e){
        state.phase='unavailable';state.reason=String(e?.message || 'Native AI could not be prepared.');
        state.patchCode=['module-size','module-hash'].includes(e?.patchCode)?e.patchCode:stage;
        if(typeof e?.moduleHash==='string'&&/^[a-f0-9]{64}$/.test(e.moduleHash))state.moduleHash=e.moduleHash;
        // Fail open to the unchanged game, closed to AI control. All memory-writing tools still require a verified module profile.
        publish();return nativeStreaming.call(WebAssembly,response,options);
      }
    };
  }
  class Controller {
    constructor(memory,available=false,capabilities=LEGACY.capabilities){this.memory=memory;this.available=!!available;this.capabilities=capabilities;this.hb=0;this.words=null;this.view=null;this.requestTarget=null;this.handbackPending=false;this.handbackHeartbeat=0;}
    refresh(){const b=this.memory.buffer;if(!this.view || this.view.buffer!==b){this.view=new DataView(b);this.words=new Int32Array(b);}return b.byteLength>=(this.capabilities.corner?CORNER.commandBase+44:BASE+92);}
    u32(p){return p>=0x10000 && p+4<=Math.min(this.view.byteLength,0x28000000)?this.view.getUint32(p,true):0;}
    read(off){return Atomics.load(this.words,(BASE+off)/4)>>>0;}
    write(off,v){Atomics.store(this.words,(BASE+off)/4,v|0);}
    publish(wanted=0,player=0,car=0,race=0,pace=1,allowNetwork=false,allowDragAI=false,cornerAssist=false,cornerFactor=0.8,cornerMargin=0){
      if(!this.available || !this.refresh() || this.read(28)!==MAGIC)return false;
      pace=this.capabilities.pace?pace:1;allowDragAI=this.capabilities.dragAI&&allowDragAI;cornerAssist=this.capabilities.corner&&cornerAssist;
      let seq=this.read(4);if(seq&1)seq++;
      this.write(4,seq+1);this.write(0,MAGIC);this.write(8,wanted);this.write(12,player);this.write(16,car);this.write(20,race);
      this.write(60,Number.isFinite(pace) && pace>=0.75 && pace<=3 ? Math.round(pace*100) : 100);
      this.write(84,allowNetwork === true ? 1 : 0);this.write(88,allowDragAI === true ? 1 : 0);
      if(this.capabilities.corner){
      const cornerOn=cornerAssist===true && wanted===2 && this.u32(0x89e7b0)===0 && !this.view.getUint8(0x89e7d8);
      const percent=Number.isFinite(cornerFactor)&&cornerFactor>=0.6&&cornerFactor<=0.95?Math.round(cornerFactor*100):80;
      const margin=Number.isFinite(cornerMargin)&&cornerMargin>=0&&cornerMargin<=25?Math.round(cornerMargin):0;
      const cr=off=>Atomics.load(this.words,(CORNER.commandBase+off)/4)>>>0,cw=(off,v)=>Atomics.store(this.words,(CORNER.commandBase+off)/4,v|0);
      const cornerOwned=cr(0)===CORNER.commandMagic,cornerEmpty=Array.from({length:11},(_,i)=>cr(i*4)).every(v=>v===0);
      if(cornerOwned||cornerEmpty){
      if(cr(0)!==CORNER.commandMagic || cr(4)!==Number(cornerOn) || cr(8)!==percent || cr(36)!==margin || (cr(12)&&cr(12)!==car)){
        for(let off=12;off<36;off+=4)cw(off,0);cw(40,0);
      }
      cw(0,CORNER.commandMagic);cw(4,Number(cornerOn));cw(8,percent);cw(36,margin);}}
      this.write(24,++this.hb);this.write(4,seq+2);return true;
    }
    stop(){this.publish(0);return this.status();}
    releaseForSwap(){
      this.publish(0);this.handbackHeartbeat=this.hb;
      const current=this.status();
      return current.available ? {...current,switching:true,status:'switching',reason:'Changing native event behavior or corner settings · waiting for native handback.'} : current;
    }
    update({enabled=false,safe=false,state=null,mode=0,pace=1,allowNetwork=false,allowDragAI=false,cornerAssist=false,cornerFactor=0.8,cornerMargin=0}={}){
      this.refresh();
      allowDragAI=this.capabilities.dragAI&&allowDragAI;cornerAssist=this.capabilities.corner&&cornerAssist;pace=this.capabilities.pace?pace:1;
      const player=this.u32(0xd00000);
      const wanted=!!enabled && !!safe && state?.ready && state.driving && (!state.network || allowNetwork === true) && (!state.drag || allowDragAI === true) && (mode===1 || mode===2) && this.u32(player+4)===state.car;
      // A race can change type while reusing player/car/race pointers. Never
      // retain the previous mode's physics: release our native driver first.
      // Keep the remembered target across pause/stop, so a quick re-enable or
      // transition cannot hide an unprocessed native handback request.
      if(wanted){
        const raceType=this.u32(0x89e7b0),cornerOn=cornerAssist===true && mode===2 && raceType===0 && !state.drag;
        const cornerPercent=Number.isFinite(cornerFactor)&&cornerFactor>=0.6&&cornerFactor<=0.95?Math.round(cornerFactor*100):80;
        const margin=Number.isFinite(cornerMargin)&&cornerMargin>=0&&cornerMargin<=25?Math.round(cornerMargin):0;
        // Native planned caps are cached: rebuild the private route on every
        // effective corner-profile/category change, never merely reissue ON.
        // These native race parameter / forced-mode flags select or specialize
        // the game's driver. Track identity also catches a new event reusing
        // every object pointer. We request reconstruction; never fake an
        // opponent racer type or substitute an extension steering algorithm.
        const event=[this.u32(0x89e7a0),this.u32(0x89e7b4),
          ...[0x89e7d8,0x89e7d9,0x89e7e1,0x89e7e3].map(a=>this.view.getUint8(a)),
          this.u32(0x890104),this.u32(0x890108),this.u32(0x89010c),this.u32(0x890114)];
        const target=[player,state.car,state.race,state.drag?'drag':'native',mode,raceType,...event,cornerOn?cornerPercent:0,cornerOn?margin:0].join(':');
        const changed=this.requestTarget!==null && this.requestTarget!==target;
        if(changed)this.handbackPending=true;
        this.requestTarget=target;
        if(changed)return this.releaseForSwap();
        if(this.handbackPending){
          const current=this.status();
          // Heartbeat observation precedes native command processing. Require
          // the failed-car latch to be cleared too, or ON could overtake OFF.
          if(!current.ready || current.owned || !current.manual || this.read(72)!==0 || this.read(44)!==(this.handbackHeartbeat>>>0))return this.releaseForSwap();
          this.handbackPending=false;
        }
      }
      this.publish(wanted?mode:0,player,state?.car||0,state?.race||0,pace,allowNetwork,allowDragAI,cornerAssist,cornerFactor,cornerMargin);
      return this.status();
    }
    status(){
      if(!this.available)return {available:false,ready:false,active:false,level:null,status:'unavailable',reason:patchState.reason==='Waiting for game module.'?'Reload the game after updating the extension.':patchState.reason};
      if(!this.refresh() || this.read(28)!==MAGIC)return {available:true,ready:false,active:false,level:null,status:'waiting',reason:'Waiting for the native game loop.'};
      const owned=this.read(36),player=this.u32(0xd00000),car=this.u32(player+4),code=this.read(52);
      const drag=!!this.view.getUint8(0x89e7d8),dragEnabled=this.read(88)===1;
      const valid=p=>p>=0x10000 && p+4096<Math.min(this.view.byteLength,0x28000000);
      const record=this.u32(car+20);
      const driftPhysicsRequired=!!this.capabilities.nativeDriftPhysics&&!drag&&!this.u32(0x890108)&&!!(this.u32(0x890114)||this.view.getUint8(0x89e7d9)||this.u32(0x890104))&&valid(record)&&this.u32(record+4)===1&&this.view.getUint8(record+0x900)===0;
      const candidateDriver=this.u32(car+44);
      const driftDriverValid=valid(candidateDriver)&&this.u32(candidateDriver)===0x785370&&this.u32(candidateDriver+4)===car;
      const active=(!driftPhysicsRequired||driftDriverValid)&&(!(drag||driftPhysicsRequired) || this.u32(car+0x28)===1) && !!owned && owned===car && this.read(32)===player && this.u32(car+0x24)===3 && code===1;
      const driver=active?this.u32(car+0x2c):0;
      const action=valid(driver)&&this.u32(driver)===0x785370&&this.u32(driver+4)===car?this.u32(driver+0x6fc):0;
      const actionId=valid(action)?this.u32(action+20):null;
      const opponentDragSelected=active&&drag&&actionId===2&&this.u32(action)===0x7847d0;
      const dragConfigUnavailable=active&&drag&&actionId===3&&valid(action)&&this.u32(action)===0x784830&&(!valid(driver)||!valid(this.u32(driver+0x6e0)));
      const dragSelection=opponentDragSelected?'opponent':!this.capabilities.opponentDrag?'unsupported':actionId===3?'player':actionId===null?'pending':'native-temporary';
      const rec=active?this.u32(car+0x14):0,manual=!!car && this.u32(car+0x24)===1;
      const cr=off=>this.capabilities.corner?Atomics.load(this.words,(CORNER.commandBase+off)/4)>>>0:0;
      const cornerMemoryBlocked=!!this.capabilities.corner && cr(0)!==CORNER.commandMagic && Array.from({length:11},(_,i)=>cr(i*4)).some(v=>v!==0);
      const cornerDriftBlocked=!!this.capabilities.corner && !!(this.view.getUint8(0x89e7d9)||this.u32(0x890104));
      const cornerRequested=cr(0)===CORNER.commandMagic && cr(4)===1 && this.read(8)===2 && this.u32(0x89e7b0)===0 && !drag;
      const cornerHits=cornerRequested && cr(12)===car?cr(16):0,cornerFactor=cr(8)/100;
      const cornerMargin=cr(36),cornerConfirmed=active && cornerRequested && cornerHits && cr(32)===cr(8) && cr(40)===cornerMargin;
      const before=this.capabilities.corner?this.view.getFloat32(CORNER.commandBase+20,true):0,after=this.capabilities.corner?this.view.getFloat32(CORNER.commandBase+24,true):0;
      const actualFactor=Number.isFinite(before)&&Number.isFinite(after)&&before>0&&after>0&&after<=before?after/before:null;
      const cornerApplied=cornerConfirmed?(cornerMargin===0?cr(32)/100:actualFactor):null;
      const level=rec>=0x10000 && rec+0x902<Math.min(this.view.byteLength,0x28000000)?this.view.getUint8(rec+0x901):null;
      return {available:true,ready:true,active,owned:!!owned,manual,driftPhysicsRequired,actionId,opponentDragSelected,dragSelection,dragConfigUnavailable,cornerRequested,cornerMemoryBlocked,cornerDriftBlocked,cornerFactor,cornerMargin,cornerApplied,cornerHits,dragUnsupported:drag && !dragEnabled,dragExperimental:drag && dragEnabled,level,paceRequested:this.read(60)/100,paceApplied:active && !drag && this.read(80) && this.read(76)>=75 && this.read(76)<=300 ? this.read(76)/100 : null,status:drag && !dragEnabled?'unsupported':active?'active':code===3?'failed':'ready',reason:drag && !this.capabilities.dragAI?'Automatic drag AI is not verified for this build. Use manual control.':drag && !dragEnabled?'Drag AI is not requested. Enable Automatic AI driver; manual drag assist is available.':active && drag?`Experimental drag AI${level===9?' · level 9':' · unusual skill left unchanged'} · ${opponentDragSelected?'opponent drag action confirmed':dragSelection==='unsupported'?'opponent selector unsupported on this build':dragConfigUnavailable?'player drag action; config unavailable, opponent selection pending':actionId===3?'player drag action; opponent selection pending':'native action '+(actionId??'pending')+'; opponent selection pending'}, gameplay unverified.`:active&&driftPhysicsRequired?`Native drift driver and physics 1 confirmed${level===9?' · level 9':''}; gameplay unverified.`:active?`Native game AI driving${level===9?' · level 9':' · unusual skill value left unchanged'}.`:code===3?'The game did not hand over the car. Turn AI off before retrying.':drag?'Experimental drag AI waiting for full driving physics after GO.':'Ready for automatic native/drag selection; online needs its separate opt-in.'};
    }
  }
  const api={Controller,install,patchState,isPatchedModule:module=>patched.has(module),getModuleProfile:module=>patched.get(module)||null,patchBytes,patchCornerBody,patchDragSelector,patchOwnedNosBody,BASE,MAGIC,CORNER_BASE:CORNER.commandBase,CORNER_MAGIC:CORNER.commandMagic};
  root.__NFSU2_AI__=api;
  if(typeof module==='object' && module.exports)module.exports=api;
})(globalThis);

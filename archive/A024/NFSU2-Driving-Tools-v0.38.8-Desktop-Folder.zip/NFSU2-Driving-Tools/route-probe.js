(function(root){
'use strict';
// Bounded read-only metadata reader. No native calls, memory writes, logging, hooks,
// timers, downloads, arming state, or control/pacing authorization.
const Profiles=root.__NFSU2_FORWARD_NATIVE_CONFIG__||(typeof require==='function'?require('./forward-native-config.js'):null);
const PIN='ed47e9bdd94a336d8d6bd52bebcc6f130b40ffb6d692f0fc728b8785db02178c';
const REVISION='3bdd9959',BITMAP=0x29779ac0,CEILING=0x28000000,PAGE=16384;
const AI=0xd0d100,MAGIC=0x3749414e,MAX_NODES=40,MAX_VTABLES=2,SLOTS=16,MAX_READ=65536;
const VTABLES=new Set([0x784a48,0x784aa0]);
const CODE_MIN=0x401000,CODE_MAX=0x782af0;
// Fixed denial identifiers only. Never derive telemetry from error text,
// pointers, object names, route positions or caller-provided numbers.
const guardReasons=Object.freeze(['reader-error','shared-game-memory-required','current-commit-bitmap-unavailable','guest-range','uncommitted-page','unaligned-pointer','read-budget','memory-buffer-changed','commit-state-changed','snapshot-changed','exact-current-module-required','expected-pace-required','focused-page-required','active-owned-road-ai-required','solo-road-race-required','online-host-context-unavailable','invalid-network-permission','online-permission-required','special-race-excluded','driving-owner-context-required','ai-owner-mismatch','native-driver-mismatch','private-main-route-required','pace-not-settled','native-route-capacity','track-identity-mismatch','region-identity-mismatch','career-heat-identity','career-heat-layout-mismatch','duplicate-route-node','node-distance-order','unsupported-node-vtable','vtable-budget','query-evaluator-slot-invalid','road-index-range','canonical-road-group','canonical-road-owner','non-finite-road-reference','non-finite-physical-position','non-finite-velocity','non-finite-heading','native-direction-invalid','online-context-changed']);
const guardCodes=Object.freeze({...Object.fromEntries(guardReasons.map((reason,i)=>[reason,100+i])),'node-owner-mismatch':143});
class Unavailable extends Error{constructor(reason){super(reason);this.name='RouteProbeUnavailable';this.reason=reason;}}
const unavailable=reason=>({status:'unavailable',reason,forwardGuardCode:guardCodes[reason]??100,wholeRaceChecked:false});
const fail=reason=>{throw new Unavailable(reason);};
function reader(memory,bitmap=BITMAP){
 const buffer=memory?.buffer;
 if(!buffer||!['[object SharedArrayBuffer]','[object ArrayBuffer]'].includes(Object.prototype.toString.call(buffer)))fail('shared-game-memory-required');
 if(Object.prototype.toString.call(buffer)!=='[object SharedArrayBuffer]')fail('shared-game-memory-required');
 const view=new DataView(buffer),reads=[],pages=new Set();let bytes=0;
 if(buffer.byteLength<bitmap+32768)fail('current-commit-bitmap-unavailable');
 function range(p,n){
  if(!Number.isSafeInteger(p)||!Number.isSafeInteger(n)||p<65536||n<1||p+n>Math.min(CEILING,buffer.byteLength))fail('guest-range');
  for(let q=Math.floor(p/PAGE)*PAGE;q<p+n;q+=PAGE){const pg=q/PAGE;if(!((view.getUint8(bitmap+(pg>>>3))>>>(pg&7))&1))fail('uncommitted-page');pages.add(pg);}
 }
 function take(p,n){range(p,n);if((bytes+=n)>MAX_READ)fail('read-budget');const copy=Uint8Array.from(new Uint8Array(buffer,p,n));reads.push({p,copy});return new DataView(copy.buffer);}
 function ptr(p,n=4){if(p%4)fail('unaligned-pointer');range(p,n);return p;}
 const u32=p=>take(p,4).getUint32(0,true),u8=p=>take(p,1).getUint8(0),f32=p=>take(p,4).getFloat32(0,true);
 return{buffer,view,take,ptr,u32,u8,f32,
  finish(){if(memory.buffer!==buffer)fail('memory-buffer-changed');
   for(const pg of pages)if(!((view.getUint8(bitmap+(pg>>>3))>>>(pg&7))&1))fail('commit-state-changed');
   for(const{p,copy}of reads){const live=new Uint8Array(buffer,p,copy.length);for(let i=0;i<copy.length;i++)if(live[i]!==copy[i])fail('snapshot-changed');}
   return{method:'equal-double-read',nativeSafePoint:false,abaExcluded:false,readBytes:bytes,checkedPages:pages.size};
  }};
}
const finite=(values,reason)=>{if(!values.every(Number.isFinite))fail(reason);return values;};
function capture(memory,{verified=false,moduleHash,expectedPace,allowNetwork=false}={}){
 try{
  // The caller supplies the existing loader's exact verified profile, bound to
  // this memory/session. These arguments do not perform binary verification.
  const profile=Profiles?.select?.(moduleHash);if(verified!==true||!profile)fail('exact-current-module-required');
  if(!Number.isFinite(expectedPace)||expectedPace<.75||expectedPace>3||Math.abs(expectedPace*100-Math.round(expectedPace*100))>1e-5)fail('expected-pace-required');
  if(root.document&&(root.document.visibilityState!=='visible'||!root.document.hasFocus()))fail('focused-page-required');
  const r=reader(memory,profile.runtime.bitmap),u=r.u32,b=r.u8,[onlineOnAddress,netOkAddress,inRoamAddress]=profile.runtime.onlineAddresses;
  const command=r.take(AI,104),a=o=>command.getUint32(o,true),sequence=a(4);
  if(a(0)!==MAGIC||a(28)!==MAGIC||!sequence||(sequence&1)||a(8)!==1||a(52)!==1)fail('active-owned-road-ai-required');
  if(u(0x8654a4)!==6||u(0xd00030)!==1||u(0x89e7b0)!==1)fail('solo-road-race-required');
  const hostRead=(p,n=4)=>{if(p+n>r.buffer.byteLength)fail('online-host-context-unavailable');const data=Uint8Array.from(new Uint8Array(r.buffer,p,n));hostReads.push({p,n,data});return n===1?data[0]:new DataView(data.buffer).getUint32(0,true);};
  const hostReads=[],network={permission:a(84),mode:u(0x850078),host:u(0x866a14),client:u(0x8669f4),online:b(0x89cf69),category:u(0x850088),nativeOnlineOn:hostRead(onlineOnAddress),nativeNetOk:hostRead(netOkAddress,1),nativeInRoam:hostRead(inRoamAddress)};
  if(network.permission>1)fail('invalid-network-permission');
  const isNetwork=!!((network.mode&520)||network.host||network.client||network.online||(network.nativeOnlineOn&&network.nativeNetOk&&network.nativeInRoam));
  if(isNetwork&&(allowNetwork!==true||network.permission!==1))fail('online-permission-required');if(isNetwork&&network.category===10)fail('special-race-excluded');
  if(b(0x89e7d8)||b(0x89e7d9)||b(0x89e7e3)||u(0x890104)||u(0x890108)||u(0x89010c)||u(0x890114))fail('special-race-excluded');
  const player=r.ptr(u(0xd00000),20),pv=r.take(player,20),car=r.ptr(pv.getUint32(4,true),0x9c),cv=r.take(car,0x9c),race=r.ptr(u(0x890118),24),rv=r.take(race,24);
  if(pv.getUint32(16,true)!==0||cv.getUint32(0x24,true)!==3||rv.getUint32(0,true)!==4)fail('driving-owner-context-required');
  if(a(12)!==player||a(16)!==car||a(20)!==race||a(32)!==player||a(36)!==car||a(40)!==race)fail('ai-owner-mismatch');
  const driver=r.ptr(cv.getUint32(0x2c,true),20),dv=r.take(driver,20);
  if(dv.getUint32(0,true)!==0x785370||dv.getUint32(4,true)!==car)fail('native-driver-mismatch');
  const route=u(driver+0x6e8);
  if(route!==driver+0x370)fail('private-main-route-required');
  r.ptr(route,0xd4);
  const requested=a(60)/100,applied=a(76)/100,native=r.f32(driver+0x770);
  // AA target consumers leave the game's cache native. The selected factor
  // must still have a settled acknowledgement, while the independent native
  // base must satisfy the same finite0..4 contract as those consumers.
  const nativePaceSettled=profile.capabilities.nativePaceTargetConsumers===true?native>=0&&native<=4:Math.abs(native-Math.fround(expectedPace))<=1e-6;
  if(!a(80)||requested!==expectedPace||applied!==expectedPace||!Number.isFinite(native)||!nativePaceSettled)fail('pace-not-settled');
  const count=u(route+4),cornerCount=u(route+0xd0);
  if(count<1||count>MAX_NODES||cornerCount>5)fail('native-route-capacity');
  const nodePointers=r.take(route+8,count*4),seenNodes=new Set(),vtables=[],byVtable=new Map(),nodes=[];
  const track=u(0x89e7a0),reverse=u(0x89e7a4),trackInfo=r.ptr(u(0x883dac),0x8c),ti=r.take(trackInfo,0x8c);
  if(track<1||track>65535||reverse>1||ti.getUint16(0x8a,true)!==track)fail('track-identity-mismatch');
  const regionBytes=Array.from({length:8},(_,i)=>ti.getUint8(0x40+i)),nul=regionBytes.indexOf(0),region=String.fromCharCode(...regionBytes.slice(0,nul<0?8:nul));
  if(!/^L4R[A-Z]$/.test(region))fail('region-identity-mismatch');
  const starts=u(0x86346c),event=u(0x863470);let eventIdentity={kind:'quick-or-noncareer',pointer:0,hash:null,starts,heat:null};
  if(event){
   const ev=r.take(r.ptr(event,0x88),0x88),hash=ev.getUint32(8,true),eventCount=ev.getInt8(0x7e),heatCount=u(0x85ef4c),heat=u(0x85ef48),delta=heat-0x85bab8;
   if(!hash||eventCount<1||eventCount>4||heatCount!==eventCount||delta<0||delta%0xd24||delta/0xd24>=heatCount)fail('career-heat-identity');
   const index=delta/0xd24,hv=r.take(r.ptr(heat,12),12),tuple=0x18+4*index;
   if(hv.getInt32(0,true)!==track||hv.getInt32(4,true)!==reverse||ev.getInt16(tuple,true)!==track||(ev.getUint8(tuple+2)&1)!==reverse||hv.getInt32(8,true)!==ev.getInt8(tuple+3))fail('career-heat-layout-mismatch');
   eventIdentity={kind:'career',pointer:event,hash:hash.toString(16).padStart(8,'0'),starts,heat:{pointer:heat,index,count:heatCount,laps:hv.getInt32(8,true)}};
  }
  let previous=-Infinity;
  for(let index=0;index<count;index++){
   const pointer=r.ptr(nodePointers.getUint32(index*4,true),120);
   if(seenNodes.has(pointer))fail('duplicate-route-node');seenNodes.add(pointer);
   const nv=r.take(pointer,120),vtable=nv.getUint32(0,true),distance=nv.getFloat32(0x54,true),nativeOffset=nv.getFloat32(0x58,true);
   if(nv.getUint32(0x64,true)!==route)fail('node-owner-mismatch');
   if(!Number.isFinite(distance)||!Number.isFinite(nativeOffset)||distance<=previous)fail('node-distance-order');previous=distance;
   if(!VTABLES.has(vtable))fail('unsupported-node-vtable');
   if(!byVtable.has(vtable)){
    if(vtables.length>=MAX_VTABLES)fail('vtable-budget');
    const table=r.take(r.ptr(vtable,SLOTS*4),SLOTS*4),slots=Array.from({length:SLOTS},(_,slot)=>{const address=table.getUint32(slot*4,true);return{offset:slot*4,address,kind:address>=CODE_MIN&&address<=CODE_MAX?'native-code-address':address===0?'null':'unclassified-address'};});
    if(slots[14].kind!=='native-code-address')fail('query-evaluator-slot-invalid');
    const entry={pointer:vtable,slots};byVtable.set(vtable,vtables.length);vtables.push(entry);
   }
   const group=nv.getInt16(0x5c,true),nodeIndex=nv.getInt16(0x5e,true);
   if(group<0||group>=1500||nodeIndex<0)fail('road-index-range');
   const groupPointer=r.ptr(u(0x88a334+group*4),140),header=r.take(groupPointer,140),roadCount=header.getInt16(0x34,true);
   if(header.getInt16(10,true)!==group||roadCount<1||roadCount>4096||nodeIndex>=roadCount)fail('canonical-road-group');
   const road=r.ptr(groupPointer+140+nodeIndex*56,56),roadView=r.take(road,56);
   if((roadView.getUint32(12,true)&2047)!==group)fail('canonical-road-owner');
   const reference=finite([roadView.getFloat32(0,true),roadView.getFloat32(4,true),roadView.getInt16(0x12,true)/8],'non-finite-road-reference');
   nodes.push({index,pointer,vtable,vtableIndex:byVtable.get(vtable),distance,nativeOffset,
    road:{pointer:road,group,index:nodeIndex,groupPointer,count:roadCount,reference,tangent:[roadView.getInt16(0x18,true)/32767,roadView.getInt16(0x1a,true)/32767]}});
  }
  const xyz=finite([0x60,0x64,0x68].map(o=>cv.getFloat32(o,true)),'non-finite-physical-position'),velocity=finite([0x70,0x74,0x78].map(o=>cv.getFloat32(o,true)),'non-finite-velocity'),heading=finite([0x90,0x94,0x98].map(o=>cv.getFloat32(o,true)),'non-finite-heading');
  const tick=u(0x86518c),clock=rv.getUint32(0x14,true),direction=dv.getUint8(0x10);
  if(direction>1)fail('native-direction-invalid');
  const consistency=r.finish();consistency.readBytes+=hostReads.reduce((n,h)=>n+h.n,0);consistency.checkedHostSpans=hostReads.length;if(consistency.readBytes>MAX_READ)fail('read-budget');for(const h of hostReads){const live=new Uint8Array(r.buffer,h.p,h.n);if(h.data.some((x,i)=>x!==live[i]))fail('online-context-changed');}if(memory.buffer!==r.buffer)fail('memory-buffer-changed');
  return{status:'captured',schema:'nfsu2-owned-route-vtable-v1',revision:profile.revision,moduleHash:profile.moduleHash,
   identity:{sequence,player,car,driver,route,race,track,reverse:!!reverse,region,tick,raceClock:clock,event:eventIdentity,network},
   pace:{expected:expectedPace,requested,applied,native,baselinePace:expectedPace===1},
   physical:{xyz,velocity,heading,plannedRoadPointer:dv.getUint32(12,true),nativeDirection:direction,progressVerified:false},
   nodeCount:count,cornerCount,nodes,vtables,consistency,
   capabilities:{metadataOnly:true,nativeCalls:false,memoryWrites:false,finalRacingLineVerified:false,forwardOrderVerified:false,horizonVerified:false,authorizesPacing:false},wholeRaceChecked:false};
 }catch(e){if(e instanceof Unavailable)return unavailable(e.reason);return unavailable('reader-error');}
}
const api=Object.freeze({capture,PIN,REVISION,BITMAP,CEILING,MAX_NODES,MAX_VTABLES,SLOTS,AI,MAGIC,guardCodes});
if(typeof module==='object'&&module.exports)module.exports=api;else root.__NFSU2_ROUTE_PROBE__=api;
})(globalThis);

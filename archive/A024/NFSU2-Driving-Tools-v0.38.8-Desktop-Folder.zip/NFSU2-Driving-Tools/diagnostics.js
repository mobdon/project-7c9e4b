/* Local, schema-only diagnostics. No console interception, requests or uploads. */
(function (root) {
  'use strict';
  const KEY = 'nfsu2-driving-tools-diagnostics-v1';
  const TRACE_KEY='nfsu2-driving-tools-race-trace-v1',TRACE_MS=250,TRACE_PERSIST_MS=2000,MAX_TRACE_SAMPLES=480,MAX_TRACE_BYTES=393216;
  const MAX_EVENTS = 180, MAX_BYTES = 65536, MAX_ERROR_INPUT = 16384;
  const MAX_DRIVING_SAMPLES=12,MAX_DRIVING_BYTES=16384;
  const EVENTS = new Set(['page-start','game-boot','game-register','game-trap','game-exit','worker-error','page-error','promise-rejection','engine-error','identity-change','state','tools','pause','resume','page-hide','manual','stop','export','clear','build','build-error','patch-state','dyno-action','dyno-error']);
  const FLAGS = ['ready','driving','network','safe','hidden','focused','aiActive','aiOwned','handbackPending','dynoBusy','dynoEnabled','wallRequested','carRequested','onlineTrafficRequested','onlinePlayersRequested','onlineRaceCarsRequested','cornerRequested','cornerMemoryBlocked','cornerDriftBlocked','cornerDriverValid','cornerRouteOwned','powerActive','gripActive','limiterRemoved','carChanged','raceChanged','playerChanged','sessionCurrent','supported','signatureExact','signatureFailed','driftRace','forcedDrift','driftVariant','aiDriverVerified','aiGoalPending','nativeDriftBehavior','nativeRoadBehavior'];
  const NUMBERS = {nativePaceFactor:[0,4],dragEngineHeat:[-1,2],dragEngineLimitRpm:[1000,30000],signatureTotal:[0,128],signatureUnique:[0,128],signatureMissing:[0,128],signatureAmbiguous:[0,128],moduleBytes:[0,4294967295],slot:[0,1024],tid:[0,1e6],code:[-2147483648,2147483647],kind:[0,100],generation:[0,1e6],memoryMiB:[0,65536],hud:[0,3],flow:[0,100],raceType:[0,100],racePhase:[0,100],driverKind:[0,100],physicsKind:[0,100],wallHits:[0,1e9],carHits:[0,1e9],trafficHits:[0,1e9],playerHits:[0,1e9],cornerMode:[0,3],cornerPace:[0.5,3],cornerBraking:[0.5,1],brakingHits:[0,4294967295],cornerHits:[0,4294967295],cornerApplied:[0,1],cornerProbeStage:[0,7],cornerRouteNodes:[0,40],cornerPlannerCorners:[0,40],cornerPlannerUsable:[0,5],cornerGuardMask:[0,255],effectivePower:[1,3],effectiveGrip:[1,2],requestedPace:[0.5,3],gameTicks:[0,4294967295],pageHeartbeat:[0,4294967295],nativeHeartbeatAck:[0,4294967295]};
  Object.assign(NUMBERS,{trackId:[0,65535],carRpm:[0,30000],carGear:[0,10],speedMps:[0,500],forwardMps:[-500,500],nativeSkill:[0,255],aiGoalId:[0,255],driftTargetMps:[-200,200]});
  FLAGS.push('dragHeatDisabled','dragEngineBlown','driftScoreLinked','driftCollisionLoss','aiGoalRecognized');
  Object.assign(NUMBERS,{driftScoreState:[0,4],driftMultiplier:[1,5],driftNextPoints:[0,1e9],driftPendingPoints:[0,1e9],driftBankedPoints:[0,1e9],driftRawRate:[0,1e6],driftLatchedSlipRad:[-Math.PI,Math.PI],currentRawRouteProgress:[-1,1e7],driftBestRawRouteProgress:[-1,1e7]});
  // Moving telemetry must not turn ordinary state sampling into per-tick
  // storage writes. Keep native scalar samples at two seconds unless a
  // discrete mode, controller, scoring-state or tool change needs a record.
  const MOVING_FIELDS=['gameTicks','pageHeartbeat','nativeHeartbeatAck','carRpm','speedMps','forwardMps','driftTargetMps','driftPendingPoints','driftBankedPoints','driftRawRate','driftLatchedSlipRad','currentRawRouteProgress','driftBestRawRouteProgress'];
  FLAGS.push('nativeTelemetry','dragRace','forcedDrag','nativeNavigationPresent','nativeNavigationValid','nativeConfigPresent','nativeConfigValid','nativeCompanionPresent','nativeCompanionValid','aiSkillSaved');
  Object.assign(NUMBERS,{nativeInputMode:[0,10],nativeNextInputMode:[0,10],nativeThrottle:[0,1],nativeHandbrake:[0,1],nativeBrake:[0,1],nativeSteering:[-32768,32767],nativeGearCommand:[-1,10],aiRequestedMode:[0,2],aiNativeStatus:[0,3],aiStaleTicks:[0,4294967295],savedNativeSkill:[0,255]});
  MOVING_FIELDS.push('cornerHits','brakingHits');
  MOVING_FIELDS.push('nativeThrottle','nativeHandbrake','nativeBrake','nativeSteering','aiStaleTicks');
  FLAGS.push('nosTelemetry','nosClockNetwork','nosTimestampActive');
  Object.assign(NUMBERS,{nosClockTicks:[0,4294967295],nosSinceTicks:[0,4294967295],nosFullTicks:[0,9999999],nosRemainingTicks:[0,9999999],nosElapsedTicks:[-4294967295,4294967295]});
  MOVING_FIELDS.push('nosClockTicks','nosSinceTicks','nosFullTicks','nosRemainingTicks','nosElapsedTicks');
  FLAGS.push('paceConfirmed','adaptiveRaceRequested','raceOnlyEligible','raceOnlyRequested','raceOnlyInputClear');
  Object.assign(NUMBERS,{paceApplied:[0.75,3],adaptiveRaceCeiling:[1,2],adaptiveRuntimePace:[.75,2],adaptiveClearanceM:[0,150]});
  MOVING_FIELDS.push('adaptiveRuntimePace','adaptiveClearanceM');
  FLAGS.push('forwardCaptured','nativeForwardGeometry','nativeForwardClamp','forwardUnavailable');
  Object.assign(NUMBERS,{forwardSamples:[0,48],forwardHorizon:[0,512.01],forwardPriorityTurns:[0,24],forwardRequestedTarget:[0,150],forwardLeaseTicks:[0,400],forwardFailureCode:[1,10]});
  Object.assign(NUMBERS,{forwardGuardCode:[11,143]});
  const FORWARD_GUARDS=new Set([11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,28,29,30,31,32,33,34,35,37,38,39,40,41,42,43,44,45,...Array.from({length:44},(_,i)=>100+i)]);
  MOVING_FIELDS.push('forwardState','forwardCaptured','forwardSamples','forwardHorizon','forwardPriorityTurns','forwardRequestedTarget','forwardLeaseTicks','forwardFailureCode');
  const FORWARD_STATES=new Set(['off','waiting','requested','unknown','armed','observed','native-fallback']);
  const PACING_STATES=new Set(['off','invalid','native-route','native-fallback','coverage-unknown','clearance-limited']);
  const ADAPTIVE_STATES=new Set(['off','invalid','unsupported','street-x','mode','network-permission','ai-off','paused','handoff','pace-pending','planner-pending','planner-observed','native-fallback','coverage-unknown','clearance-limited']);
  const POWER_STATUSES=new Set(['off','unsupported','not-ready','not-driving','network-permission','hidden','unfocused','menu','hud','drift-change','layout','settling','applied','neutral','changed','rejected','suspended','tuner-busy']);
  const TOOL_FLAGS = ['ai','raceOnlyAI','aiPace','raceCornerAssist','cornerAssist','racePace','walls','cars','traffic','players','online','nos','drag','dragNoBlowout','tester','boost','unlimit','grip','drift','dynoEnabled','adaptiveRace'];
  const TOOL_NUMBERS = {adaptiveRaceCeiling:[1,2],raceCornerFactor:[0.6,0.95],raceCornerMargin:[0,25],raceBraking:[0.5,1],paceFactor:[0.75,3],racePaceFactor:[0.75,3],cornerFactor:[0.6,0.95],cornerMargin:[0,25],power:[1,3],gripFactor:[1,2],rpm:[3000,10000]};
  const DYNO_STATUSES=new Set([0,1,2,3,4,5,6,8]);
  const DYNO_GUARDS=new Set([0,1,2,3,4,5,10,11,12,13,14,15,20,21,22,23,24,30,31,32,40,41,42,43,44,45,50,60,70,71,72,73,74]);
  const DYNO_SOURCE_PAIRS=new Set([12,13,14,15,23,24,25,34,35,45]);
  const ERROR_KINDS = new Set(['memory-bounds','unreachable','indirect-call','integer-divide','invalid-conversion','stack-overflow','out-of-memory','type-error','reference-error','syntax-error','other']);
  const PHASES = new Set(['idle','preparing','ready','unavailable','waiting','active','failed','unsupported']);
  const PATCH_CODES = new Set(['module-size','module-hash','module-read','module-layout','module-compile']);
  const REASONS = new Set(['blur','hidden','page-hide','manual','stop','game-stopped','build-unavailable','metadata','find','apply','restore','cancel','unknown']);
  FLAGS.push('streetXRace','forcedStreetX','onlineStreetX','planCurrentCorners','planClearanceAvailable','planClearanceObserved','forwardPlanAvailable','forwardPlanOverride');
  FLAGS.push('catchupDriverVerified','shortcutPolicyInstalled','shortcutPolicyRequested');
  Object.assign(NUMBERS,{catchupDriverFactor:[0,32],catchupCarFactor:[0,32]});
  MOVING_FIELDS.push('catchupDriverFactor','catchupCarFactor','catchupTelemetryStatus');
  Object.assign(NUMBERS,{producerFailureCode:[0,3],producerStage:[0,3],nativeRoadTarget:[-500,500],nativePaceRequested:[.75,3],nativePaceApplied:[.75,3],nativePaceHits:[0,4294967295],planClearanceTarget:[0,60],planInputSpeedMps:[0,500],planSelectedPace:[.75,3],forwardPlanReasonCode:[0,40],forwardPlanTarget:[0,150],forwardPlanConstraints:[0,24],forwardPlanKnots:[0,24],forwardLimitingDistance:[0,512.01],forwardLimitingAngle:[0,180],forwardLimitingCurvature:[0,100],forwardLimitingCurveTarget:[0,1e6],forwardLimitingEntryTarget:[0,1e6],forwardPlanGrip:[0,100],forwardPlanLateral:[0,1000],forwardPlanBrake:[0,1000]});
  MOVING_FIELDS.push('nativeRoadTarget','nativePaceHits','nativePaceRequested','nativePaceApplied','nativePaceFactor','paceApplied','cornerApplied','cornerRouteNodes','cornerPlannerCorners','cornerPlannerUsable','planClearanceTarget','planInputSpeedMps','planCurrentCorners','planClearanceAvailable','planClearanceObserved','planClearanceSource','forwardPlanAvailable','forwardPlanOverride','forwardPlanReasonCode','forwardPlanTarget','forwardPlanConstraints','forwardPlanKnots','forwardLimitingDistance','forwardLimitingAngle','forwardLimitingCurvature','forwardLimitingCurveTarget','forwardLimitingEntryTarget','forwardPlanGrip','forwardPlanLateral','forwardPlanBrake');
  const TRACE_ENUMS={
    rubberbandState:['off','unsupported','unavailable','unverified','protocol-error','waiting','applied','reset-pending','guarded-native','blocked'],
    traceStatus:['captured','unavailable'],
    nativeTelemetryStatus:['sampled','profile-unverified','state-unavailable','context-stale','drift-ineligible','context-changed'],
    nativeRoadTargetStatus:['sampled','driver-unverified','behavior-unverified','not-road','value-invalid'],
    nativePaceTelemetryStatus:['unavailable','mailbox-unready','unsupported','context-unowned','mailbox-invalid','mailbox-changed','sampled'],
    catchupTelemetryStatus:['unsupported','unavailable','mailbox-unready','context-invalid','context-changed','value-invalid','sampled'],
    cornerPlannerTelemetryStatus:['unsupported','command-ineligible','route-unavailable','record-invalid','context-changed','sampled'],
    planClearanceSource:['barrier','vehicle'],
  };
  const PLAN_REASONS=['verified-native-policy-required','verified-owned-native-capture-and-policy-required','bounded-policy-required','ordered-bounded-native-knots-required','incomplete-or-reversing-native-knots','unverified-native-unit-spacing','invalid-native-curve-policy','verified-exit-heading-required','measured-native-knot-bend','no-observed-speed-limiting-bend','verified-forward-centerline-required','bounded-physical-policy-required','verified-current-native-speed-required','bounded-forward-samples-required','invalid-distance-order-or-spacing','grade-outside-horizontal-policy','incomplete-or-reversing-geometry','no-observed-corner-constraint','insufficient-observed-reaction-horizon','no-supported-positive-corner-target','measured-corner-constraint'];
  const PACED_FIELDS=['nativePacedCatchup','pacedCatchupEligible','pacedRequestedStrength','pacedAppliedStrength','pacedSourceFactor','pacedPowerFactor','pacedTireFactor','pacedPowerGain','pacedTireGain','pacedWheelHits','pacedOutputsVerified'];
  const RUBBERBAND_FIELDS=['rubberbandState','rubberbandActive','rubberbandResetPending','rubberbandResetAcknowledged','rubberbandRequestedPercent','rubberbandAppliedPercent','rubberbandPublication','rubberbandAckAgeMs','nativeRubberband','rubberbandUnavailable','nativeCalculatedEligible','nativeCatchupOn','nativeCornerTarget',...PACED_FIELDS];
  FLAGS.push('rubberbandActive','rubberbandResetPending','rubberbandResetAcknowledged','nativeRubberband','rubberbandUnavailable','nativeCalculatedEligible','nativeCatchupOn','nativeCornerTarget');
  FLAGS.push('nativePacedCatchup','pacedCatchupEligible','pacedOutputsVerified');
  Object.assign(NUMBERS,{rubberbandRequestedPercent:[100,200],rubberbandAppliedPercent:[100,200],rubberbandPublication:[0,32767],rubberbandAckAgeMs:[0,1e9],pacedRequestedStrength:[1,10],pacedAppliedStrength:[1,10],pacedSourceFactor:[0,1e6],pacedPowerFactor:[0,1e6],pacedTireFactor:[0,1e6],pacedPowerGain:[1,20],pacedTireGain:[1,40],pacedWheelHits:[0,4]});
  MOVING_FIELDS.push(...RUBBERBAND_FIELDS);
  TOOL_FLAGS.push('rubberband');TOOL_NUMBERS.rubberbandPercent=[100,200];TOOL_NUMBERS.rubberbandStrength=[1,10];
  const TRACE_FIELDS=[
    'version','revision','moduleHash','ready','driving','network','safe','hidden','focused','supported','hud','flow','trackId','raceType','racePhase',
    'streetXRace','forcedStreetX','onlineStreetX','dragRace','forcedDrag','driftRace','forcedDrift','driverKind','physicsKind',
    'aiActive','aiOwned','handbackPending','aiRequestedMode','aiNativeStatus','aiStaleTicks','nativeSkill',
    'paceConfirmed','requestedPace','paceApplied','nativePaceFactor','nativePaceRequested','nativePaceApplied','nativePaceHits','nativePaceTelemetryStatus',
    'speedMps','forwardMps','carGear','carRpm','nativeThrottle','nativeBrake','nativeHandbrake','nativeSteering','nativeRoadTarget','nativeRoadTargetStatus','nativeTelemetryStatus',
    'cornerRequested','cornerMode','cornerPace','cornerBraking','cornerHits','brakingHits','cornerApplied','cornerDriverValid','cornerRouteOwned','cornerRouteNodes','cornerPlannerCorners','cornerPlannerUsable','cornerPlannerTelemetryStatus','cornerGuardMask','cornerMemoryBlocked','cornerDriftBlocked',
    'adaptiveRaceRequested','adaptiveRaceCeiling','adaptiveRaceState','adaptivePacingState','adaptiveRuntimePace','adaptiveClearanceM',
    'planCurrentCorners','planClearanceAvailable','planClearanceObserved','planClearanceTarget','planClearanceSource','planInputSpeedMps','planSelectedPace',
    'nativeForwardGeometry','nativeForwardClamp','forwardUnavailable','forwardState','forwardCaptured','forwardSamples','forwardHorizon','forwardPriorityTurns','forwardRequestedTarget','forwardLeaseTicks','forwardFailureCode','forwardGuardCode','forwardNativeApplied','forwardLiveVerified',
    'forwardPlanAvailable','forwardPlanOverride','forwardPlanReasonCode','forwardPlanTarget','forwardPlanConstraints','forwardPlanKnots','forwardLimitingDistance','forwardLimitingAngle','forwardLimitingCurvature','forwardLimitingCurveTarget','forwardLimitingEntryTarget','forwardPlanGrip','forwardPlanLateral','forwardPlanBrake',
    'powerActive','effectivePower','powerStatus','gripActive','effectiveGrip','producerFailureCode','producerStage','traceStatus','pageHeartbeat','nativeHeartbeatAck',
    'catchupDriverVerified','catchupDriverFactor','catchupCarFactor','catchupTelemetryStatus','shortcutPolicyInstalled','shortcutPolicyRequested',...RUBBERBAND_FIELDS,
  ];
  const TRACE_COLUMNS=Object.freeze(['at',...TRACE_FIELDS,...TOOL_FLAGS.map(k=>'tools.'+k),...Object.keys(TOOL_NUMBERS).map(k=>'tools.'+k)]);
  const RECENT_TRACE_COLUMNS=TRACE_COLUMNS.filter(k=>![...PACED_FIELDS,'tools.rubberbandStrength'].includes(k));
  const PREVIOUS_TRACE_COLUMNS=TRACE_COLUMNS.filter(k=>![...RUBBERBAND_FIELDS,'tools.rubberband','tools.rubberbandPercent','tools.rubberbandStrength'].includes(k));
  const OLDER_TRACE_COLUMNS=PREVIOUS_TRACE_COLUMNS.filter(k=>!['catchupDriverVerified','catchupDriverFactor','catchupCarFactor','catchupTelemetryStatus','shortcutPolicyInstalled','shortcutPolicyRequested'].includes(k));
  const cleanTraceRow=row=>{
    const input={tools:{}};
    for(let i=1;i<TRACE_COLUMNS.length;i++){const key=TRACE_COLUMNS[i];if(key.startsWith('tools.'))input.tools[key.slice(6)]=row[i];else input[key]=row[i];}
    const clean=sanitize(input);
    return [Math.floor(row[0]),...TRACE_COLUMNS.slice(1).map(key=>key.startsWith('tools.')?(clean.tools?.[key.slice(6)]??null):(clean[key]??null))];
  };
  const read = (value, key) => { try { return value == null ? undefined : value[key]; } catch { return undefined; } };
  const str = value => typeof value === 'string' ? value.slice(0,MAX_ERROR_INPUT) : '';
  const number = (value, limits) => typeof value === 'number' && Number.isFinite(value) && value >= limits[0] && value <= limits[1] ? Math.round(value*1000)/1000 : undefined;
  function fields(value, flags, numbers) {
    const out = {};
    for (const key of flags) if (typeof read(value,key) === 'boolean') out[key] = read(value,key);
    for (const [key,limits] of Object.entries(numbers)) { const v = number(read(value,key),limits); if (v !== undefined) out[key] = v; }
    return out;
  }
  function errorInfo(error, stack) {
    const message = str(typeof error === 'string' ? error : read(error,'message'));
    const name = str(read(error,'name'));
    const text = `${name} ${message}`.toLowerCase();
    const errorKind = /out of bounds|bounds check|outside.*memory/.test(text) ? 'memory-bounds'
      : /unreachable/.test(text) ? 'unreachable'
      : /indirect call|signature mismatch|null function|table index/.test(text) ? 'indirect-call'
      : /divide by zero|integer overflow/.test(text) ? 'integer-divide'
      : /invalid conversion/.test(text) ? 'invalid-conversion'
      : /call stack|stack overflow/.test(text) ? 'stack-overflow'
      : /out of memory|allocation failed|memory allocation/.test(text) ? 'out-of-memory'
      : /typeerror/.test(text) ? 'type-error'
      : /referenceerror/.test(text) ? 'reference-error'
      : /syntaxerror/.test(text) ? 'syntax-error' : 'other';
    const source = str(stack === undefined ? read(error,'stack') : stack);
    // Keep only numeric wasm locations and known local source basenames/line numbers.
    // Never retain error text, URLs, arguments, file paths, arbitrary function names or query strings.
    const wasmFrames = [...source.matchAll(/wasm-function\[(\d{1,7})\]:(0x[0-9a-f]{1,12}|\d{1,12})(?![\da-f])/gi)].slice(0,12).map(m=>`wasm-function[${m[1]}]:${m[2]}`);
    const jsFrames = [...source.matchAll(/(?:^|[/\\\s(])((?:page|ai|core|diagnostics|current-profile|latest-profile|signatures|signature-profile|signature-profile-latest|dyno|dyno-core|dyno-full|dyno-evaluator|dyno-native|walls|cars|game-worker)\.js):(\d{1,7}):(\d{1,7})(?!\d)/g)].slice(0,8).map(m=>`${m[1]}:${m[2]}:${m[3]}`);
    return {errorKind,wasmFrames,jsFrames};
  }
  function sanitize(value) {
    const out = fields(value,FLAGS,NUMBERS);
    for(const [key,allowed] of Object.entries(TRACE_ENUMS))if(allowed.includes(read(value,key)))out[key]=read(value,key);
    for(const key of ['producerFailureCode','producerStage','forwardPlanReasonCode','nativePaceHits','forwardPlanConstraints','forwardPlanKnots'])if(!Number.isInteger(read(value,key)))delete out[key];
    const curvature=read(value,'forwardLimitingCurvature');if(typeof curvature==='number'&&Number.isFinite(curvature)&&curvature>=0&&curvature<=100)out.forwardLimitingCurvature=Math.round(curvature*1e9)/1e9;
    if(!Number.isInteger(read(value,'forwardFailureCode')))delete out.forwardFailureCode;
    if(!FORWARD_GUARDS.has(read(value,'forwardGuardCode')))delete out.forwardGuardCode;
    if(FORWARD_STATES.has(read(value,'forwardState')))out.forwardState=read(value,'forwardState');
    // There is no native application receipt or live verification for this
    // preview yet. Persisted/page data cannot promote a request into proof.
    for(const key of ['forwardNativeApplied','forwardLiveVerified'])if(read(value,key)===false)out[key]=false;
    if(ADAPTIVE_STATES.has(read(value,'adaptiveRaceState')))out.adaptiveRaceState=read(value,'adaptiveRaceState');
    if(PACING_STATES.has(read(value,'adaptivePacingState')))out.adaptivePacingState=read(value,'adaptivePacingState');
    if(POWER_STATUSES.has(read(value,'powerStatus')))out.powerStatus=read(value,'powerStatus');
    for(const key of ['revision','reportedRevision','candidateRevision','signatureReference']){
      const revision=read(value,key);
      if(typeof revision==='string'&&/^(?:[a-f0-9]{8,40}|unknown)$/.test(revision))out[key]=revision;
    }
    const moduleHash=read(value,'moduleHash');
    if(typeof moduleHash==='string'&&/^[a-f0-9]{64}$/.test(moduleHash))out.moduleHash=moduleHash;
    if(PATCH_CODES.has(read(value,'patchCode')))out.patchCode=read(value,'patchCode');
    const version = read(value,'version');
    if (typeof version === 'string' && /^\d{1,3}\.\d{1,3}\.\d{1,3}$/.test(version)) out.version = version;
    for (const [key,allowed] of [['phase',PHASES],['reason',REASONS],['errorKind',ERROR_KINDS]]) if (allowed.has(read(value,key))) out[key] = read(value,key);
    if (read(value,'tools')) out.tools = fields(read(value,'tools'),TOOL_FLAGS,TOOL_NUMBERS);
    const dynoStatus=read(value,'dynoStatus'),dynoGuard=read(value,'dynoGuard'),dynoObserved=read(value,'dynoObserved');
    if(DYNO_STATUSES.has(dynoStatus))out.dynoStatus=dynoStatus;
    if(dynoStatus===8&&DYNO_GUARDS.has(dynoGuard)){
      out.dynoGuard=dynoGuard;
      if(Number.isInteger(dynoObserved)&&dynoObserved>=0&&dynoObserved<=4294967295&&
        ([30,31,32,70].includes(dynoGuard)||(dynoGuard===50&&DYNO_SOURCE_PAIRS.has(dynoObserved))))out.dynoObserved=dynoObserved;
    }

    if (read(value,'error') !== undefined || read(value,'stack') !== undefined) Object.assign(out,errorInfo(read(value,'error'),read(value,'stack')));
    // Revalidate persisted records too, never trust same-origin storage or its fields.
    else for (const [key,re,max] of [['wasmFrames',/^wasm-function\[\d{1,7}\]:(?:0x[0-9a-f]{1,12}|\d{1,12})$/i,12],['jsFrames',/^(?:page|ai|core|diagnostics|current-profile|latest-profile|signatures|signature-profile|signature-profile-latest|dyno|dyno-core|dyno-full|dyno-evaluator|dyno-native|walls|cars|game-worker)\.js:\d{1,7}:\d{1,7}$/,8]]) {
      const a=read(value,key);if(Array.isArray(a))out[key]=a.slice(0,max).filter(v=>typeof v==='string'&&re.test(v));
    }
    return out;
  }
  function create({storage=null,clock=()=>Date.now(),version='0.38.8'}={}) {
    let events=[],drivingSamples=[],dropped=0,persistence=storage?'same-tab':'memory-only',lastSnapshot='',lastSample=0;
    let traceRows=[],traceDropped=0,lastTraceAt=null,lastTracePersistAt=null,traceWasDriving=false,lastIdleFailure=null,tracePersistence=storage?'same-tab':'memory-only',traceRestored=false;
    const bursts=new Map();
    const now=()=>{try{const n=clock();return Number.isFinite(n)&&n>=0?Math.floor(n):0;}catch{return 0;}};
    const tracePacked=()=>({format:'nfsu2-driving-trace-v1',schema:1,columns:TRACE_COLUMNS,dropped:traceDropped,rows:traceRows});
    const boundTrace=()=>{while(traceRows.length>MAX_TRACE_SAMPLES||JSON.stringify(tracePacked()).length>MAX_TRACE_BYTES){traceRows.shift();traceDropped++;}};
    const persistTrace=(force=false)=>{
      const t=now();if(!force&&lastTracePersistAt!==null&&t>=lastTracePersistAt&&t-lastTracePersistAt<TRACE_PERSIST_MS)return;
      lastTracePersistAt=t;boundTrace();
      if(storage)try{storage.setItem(TRACE_KEY,JSON.stringify(tracePacked()));tracePersistence='same-tab';}catch{tracePersistence='memory-only';}
    };
    try{
      const raw=storage?.getItem(TRACE_KEY);
      if(typeof raw==='string'&&raw.length<=MAX_TRACE_BYTES){
        const saved=JSON.parse(raw);
        const currentColumns=JSON.stringify(saved?.columns)===JSON.stringify(TRACE_COLUMNS),previousColumns=JSON.stringify(saved?.columns)===JSON.stringify(RECENT_TRACE_COLUMNS)||JSON.stringify(saved?.columns)===JSON.stringify(PREVIOUS_TRACE_COLUMNS)||JSON.stringify(saved?.columns)===JSON.stringify(OLDER_TRACE_COLUMNS);
        if(saved?.format==='nfsu2-driving-trace-v1'&&saved.schema===1&&(currentColumns||previousColumns)&&Array.isArray(saved.rows)){
          traceDropped=Number.isSafeInteger(saved.dropped)&&saved.dropped>=0?saved.dropped:0;
          const indexes=TRACE_COLUMNS.map(k=>saved.columns.indexOf(k));
          traceRows=saved.rows.slice(-MAX_TRACE_SAMPLES).filter(r=>Array.isArray(r)&&r.length===saved.columns.length&&Number.isFinite(r[0])&&r[0]>=0&&r[0]<=8640000000000000).map(r=>cleanTraceRow(currentColumns?r:indexes.map(i=>i<0?null:r[i])));
          boundTrace();traceRestored=traceRows.length>0;
        }
      }
    }catch{tracePersistence='memory-only';}
    const trace=(data={})=>{
      try{
        const clean=sanitize(data),active=clean.ready===true&&(clean.driving===true||clean.aiActive===true||clean.aiOwned===true)&&clean.safe!==false&&clean.hidden!==true&&clean.focused!==false;
        const failure=clean.producerFailureCode>0?JSON.stringify([clean.producerFailureCode,clean.producerStage,clean.nativeTelemetryStatus,clean.nativeRoadTargetStatus,clean.traceStatus,clean.trackId,clean.raceType]):null;
        const relevant=active||traceWasDriving||failure!==lastIdleFailure;
        if(!relevant)return false;
        const t=now();if(lastTraceAt!==null&&t>=lastTraceAt&&t-lastTraceAt<TRACE_MS)return false;lastTraceAt=t;
        traceWasDriving=active;lastIdleFailure=active?null:failure;
        clean.version=sanitize({version}).version;
        const row=[t,...TRACE_COLUMNS.slice(1).map(key=>key.startsWith('tools.')?(clean.tools?.[key.slice(6)]??null):(clean[key]??null))];
        traceRows.push(row);boundTrace();persistTrace();return true;
      }catch{return false;}
    };
    const traceExport=()=>{
      const missing=Object.fromEntries(TRACE_COLUMNS.slice(1).map(k=>[k,0]));let maxGap=0,gaps=0,clockRollbacks=0;
      for(let i=0;i<traceRows.length;i++){
        const row=traceRows[i];for(let j=1;j<TRACE_COLUMNS.length;j++)if(row[j]===null)missing[TRACE_COLUMNS[j]]++;
        if(i){const delta=row[0]-traceRows[i-1][0];maxGap=Math.max(maxGap,delta);if(delta>TRACE_MS*2)gaps++;if(delta<0)clockRollbacks++;}
      }
      return {...tracePacked(),restoredFromSameTab:traceRestored,persistence:tracePersistence,nominalCadenceMs:TRACE_MS,persistIntervalMs:TRACE_PERSIST_MS,
        codebooks:{producerFailureCode:{0:'producer completed',1:'native/context read failed',2:'AI mailbox read failed',3:'forward diagnostics or trace sink failed'},producerStage:{0:'complete',1:'native/context',2:'AI mailbox',3:'forward diagnostics or sink'},forwardPlanReasonCode:{0:'not reported or unrecognized',...Object.fromEntries(PLAN_REASONS.map((name,i)=>[i+1,name]))},nativeUnits:['nativeRoadTarget','forwardRequestedTarget','forwardPlanTarget','forwardLimitingDistance','forwardLimitingCurveTarget','forwardLimitingEntryTarget'],statuses:TRACE_ENUMS},
        coverage:{samples:traceRows.length,firstAt:traceRows[0]?.[0]??null,lastAt:traceRows.at(-1)?.[0]??null,spanMs:traceRows.length?Math.max(0,traceRows.at(-1)[0]-traceRows[0][0]):0,maxGapMs:maxGap,gapsOver500Ms:gaps,clockRollbacks,missingByColumn:missing},
        notice:'Each row follows columns. null means unavailable or rejected, never zero. Desired cadence is 250ms; coverage reports actual retained timing. Samples are best-effort shared-memory observations, not atomic snapshots. Native target/geometry values use native units; cap requests are not application receipts. A loss of speed is not proof of an impact. Menus do not continuously evict driving evidence. Same-tab checkpoints are limited to one write per two seconds; a tab crash can lose recent samples.'};
    };
    const isDriving=data=>data.ready===true&&data.driving===true&&data.aiActive===true&&data.aiOwned===true;
    const retainDriving=sample=>{
      if(!isDriving(sample.data))return;
      drivingSamples.push(sample);
      while(drivingSamples.length>MAX_DRIVING_SAMPLES||JSON.stringify(drivingSamples).length>MAX_DRIVING_BYTES)drivingSamples.shift();
    };
    const packed=()=>({schema:1,dropped,events,drivingSamples});
    const bound=()=>{while(events.length>MAX_EVENTS || JSON.stringify(packed()).length>MAX_BYTES){events.shift();dropped++;}};
    const persist=()=>{bound();if(storage)try{storage.setItem(KEY,JSON.stringify(packed()));persistence='same-tab';}catch{persistence='memory-only';}};
    try {
      const raw=storage?.getItem(KEY);
      if(typeof raw==='string'&&raw.length<=MAX_BYTES){
        const saved=JSON.parse(raw);
        if(saved?.schema===1&&Array.isArray(saved.events)){
          dropped=Number.isSafeInteger(saved.dropped)&&saved.dropped>=0?saved.dropped:0;
          events=saved.events.slice(-MAX_EVENTS).filter(e=>EVENTS.has(read(e,'event'))).map(e=>({at:number(read(e,'at'),[0,8640000000000000])??0,event:read(e,'event'),data:sanitize(read(e,'data'))}));
          // Historical driving evidence has its own small budget so a few
          // minutes in the menus cannot replace every useful race sample.
          // Revalidate stored values exactly like ordinary event records.
          if(Array.isArray(saved.drivingSamples))for(const e of saved.drivingSamples.slice(-MAX_DRIVING_SAMPLES))retainDriving({at:number(read(e,'at'),[0,8640000000000000])??0,data:sanitize(read(e,'data'))});
          if(!drivingSamples.length)for(const e of events)if(e.event==='state')retainDriving({at:e.at,data:e.data});
        }
      }
    } catch { persistence='memory-only'; }
    const record=(event,data={})=>{try{if(!EVENTS.has(event))return false;const at=now();if(['page-error','promise-rejection','worker-error','engine-error','dyno-error'].includes(event)){const burst=bursts.get(event);if(burst&&at-burst.at<1000){if(burst.count++>=8){dropped++;return false;}}else bursts.set(event,{at,count:1});}const clean=sanitize(data);events.push({at,event,data:clean});if(event==='state')retainDriving({at,data:clean});persist();return true;}catch{return false;}};
    const snapshot=(data={})=>{try{const clean=sanitize(data),stable={...clean};for(const key of MOVING_FIELDS)delete stable[key];const key=JSON.stringify(stable),t=now(),sampleMs=clean.nativeTelemetry||clean.driftRace||clean.forcedDrift||clean.driftVariant?2000:5000;if(lastSnapshot && t-lastSample < (key===lastSnapshot?sampleMs:250))return;lastSnapshot=key;lastSample=t;record('state',clean);}catch{}};
    const exportText=()=>{persistTrace(true);return JSON.stringify({format:'NFSU2 Driving Tools local diagnostics',schema:1,exporterVersion:sanitize({version}).version,exportedAt:now(),persistence,dropped,limits:{maxEvents:MAX_EVENTS,maxStoredBytes:MAX_BYTES,maxHistoricalDrivingSamples:MAX_DRIVING_SAMPLES,maxHistoricalDrivingBytes:MAX_DRIVING_BYTES,maxTraceSamples:MAX_TRACE_SAMPLES,maxTraceBytes:MAX_TRACE_BYTES},capture:'Tool selections, sampled game mode/status, bounded power application status, native pace acknowledgement and session-only adaptive planner request/evidence, bounded native controller/skill/input-mode/speed, Drift scoring, sampled NOS clock/timestamp/resource fields and corner evidence, page and game-worker lifecycle, classified errors, bounded tuner rejection codes/counts, numeric wasm locations and known script line numbers. No raw logs, messages, URLs, credentials, saves, names, keyboard input or network traffic. Same-origin page scripts can access this same-tab storage. Browser/tab/GPU failures may prevent a final event; absence of an error does not show that the game was healthy. Not a game crash dump.',historicalDriving:{historical:true,notice:'Previous sampled driving states; not current ownership, a complete route, or proof of a race result.',samples:drivingSamples},raceTrace:traceExport(),events},null,2)+'\n';};
    const clear=()=>{events=[];drivingSamples=[];dropped=0;lastSnapshot='';lastSample=0;traceRows=[];traceDropped=0;lastTraceAt=null;traceWasDriving=false;lastIdleFailure=null;traceRestored=false;persistTrace(true);bursts.clear();record('clear');};
    record('page-start',{version});
    return Object.freeze({record,snapshot,trace,exportText,clear,status:()=>({events:events.length,dropped,persistence,traceSamples:traceRows.length,traceDropped,tracePersistence})});
  }
  const api=Object.freeze({create,errorInfo,KEY,MAX_EVENTS,MAX_BYTES,TRACE_KEY,TRACE_MS,MAX_TRACE_SAMPLES,MAX_TRACE_BYTES,TRACE_COLUMNS});
  root.__NFSU2_DIAGNOSTICS__=api;
  if(typeof module==='object'&&module.exports)module.exports=api;
})(globalThis);

/* Source-backed guest offsets: 6f4f1e4e; checked against exact 2f0ddd3b and 78e2bb69 native functions. Page additionally requires a verified binary profile. See README. */
(function (root) {
  'use strict';
  const A = Object.freeze({ FLOW: 0x8654a4, MODE: 0x850078, PLAYER: 0xd00000,
    RACE: 0x890118, DRAG: 0x89e7d8, TICKS: 0x86518c,
    NOS_FULL: 0x454, NOS_LEFT: 0x45c, NOS_SINCE: 0x460, RPM: 0x440, GEAR: 0x434,
    HOST: 0x866a14, CLIENT: 0x8669f4, ONLINE: 0x89cf69 });
  class Engine {
    constructor(memory) { this.memory = memory; this.view = null; this.performancePatch = null; this.gripPatch = null; this.words = null; this.floatBits = new Float32Array(1); this.intBits = new Int32Array(this.floatBits.buffer); }
    refresh() { if (!this.view || this.view.buffer !== this.memory.buffer) { this.view = new DataView(this.memory.buffer); this.words = new Int32Array(this.memory.buffer); } }
    ok(p, n = 4) { return Number.isSafeInteger(p) && p >= 0x10000 && p + n <= Math.min(0x28000000, this.view.byteLength); }
    u32(p) { return this.ok(p) ? this.view.getUint32(p, true) : 0; }
    u8(p) { return this.ok(p, 1) ? this.view.getUint8(p) : 0; }
    state() {
      this.refresh();
      if (this.u32(A.FLOW) !== 6) return { ready: false, reason: 'Start driving to use the tools.' };
      const player = this.u32(A.PLAYER), car = this.u32(player + 4), race = this.u32(A.RACE);
      if (player%4 || car%4 || race%4 || !this.ok(player, 0x14) || !this.ok(car, 0x9e4) || !this.ok(race, 0xc44) || this.u32(player + 0x10) !== 0)
        return { ready: false, reason: 'Waiting for a valid player car.' };
      const rpm = this.view.getFloat32(car + A.RPM, true), gear = this.u32(car + A.GEAR);
      if (!Number.isFinite(rpm) || rpm < 0 || rpm > 30000 || gear > 10)
        return { ready: false, reason: 'Car layout not recognized; no memory changed.' };
      const network = !!(this.u32(A.MODE) & 0x208) || !!this.u32(A.HOST) || !!this.u32(A.CLIENT) || !!this.u8(A.ONLINE);
      return { ready: true, car, race, rpm, gear, driving: this.u32(race) === 4, drag: this.u8(A.DRAG) === 1, network };
    }
    live(s, allowNetwork = true, driving = false) {
      const now=this.state();
      return !!s?.ready && now.ready && now.car===s.car && now.race===s.race && (!driving||now.driving) && (!now.network||allowNetwork===true);
    }
    bits(value) {this.floatBits[0]=value;return this.intBits[0];}
    compareFloat(p, expected, value, guard) {
      if(!this.ok(p)||p%4||!guard())return false;
      const before=this.bits(expected),after=this.bits(value);
      // Exact field ownership, including a native change after validation.
      // This narrows interleavings; it is NOT an allocator/lifetime lock.
      if(before===after)return Atomics.load(this.words,p/4)===before;
      return Atomics.compareExchange(this.words,p/4,before,after)===before;
    }
    refill(s, allowNetwork = false) {
      this.refresh();
      if(!this.live(s,allowNetwork,true))return false;
      const full=this.u32(s.car+A.NOS_FULL);
      if(!full||full>=10000000)return false;
      const guard=()=>this.live(s,allowNetwork,true)&&this.u32(s.car+A.NOS_FULL)===full;
      const remaining=this.u32(s.car+A.NOS_LEFT);
      if(!guard())return false;
      if(remaining===full){if(Atomics.load(this.words,(s.car+A.NOS_LEFT)/4)!==(remaining|0))return false;}
      else if(Atomics.compareExchange(this.words,(s.car+A.NOS_LEFT)/4,remaining,full)!==(remaining|0))return false;
      const since=this.u32(s.car+A.NOS_SINCE),ticks=this.u32(A.TICKS);
      if(since&&since!==0x7fffffff&&since!==(ticks||1)&&guard())Atomics.compareExchange(this.words,(s.car+A.NOS_SINCE)/4,since,ticks||1);
      return true;
    }
    performanceInfo(s) {
      if (!s?.ready || this.u32(A.FLOW) !== 6 || this.u32(A.RACE) !== s.race || this.u32(this.u32(A.PLAYER) + 4) !== s.car) return null;
      const ride = this.u32(s.car + 0x10), pi = ride + 0x10;
      if (!ride || pi%4 || !this.ok(pi, 0x574)) return null;
      const f = o => this.view.getFloat32(pi + o, true);
      const type = this.u32(pi), mass = f(0x140), idle = f(0x220), max = f(0x228);
      if (type > 30 || !(mass > 0.1 && mass < 10) || !(idle >= 100 && idle <= 4000) || !(max > idle && max <= 20000)) return null;
      const offsets = [...Array.from({length:9}, (_,i)=>0x230+i*4), 0x2dc, 0x2c0];
      const values = offsets.map(f);
      if (!values.every((v,i)=>Number.isFinite(v) && v >= 0 && v < (i === 10 ? 1000 : 20))) return null;
      return { ride, pi, offsets, values };
    }
    performanceOwned(s, patch, allowNetwork=true, driving=false) {
      return this.live(s,allowNetwork,driving) && s.car===patch.car && s.race===patch.race && this.u32(patch.car+0x10)===patch.ride && patch.pi===patch.ride+0x10;
    }
    restorePerformance(s) {
      const old=this.performancePatch;this.performancePatch=null;
      if(!old)return false;this.refresh();
      const guard=()=>this.performanceOwned(s,old);
      if(!guard())return false;
      for(let i=0;i<old.offsets.length;i++){
        if(!guard())return false;
        this.compareFloat(old.pi+old.offsets[i],old.expected[i],old.original[i],guard);
      }
      return true;
    }
    tunePerformance(s, power = 1, unlimit = false, allowNetwork = false) {
      this.refresh();
      if(!this.live(s,allowNetwork,true)||!Number.isFinite(power)||power<1||power>3){this.restorePerformance(s);return {ok:false};}
      if(power===1&&!unlimit){this.restorePerformance(s);return {ok:true,active:false};}
      const info=this.performanceInfo(s);
      if(!info){this.restorePerformance(s);return {ok:false,reason:'Car performance layout unavailable.'};}
      let patch=this.performancePatch;
      if(patch&&(patch.car!==s.car||patch.race!==s.race||patch.pi!==info.pi)){this.performancePatch=null;patch=null;}
      if(patch&&info.values.some((v,i)=>v!==patch.expected[i])){this.restorePerformance(s);return {ok:false,changed:true,reason:'Car tuning changed. Power controls will resume after the new values settle.'};}
      if(!patch)patch={car:s.car,race:s.race,ride:info.ride,pi:info.pi,offsets:info.offsets,original:info.values,expected:info.values.slice()};
      const expected=patch.original.map((v,i)=>Math.fround(i===10?unlimit?0:v:v*power));
      if(expected.some((v,i)=>!Number.isFinite(v)||v<0||v>=(i===10?1000:20))){this.restorePerformance(s);return {ok:false,reason:'Requested power exceeds the recognized tuning range. Lower the power factor.'};}
      const guard=()=>this.performanceOwned(s,patch,allowNetwork,true);
      this.performancePatch=patch;
      for(let i=0;i<expected.length;i++){
        if(!this.compareFloat(info.pi+info.offsets[i],patch.expected[i],expected[i],guard)){
          this.restorePerformance(s);return {ok:false,changed:true,reason:'Car state changed during power adjustment. Waiting for stable values.'};
        }
        patch.expected[i]=expected[i];
      }
      return {ok:true,active:true,power,unlimit};
    }
    gripInfo(s) {
      if (!s?.ready || this.u32(A.FLOW)!==6 || this.u32(A.RACE)!==s.race || this.u32(this.u32(A.PLAYER)+4)!==s.car) return null;
      const physics=this.u32(s.car+0x34);
      if (!this.ok(physics,0x48)) return null;
      const wheels=[0x38,0x3c,0x40,0x44].map(o=>this.u32(physics+o));
      if (new Set(wheels).size!==4 || wheels.some(w=>w%4 || !this.ok(w,0x18c))) return null;
      const values=wheels.map(w=>this.view.getFloat32(w+0x188,true));
      if (values.some(v=>!Number.isFinite(v) || v<0.1 || v>4)) return null;
      return {physics,wheels,values};
    }
    gripOwned(s,patch,allowNetwork=true,driving=false) {
      return this.live(s,allowNetwork,driving) && s.car===patch.car && s.race===patch.race && this.u32(s.car+0x34)===patch.physics && patch.wheels.every((w,i)=>this.u32(patch.physics+0x38+i*4)===w);
    }
    restoreGrip(s) {
      const patch=this.gripPatch;this.gripPatch=null;
      if(!patch)return false;this.refresh();
      const guard=()=>this.gripOwned(s,patch);
      if(!guard())return false;
      for(let i=0;i<4;i++){
        if(!guard())return false;
        this.compareFloat(patch.wheels[i]+0x188,patch.expected[i],patch.original[i],guard);
      }
      return true;
    }
    tuneGrip(s, factor=1, allowNetwork=false) {
      this.refresh();
      if(!this.live(s,allowNetwork,true)||!Number.isFinite(factor)||factor<1||factor>2){this.restoreGrip(s);return {ok:false};}
      if(this.u32(0x890104)!==0||this.u8(0x89e7d9)!==0){this.restoreGrip(s);return {ok:false,paused:true,reason:'Extra grip is paused during drift mode/races.'};}
      if(factor===1){this.restoreGrip(s);return {ok:true,active:false};}
      const info=this.gripInfo(s);
      if(!info){this.restoreGrip(s);return {ok:false,reason:'Wheel physics unavailable.'};}
      let patch=this.gripPatch;
      if(patch&&(patch.car!==s.car||patch.race!==s.race||patch.physics!==info.physics||patch.wheels.some((w,i)=>w!==info.wheels[i]))){this.gripPatch=null;patch=null;}
      if(patch&&info.values.some((v,i)=>v!==patch.expected[i])){this.restoreGrip(s);return {ok:false,changed:true,reason:'Wheel physics changed. Extra grip will resume after the new values settle.'};}
      if(!patch)patch={car:s.car,race:s.race,physics:info.physics,wheels:info.wheels,original:info.values,expected:info.values.slice()};
      const expected=patch.original.map(v=>Math.fround(Math.min(4,v*factor)));
      const guard=()=>this.gripOwned(s,patch,allowNetwork,true)&&this.u32(0x890104)===0&&this.u8(0x89e7d9)===0;
      this.gripPatch=patch;
      for(let i=0;i<4;i++){
        if(!this.compareFloat(info.wheels[i]+0x188,patch.expected[i],expected[i],guard)){
          this.restoreGrip(s);return {ok:false,changed:true,reason:'Car state changed during grip adjustment. Waiting for stable values.'};
        }
        patch.expected[i]=expected[i];
      }
      return {ok:true,active:true,factor};
    }
    driftTap(ptr) {
      // Same synthetic action used by the game's touch Drift button, through
      // its documented single-producer main-page input ring instead of hidden DOM.
      this.refresh();
      if (!Number.isSafeInteger(ptr) || ptr <= 0 || ptr % 4 || ptr+20800 > this.view.byteLength) return false;
      const h=new Int32Array(this.view.buffer,ptr,64);
      if ((Atomics.load(h,0)>>>0)!==0x4e494e50 || Atomics.load(h,1)!==2 || Atomics.load(h,3)!==1024 || Atomics.load(h,7)!==1 || Atomics.load(h,27)!==0 || Atomics.load(h,34)!==0) return false;
      const w=Atomics.load(h,4), r=Atomics.load(h,5);
      if (((w-r)>>>0)>=1024) return false;
      const p=ptr+4416+(w&1023)*16;
      const bytes=new Uint8Array(this.view.buffer,p,16); bytes.fill(0);
      bytes[0]=3; bytes[1]=0xf1; bytes[3]=32; // KEY_TAP, dedicated Drift key, synthetic.
      Atomics.store(h,4,(w+1)|0); Atomics.notify(h,4,1);
      return true;
    }
    hazards(s) {
      // Read-only tester. These are cars and the track's barrier-line table,
      // not a complete collision mesh, traffic classifier, lane map or autopilot.
      if (!s.ready) return null;
      const f = p => this.ok(p) ? this.view.getFloat32(p, true) : NaN;
      const x = f(s.car + 0x60), y = f(s.car + 0x64), z = f(s.car + 0x68);
      let fx = f(s.car + 0x90), fy = f(s.car + 0x94);
      const fl = Math.hypot(fx, fy);
      if (![x,y,z,fl].every(Number.isFinite) || fl < 0.5 || fl > 1.5) return null;
      fx /= fl; fy /= fl;
      const world = this.u32(0x890080), seen = new Set(); let car = this.u32(world);
      const cars = [];
      while (car && car !== world && seen.size < 96 && this.ok(car, 0x9e4) && !seen.has(car)) {
        seen.add(car);
        if (car !== s.car) {
          const dx = f(car + 0x60) - x, dy = f(car + 0x64) - y, dz = f(car + 0x68) - z;
          const ahead = dx * fx + dy * fy, side = -dx * fy + dy * fx;
          if ([ahead,side,dz].every(Number.isFinite) && ahead > 0 && ahead < 150 && Math.abs(side) < 20 && Math.abs(dz) < 5)
            cars.push({ ahead, side });
        }
        car = this.u32(car);
      }
      cars.sort((a,b) => a.ahead - b.ahead);
      const nb = this.u32(0x88f298 + 0x498), bars = this.u32(0x88f298 + 0x49c);
      let barrierAhead = null, activeBarriers = 0;
      if (nb <= 8192 && this.ok(bars, nb * 0x24)) for (let i = 0; i < nb; i++) {
        const p = bars + i * 0x24; if (!this.u8(p + 0x10)) continue;
        const ax = f(p) - x, ay = f(p+4) - y, bx = f(p+8) - x, by = f(p+12) - y;
        if (![ax,ay,bx,by].every(Number.isFinite)) continue;
        activeBarriers++;
        const al = -ax*fy + ay*fx, bl = -bx*fy + by*fx;
        if ((al > 0) === (bl > 0) || Math.abs(al-bl) < 0.0001) continue;
        const t = al / (al-bl), distance = (ax + (bx-ax)*t)*fx + (ay + (by-ay)*t)*fy;
        if (distance >= 0 && distance < 150 && (barrierAhead === null || distance < barrierAhead)) barrierAhead = distance;
      }
      return { cars, scannedCars: seen.size, activeBarriers, barrierAhead };
    }
    status(ptr) {
      this.refresh();
      if (!Number.isSafeInteger(ptr) || ptr <= 0 || ptr % 4 || ptr + 16 > this.view.byteLength) return null;
      const h = new Int32Array(this.view.buffer, ptr, 4);
      if ((Atomics.load(h, 0) >>> 0) !== 0x31545453) return null;
      const seq = Atomics.load(h, 1), count = Atomics.load(h, 2);
      if (seq & 1 || count < 0 || count > 48 || ptr + 16 + count * 24 > this.view.byteLength) return null;
      const out = {};
      for (let k = 0; k < count; k++) {
        const p = ptr + 16 + 24 * k; let name = '';
        for (let j = 0; j < 16; j++) { const c = this.view.getUint8(p + j); if (!c) break; name += String.fromCharCode(c); }
        out[name] = this.view.getFloat64(p + 16, true);
      }
      return seq === Atomics.load(h, 1) ? out : null;
    }
  }
  class StableGate {
    constructor(samples=3) {this.samples=samples;this.reset();}
    reset() {this.last=null;this.count=0;}
    accept(value) {const key=JSON.stringify(value);if(key!==this.last){this.last=key;this.count=1;}else this.count++;return this.count>=this.samples;}
  }
  const api = Object.freeze({ Engine, StableGate, A, supportedRevision: '6f4f1e4e' });
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else Object.defineProperty(root, '__NFSU2_DRIVING_CORE__', { value: api, configurable: true });
})(globalThis);

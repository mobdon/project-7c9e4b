# v0.15.0 · Native opponent AI paths

## Changes on exact build 78e2bb69 only

- **Opponent drag action:** allows the native initializer to select actual opponent “Win drag race” action 2 for the extension's requested and owned player car. It does not change racer identity, global difficulty, native action pointers or vtables directly. A confirmed player action 3 may be upgraded once through the initializer; NULL initializes lazily and recovery 11/other actions are left to the game. Status confirms id and vtable; pending is not success.
- **Native drift physics:** corrects normal unmarked player drift events to driver 3/physics 1 through the native setter, preserving drag-first mode precedence. Invalid driver state or failed correction rolls back to manual control. Existing mode/identity/heartbeat/network guards and full event handback remain.
- **Native nitrous decisions:** permits the owned player to reach native request/cancellation logic for recognized drag goal 2, observed road goal 1 in actual race types 1/7, and observed chase goal 5 only in Outrun 7. It never selects chase goal 5 or enables this new path in free roam 0. Native tactical/skill/availability/resource conditions remain intact; no refill or forced activation is added. The separate Unlimited NOS control remains unchanged.
- Cancellation uses the same authorized owned race scope without a new-start goal requirement, so recovery/NULL goal transitions cannot suppress native cancellation. New starts remain strictly goal-gated.

## Limits

**Force-only drag and the special 1099 combination are unsupported by the new opponent path.** It requires the actual native drag flag. This is not full opponent equivalence, a distinct specialist AI for every race, or a fastest-driver claim. No live race benchmark, reliable launch/shift/lane behavior, race completion, winning or crash-freedom is proven. Temporary/recovery actions are not forced. Native full allocator/configuration and cancellation execution, plus the complete skill/resource graph, remain unverified.

The reported freezes remain unresolved. Back up the save, preserve v0.14, enable only one extension version and reload the game. Begin with normal 1× pace and unrelated power/grip changes off. F7 returns control. Unknown game binaries stay disabled, and older exact supported profiles retain their previous behavior.

## Preserved v0.14 features

Guarded five-slot dyno Find/Apply/Restore and Store/Save guidance; adaptive free-roam corner margin and honest hit/status logging; separate online NPC traffic no-clip; solo collision switches; separate free-roam/race pace; NOS refill, power, limiter, grip, manual drag, drift input, read-only tester, signature scanner and sanitized local crash-log export are retained. Corner assistance remains free-roam-only and drag bypasses custom pace. No game assets, extracted binaries or research files are included.

## Verification

The final v0.15 release-folder suite passed **897/897 tests, zero failures and zero skips** after integration and version changes. Independent review passed **390 selected overlapping tests** on the frozen implementation. Authored drag-selector, owned-NOS and latest-profile builders reproduce byte-for-byte; all extension JavaScript passes syntax checks. Production JavaScript matches the frozen reviewed candidate except version labels. Additional bounded native downstream proof passed 56 cases with controlled skill/resource boundaries. These are not live gameplay or full end-to-end native graph benchmarks.

Only eight intended current-build bodies change: 3174, 4653, 7395, 17404, 19277, 21213, 21263 and 22470. All other function bodies and non-code sections remain identical. Older exact profiles retain their existing hooks. Strict-CSP browser visuals remain unverified because Chromium startup was blocked in this environment.

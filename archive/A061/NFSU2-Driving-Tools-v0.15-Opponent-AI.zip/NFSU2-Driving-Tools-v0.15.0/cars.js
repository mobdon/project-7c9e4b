/* Local-player car-only contacts. Exact-build hook; no body flag or map edits. */
(function(root){
  'use strict';
  const BASE=0xd0d1c0, MAGIC=0x3143414e, AI_BASE=0xd0d100, AI_MAGIC=0x3749414e;
  class Controller {
    constructor(memory,available=false,profile=null){this.memory=memory;this.available=!!available;this.onlineTrafficAvailable=profile?.onlineTraffic===true;this.words=null;this.view=null;this.onlineAddresses=profile?.onlineAddresses||[704405244,704522128,704406412];}
    refresh(){const b=this.memory.buffer;if(!this.view||this.view.buffer!==b){this.view=new DataView(b);this.words=new Int32Array(b);}return b.byteLength>=BASE+40;}
    read(off){return Atomics.load(this.words,(BASE+off)/4)>>>0;}
    write(off,v){Atomics.store(this.words,(BASE+off)/4,v|0);}
    guest(p){return p>=0x10000&&p+4<=Math.min(this.view.byteLength,0x28000000)?this.view.getUint32(p,true):0;}
    onlineRoam(){
      // The verified module profile supplies roam_game_online_here addresses.
      const [a,b,c]=this.onlineAddresses;
      return this.view.byteLength>=Math.max(a+4,b+1,c+4)&&!!this.view.getUint32(a,true)&&!!this.view.getUint8(b)&&!!this.view.getUint32(c,true);
    }
    publish(enabled=false,player=0,car=0,race=0,onlineTraffic=false){
      if(!this.available||!this.refresh()||this.guest(AI_BASE+28)!==AI_MAGIC)return false;
      if(this.read(0)!==MAGIC){for(let off=0;off<40;off+=4)if(this.read(off)!==0)return false;}
      const mode=enabled===true&&onlineTraffic===true&&this.onlineTrafficAvailable?1:0;
      const identityChanged=this.read(36)!==mode||this.read(12)!==player||this.read(16)!==car||this.read(20)!==race;
      let seq=this.read(4);if(seq&1)seq++;
      this.write(4,seq+1);this.write(0,MAGIC);this.write(8,enabled===true?1:0);this.write(12,player);this.write(16,car);this.write(20,race);this.write(36,mode);
      if(!enabled||identityChanged){this.write(24,0);this.write(28,0);this.write(32,0);}
      this.write(4,seq+2);return true;
    }
    stop(){this.publish(false);return this.status();}
    update({enabled=false,onlineTraffic=false,safe=false,state=null}={}){
      this.refresh();const p=this.guest(0xd00000),roam=this.onlineRoam(),raceType=this.guest(0x89e7b0);
      const traffic=onlineTraffic===true&&this.onlineTrafficAvailable&&roam&&raceType===0;
      const wanted=safe===true&&state?.ready&&state.driving&&!state.network&&this.guest(p+4)===state.car&&(traffic||enabled===true&&!roam);
      this.publish(!!wanted,p,state?.car||0,state?.race||0,!!traffic);
      const result=this.status();
      const networkReason='Paused in Online/LAN races. Traffic no-clip only supports online free roam.';
      result.soloReason=!enabled?'OFF · other cars only · solo':state?.network?networkReason:roam?'Paused online · use Online traffic no-clip':result.reason;
      result.trafficReason=!onlineTraffic?'OFF · traffic only · online free roam':!this.onlineTrafficAvailable?'Online traffic no-clip is not verified for this build.':state?.network?networkReason:!roam||raceType!==0?'Waiting for online free roam. Races and outruns keep normal collisions.':result.reason;
      result.reason=result.onlineTraffic?result.trafficReason:enabled&&!roam?result.soloReason:onlineTraffic?result.trafficReason:result.soloReason;
      return result;
    }
    status(){
      if(!this.available)return {available:false,requested:false,hits:0,reason:'Reload after installing the car-contact module.'};
      if(!this.refresh()||this.guest(AI_BASE+28)!==AI_MAGIC)return {available:true,requested:false,hits:0,reason:'Waiting for the native game loop.'};
      if(this.read(0)!==MAGIC)return {available:true,requested:false,hits:0,reason:'Car no-clip paused: command memory is unavailable.'};
      const seq=this.read(4);
      if(seq&1)return {available:true,requested:false,hits:0,reason:'Car no-clip paused: waiting for a complete command.'};
      const onlineTraffic=this.read(36)===1,wanted=this.read(8)===1,code=this.read(24),hits=this.read(28),p=this.guest(0xd00000),car=this.guest(p+4);
      const current=wanted&&p===this.read(12)&&car===this.read(16)&&this.guest(0x890118)===this.read(20)&&this.read(0)===MAGIC&&this.read(4)===seq;
      return {available:true,requested:current,onlineTraffic:current&&onlineTraffic,hits:current?hits:0,reason:!current?'Paused or off.':code===2?'Paused online or in an Online/LAN race.':code===3?'Waiting for online free roam.':hits?`${hits} ${onlineTraffic?'traffic':'car'} contacts skipped · ${onlineTraffic?'player cars':'ground and walls'} unchanged`:onlineTraffic?'Armed · online traffic only · player cars unchanged':'Armed · waiting for a car contact'};
    }
  }
  const api={Controller,BASE,MAGIC};root.__NFSU2_CARS__=api;
  if(typeof module==='object'&&module.exports)module.exports=api;
})(globalThis);

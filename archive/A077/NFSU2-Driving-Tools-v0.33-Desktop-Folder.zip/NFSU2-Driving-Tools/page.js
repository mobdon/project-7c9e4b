(() => {
  'use strict';
  if (location.origin !== 'https://nfsu2.xyz' || window.top !== window || window.__nfsu2DrivingTools) return;
  Object.defineProperty(window, '__nfsu2DrivingTools', { value: true });
  let diagnostics = null;
  try { let storage = null; try { storage = sessionStorage; } catch {} diagnostics = globalThis.__NFSU2_DIAGNOSTICS__?.create({storage,version:'0.33.0'}) || null; } catch {}
  let diagnosticState = {}, diagnosticIdentity = null, diagnosticPatch = '';
  // The log is observational only: no memory writes, upload, raw console capture or error text.
  const recordDiagnostic = (event, extra = {}) => { try { diagnostics?.record(event,{...diagnosticState,...extra}); } catch {} };
  window.addEventListener('error', event => {try{recordDiagnostic('page-error',{error:event.error || event.message,tools:diagnosticTools()});}catch{recordDiagnostic('page-error',{error:event.error || event.message});}});
  window.addEventListener('unhandledrejection', event => {try{recordDiagnostic('promise-rejection',{error:event.reason,tools:diagnosticTools()});}catch{recordDiagnostic('promise-rejection',{error:event.reason});}});
  const AI = globalThis.__NFSU2_AI__;
  const Walls = globalThis.__NFSU2_WALLS__;
  const Cars = globalThis.__NFSU2_CARS__;
  const Tune = globalThis.__NFSU2_DYNO_CORE__;
  AI?.install();
  let wall = null, cars = null;
  let dyno = null, dynoEnabled = false, dynoText = 'OFF · back up progress before testing';
  let ai = null, dragTakenOver = false, dragRace = false;
  const { Engine, StableGate, adaptiveRaceSettings, supportedRevision } = globalThis.__NFSU2_DRIVING_CORE__;
  delete globalThis.__NFSU2_DRIVING_CORE__;
  let engine = null, statusPtr = 0, inputPtr = 0, supported = false, revision = '', visible = false, moduleProfile = null, activeModule = null, activeWorker = null, sessionGeneration = 0;
  const refreshCompatibility=()=>{supported=!!moduleProfile?.capabilities.legacy && moduleProfile.revision===revision;};
  let host, ui, note, live, timer, driftPending = null, driftNeedsReapply = false;
  const powerGate=new StableGate(), gripGate=new StableGate();
  let lastShift = 0, shiftTimer = 0, lastPulse = 0, lastScan = 0;
  const held = new Set(), physicallyHeld = new Set();
  const prefs = { raceCornerAssist: false, raceCornerFactor: 0.8, raceCornerMargin: 15, raceBraking: 0.75, cornerAssist: false, cornerFactor: 0.8, cornerMargin: 15, racePace: false, racePaceFactor: 1, walls: false, cars: false, traffic: false, players: false, online: false, ai: false, aiPace: false, paceFactor: 1, nos: false, dragNoBlowout: false, drag: false, rpm: 6500, tester: false, boost: false, power: 1.5, unlimit: false, grip: false, gripFactor: 1.3, drift: null };
  // Session-only race arming is separate from existing saved driving profiles.
  let raceOnlyAI=false;
  // Display-only preference, deliberately outside saved driving-tool profiles.
  const HUD_KEY='nfsu2-driving-tools-info-hud-v1';
  let infoHudEnabled=true,infoHudSample=null;
  try {infoHudEnabled=sessionStorage.getItem(HUD_KEY)!=='0';} catch {}
  const STORAGE_KEY='nfsu2-driving-tools-v1';
  try {
    const saved=JSON.parse(sessionStorage.getItem(STORAGE_KEY)||'null');
    if(saved && typeof saved==='object') {
      for(const name of ['nos','drag','tester','dragNoBlowout']) if(typeof saved[name]==='boolean') prefs[name]=saved[name];
      for(const [name,min,max] of [['raceCornerFactor',0.6,0.95],['raceCornerMargin',0,25],['raceBraking',0.5,1],['racePaceFactor',0.75,3],['cornerFactor',0.6,0.95],['cornerMargin',0,25],['paceFactor',0.75,3],['rpm',3000,10000],['power',1,3],['gripFactor',1,2]]) if(Number.isFinite(saved[name])) prefs[name]=Math.max(min,Math.min(max,saved[name]));
      if(typeof saved.drift==='boolean') prefs.drift=saved.drift;
    }
  } catch { /* storage disabled: choices still persist between races in this page */ }
  const ToolProfiles=globalThis.__NFSU2_TOOL_PROFILES__;
  let profileStore=null,profileSelection=null,loadedProfile=null,profileNotice='',profileStartup=null,profileDriftChoice=false,profileActionPending=false,profileActionEpoch=0;
  const PROFILE_SESSION_STOP='nfsu2-driving-tools-profiles-session-stop';
  let profileSessionStopped=false;
  try {profileSessionStopped=sessionStorage.getItem(PROFILE_SESSION_STOP)==='1';}catch{}
  if(ToolProfiles){let storage=null;try{storage=localStorage;}catch{}profileStore=ToolProfiles.create(storage);profileStartup=profileSessionStopped?null:profileStore.startup();}
  // A durable Stop suppresses legacy same-tab driving reapplication as well.
  if(profileSessionStopped||profileStore?.snapshot().paused||(profileStore&&!profileStore.snapshot().available)){for(const k of ['raceCornerAssist','cornerAssist','racePace','walls','cars','traffic','players','online','ai','aiPace','nos','dragNoBlowout','drag','boost','unlimit','grip'])prefs[k]=false;}
  // Intentionally outside saved profiles and legacy session preference storage.
  let adaptiveRaceEnabled=false,adaptiveRaceCeiling=1.3;
  const diagnosticTools = () => ({...prefs,raceOnlyAI,dynoEnabled,adaptiveRace:adaptiveRaceEnabled,adaptiveRaceCeiling});
  const savePrefs=()=>{try{sessionStorage.setItem(STORAGE_KEY,JSON.stringify(prefs));}catch{}};
  recordDiagnostic('tools',{tools:diagnosticTools()});
  const message = text => { if (note) {note.textContent=text;const summary=ui.querySelector('#status-summary');summary.title=text;} };
  // Pure presentation of existing verified samples. No reads or writes to game
  // memory occur here; missing/paused telemetry is never replaced with zero.
  function infoHudView(sample,choices,now) {
    const fresh=sample && Number.isFinite(sample.at) && now-sample.at>=0 && now-sample.at<=500;
    const d=fresh?sample.data:{}, c=fresh?sample.context:{};
    const aiSelected=!!choices.ai || (!!choices.raceOnlyAI && d.raceOnlyRequested===true);
    const paused=!fresh?'Waiting for live sample':!d.supported?'Build not verified':!d.ready?'Waiting for car':d.hidden?'Tab hidden':d.focused===false?'Game unfocused':!d.hud?'Waiting for driving HUD':!d.driving?'Waiting for GO':c.menu?'Game menu open':c.suspended||'';
    const live=!paused;
    const blocked=paused||(d.network&&!choices.online?'Online tools paused':'');
    const speed=live && d.nativeTelemetry===true && Number.isFinite(d.speedMps) && d.speedMps>=0 && d.speedMps<=500 ? String(Math.round(d.speedMps*3.6)) : 'Unavailable';
    const mode=!fresh||!d.supported||!d.ready?'Waiting for game':c.drag?'Drag':c.drift?'Drift':d.raceType===0&&d.hud===2?'Free roam':d.raceType===7?'Outrun':d.raceType===1?'Race':'Driving';
    const context=d.supported&&d.ready?(d.network?'Online / LAN':'Solo')+' · '+mode:mode;
    let driver=blocked||'Driver unavailable';
    if(!blocked) {
      if(d.handbackPending||c.switching)driver='AI handoff pending';
      else if(!aiSelected&&d.aiOwned)driver='Releasing native AI';
      else if(aiSelected&&d.aiActive)driver=c.drag?'Native Drag AI active':'Native AI active';
      else if(aiSelected)driver=c.aiAvailable===false?'AI unavailable':c.aiStatus==='failed'?'AI handoff failed':c.aiStatus==='retry'?'AI needs off / on':'AI requested · waiting';
      else if(c.manual||d.driverKind===1)driver='Manual driver';
      else if(d.aiDriverVerified)driver='Native AI · not tool-owned';
      else driver='Driver unavailable';
    }
    const adaptiveRequested=d.adaptiveRaceRequested===true;
    const selected=adaptiveRequested|| (c.roam?choices.aiPace:c.race?choices.racePace:false);
    const factor=adaptiveRequested?d.adaptiveRaceCeiling:c.roam?choices.paceFactor:c.race?choices.racePaceFactor:1;
    let pace=blocked?'Not confirmed':c.paceAvailable===false?'Unavailable on this build':c.drag||c.drift?'Native · custom pace paused':!c.roam&&!c.race?'Unavailable in this mode':!selected?'Native target':Number.isFinite(factor)?factor.toFixed(2)+'× selected':'Unavailable';
    if(live&&!blocked&&c.paceAvailable!==false&&!c.drag&&!c.drift&&(c.roam||c.race)) {
      const target=selected?factor:1;
      if(aiSelected&&Number.isFinite(target)) {
        // An older acknowledgement must not confirm a newly selected factor.
        const confirmed=d.paceConfirmed===true && !c.switching && Number.isFinite(d.paceApplied) && d.paceApplied>=.75 && d.paceApplied<=3 && Math.abs(d.paceApplied-target)<.011;
        pace=target.toFixed(2)+'× req · '+(confirmed?d.paceApplied.toFixed(2)+'× ack':'pending');
      } else if(selected&&Number.isFinite(factor))pace=factor.toFixed(2)+'× selected · AI off';
    }
    if(adaptiveRequested&&!blocked&&Number.isFinite(factor))pace=`Adaptive ${factor.toFixed(2)}× ceiling · ${d.adaptiveRaceState==='planner-observed'?'planner observed':'pending'}`;
    const req=choices.boost?choices.power:1;
    const requested=Number.isFinite(req)?req.toFixed(1)+'× req':'Requested';
    const states={'network-permission':'online paused',unsupported:'unavailable','not-ready':'waiting',hidden:'paused',unfocused:'paused',hud:'waiting','not-driving':'waiting',menu:'paused','drift-change':'waiting',layout:'unavailable',settling:'settling',suspended:'paused','tuner-busy':'tuner busy',neutral:'neutral',changed:'changed',rejected:'rejected'};
    let power=!(choices.boost||choices.unlimit)?'Off':requested+' · '+(blocked?'not confirmed':states[d.powerStatus]||'pending');
    if(!blocked&&d.powerStatus==='applied'&&d.powerActive===true&&Number.isFinite(d.effectivePower)&&d.effectivePower>=1&&d.effectivePower<=3&&Math.abs(d.effectivePower-req)<.011)power=requested+' · '+d.effectivePower.toFixed(1)+'× set';
    const limiter=!choices.unlimit?'':!blocked&&d.powerStatus==='applied'&&d.limiterRemoved===true?' · governor removed':' · governor requested';
    return {governor:limiter?limiter.slice(3):'',speed,unit:speed==='Unavailable'?'':'km/h',context,driver,pace,power,powerTitle:power+limiter+'. Set reports guarded power-field writes, not measured speed or horsepower.',state:paused||(d.network&&!choices.online?'Read-only · network tools paused':'Live observations'),speedTitle:speed==='Unavailable'?(paused||'Speed telemetry is unavailable for this build or car.'):'Native speed sample converted from m/s to km/h. Not a GPS or measured tuning gain.'};
  }
  function renderInfoHud() {
    if(!ui)return;
    const hud=ui.querySelector('#info-hud');
    hud.hidden=!infoHudEnabled||visible;
    ui.querySelector('#info-hud-enable').checked=infoHudEnabled;
    if(hud.hidden)return;
    const view=infoHudView(infoHudSample,{...prefs,raceOnlyAI},performance.now());
    for(const field of ['speed','unit','context','driver','pace','power','governor','state']) {
      const node=ui.querySelector('#hud-'+field);
      if(node.textContent!==view[field])node.textContent=view[field];
      node.title=field==='speed'?view.speedTitle:field==='power'?view.powerTitle:view[field];
      if(field==='governor')node.hidden=!view.governor;
    }
  }
  function setInfoHud(enabled) {
    infoHudEnabled=!!enabled;
    try {sessionStorage.setItem(HUD_KEY,infoHudEnabled?'1':'0');} catch {}
    renderInfoHud();
  }
  function clearInfoHud(reason='Waiting for live sample') {
    infoHudSample=null;
    renderInfoHud();
    if(ui&&infoHudEnabled&&!visible)ui.querySelector('#hud-state').textContent=reason;
  }
  function renderPowerStatus(powerStatus,tune={}) {
    if(!ui)return;
    const powerText={off:'Off · not a vehicle-speed multiplier',unsupported:'Unavailable · game build not verified','not-ready':'Waiting for the current car','network-permission':'Paused online · enable Allow network tools',hidden:'Paused · tab hidden',unfocused:'Paused · game unfocused',hud:'Waiting for driving HUD','not-driving':'Waiting for active driving',menu:'Paused · game menu open','drift-change':'Waiting for drift handling change',layout:'Unavailable · car performance layout',settling:'Waiting for stable performance values',suspended:'Paused · waiting for driving tools to resume','tuner-busy':'Paused · tuner is busy',applied:`Power fields set to ${Number(tune.power).toFixed(1)}×${tune.unlimit?' · stock governor set to zero':''}`,neutral:'Neutral · 1.0× power',changed:'Waiting · native tuning/state changed',rejected:'Not applied · performance guard rejected'};
    ui.querySelector('#power-state').textContent=powerText[powerStatus];
    ui.querySelector('#power-state').title=(tune.reason||powerText[powerStatus])+'. This reports guarded field writes, not a measured speed increase.';
  }
  function clearPaceEvidence() {
    // A stop request can precede native handback. Retain native ownership
    // diagnostics, but never present an old acknowledgement as a current one.
    diagnosticState={...diagnosticState,raceOnlyRequested:false,adaptiveRaceRequested:false,adaptiveRaceState:adaptiveRaceEnabled?'paused':'off',paceConfirmed:false,paceApplied:undefined};
    clearInfoHud();
    if(ui){
      const raceState=ui.querySelector('#race-only-state');raceState.textContent=raceOnlyAI?'Armed · waiting for current race evidence':'Off · current page only';raceState.title=raceState.textContent;
      ui.querySelector('#adaptive-race-state').textContent=adaptiveRaceEnabled?'Selected · waiting for current planner evidence':'Off · session only';
      if(adaptiveRaceEnabled)ui.querySelector('#race-corner-state').textContent='Adaptive selected · waiting for current planner evidence';
      ui.querySelector('#ai-pace-state').textContent=prefs.aiPace?'Waiting for current AI acknowledgement':'Off · free roam only';
      ui.querySelector('#race-pace-state').textContent=prefs.racePace?'Waiting for current AI acknowledgement':'Off · normal race pace';
    }
  }
  function clearApplicationEvidence(status='suspended') {
    // Reporting only. Actual restoration and native handback remain owned by
    // the existing callers, and are not claimed to have completed here.
    try {
      clearPaceEvidence();
      const powerStatus=prefs.boost||prefs.unlimit?status:'off';
      diagnosticState={...diagnosticState,powerStatus,powerActive:false,effectivePower:undefined,limiterRemoved:false};
      renderPowerStatus(powerStatus);
    } catch {}
  }
  function pendingCornerText(state) {
    // Existing read-only evidence only. Stages are the furthest native check
    // reached for this request, not a diagnosis of the latest turn or failure.
    // A missing hit does not prove the road has no qualifying bends.
    if (state.cornerHits > 0) return 'Armed · waiting for current settings confirmation';
    if (state.cornerRouteOwned === true && state.cornerPlannerCorners === 0) return 'Armed · native plan currently has no corner entries';
    if (state.cornerProbeStage === 6) return 'Armed · limiting curve seen; reduction not confirmed';
    if (state.cornerProbeStage === 5) return 'Armed · planner reached; no speed reduction recorded';
    if (state.cornerProbeStage >= 1 && state.cornerProbeStage <= 4) return 'Armed · native corner checks not yet complete';
    return 'Armed · no native corner reduction recorded';
  }
  function cornerEvidenceText(state) {
    const count = value => Number.isInteger(value) && value >= 0 && value <= 40 ? value : 'unknown';
    const stage = Number.isInteger(state.cornerProbeStage) && state.cornerProbeStage >= 0 && state.cornerProbeStage <= 7 ? state.cornerProbeStage : 'unknown';
    const mask = Number.isInteger(state.cornerGuardMask) && state.cornerGuardMask >= 0 && state.cornerGuardMask <= 255 ? state.cornerGuardMask : null;
    const checks = [[1,'command/profile'],[2,'AI ownership'],[4,'game context'],[8,'race state'],[16,'drag/drift exclusion'],[32,'network permission'],[64,'driver identity'],[128,'private route']];
    const sampled = mask === null ? 'unknown' : mask ? checks.filter(([bit]) => mask & bit).map(([,name]) => name).join(', ') : 'none';
    return `Native route points: ${count(state.cornerRouteNodes)}; corner entries: ${count(state.cornerPlannerCorners)}. Furthest native check: ${stage}/7; 7 means a hit exists. Sampled unmet checks: ${sampled}. Counts/checks are snapshots, not a proven cause. Export a short crash log after several turns if no reduction is recorded.`;
  }
  const NativeWorker = window.Worker;
  // Observe only the known game worker; AI validates its patched module separately.
  window.Worker = new Proxy(NativeWorker, {
    construct(Target, args, NewTarget) {
      const worker = Reflect.construct(Target, args, NewTarget);
      let url; try { url = new URL(String(args[0]), location.href); } catch { return worker; }
      if (url.origin !== location.origin || url.pathname !== '/host/game-worker.js') return worker;
      const send = worker.postMessage;
      let bootSession=null;
      worker.postMessage = function (m, ...rest) {
        if (m && m.mod instanceof WebAssembly.Module && m.memory instanceof WebAssembly.Memory && Number.isSafeInteger(m.slot) && m.slot>=0) {
          if(m.slot===0){
          const verifiedProfile=AI?.getModuleProfile?.(m.mod)||null;
          if (!engine || engine.memory !== m.memory || activeModule!==m.mod || activeWorker!==worker || moduleProfile!==verifiedProfile) {
            // Release only the previous verified session before sending the new
            // module to its worker. A reused memory object is not an identity.
            if(engine&&moduleProfile){try{const state=engine.state();engine.restorePerformance(state);engine.restoreGrip(state);}catch{}}
            dyno?.cancel();wall?.stop();cars?.stop();ai?.stop();
            sessionGeneration++;activeWorker=worker;activeModule=m.mod;moduleProfile=verifiedProfile;refreshCompatibility();
            // A new module/worker/memory generation has no current native
            // observations yet. Do not carry prior application or ownership
            // evidence into its boot event or an immediate diagnostic export.
            diagnosticState={generation:sessionGeneration,revision:moduleProfile?.revision||'unknown',supported,ready:false,driving:false,safe:false,tools:diagnosticTools()};
            clearApplicationEvidence('not-ready');
            diagnosticIdentity=null;
            recordDiagnostic('game-boot',{generation:sessionGeneration,slot:m.slot,memoryMiB:m.memory.buffer.byteLength/1048576,revision:moduleProfile?.revision||'unknown',supported,tools:diagnosticTools()});
            const caps=moduleProfile?.capabilities;
            dyno=caps?.fullTuner && globalThis.__NFSU2_DYNO_FULL__?.Controller?new globalThis.__NFSU2_DYNO_FULL__.Controller(m.memory,true,moduleProfile.revision,{prepared:AI.getNativeEvaluator(m.mod),module:m.mod}):caps?.dyno && globalThis.__NFSU2_DYNO__?.Controller?new globalThis.__NFSU2_DYNO__.Controller(m.memory,true,moduleProfile.revision):null;dyno?.setEnabled(dynoEnabled);
            wall=caps?.walls && Walls?.Controller?new Walls.Controller(m.memory,true,moduleProfile.wall):null;
            cars=caps?.cars && Cars?.Controller?new Cars.Controller(m.memory,true,moduleProfile.cars):null;
            ai=AI?.Controller?new AI.Controller(m.memory,!!caps?.ai,caps):null;
            engine = new Engine(m.memory,moduleProfile?.statusCapacity); statusPtr = 0; inputPtr = 0; driftPending = null; driftNeedsReapply=typeof prefs.drift==='boolean'; powerGate.reset(); gripGate.reset();
          }
          }
          bootSession={module:m.mod,memory:m.memory,generation:activeModule===m.mod&&engine?.memory===m.memory?sessionGeneration:-1};
        }
        return Reflect.apply(send, this, [m, ...rest]);
      };
      const currentSession = () => !!bootSession && bootSession.generation===sessionGeneration && bootSession.module===activeModule && bootSession.memory===engine?.memory;
      worker.addEventListener('error', event => recordDiagnostic('worker-error',{sessionCurrent:currentSession(),error:event.error || event.message,tools:diagnosticTools()}));
      worker.addEventListener('message', event => {
        const m = event.data;
        if(m?.t==='trap')recordDiagnostic('game-trap',{sessionCurrent:currentSession(),tid:m.tid,error:m.msg,stack:m.stack,tools:diagnosticTools()});
        if(m?.t==='exit')recordDiagnostic('game-exit',{sessionCurrent:currentSession(),code:m.code,tools:diagnosticTools()});
        if(!currentSession())return;
        if(m?.t==='register' && (m.kind===3||m.kind===5))recordDiagnostic('game-register',{kind:m.kind});
        if (worker===activeWorker && m?.t === 'register' && m.kind === 3 && Number.isSafeInteger(m.ptr)) inputPtr = m.ptr;
        if (worker===activeWorker && m?.t === 'register' && m.kind === 5 && Number.isSafeInteger(m.ptr)) statusPtr = m.ptr;
        if (m?.t === 'exit' || m?.t === 'trap') {suspend('Game stopped. Enabled choices are kept for the next game.');ai=null;wall=null;cars=null;dyno=null;engine=null;activeWorker=null;activeModule=null;moduleProfile=null;refreshCompatibility();statusPtr=0;inputPtr=0;}
      });
      return worker;
    }
  });
  // A different game revision must be reviewed before writing its memory.
  fetch('/game.json', { cache: 'no-store', credentials: 'omit' }).then(r => {
    if (!r.ok) throw new Error('Build information unavailable');
    return r.json();
  }).then(info => {
    revision = String(info.rev || 'unknown');refreshCompatibility();
    recordDiagnostic('build',{revision,supported});
    if (!supported) message('Waiting for an exact verified game module. Unknown builds stay disabled.');
  }).catch(error => {recordDiagnostic('build-error',{error});message('Could not check game version. Memory tools stay disabled.');});

  function key(code, down) {
    const keyName = { ArrowUp: 'ArrowUp', ShiftLeft: 'Shift', AltLeft: 'Alt' }[code] || code;
    window.dispatchEvent(new KeyboardEvent(down ? 'keydown' : 'keyup', { code, key: keyName,
      location: /Left$/.test(code) ? 1 : 0, bubbles: true, cancelable: true }));
  }
  function hold(code, down) {
    if (down && !held.has(code)) { if (!physicallyHeld.has(code)) { held.add(code); key(code, true); } }
    else if (!down && held.delete(code) && !physicallyHeld.has(code)) key(code, false);
  }
  function release() { clearTimeout(shiftTimer); for (const code of [...held]) hold(code, false); }
  function suspend(why) {
    dyno?.cancel();
    wall?.stop();cars?.stop(); ai?.stop(); release(); powerGate.reset(); gripGate.reset();
    try {if(engine){const state=engine.state();engine.restorePerformance(state);engine.restoreGrip(state);}} catch { /* no stale pointer writes */ }
    clearApplicationEvidence();
    if(why) message(why);
  }
  function stop(why = 'Driving controls off. F9 cleared driving assists and network permission. Saved profiles are kept. Load one manually, or select it and enable Load on startup to resume.', persistProfilePause=true) {
    profileStartup=null;loadedProfile=null;profileActionEpoch++;profileActionPending=false;if(profileDriftChoice)driftNeedsReapply=false;profileDriftChoice=false;
    // Keep an already-issued drift request pending until confirmation/timeout: a
    // native toggle cannot be recalled safely, and a second must not overlap it.
    if(persistProfilePause){
      profileSessionStopped=true;
      try{sessionStorage.setItem(PROFILE_SESSION_STOP,'1');}catch{}
      const result=profileStore?.pause();
      profileNotice=result?.error||'Automatic loading paused by Stop. Select a profile and enable Load on startup to resume.';
      renderProfiles();
    }
    recordDiagnostic('stop',{tools:diagnosticTools()});
    clearRaceOnlyAI();
    dynoEnabled=false;dyno?.setEnabled(false);if(ui)ui.querySelector('#dyno-enable').checked=false;
    adaptiveRaceEnabled=false;if(ui)ui.querySelector('#adaptive-race').checked=false;
    prefs.raceCornerAssist=false;prefs.cornerAssist=false;prefs.racePace=false;prefs.walls=false;prefs.cars=false;prefs.traffic=false;prefs.players=false;prefs.online=false;prefs.ai=false;prefs.aiPace=false;prefs.nos=false;prefs.dragNoBlowout=false;prefs.drag=false;prefs.boost=false;prefs.unlimit=false;prefs.grip=false;savePrefs();suspend();
    if(ui) for(const id of ['race-corner-assist','corner-assist','race-pace','walls','cars','traffic','players','online','ai','ai-pace','nos','drag-no-blowout','drag','boost','unlimit','grip']) ui.querySelector('#'+id).checked=false;
    message(profileNotice&&persistProfilePause ? why+' '+profileNotice : why);
  }
  function clearRaceOnlyAI() {
    raceOnlyAI=false;
    if(ui){ui.querySelector('#race-only-ai').checked=false;ui.querySelector('#race-only-state').textContent='Off · current page only';}
  }
  function setRaceOnlyAI(enabled) {
    raceOnlyAI=enabled===true;
    if(raceOnlyAI){prefs.ai=false;if(ui)ui.querySelector('#ai').checked=false;}
    ai?.stop();release();clearPaceEvidence();savePrefs();
    if(ui){ui.querySelector('#race-only-ai').checked=raceOnlyAI;ui.querySelector('#race-only-state').textContent=raceOnlyAI?'Armed · waiting for an eligible race':'Off · current page only';}
    message(raceOnlyAI?'Race-only AI armed on this page. Start or join races yourself. It waits for GO, releases in free roam/results, and needs online permission. F7/F9 or driving keys during a race disarm it. Reload or profile Load turns it off.':'Race-only AI off. Native handback may complete on the next game frame.');
  }
  function raceOnlyRaceContext() {
    // Manual driving in free roam should not cancel arming for the next race.
    // Read the current context so an old sample cannot ignore race takeover.
    if(!supported||!engine||!statusPtr)return false;
    try {const state=engine.state(),hud=engine.status(statusPtr)?.drive;return !!state.ready&&Number.isFinite(hud)&&(hud&3)===1&&engine.u32(0x89e7b0)===1;}catch{return false;}
  }
  function takeControl() {
    recordDiagnostic('manual',{tools:diagnosticTools()});
    clearRaceOnlyAI();
    prefs.ai=false; ai?.stop(); dragTakenOver=true; release(); savePrefs();
    try {clearPaceEvidence();} catch {}
    if(ui) {ui.querySelector('#ai').checked=false;ui.querySelector('#ai-state').textContent='Manual control · native AI off';}
    message('Returning control to you. Native AI is off on the next game frame. Toggle drag assist again if you want assisted throttle.');
  }
  window.addEventListener('keydown', e => {
    if (!e.isTrusted) return;
    if(e.code==='Insert' && e.shiftKey && !e.ctrlKey && !e.altKey && !e.metaKey){
      // Shift+Insert remains Paste in text/editable controls, including controls
      // inside a shadow root. Otherwise it mirrors the existing F8 menu action.
      const path=e.composedPath?.()||[e.target];
      const editingNode=node=>{
        for(let depth=0;node&&depth<32;depth++,node=node.parentElement){
          if(node.isContentEditable || node.getAttribute?.('role')==='textbox' || /^(TEXTAREA|SELECT)$/.test(node.tagName) || (node.tagName==='INPUT' && !/^(button|checkbox|radio|range|submit|reset|color|file|image|hidden)$/.test(String(node.type||'').toLowerCase())))return true;
        }
        return false;
      };
      // Window's composedPath hides our closed shadow tree. Its retained
      // activeElement is required to preserve Paste in the profile-name field.
      const editing=[...path,ui?.activeElement,document.activeElement].some(editingNode);
      if(e.isComposing || e.defaultPrevented || editing)return;
      e.preventDefault();if(!e.repeat)setPanel(!visible);return;
    }
    // Range controls keep their native arrow/Space behavior without taking over the car.
    if(host && e.composedPath?.().includes(host) && !['F6','F7','F8','F9','Escape'].includes(e.code)) return;
    if(e.code==='F6'){e.preventDefault();if(!e.repeat)setInfoHud(!infoHudEnabled);return;}
    physicallyHeld.add(e.code);
    if(e.code==='F7') {e.preventDefault();takeControl();}
    else if((prefs.ai || (raceOnlyAI && raceOnlyRaceContext())) && ['ArrowLeft','ArrowRight','ArrowUp','ArrowDown','KeyW','KeyA','KeyS','KeyD','Space'].includes(e.code)) takeControl();
    if (e.code === 'F8') { e.preventDefault(); setPanel(!visible); }
    if (e.code === 'Escape' && visible) setPanel(false);
    if (e.code === 'F9') { e.preventDefault(); stop(); }
  }, true);
  window.addEventListener('keyup', e => { if (e.isTrusted) physicallyHeld.delete(e.code); }, true);
  window.addEventListener('focus', () => recordDiagnostic('resume',{reason:'blur',tools:diagnosticTools()}));
  window.addEventListener('blur', () => { recordDiagnostic('pause',{reason:'blur',tools:diagnosticTools()}); physicallyHeld.clear(); suspend('Paused while unfocused. Enabled tools resume when you return to a supported driving mode.'); });
  document.addEventListener('visibilitychange', () => { recordDiagnostic(document.hidden?'pause':'resume',{reason:'hidden',hidden:document.hidden,tools:diagnosticTools()}); if (document.hidden) suspend('Paused while the tab is hidden. Your enabled choices are kept.'); });
  window.addEventListener('storage',event=>{
    if(!ToolProfiles||![null,ToolProfiles.KEY,ToolProfiles.STOP_KEY].includes(event.key))return;
    const after=profileStore.refresh();
    const changed=loadedProfile&&!after.data.profiles.some(p=>p.id===loadedProfile.id&&p.revision===loadedProfile.revision);
    if(event.key===null||event.key===ToolProfiles.STOP_KEY||!after.available||changed){
      stop('Profile storage or Stop changed in another tab. Current driving controls are off. Load a profile explicitly to resume.',false);
      profileSessionStopped=true;try{sessionStorage.setItem(PROFILE_SESSION_STOP,'1');}catch{}
    }
    profileSelection=null;profileNotice=after.error||'Profiles updated in another tab. Select a profile again; nothing was automatically loaded.';renderProfiles();
  });
  window.addEventListener('pageshow',event=>{
    if(!event.persisted)return;
    // A BFCache page must recheck durable Stop and profile permissions before it
    // resumes. Do not auto-reload a profile or revive a retained controller.
    stop('Page restored. Driving controls remain off; load a profile explicitly to resume.',false);
    profileStore?.refresh();profileSelection=null;profileNotice='Page restored with controls off. Select and Load a profile to resume.';renderProfiles();
    clearInterval(timer);timer=setInterval(tick,50);
  });
  window.addEventListener('pagehide', () => { recordDiagnostic('page-hide',{reason:'page-hide',tools:diagnosticTools()});savePrefs(); suspend(); clearInterval(timer); });

  function setDrift(wanted) {
    if (driftPending) return false;
    const state = engine?.state(), counters = engine && statusPtr ? engine.status(statusPtr) : null;
    if (!supported || !state?.ready || !state.driving || state.network || !counters || (counters.drive & 3) !== 2 || !Number.isFinite(counters.drift) || document.hidden || document.querySelector('dialog[open]')) {
      message('Drift assist only works while driving solo free roam with the game menus closed.'); return false;
    }
    if (!!(counters.drift & 1) === wanted) return true;
    // Rebuilding the native drift setup must not inherit our power multiplier.
    engine.restorePerformance(state);engine.restoreGrip(state);powerGate.reset();gripGate.reset();
    if (!engine.driftTap(inputPtr)) { message('Drift request not sent: the game input mailbox is unavailable, inactive, typing, or full.'); return false; }
    driftPending = { wanted, until: performance.now() + 3000 };
    ui.querySelector('#drift').disabled = true;
    message('Drift request sent. Waiting for the game to confirm its handling state…');
    return true;
  }
  function moduleFailure() {
    const patch=AI?.patchState;
    if(moduleProfile || patch?.phase!=='unavailable')return '';
    const reported=/^[a-f0-9]{8,40}$/.test(revision)?` Site reports build ${revision}.`:'';
    const bytes=Number.isSafeInteger(patch.moduleBytes)?` Loaded module: ${patch.moduleBytes} bytes.`:'';
    const signatures=Number.isInteger(patch.signatureUnique)?` Fingerprints: ${patch.signatureUnique}/${patch.signatureTotal} unique matches; this does not approve an unknown build.`:'';
    return ['module-size','module-hash'].includes(patch.patchCode)
      ? `Game module is not verified.${reported}${bytes} A compatible Driving Tools update is required.${signatures}`
      : `Game module could not be prepared.${reported} Reload once. If it persists, export the diagnostic log.`;
  }
  function tick() {
    try {
      const patch=AI?.patchState,phase=patch?.phase || 'idle';
      const key=JSON.stringify([phase,patch?.revision,patch?.moduleBytes,patch?.moduleHash,patch?.patchCode,patch?.signatureReference,patch?.signatureUnique,patch?.signatureFailed,revision]);
      if(key!==diagnosticPatch){diagnosticPatch=key;recordDiagnostic('patch-state',{phase,revision:patch?.revision,reportedRevision:revision,candidateRevision:patch?.candidateRevision,moduleBytes:patch?.moduleBytes,moduleHash:patch?.moduleHash,patchCode:patch?.patchCode,signatureReference:patch?.signatureReference,signatureExact:patch?.signatureExact,signatureTotal:patch?.signatureTotal,signatureUnique:patch?.signatureUnique,signatureMissing:patch?.signatureMissing,signatureAmbiguous:patch?.signatureAmbiguous,signatureFailed:patch?.signatureFailed,error:phase==='unavailable'?patch?.reason:undefined});}
      if(ui){const status=diagnostics?.status();ui.querySelector('#diagnostic-state').textContent=status?`${status.events} recent events · ${status.persistence==='same-tab'?'kept across reloads in this tab':'memory only; storage unavailable'}`:'Logger unavailable';if(status&&Number.isInteger(patch?.signatureUnique))ui.querySelector('#diagnostic-state').textContent+=` · fingerprints ${patch.signatureUnique}/${patch.signatureTotal}`;}
    } catch {}
    updateDynoUI();
    if(dyno?.busy) {clearApplicationEvidence('tuner-busy');clearInfoHud('Tuner busy · driving tools paused');try{diagnostics?.snapshot({...diagnosticState,dynoBusy:true,tools:diagnosticTools()});}catch{} wall?.stop();cars?.stop();ai?.stop();release();return;}
    if (!engine) { clearApplicationEvidence('not-ready');if (live) live.textContent = 'Waiting for game. Reload after installing, then press Play.'; return; }
    try {
      const s = engine.state(), counters = statusPtr ? engine.status(statusPtr) : null;
      dragRace=!!(s.ready && s.drag);
      const driveStatus = counters && Number.isFinite(counters.drive) ? counters.drive & 3 : 0;
      const canInput = supported && s.ready && (!s.network || prefs.online) && driveStatus !== 0 && !document.hidden && document.hasFocus() && !document.querySelector('dialog[open]');
      const safe = canInput && s.driving;
      // Record identity changes as booleans, never addresses or save/player identifiers.
      try {
      const identity={player:engine.u32(0xd00000),car:s.car,race:s.race};
      diagnosticState={generation:sessionGeneration,revision,supported,ready:!!s.ready,driving:!!s.driving,network:!!s.network,safe:!!safe,hidden:document.hidden,focused:document.hasFocus(),hud:driveStatus,flow:engine.u32(0x8654a4),gameTicks:engine.u32(0x86518c),raceType:engine.u32(0x89e7b0),racePhase:s.ready?engine.u32(s.race):0,driverKind:s.ready?engine.u32(s.car+0x24):0,physicsKind:s.ready?engine.u32(s.car+0x28):0,dynoBusy:!!dyno?.busy,tools:diagnosticTools()};
      if(diagnosticIdentity && Object.keys(identity).some(key=>identity[key]!==diagnosticIdentity[key]))recordDiagnostic('identity-change',{playerChanged:identity.player!==diagnosticIdentity.player,carChanged:identity.car!==diagnosticIdentity.car,raceChanged:identity.race!==diagnosticIdentity.race});
      diagnosticIdentity=identity;
      } catch {}
      const nativeRaceType=s.ready?engine.u32(0x89e7b0):null;
      const roamProfile=!dragRace && driveStatus===2 && nativeRaceType===0;
      const raceProfile=!dragRace && (nativeRaceType===1 || nativeRaceType===7);
      const roadRaceProfile=(!s.network || prefs.online) && !dragRace && driveStatus===1 && nativeRaceType===1 && !engine.u8(0x89e7d8) && !engine.u8(0x89e7d9) && !engine.u32(0x890108) && !engine.u32(0x890104) && !engine.u32(0x890114);
      const nativeDriftPace=moduleProfile?.capabilities.nativeDriftPace===true && !dragRace && !engine.u32(0x890108) && !!(engine.u8(0x89e7d9)||engine.u32(0x890104)||engine.u32(0x890114));
      const raceOnlyInputClear=!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown','KeyW','KeyA','KeyS','KeyD','Space'].some(code=>physicallyHeld.has(code));
      const raceOnlyEligible=!!(safe && raceOnlyInputClear && driveStatus===1 && nativeRaceType===1 && moduleProfile?.capabilities.ai===true && (!dragRace||moduleProfile?.capabilities.dragAI===true));
      const raceOnlyRequested=raceOnlyAI && raceOnlyEligible;
      const aiRequested=prefs.ai || raceOnlyRequested;
      const streetX=!!(engine.u8(0x89e7e3)||engine.u32(0x89010c)||(s.network&&engine.u32(0x850088)===10));
      const adaptive=adaptiveRaceSettings({enabled:adaptiveRaceEnabled,ceiling:adaptiveRaceCeiling,verified:supported&&moduleProfile?.capabilities.nativeDragInputHandoff===true&&moduleProfile?.capabilities.corner===true&&moduleProfile?.capabilities.pace===true,ai:aiRequested,safe,network:s.network,allowNetwork:prefs.online,hud:driveStatus,raceType:nativeRaceType,drag:dragRace||!!engine.u32(0x890108),drift:!!(engine.u8(0x89e7d9)||engine.u32(0x890104)||engine.u32(0x890114)),streetX});
      const requestedPace=adaptive.requested?adaptive.ceiling:nativeDriftPace?1:roamProfile && prefs.aiPace?prefs.paceFactor:raceProfile && prefs.racePace?prefs.racePaceFactor:1;
      const effectiveRaceCorner=(prefs.raceCornerAssist||adaptive.requested)&&roadRaceProfile;
      // Drop synthetic input before publishing a native drag handoff request.
      const dragAIRequested = aiRequested && dragRace;
      if (dragAIRequested) release();
      const aiState = ai?.update({enabled:aiRequested,safe,state:s,mode:driveStatus,pace:requestedPace,allowNetwork:prefs.online,allowDragAI:dragAIRequested,cornerAssist:prefs.cornerAssist,cornerFactor:prefs.cornerFactor,cornerMargin:prefs.cornerMargin,raceCornerAssist:effectiveRaceCorner,adaptiveCorners:adaptive.requested,raceCornerFactor:prefs.raceCornerFactor,raceCornerMargin:prefs.raceCornerMargin,raceBraking:prefs.raceBraking,dragNoBlowout:prefs.dragNoBlowout}) || {available:false,active:false,status:'Native game AI · experimental',reason:'Reload with the native AI module installed.'};
      const paceConfirmed=!!aiRequested && safe && !ai?.handbackPending && !aiState.switching && !!aiState.active && Number.isFinite(aiState.paceApplied) && aiState.paceApplied>=.75 && aiState.paceApplied<=3;
      const adaptiveState=!adaptive.requested?adaptive.state:ai?.handbackPending||aiState.switching||!aiState.active?'handoff':!paceConfirmed||Math.abs(aiState.paceApplied-adaptive.ceiling)>.011?'pace-pending':aiState.cornerMode===3&&Number.isFinite(aiState.cornerApplied)&&aiState.cornerHits>0&&aiState.brakingHits>0?'planner-observed':'planner-pending';
      diagnosticState={...diagnosticState,adaptiveRaceRequested:adaptive.requested,adaptiveRaceState:adaptiveState,adaptiveRaceCeiling};
      const wallState=wall?.update({enabled:prefs.walls,safe,state:s}) || {requested:false,hits:0,reason:'Reload with the wall-contact module installed.'};
      const carState=cars?.update({enabled:prefs.cars,onlineTraffic:prefs.traffic,onlinePlayers:prefs.players,allowNetwork:prefs.online,safe,state:s}) || {requested:false,hits:0,reason:'Car no-clip is not verified for this build.'};
      try {diagnosticState={...diagnosticState,...engine.nosDiagnostics(s,supported&&moduleProfile?.capabilities.driftDiagnostics===true)};} catch {}
      let nos = false;
      if (safe && prefs.nos) nos = engine.refill(s,prefs.online);
      let tune={active:false},grip={active:false};
      // Observational only: selection, page-side write success and a native
      // pace-hook acknowledgement are different from measured vehicle speed.
      let powerStatus=!(prefs.boost||prefs.unlimit)?'off':!supported?'unsupported':!s.ready?'not-ready':s.network&&!prefs.online?'network-permission':document.hidden?'hidden':!document.hasFocus()?'unfocused':!driveStatus?'hud':!s.driving?'not-driving':!safe?'menu':driftPending?'drift-change':'settling';
      if(safe && !driftPending && (prefs.boost || prefs.unlimit)) {
        const info=engine.performanceInfo(s),patch=engine.performancePatch;
        if(patch && (!info || patch.car!==s.car || patch.race!==s.race || patch.pi!==info.pi)) {engine.restorePerformance(s);powerGate.reset();}
        if(!info){powerGate.reset();powerStatus='layout';}
        if(info && (engine.performancePatch || powerGate.accept([s.car,s.race,info.pi,...info.values]))) {
          tune=engine.tunePerformance(s,prefs.boost?prefs.power:1,prefs.unlimit,prefs.online);
          powerStatus=tune.active?'applied':tune.ok?'neutral':tune.changed?'changed':'rejected';
          if(tune.changed){powerGate.reset();message(tune.reason);}
        }
      } else {engine.restorePerformance(s);powerGate.reset();}
      if(safe && !driftPending && prefs.grip) {
        const info=engine.gripInfo(s),patch=engine.gripPatch;
        if(patch && (!info || patch.car!==s.car || patch.race!==s.race || patch.physics!==info.physics || patch.wheels.some((w,i)=>w!==info.wheels[i]))) {engine.restoreGrip(s);gripGate.reset();}
        if(!info)gripGate.reset();
        if(info && (engine.gripPatch || gripGate.accept([s.car,s.race,info.physics,...info.wheels,...info.values]))) {
          grip=engine.tuneGrip(s,prefs.gripFactor,prefs.online);
          if(grip.changed){gripGate.reset();message(grip.reason);}
        }
      } else {engine.restoreGrip(s);gripGate.reset();}
      try {diagnosticState={...diagnosticState,...engine.nativeDiagnostics(s,supported&&moduleProfile?.capabilities.driftDiagnostics===true),...engine.dragEngineDiagnostics(s,supported&&moduleProfile?.capabilities.nativeDragOverheat===true),powerStatus,raceOnlyInputClear,raceOnlyEligible,raceOnlyRequested,paceConfirmed,paceApplied:paceConfirmed?aiState.paceApplied:undefined,powerActive:!!tune.active,gripActive:!!grip.active,effectivePower:tune.power,effectiveGrip:grip.factor,limiterRemoved:!!tune.unlimit,aiActive:!!aiState.active,aiOwned:!!aiState.owned,handbackPending:!!ai?.handbackPending,pageHeartbeat:ai?.hb,nativeHeartbeatAck:aiState.ready&&typeof ai?.read==='function'?ai.read(44):undefined,aiRequestedMode:aiState.ready&&typeof ai?.read==='function'?ai.read(8):undefined,aiNativeStatus:aiState.ready&&typeof ai?.read==='function'?ai.read(52):undefined,aiStaleTicks:aiState.ready&&typeof ai?.read==='function'?ai.read(48):undefined,aiSkillSaved:aiState.ready&&typeof ai?.read==='function'?!!ai.read(64):undefined,savedNativeSkill:aiState.ready&&typeof ai?.read==='function'&&ai.read(64)?ai.read(68):undefined,requestedPace,cornerRequested:!!aiState.cornerRequested,cornerMemoryBlocked:!!aiState.cornerMemoryBlocked,cornerDriftBlocked:!!aiState.cornerDriftBlocked,cornerMode:aiState.cornerMode,cornerPace:aiState.cornerPace,cornerBraking:aiState.cornerBraking,brakingHits:aiState.brakingHits,cornerHits:aiState.cornerHits,cornerApplied:aiState.cornerApplied,cornerProbeStage:aiState.cornerProbeStage,cornerDriverValid:aiState.cornerDriverValid,cornerRouteOwned:aiState.cornerRouteOwned,cornerRouteNodes:aiState.cornerRouteNodes,cornerPlannerCorners:aiState.cornerPlannerCorners,cornerGuardMask:aiState.cornerGuardMask,wallRequested:!!wallState.requested,wallHits:wallState.hits,onlineTrafficRequested:!!carState.onlineTraffic,onlinePlayersRequested:!!carState.onlinePlayers,onlineRaceCarsRequested:!!carState.onlineRaceCars,trafficHits:carState.trafficHits,playerHits:carState.playerHits,carRequested:typeof carState!=='undefined'?!!carState.requested:false,carHits:typeof carState!=='undefined'?carState.hits:0};diagnostics?.snapshot(diagnosticState);} catch {}
      infoHudSample={at:performance.now(),data:{...diagnosticState},context:{menu:!!document.querySelector('dialog[open]'),drag:dragRace,drift:nativeDriftPace,roam:roamProfile,race:raceProfile,paceAvailable:moduleProfile?.capabilities.pace===true,aiAvailable:aiState.available,aiStatus:aiState.status,manual:aiState.manual,switching:!!aiState.switching}};
      renderInfoHud();
      const manualDriver = s.ready && engine.u32(s.car+0x24)===1 && !aiState.active && (!ai || !aiState.available || (aiState.ready && !aiState.owned));
      const dragCountdown = dragRace && engine.u32(s.race)===3;
      const activeDrag = canInput && (s.driving || dragCountdown) && prefs.drag && !dragAIRequested && dragRace && manualDriver && !dragTakenOver;
      const now = performance.now();
      if (activeDrag) {
        hold('ArrowUp', true);
        if (s.driving && prefs.nos && nos && s.gear >= 3) hold('AltLeft', true); else hold('AltLeft', false);
        if (s.driving && s.rpm >= prefs.rpm && s.gear >= 2 && s.gear < 7 && now - lastShift > 650) {
          lastShift = now; hold('ShiftLeft', true);
          shiftTimer = setTimeout(() => hold('ShiftLeft', false), 85);
        }
        // Refresh synthetic held keys after a game's own input-release event.
        if (now - lastPulse > 500) { lastPulse = now; for (const code of held) if (code !== 'ShiftLeft') key(code, true); }
      } else release();
      if (live) live.textContent = !supported ? `Game build ${revision || '(checking)'} is not verified. Memory tools disabled.` : !s.ready ? s.reason : s.network && !prefs.online ? 'Online/LAN tools paused. Enable Allow Online/LAN tools in Session mode.' : !driveStatus ? 'Waiting for driving HUD.' : `${s.network ? 'Online/LAN opt-in' : 'Game linked'} · ${Math.round(s.rpm)} RPM${prefs.nos ? nos ? ' · NOS refilling' : ' · NOS unavailable/paused' : ''}${tune.active ? ` · Power ${tune.power.toFixed(1)}×${tune.unlimit ? ' · Governor off' : ''}` : (prefs.boost || prefs.unlimit) ? ' · Power controls waiting/unavailable' : ''}${grip.active ? ` · Grip ${grip.factor.toFixed(1)}×` : prefs.grip ? ' · Grip paused/unavailable' : ''}${prefs.drag ? activeDrag ? dragCountdown ? ' · Drag countdown throttle' : ' · Drag throttle/shifting · you steer' : dragTakenOver ? ' · Drag paused for manual control' : dragRace && !manualDriver ? ' · Drag waiting for native handback' : ' · Drag assist paused/waiting' : ''}`;
      if (ui) {
        const caps=moduleProfile?.capabilities;
        for(const [id,feature] of [['ai-pace','pace'],['pace-factor','pace'],['race-pace','pace'],['race-pace-factor','pace'],['race-corner-assist','corner'],['race-corner-factor','corner'],['race-corner-margin','corner'],['race-braking','corner'],['corner-assist','corner'],['corner-factor','corner'],['corner-margin','corner'],['walls','walls'],['cars','cars'],['traffic','onlineTraffic'],['players','onlinePlayers'],['dyno-enable','dyno']]){const control=ui.querySelector('#'+id);if(control)control.disabled=(feature==='onlineTraffic'||feature==='onlinePlayers')?caps?.[feature]!==true:!!caps&&!caps[feature];}
        if(live)live.title=live.textContent;
        renderPowerStatus(powerStatus,tune);
        const enabled=[adaptiveRaceEnabled,prefs.raceCornerAssist,prefs.cornerAssist,prefs.racePace,prefs.walls,prefs.cars,prefs.traffic,prefs.players,prefs.ai,raceOnlyAI,prefs.aiPace,prefs.nos,prefs.boost,prefs.unlimit,prefs.grip,prefs.dragNoBlowout,prefs.drag,prefs.tester,!!(counters?.drift & 1)].filter(Boolean).length;
        ui.querySelector('#enabled').textContent=enabled ? `${enabled} selected` : 'Ready';
        ui.querySelector('#cars-state').textContent=caps&&!caps.cars?'Not verified for this build':prefs.cars?(carState.soloReason||carState.reason):'OFF · other cars only · solo';
        ui.querySelector('#traffic-state').textContent=caps?.onlineTraffic!==true?'Not verified for this build':prefs.traffic?(carState.trafficReason||carState.reason):'OFF · traffic only · online free roam';
        ui.querySelector('#players-state').textContent=caps?.onlinePlayers!==true?'Not verified for this build':prefs.players?(carState.playersReason||carState.reason):'OFF · players / online race cars';
        ui.querySelector('#walls-state').textContent=caps&&!caps.walls?'Not yet verified for this build':prefs.walls?wallState.reason:'OFF · resets after reload';
        ui.querySelector('#online-state').textContent = prefs.online ? 'ON this page · experimental · F9 disables' : 'OFF · profile restore needs saved permission';
        const aiNode=ui.querySelector('#ai-state'),failure=moduleFailure();
        aiNode.dataset.unavailable=String(!!failure);
        ui.querySelector('#race-only-state').textContent=!raceOnlyAI?'Off · current page only':!supported||caps?.ai!==true?'Armed · waiting for a verified AI build':s.network&&!prefs.online?'Armed · paused online without permission':!raceOnlyInputClear?'Armed · release driving controls before takeover':!raceOnlyEligible?(ai?.handbackPending||aiState.owned?'Leaving race · native handback pending':'Armed · waiting for active race / GO'):aiState.active&&!ai?.handbackPending&&!aiState.switching?'Native race AI active':aiState.status==='retry'?'Native request preserved · switch off/on to retry':aiState.reason||'Race AI requested · waiting for native confirmation';
        aiNode.textContent = failure ? `AI unavailable. ${failure}` : (prefs.ai||raceOnlyAI) && s.network && !prefs.online ? 'Paused online · enable Session mode opt-in' : aiRequested ? [dragRace ? 'Auto · drag AI' : 'Auto · native AI', aiState.status || 'Native game AI · experimental', aiState.reason].filter(Boolean).join(' · ') : 'Highest native skill · experimental · off';
        ui.querySelector('#adaptive-race').disabled=!(supported&&caps?.nativeDragInputHandoff&&caps?.corner&&caps?.pace);
        const adaptiveLabels={off:'Off · session only',invalid:'Invalid ceiling · not applied',unsupported:'Unavailable on this build','street-x':'Street X unchanged · using saved controls',mode:'Waiting for road race · not Drag, Drift, Outrun or free roam','network-permission':'Paused online · allow network tools first','ai-off':'Waiting for an automatic driver mode',paused:'Paused · waiting for safe active driving',handoff:'Rebuilding native route · waiting for handoff','pace-pending':'Requested · waiting for pace acknowledgment','planner-pending':'Pace acknowledged · awaiting corner/braking evidence','planner-observed':'Pace, corner and braking hooks observed'};
        ui.querySelector('#adaptive-race-state').textContent=adaptiveLabels[adaptiveState];
        ui.querySelector('#adaptive-race-state').title=adaptiveLabels[adaptiveState]+'. Planned target speed varies with native route distance; this is not measured speed or proof of a clean corner.';
        ui.querySelector('#ai-pace-state').textContent = caps&&!caps.pace?'Not yet verified for this build':!prefs.aiPace ? 'Off · free roam only' : nativeDriftPace ? 'Paused in Drift · native pace retained' : dragRace ? 'Paused in drag · native pace unchanged' : !roamProfile ? `${prefs.paceFactor.toFixed(2)}× saved · waiting for free roam` : !aiRequested || !aiState.active ? `${prefs.paceFactor.toFixed(2)}× selected · waiting for AI` : paceConfirmed ? `${aiState.paceApplied.toFixed(2)}× confirmed` : `${prefs.paceFactor.toFixed(2)}× requested`;
        ui.querySelector('#race-pace-state').textContent = adaptive.requested?`Adaptive ceiling ${adaptive.ceiling.toFixed(2)}× · saved race pace unchanged`: caps&&!caps.pace?'Not yet verified for this build':!prefs.racePace ? 'Off · normal race pace' : nativeDriftPace ? 'Paused in Drift · native pace retained' : !raceProfile ? `${prefs.racePaceFactor.toFixed(2)}× saved · waiting for race / outrun` : !aiRequested || !aiState.active ? `${prefs.racePaceFactor.toFixed(2)}× selected · waiting for AI` : paceConfirmed ? `${aiState.paceApplied.toFixed(2)}× confirmed` : `${prefs.racePaceFactor.toFixed(2)}× requested`;
        ui.querySelector('#race-corner-state').textContent = adaptive.requested?adaptiveState==='planner-observed'?'Adaptive hook hits observed · not a check of this corner':`Adaptive requested · ${pendingCornerText(aiState)}`: caps&&!caps.corner?'Not yet verified for this build':!prefs.raceCornerAssist ? 'Off · road races; online needs opt-in' : s.network && !prefs.online ? 'Paused online · enable Session mode opt-in' : !roadRaceProfile ? 'Waiting for ordinary road race · excludes outrun, drag and drift' : !aiRequested || !aiState.active ? 'Waiting for automatic AI' : aiState.cornerMemoryBlocked ? 'Blocked · corner command memory is occupied' : aiState.cornerMode===2 && Number.isFinite(aiState.cornerApplied) ? `${aiState.cornerApplied.toFixed(2)}× road-race corner cap observed · braking hits ${aiState.brakingHits ?? 0}` : aiState.cornerMode===2 && aiState.cornerRequested ? pendingCornerText(aiState) : 'Not armed · road-race command was not accepted';
        ui.querySelector('#corner-state').textContent = caps&&!caps.corner?'Not yet verified for this build':!prefs.cornerAssist ? 'Off · free roam only' : !roamProfile ? 'Waiting for free roam' : !aiRequested || !aiState.active ? 'Waiting for automatic AI' : aiState.cornerMemoryBlocked ? 'Blocked · corner command memory is occupied' : aiState.cornerDriftBlocked ? 'Paused · drift mode excludes corner assist' : Number.isFinite(aiState.cornerApplied) ? `${aiState.cornerApplied.toFixed(2)}× corner-speed cap confirmed` : aiState.cornerRequested ? pendingCornerText(aiState) : 'Not armed · corner command was not accepted';
        ui.querySelector('#drag-ai-state').textContent = caps&&!caps.dragAI?'Not yet verified for this build':!aiRequested ? (raceOnlyAI?'Race-only AI armed · waiting for active race':'Enable Automatic driver or Race-only automatic driver') : dragRace ? aiState.active ? aiState.opponentDragSelected ? 'Opponent drag action confirmed · gameplay unverified' : aiState.dragSelection==='unsupported' ? 'Opponent selector unsupported on this build' : 'Native driver active · opponent action pending' : safe ? 'Auto-selected · waiting for native confirmation' : 'Auto-selected · waits for GO / supported driving state' : 'Automatic · waiting for a drag race';
        ui.querySelector('#drag-no-blowout').disabled=moduleProfile?.capabilities.nativeDragOverheat!==true;
        ui.querySelector('#drag-no-blowout-state').textContent=moduleProfile?.capabilities.nativeDragOverheat!==true?'Unavailable on this game build':prefs.dragNoBlowout?(s.network&&!prefs.online?'Paused online · enable Allow network tools':safe && s.drag?'Requested · current player engine only':'Waiting for active Drag'):'Off · normal Drag engine damage';
        ui.querySelector('#drag-state').textContent = activeDrag ? dragCountdown ? 'Countdown throttle · shifts wait for GO' : 'Throttle + shifting active · you steer' : prefs.drag ? dragAIRequested ? 'Paused while automatic drag AI is requested' : dragTakenOver ? 'Paused by manual takeover · toggle to resume' : dragRace && !manualDriver ? 'Waiting for native AI to release the car' : s.network && !prefs.online ? 'Paused online · enable Session mode opt-in' : 'Waiting for drag driving state' : 'Throttle + shifting · you steer';
        ui.querySelector('#grip-state').textContent=grip.active ? `Tyre-force multiplier ${grip.factor.toFixed(1)}× applied` : prefs.grip ? (grip.reason || 'Waiting for driving state') : 'More tyre grip · start at 1.3×';
        if (prefs.tester && supported && s.ready && now - lastScan > 250) {
          lastScan = now;
          const h = engine.hazards(s), close = h?.cars[0];
          ui.querySelector('#hazards').textContent = h ? `${h.scannedCars} car objects read. ${close ? `Nearest ahead: ${close.ahead.toFixed(0)} m, side offset ${close.side.toFixed(1)} m.` : 'No nearby car detected ahead.'} ${h.barrierAhead !== null ? `Barrier line ahead: ${h.barrierAhead.toFixed(0)} m.` : 'No crossing barrier line detected.'} Props and general obstacles: NOT detected.` : 'Detector waiting for valid car coordinates.';
        }
        const driftKnown = counters && Number.isFinite(counters.drift);
        const drift = driftKnown ? !!(counters.drift & 1) : null;
        const driftActive = driftKnown && !!(counters.drift & 2);
        if (driftPending && driftKnown && drift === driftPending.wanted && (!drift || driftActive)) {
          message(drift ? 'Drift assist ON: confirmed by the game’s handling state.' : 'Drift assist OFF: confirmed by the game.'); driftPending=null;
        } else if (driftPending && now > driftPending.until) {
          message('The game did not confirm drift assist. Use solo free roam (not a race or co-op), close menus, then try again.'); driftPending=null;
        }
        ui.querySelector('#drift').disabled = !!driftPending;
        if(driftNeedsReapply && !driftPending && safe && driveStatus===2 && driftKnown) {driftNeedsReapply=false;if(!setDrift(prefs.drift))message('Drift request could not be sent. Toggle it again in free roam.');}
        if(driftKnown && !driftPending && !driftNeedsReapply) {
          ui.querySelector('#drift').checked=drift;
          if(typeof prefs.drift==='boolean' && prefs.drift!==drift){prefs.drift=drift;savePrefs();}
        }
        for(const id of ['ai-state','race-only-state','ai-pace-state','race-pace-state','race-corner-state','corner-state','grip-state','walls-state','cars-state','traffic-state','players-state','drag-state','drag-ai-state','online-state']) {const node=ui.querySelector('#'+id);node.title=node.textContent;}
        for(const [id,mode] of [['corner-state',1],['race-corner-state',2]]) if(aiState.cornerRequested && aiState.cornerMode===mode) {const node=ui.querySelector('#'+id);node.title=node.textContent+' · '+cornerEvidenceText(aiState);}
        ui.querySelector('#drift-state').textContent = driftNeedsReapply ? 'Choice saved · waiting for solo free roam' : driftPending ? 'Waiting for confirmation…' : driftActive ? 'Game confirms drift handling ON' : drift ? 'Selected, but not active in this game mode' : 'Free roam only · not perfect-drift automation';
      }
    } catch (error) { recordDiagnostic('engine-error',{error,tools:diagnosticTools()});stop('Runtime changed or is unavailable. Reload the game before retrying.'); engine = null; }
  }
  function setPanel(open) {
    visible=!!open;
    if(host)host.style.width=visible?'244px':'170px';
    if(!visible && dyno?.busy)dyno.cancel();
    if(!ui) return;
    ui.querySelector('#tools-panel').hidden=!visible;
    ui.querySelector('#min').setAttribute('aria-expanded',String(visible));
    ui.querySelector('#chevron').textContent=visible ? '▴' : '▾';
    renderInfoHud();
  }
  function updateDynoUI() {
    if(!ui)return;
    const busy=!!dyno?.busy,ready=!!(dynoEnabled && supported && dyno?.canUse() && !document.hidden && document.hasFocus());
    const context=ready&&!busy?dyno?.syncContext?.():null;
    if(context?.invalidated)dynoText='Car tuning or installed parts changed. Load settings or find a new tune for this game mode.';
    else if(context?.changed)dynoText=dyno.applied?'Applied tune found for this car and mode. Restore is available while it stays unchanged.':dyno.outcome?'Preview found for this car and mode. Review it before Apply.':'Ready for the selected mode. Load all settings or search a measured native estimate.';
    ui.querySelector('#dyno-mode').textContent=context?`Game tuning slot ${context.kind+1} of 5${Tune?.MODE_LABELS?.[context.kind]?' · '+Tune.MODE_LABELS[context.kind]:''} · selected in Mode Select`:busy&&dyno?.context?`Game tuning slot ${dyno.context.kind+1} of 5`:'Choose a race mode in the game, then open the Dyno main screen.';
    ui.querySelector('#dyno-find').disabled=!ready || busy || !!dyno?.applied;
    ui.querySelector('#dyno-cancel').disabled=!busy;
    ui.querySelector('#dyno-apply').disabled=!ready || busy || !(dyno?.full?dyno.outcome?.changed:dyno?.outcome?.improved) || !!dyno?.applied;
    ui.querySelector('#dyno-restore').disabled=!ready || busy || !dyno?.applied;
    ui.querySelector('#dyno-goal').disabled=busy;
    for(const option of ui.querySelector('#dyno-goal').options||[])if(['acceleration60','acceleration100','topSpeed'].includes(option.value))option.disabled=!dyno?.full;
    if(dyno && !dyno.full&&['acceleration60','acceleration100','topSpeed'].includes(ui.querySelector('#dyno-goal').value))ui.querySelector('#dyno-goal').value='peakPower';
    updateSetupEditor(ready,busy);
    ui.querySelector('#dyno-state').textContent=moduleFailure()?`Dyno unavailable. ${moduleFailure()}`:moduleProfile&&!moduleProfile.capabilities.dyno?'Not yet verified for this build':dynoText;
  }
  const tuneValue=value=>(value>100?'+':'')+(value-100);
  function updateSetupEditor(ready,busy){
    const editor=dyno?.editor,editable=!!(ready&&!busy&&editor&&!dyno?.applied);
    ui.querySelector('#tune-load').disabled=!ready||busy||!!dyno?.applied||!dyno?.full;
    ui.querySelector('#tune-preview').disabled=!editable;
    ui.querySelector('#tune-reset').disabled=!editable;
    ui.querySelector('#tune-group').disabled=!editable;
    const group=Tune?.GROUPS?.find(g=>g.id===ui.querySelector('#tune-group').value)||Tune?.GROUPS?.[0];
    for(let i=0;i<9;i++){
      const offset=group?.offsets[i],present=!!editor&&offset!==undefined,row=ui.querySelector('#tune-row-'+i),input=ui.querySelector('#tune-input-'+i);
      row.hidden=!present;input.disabled=!editable||!editor?.allowedOffsets.includes(offset);
      if(present){
        input.dataset.offset=String(offset);input.value=editor.draft[offset]-100;
        ui.querySelector('#tune-label-'+i).textContent=(Tune?.FIELD_LABELS?.[offset]||'Setting '+(offset+1))+(editor.allowedOffsets.includes(offset)?'':editor.unlockedOffsets?.includes(offset)?' · unverified':' · locked');
        ui.querySelector('#tune-value-'+i).textContent=tuneValue(editor.draft[offset]);
      }
    }
    const o=dyno?.outcome;
    ui.querySelector('#tune-changes').textContent=dyno?.full&&Array.isArray(o?.changes)?o.changes.map(x=>`${Tune?.FIELD_LABELS?.[x.offset]||x.field}: ${tuneValue(x.before)} → ${tuneValue(x.after)}${x.adjusted?' (native adjusted request '+tuneValue(x.requested)+')':''}`).join('\n')||'No accepted setup changes.':editor?'Edit sliders, then Preview changes. Drafts never alter the game.':'Load settings to see unlocked controls for this car and preset.';
  }
  async function runDyno(action) {
    if(!dynoEnabled || !dyno || dyno.busy)return;
    recordDiagnostic('dyno-action',{reason:action,tools:diagnosticTools()});
    suspend();
    dyno.setEnabled(true);
    try {
      if(action==='load'){
        await dyno.loadSetup();dynoText='All supported settings loaded. Edit a category, then Preview. Nothing changes in the game until Stage.';
      } else if(action==='preview'){
        const r=await dyno.preview();
        dynoText=`${r.changed?'Preview ready. Review accepted changes, then Stage selected preset.':'No accepted setup changes.'} Game unchanged. Native estimates: 0–60 ${r.bestResult.zeroTo60Seconds.toFixed(2)} s; 0–100 ${r.bestResult.zeroTo100Seconds.toFixed(2)} s; top ${(r.bestResult.topSpeedMps*3.6).toFixed(1)} km/h; ${r.bestResult.peakPowerKw.toFixed(1)} kW / ${r.bestResult.peakTorqueNm.toFixed(1)} Nm. NOS ${r.bestResult.nitrousSeconds.toFixed(2)} s / torque setting ${r.bestResult.nitrousTorque.toFixed(3)}. No handling/lap-time measurement.`;
      } else if(action==='find') {
        dynoText=dyno.full?'Searching in private memory · game setup stays unchanged':'Searching · original setup is restored after each trial';updateDynoUI();
        const r=await dyno.find({goal:ui.querySelector('#dyno-goal').value,onProgress:p=>{dynoText=`Searching ${p.evaluations}/${p.budget} trials · Cancel or F9 to stop`;updateDynoUI();}});
        const [field,unit]=({peakPower:['peakPowerKw','kW'],peakTorque:['peakTorqueNm','Nm'],acceleration60:['zeroTo60Seconds','s (0–60)'],acceleration100:['zeroTo100Seconds','s (0–100)'],topSpeed:['topSpeedMps','m/s']}[r.goal]);
        if(dyno.full){
          const manualSeed=r.seed?.some((value,index)=>value!==r.baseline[index]);
          const seedText=manualSeed&&r.changed?(r.improvedFromSeed?' Search improved the measured goal over your draft.':' No further measured improvement over the draft. Accepted manual draft retained.'):'';
          dynoText=`${r.baselineResult[field].toFixed(1)} → ${r.bestResult[field].toFixed(1)} ${unit} · ${r.evaluations} trials. Original kept. ${r.improved?'Measured goal improved versus original.':'No measured goal improvement versus original.'}${seedText} ${r.changed?'Review accepted changes, then Stage selected preset.':'No accepted setup changes.'} No handling/lap-time measurement.`;
        }else dynoText=`${r.baselineResult[field].toFixed(1)} → ${r.bestResult[field].toFixed(1)} ${unit} · ${r.evaluations} trials. Original kept. ${r.improved?'Stage preview to use this tune.':'No improvement found.'}`;
      } else if(action==='apply') {const r=await dyno.apply();dynoText=dyno.full?'Selected preset staged. Use the game’s Test Run to refresh driving physics, and Save Profile to persist. Disk save is not confirmed.'+(r.saveReady?'':' Other presets also have unsaved edits; native Save Profile saves them too.'):'Best tune applied. Use native Save Profile to persist.';}
      else {await dyno.restore();dynoText=dyno.full?'Previous current and selected-visit settings restored. Test Run refreshes physics. Save Profile again if you want this restored version persisted.':'Previous tune restored and confirmed.';}
    } catch(error) {recordDiagnostic('dyno-error',{error,dynoStatus:error?.dynoStatus,dynoGuard:error?.dynoGuard,dynoObserved:error?.dynoObserved,tools:diagnosticTools()});dynoText=error?.message || 'Dyno tuner stopped. Reload before retrying.';}
    updateDynoUI();
  }
  function exportDiagnostic() {
    if(!diagnostics){message('Diagnostic logger is unavailable. The game’s Download log may still have crash details.');return;}
    let url=null,link=null;
    try {
      recordDiagnostic('export',{tools:diagnosticTools()});
      const blob=new Blob([diagnostics.exportText()],{type:'application/json'});
      url=URL.createObjectURL(blob);link=document.createElement('a');link.href=url;link.download='nfsu2-driving-tools-diagnostics.json';link.hidden=true;
      (document.body||document.documentElement).append(link);link.click();
      message('Diagnostic download requested. It stays local until you choose to share the file. For native crash details, also use the game’s Download log.');
    } catch(error) {recordDiagnostic('engine-error',{error});message('Diagnostic download failed. Try again, or use the game’s Download log.');}
    finally {link?.remove();if(url)setTimeout(()=>URL.revokeObjectURL(url),1000);}
  }
  const profileToggleIds={raceCornerAssist:'race-corner-assist',cornerAssist:'corner-assist',racePace:'race-pace',walls:'walls',cars:'cars',traffic:'traffic',players:'players',online:'online',ai:'ai',aiPace:'ai-pace',nos:'nos',dragNoBlowout:'drag-no-blowout',drag:'drag',tester:'tester',boost:'boost',unlimit:'unlimit',grip:'grip'};
  const profileNumericBindings=[['race-corner-factor','raceCornerFactor','race-corner-value',2,'×'],['race-corner-margin','raceCornerMargin','race-corner-margin-value',0,'%'],['race-braking','raceBraking','race-braking-value',2,'×'],['race-pace-factor','racePaceFactor','race-pace-value',2,'×'],['corner-factor','cornerFactor','corner-value',2,'×'],['corner-margin','cornerMargin','corner-margin-value',0,'%'],['pace-factor','paceFactor','pace-value',2,'×'],['rpm','rpm','rpm-value',0,''],['power','power','power-value',1,'×'],['grip-factor','gripFactor','grip-value',1,'×']];
  function syncProfileControls(){
    if(!ui)return;
    for(const [key,id]of Object.entries(profileToggleIds))ui.querySelector('#'+id).checked=prefs[key];
    for(const [id,key,out,digits,suffix]of profileNumericBindings){const el=ui.querySelector('#'+id);el.value=prefs[key];ui.querySelector('#'+out).textContent=prefs[key].toFixed(digits)+suffix;el.setAttribute('aria-valuetext',prefs[key].toFixed(digits)+(suffix==='%'?' percent':suffix?' times':' RPM'));}
    ui.querySelector('#dyno-enable').checked=dynoEnabled;
    ui.querySelector('#drift').checked=!!prefs.drift;
    ui.querySelector('#hazards').hidden=!prefs.tester;
  }
  const profileLocks=()=>typeof navigator!=='undefined'&&navigator.locks&&typeof navigator.locks.request==='function'?navigator.locks:null;
  function renderProfiles(){
    if(!ui)return;
    const state=profileStore?.snapshot(),select=ui.querySelector('#profile-select');
    select.replaceChildren();const empty=document.createElement('option');empty.value='';empty.textContent='Choose a saved profile';select.append(empty);
    for(const p of state?.data.profiles||[]){const option=document.createElement('option');option.value=p.id;option.textContent=p.name;select.append(option);}
    const selected=state?.data.profiles.find(p=>p.id===profileSelection?.id&&p.revision===profileSelection?.revision);
    if(!selected){profileSelection=null;ui.querySelector('#profile-network').checked=false;}
    select.value=selected?.id||'';
    for(const id of ['profile-load','profile-update','profile-delete','profile-auto'])ui.querySelector('#'+id).disabled=profileActionPending||!state?.available||!selected||(id!=='profile-load'&&!profileLocks());
    ui.querySelector('#profile-save').disabled=profileActionPending||!state?.available||!profileLocks();
    for(const id of ['profile-select','profile-name','profile-network'])ui.querySelector('#'+id).disabled=profileActionPending;
    ui.querySelector('#profile-auto').checked=!!selected&&state.data.auto?.id===selected.id&&state.data.auto.stopToken===state.stopToken&&!profileSessionStopped;
    ui.querySelector('#profile-state').textContent=state?.error||(profileActionPending?'Waiting for another tab to finish saving profiles.':profileNotice)||(!profileLocks()?'Profile editing is unavailable because this browser cannot lock local saves.':!profileStore?'Profiles unavailable; existing controls still work.':state.paused?'Automatic loading paused by Stop. Select a profile and enable Load on startup to resume.':state.data.auto?'A saved profile will load on next startup.':'Automatic loading is off. Save current controls, then select and Load when needed.');
  }
  function selectProfile(){
    const id=ui.querySelector('#profile-select').value,state=profileStore?.refresh();
    profileSelection=state?.data.profiles.find(p=>p.id===id)||null;
    ui.querySelector('#profile-name').value=profileSelection?.name||'';
    ui.querySelector('#profile-network').checked=profileSelection?.networkConsent||false;
    profileNotice=profileSelection?'Selected '+profileSelection.name+'. Load applies its saved choices. Update replaces it with current controls.':'';renderProfiles();
  }
  function applyToolProfile(result,automatic=false){
    if(driftPending)throw Error('Wait for the current drift request to confirm or time out, then Load again. No profile was loaded.');
    if(dyno?.busy||dyno?.pending){dyno.cancel();throw Error('Tuner cancellation requested. Wait for the pending game request to finish, then Load again. A staged preset is not reverted.');}
    clearRaceOnlyAI();
    adaptiveRaceEnabled=false;if(ui)ui.querySelector('#adaptive-race').checked=false;
    suspend();driftNeedsReapply=false;dragTakenOver=false;lastShift=0;lastPulse=0;
    const choices=result.settings;
    for(const key of Object.keys(prefs))prefs[key]=choices[key];
    dynoEnabled=choices.dynoEnabled;dyno?.setEnabled(dynoEnabled);
    if(ui){ui.querySelector('#dyno-goal').value=choices.dynoGoal;ui.querySelector('#profile-network').checked=result.profile.networkConsent;ui.querySelector('#profile-name').value=result.profile.name;}
    driftNeedsReapply=typeof prefs.drift==='boolean';profileDriftChoice=driftNeedsReapply;
    loadedProfile={id:result.profile.id,revision:result.profile.revision};savePrefs();syncProfileControls();
    dynoText=dynoEnabled?'Profile loaded. Open the solo Performance Tuning main screen. Existing staged presets are unchanged.':'Tuner off. Existing staged presets are unchanged.';updateDynoUI();
    profileNotice=(automatic?'Loaded on startup: ':'Loaded: ')+result.profile.name+'. Choices wait for verified game contexts.'+(result.profile.networkConsent?' Saved network permission restored where selected.':' Network permission and online no-clip remain off.')+' Game presets and drafts are not saved or restored by profiles.';
    message(profileNotice);renderProfiles();
  }
  function profileAction(action){
    if(profileActionPending)return;
    const request={stopToken:profileStore?.snapshot().stopToken,selection:profileSelection?{...profileSelection}:null,name:ui.querySelector('#profile-name').value,networkConsent:ui.querySelector('#profile-network').checked===true,auto:ui.querySelector('#profile-auto').checked,settings:{...prefs,dynoEnabled,dynoGoal:ui.querySelector('#dyno-goal').value}};
    const epoch=profileActionEpoch;
    // localStorage has no atomic compare-and-swap. Serialize named-profile
    // writes across tabs with a browser-managed lock; Stop remains immediate
    // and its independent marker invalidates any stale startup authorization.
    const execute=()=>{
      if(epoch!==profileActionEpoch)return;
      if(action==='auto'){
        const latest=profileStore?.refresh();
        if(!latest?.available||latest.stopToken!==request.stopToken){profileNotice='Stop or profile storage changed while waiting. Select a profile and request startup loading again.';renderProfiles();return;}
      }
      performProfileAction(action,request);
    };
    if(action==='load'){execute();return;}
    const locks=profileLocks();
    if(!locks){profileNotice='Profile editing needs browser storage locking, which is unavailable. No profile was changed.';renderProfiles();return;}
    profileActionPending=true;renderProfiles();
    try{
      const result=locks.request('nfsu2-driving-tools-profiles-v1-write',execute);
      if(result&&typeof result.then==='function')result.catch(()=>{if(epoch===profileActionEpoch)profileNotice='Could not lock profile storage. No profile change was confirmed.';}).finally(()=>{if(epoch===profileActionEpoch){profileActionPending=false;renderProfiles();}});
      else {profileActionPending=false;renderProfiles();}
    }catch{profileActionPending=false;profileNotice='Could not lock profile storage. No profile change was confirmed.';renderProfiles();}
  }
  function performProfileAction(action,request){
    const selected=request.selection;
    try{
      if(!profileStore)throw Error('Profiles are unavailable.');
      if(action==='save'||action==='update'){
        if(action==='update'&&!selected)throw Error('Select a saved profile first.');
        const saved=profileStore.save({id:action==='update'?selected.id:null,revision:action==='update'?selected.revision:null,name:request.name,settings:request.settings,networkConsent:request.networkConsent});
        profileSelection=saved;profileNotice='Saved '+saved.name+' locally in this browser. This profile will not load on startup until explicitly enabled.';
      }else if(action==='load'){
        if(!selected)throw Error('Select a saved profile first.');
        applyToolProfile(profileStore.load(selected.id,selected.revision));return;
      }else if(action==='delete'){
        if(!selected)throw Error('Select a saved profile first.');
        profileStore.remove(selected.id,selected.revision);profileSelection=null;ui.querySelector('#profile-name').value='';ui.querySelector('#profile-network').checked=false;profileNotice='Saved profile deleted. Current controls are unchanged; automatic loading for it is off.';
      }else if(action==='auto'){
        const enabled=request.auto;
        if(enabled&&!selected)throw Error('Select a saved profile first.');
        profileStore.setAuto(enabled?selected.id:null,enabled?selected.revision:null);
        if(enabled){
          // Clear the fallback latch only AFTER the requested saved revision was
          // authorized successfully; a stale/failed enable must not erase Stop.
          try{sessionStorage.removeItem(PROFILE_SESSION_STOP);if(sessionStorage.getItem(PROFILE_SESSION_STOP)==='1')throw Error();}
          catch{try{profileStore.setAuto(null);}catch{}throw Error('Cannot clear the Stop pause in this tab. Automatic loading remains blocked here; check storage before retrying.');}
          profileSessionStopped=false;
        }
        profileNotice=enabled?'Load on startup enabled for '+selected.name+'. Its saved choices, including separately saved network permission, will be requested after reload. F9 pauses this.':'Automatic profile loading is off. Current controls are unchanged.';
      }
    }catch(error){profileNotice=error.message||'Profile action failed. Nothing was loaded.';message(profileNotice);}
    renderProfiles();
  }
  function mount() {
    host = document.createElement('div'); host.id = 'nfsu2-driving-tools'; host.dataset.nfsu2Ui = '';
    host.addEventListener('keydown', e => e.stopPropagation());
    host.addEventListener('keyup', e => e.stopPropagation());
    Object.assign(host.style, { position: 'fixed', top: '8px', right: '8px', zIndex: '2147483647', width: '170px', maxWidth: 'calc(100vw - 16px)' });
    ui = host.attachShadow({ mode: 'closed' });
    // MAIN-world content scripts follow the page's CSP. A <style> element is
    // rejected by the game's style-src 'self'; use the CSSOM-supported sheet
    // instead, keeping styling scoped to this shadow root and CSP unchanged.
    const stylesheet = new CSSStyleSheet();
    stylesheet.replaceSync(`
:host{color-scheme:dark}*{box-sizing:border-box}[hidden]{display:none!important}button,input,select{font:inherit}button,summary{cursor:pointer}button,input,select,summary{-webkit-tap-highlight-color:transparent}button:focus-visible,input:focus-visible,select:focus-visible,summary:focus-visible{outline:2px solid #8cdbb5;outline-offset:2px}
.shell{font:11px/1.4 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;color:#dde9e5;filter:drop-shadow(0 5px 14px #0005)}button{color:inherit}.launcher{width:100%;height:29px;display:flex;align-items:center;gap:7px;padding:0 9px;background:#141e24;border:1px solid #50645e;border-radius:5px;color:#e3eee8;text-align:left}.mark{width:6px;height:6px;background:#9be8bc;border-radius:2px;box-shadow:0 0 8px #9be8bc35;flex:none}.title{font-size:11px;font-weight:650;white-space:nowrap}.badge{font-size:9px;color:#9bb4aa;margin-left:auto;white-space:nowrap}.arrow{color:#9bb4aa;font-size:10px;flex:none}.launcher[aria-expanded=true]{border-radius:5px 5px 0 0;border-bottom-color:#2a3b3b}
.panel{border:1px solid #50645e;border-top:0;border-radius:0 0 5px 5px;background:#141e24;max-height:calc(100vh - 48px);max-height:min(390px,calc(100dvh - 48px));overflow-y:auto;scrollbar-width:thin;scrollbar-color:#4e6860 #141e24}.toolbar{display:flex;align-items:center;gap:5px;padding:6px 8px;border-bottom:1px solid #2a3b3b;position:sticky;top:0;z-index:2;background:#141e24}.toolbar button{height:24px;flex:1;border:1px solid #3d5550;border-radius:3px;background:#20332f;font-size:10px}.toolbar button.stop{border-color:#60494c;background:#32272b;color:#e3afb3}.toolbar kbd{margin-left:4px;font-size:9px;color:#8eaaa0}.toolbar .stop kbd{color:#bc9095}.version{font-size:8px;color:#789289;line-height:1;white-space:nowrap;padding-left:2px}
.group{border:0;border-bottom:1px solid #263737}.group>summary{display:flex;align-items:center;gap:8px;list-style:none;min-height:26px;padding:5px 9px;color:#c3d5ce;font-weight:550;font-size:11px}.group>summary::-webkit-details-marker,.help>summary::-webkit-details-marker{display:none}.group>summary::after{content:'›';font-size:13px;line-height:1;color:#78978c;margin-left:auto;transform:rotate(0deg)}.group[open]>summary{background:#1d2e2d;color:#a7e8c2}.group[open]>summary::after{transform:rotate(90deg);color:#9be8bc}.section-icon{width:4px;height:4px;border-radius:1px;background:#789c8d;flex:none}.group-body{padding:3px 9px 7px;background:#101a20}
.row{display:flex;align-items:center;justify-content:space-between;gap:8px;min-height:26px;padding:4px 0;margin:0;color:#d1dfd9}.row>span:first-child{min-width:0;flex:1}.row small,.state{display:block;max-width:100%;margin:1px 0 0;color:#849d93;font-size:9px;font-weight:400;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.row small{max-width:184px}#ai-state[data-unavailable="true"]{white-space:normal;overflow:visible;text-overflow:clip;overflow-wrap:anywhere;line-height:1.45;color:#c5b591}.row-main{font-weight:550}.row input[type=checkbox]{appearance:none;width:25px;height:14px;margin:0;flex:none;border:1px solid #4d665b;border-radius:8px;background:#263a33;position:relative;cursor:pointer}.row input[type=checkbox]::before{content:'';position:absolute;left:2px;top:2px;width:8px;height:8px;background:#8ba69b;border-radius:50%}.row input[type=checkbox]:checked{background:#6cb68c;border-color:#8bcda7}.row input[type=checkbox]:checked::before{transform:translateX(11px);background:#10291f}
.slider{display:grid;grid-template-columns:1fr 40px;gap:0 6px;align-items:center;margin:0;padding:1px 0 5px;color:#9db6aa;font-size:9px}.slider>span{display:contents}.slider output{grid-column:2;grid-row:1;text-align:right;color:#bfe9cf;font:600 10px ui-monospace,SFMono-Regular,Consolas,monospace}.slider input{grid-column:1 / -1;width:100%;height:14px;margin:1px 0 0;accent-color:#91d3ad;cursor:pointer}.slider:has(input:disabled){opacity:.5}input:disabled,button:disabled,select:disabled{opacity:.4;cursor:default}
.help{margin:3px 0 1px;border-top:1px solid #263737;padding-top:2px}.help>summary{font-size:9px;list-style:none;display:flex;gap:5px;align-items:center;padding:4px 0;color:#839f92}.help>summary::before{content:'+';font:11px ui-monospace,monospace;color:#a4c3b2}.help[open]>summary::before{content:'−'}.help[open]>summary{color:#adcfba}.help p,.fine{font-size:9px;line-height:1.45;color:#90a89c;margin:4px 0}.warn{color:#c3b391}.help .row{font-size:10px}.inline-readout{padding:5px 6px;margin:4px 0;background:#1a2a2b;border-radius:3px;font-size:9px;color:#a6c3b3}.inline-readout strong{font-size:9px;font-weight:500;color:#badbc8}.inline-readout .state{white-space:normal;line-height:1.4}
select{max-width:140px;padding:4px 6px;border:1px solid #3c5549;border-radius:3px;background:#1c2e27;color:#c5dfce;font-size:10px}.dyno-buttons{display:grid;grid-template-columns:1fr 1fr;gap:5px;margin:6px 0}.dyno-buttons button{padding:5px 6px;border:1px solid #3e5b4c;border-radius:3px;background:#22372a;font-size:10px}.dyno-buttons button:nth-child(n+3){background:#192822;color:#a9c6b4}.dyno-buttons button:disabled{background:#192322}.tune-field{margin:8px 0}.tune-field label{display:flex;justify-content:space-between;gap:4px;font-size:10px}.tune-field input{width:100%}.tune-field output{color:#c5dfce;font-variant-numeric:tabular-nums}#tune-changes{white-space:pre-line;max-height:150px;overflow:auto;font-size:9px;line-height:1.45}#profile-name{width:100%;min-width:0;padding:5px 6px;margin:3px 0 6px;border:1px solid #3c5549;border-radius:3px;background:#1c2e27;color:#c5dfce;font-size:10px}.profile-name-label{font-size:10px;color:#b5cabe}#profile-state{white-space:normal;overflow-wrap:anywhere;font-size:10px;line-height:1.45;color:#b5d8c3}#dyno-state{white-space:normal;overflow-wrap:anywhere;max-height:62px;overflow:auto;font-size:9px;line-height:1.45;color:#a8c9b5}
.status{margin:0;padding:0 8px;background:#121b20}.status>summary{display:flex;gap:6px;align-items:center;padding:5px 0;list-style:none;min-height:24px;cursor:pointer}.status>summary::before{content:'';width:4px;height:4px;border-radius:50%;background:#759d86;flex:none}.status>summary::after{content:'ⓘ';font-size:10px;margin-left:auto;color:#708d7b}.status[open]>summary{border-bottom:1px solid #293c32}#live{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:9px;color:#8fafa0;margin:0;flex:1;min-width:0}#note{margin:5px 0;color:#c5b591;font-size:10px;line-height:1.45;overflow-wrap:anywhere}.keys{font-size:9px;color:#708d7c;margin:4px 0 7px}.keys kbd{font:inherit;color:#a1c0ab}#hazards{font-size:9px;line-height:1.4;color:#a8c7b5;background:#1a2a23;padding:6px;border-radius:3px;overflow-wrap:anywhere}
.info-hud{position:absolute;right:0;top:35px;width:226px;max-width:calc(100vw - 16px);padding:8px 10px;border:1px solid #50645e88;border-radius:5px;background:#101a20d9;color:#c3d5ce;pointer-events:none;font-variant-numeric:tabular-nums;contain:layout style}.hud-heading{display:flex;justify-content:space-between;color:#8ba99b;font-size:9px;letter-spacing:.08em}.hud-heading kbd{font:inherit;letter-spacing:0;color:#789289}.hud-speedline{display:flex;align-items:baseline;gap:5px;padding:2px 0 1px}#hud-speed{color:#dbf2e4;font-size:24px;font-weight:650;line-height:1.2;letter-spacing:-.03em}#hud-unit{font-size:10px;color:#9bb4aa}#hud-context{margin-left:auto;font-size:9px;text-align:right;max-width:110px}.hud-readouts{margin:5px 0 0;padding-top:4px;border-top:1px solid #50645e44;display:grid;grid-template-columns:33px 1fr;gap:3px 5px;font-size:10px;line-height:1.4}.hud-readouts dt{color:#8ba99b}.hud-readouts dd{margin:0;text-align:right;overflow-wrap:anywhere;color:#c7e0d2}.hud-foot{font-size:8px;color:#8ba99b;line-height:1.35;margin:5px 0 0}#hud-state,#hud-governor{display:block;color:#c3b391}.hud-preference{padding:4px 9px;border-bottom:1px solid #263737;font-size:10px}.hud-preference small{font-size:8px}.hud-readouts,.hud-foot{user-select:none}
@media(max-height:280px){.info-hud{padding:5px 8px}.hud-foot{display:none}.hud-readouts{gap:1px 5px}}
@media(prefers-reduced-motion:no-preference){.row input[type=checkbox]::before{transition:transform .12s}.group>summary{transition:background .12s}}
`);
    ui.adoptedStyleSheets = [stylesheet];
    ui.innerHTML = `<div class="shell">
<button id="min" class="launcher" aria-expanded="false" aria-controls="tools-panel" title="Driving tools · F8 or Shift+Insert"><span class="mark" aria-hidden="true"></span><span class="title">Driving tools</span><span id="enabled" class="badge">Ready</span><span id="chevron" class="arrow" aria-hidden="true">▾</span></button>
<section id="info-hud" class="info-hud" aria-label="Driving information HUD" aria-live="off">
<div class="hud-heading"><span>INFO HUD</span><kbd>F6 hide</kbd></div>
<div class="hud-speedline"><strong id="hud-speed">Unavailable</strong><span id="hud-unit"></span><span id="hud-context">Waiting for game</span></div>
<dl class="hud-readouts"><dt>Driver</dt><dd id="hud-driver">Waiting for live sample</dd><dt>Pace</dt><dd id="hud-pace">Not confirmed</dd><dt>Power</dt><dd id="hud-power">Off</dd></dl>
<p class="hud-foot">req = requested · ack = native acknowledgement<br>set = power fields, not a measured speed gain<span id="hud-governor" hidden></span><span id="hud-state">Waiting for live sample</span></p>
</section>
<div id="tools-panel" class="panel" hidden>
<div class="toolbar"><button id="take-control" title="Return to manual control">Manual <kbd>F7</kbd></button><button id="stop" class="stop" title="Stop driving assists">Stop <kbd>F9</kbd></button><span class="version">0.33.0</span></div>
<label class="row hud-preference"><span>Info HUD <small>F6 · shown when this menu is closed</small></span><input id="info-hud-enable" type="checkbox" aria-label="Show driving information HUD"></label>
<details id="group-profiles" class="group"><summary><span class="section-icon" aria-hidden="true"></span>Saved tool profiles</summary><div class="group-body">
<label class="row"><span>Saved profile</span><select id="profile-select" aria-label="Saved tool profile"><option value="">Choose a saved profile</option></select></label>
<label class="profile-name-label" for="profile-name">Profile name</label><input id="profile-name" type="text" maxlength="48" autocomplete="off" placeholder="e.g. Solo driving">
<label class="row"><span>Restore network settings<small>Explicit permission for this profile</small></span><input id="profile-network" type="checkbox" aria-describedby="profile-network-help"></label>
<p id="profile-network-help" class="fine warn">Default off. Save / Update records this permission. Without it, Load leaves Allow network tools, online traffic and player no-clip off, even if they are currently on. Network tools may affect others or lead to a ban; follow server rules.</p>
<div class="dyno-buttons"><button id="profile-save" type="button">Save as new</button><button id="profile-update" type="button" disabled>Update selected</button><button id="profile-load" type="button" disabled>Load selected</button><button id="profile-delete" type="button" disabled>Delete selected</button></div>
<label class="row"><span>Load on startup<small>Selected saved profile · default off</small></span><input id="profile-auto" type="checkbox" disabled aria-describedby="profile-help"></label>
<p id="profile-state" role="status">Automatic loading is off.</p>
<details class="help"><summary>Profile storage &amp; safety</summary><p id="profile-help">Stores only these extension switches, numbers and tuner enable/search preference in this browser for nfsu2.xyz. No game setups, drafts, car data or diagnostic logs. Profiles do not Stage, Restore or Save game presets. Page scripts can access this local storage; it is not a private backup or browser sync. Up to 16 profiles, 48 characters per name.</p><p>Load stops old controllers and releases assisted input first. Saved choices still wait for the exact supported module, current car and each tool’s mode checks. Startup loading is optional and applies once per reload, never when another tab edits a profile. Updating an automatic profile disables its startup loading until selected again.</p><p>F9 stops driving tools, clears profile-requested drift reapplication and pauses startup loading; saved profiles stay intact. A drift toggle already sent to the game cannot be recalled, and native drift handling already on is not forcibly changed. Load manually to resume now, or select a profile and enable Load on startup to resume after reload. F7 takes manual control without deleting profiles.</p><p>Blowout protection is a saved user choice for the local current engine only. It does not repair an already blown engine or restore a lost race. Network use still requires this profile’s explicit network permission. Unless startup loading is enabled, normal per-tool reload defaults shown elsewhere still apply.</p></details>
</div></details>
<details id="group-driver" class="group"><summary><span class="section-icon" aria-hidden="true"></span>AI driver</summary><div class="group-body">
<label class="row row-main"><span>Automatic driver<small id="ai-state">All modes · includes free roam</small></span><input id="ai" type="checkbox" aria-describedby="ai-auto-risk"></label>
<label class="row"><span>Race-only automatic driver<small id="race-only-state">Off · current page only</small></span><input id="race-only-ai" type="checkbox" aria-describedby="race-only-help"></label>
<p id="race-only-help" class="fine">Starts native AI only in an active race, including Street X, Drag and Drift. Releases in free roam, outrun and results. Start/join events yourself. Online needs Allow network tools. This switch stays armed between races on this page; reload, profile Load, F7/F9 or race driving-key takeover turns it off. Not saved in profiles. Selecting either driver mode turns the other off.</p>
<details class="help"><summary>Free-roam tuning</summary>
<label class="row"><span>Free-roam corner assist<small id="corner-state">Off · experimental · free roam only</small></span><input id="corner-assist" type="checkbox" aria-describedby="corner-risk"></label>
<label class="slider"><span>Planned corner speed <output id="corner-value" for="corner-factor">0.80×</output></span><input id="corner-factor" aria-label="Planned corner speed" type="range" value="0.8" min="0.6" max="0.95" step="0.05"></label>
<label class="slider"><span>Sharp-turn margin <output id="corner-margin-value" for="corner-margin">15%</output></span><input id="corner-margin" aria-label="Extra sharp-turn margin" type="range" value="15" min="0" max="25" step="5"></label>
<label class="row"><span>Free-roam pace<small id="ai-pace-state">Off · normal pace</small></span><input id="ai-pace" type="checkbox" aria-describedby="ai-pace-help"></label>
<label class="slider"><span>Target-speed factor <output id="pace-value" for="pace-factor">1.00×</output></span><input id="pace-factor" aria-label="Free-roam pace factor" type="range" value="1" min="0.75" max="3" step="0.05"></label>
<p id="corner-risk" class="fine">Lower factor = slower planned turns. Sharp-turn margin adds more slowing as upcoming bends tighten; 0% keeps the v0.13 calculation. Changes rebuild the native route. Not obstacle avoidance or new steering. Armed is not a confirmed reduction: straight plans, missing corner entries and rejected native checks do not add hits. Hover the status for route/check evidence. Free-roam corner assist does not tune road races; use the separate Road-race hairpin assist there. Diagnose at 1× pace; 0.95× means only 5% corner slowing.</p><p id="ai-pace-help" class="fine warn">Pace up to 3× is experimental; 2–3× can cause severe overspeed, missed turns or instability. Start at 1×. Neither control changes race or drag pace.</p>
</details>
<details class="help"><summary>Race / outrun tuning</summary>
<label class="row"><span>Adaptive road-race speed<small id="adaptive-race-state">Off · session only</small></span><input id="adaptive-race" type="checkbox" disabled aria-describedby="adaptive-race-help"></label>
<label class="slider"><span>Straight ceiling <output id="adaptive-race-value" for="adaptive-race-ceiling">1.30×</output></span><input id="adaptive-race-ceiling" aria-label="Adaptive race straight ceiling" type="range" value="1.3" min="1" max="2" step="0.05"></label>
<p id="adaptive-race-help" class="fine">Optional continuous route-speed planning: every valid sampled nonzero bend gets a curvature-based target, with native distance-based braking. Exact straights keep the selected target ceiling. The native route can omit bends; this is not detection of every corner. Uses the road-corner speed, sharp-turn margin and braking sliders below, even with their separate assist switch off. Existing saved switches and values stay unchanged. Street X keeps its existing controls; excludes Drag, Drift, Outrun and free roam. Online needs Allow network tools. Session only: off after reload, Stop or profile Load. No new steering, obstacle avoidance or NOS control. Start at 1.30×; higher targets can still cause crashes. Hook counters describe prior calls, not detection of the current corner.</p>
<label class="row"><span>Road-race hairpin assist<small id="race-corner-state">Off · experimental · online needs opt-in</small></span><input id="race-corner-assist" type="checkbox" aria-describedby="race-corner-risk"></label>
<label class="slider"><span>Race corner speed <output id="race-corner-value" for="race-corner-factor">0.80×</output></span><input id="race-corner-factor" aria-label="Road-race corner speed" type="range" value="0.8" min="0.6" max="0.95" step="0.05"></label>
<label class="slider"><span>Race sharp-turn margin <output id="race-corner-margin-value" for="race-corner-margin">15%</output></span><input id="race-corner-margin" aria-label="Road-race sharp-turn margin" type="range" value="15" min="0" max="25" step="5"></label>
<label class="slider"><span>Race braking factor <output id="race-braking-value" for="race-braking">0.75×</output></span><input id="race-braking" aria-label="Road-race braking factor, lower means earlier braking" type="range" value="0.75" min="0.5" max="1" step="0.05"></label>
<p id="race-corner-risk" class="fine warn">Experimental native race-AI tuning, not new steering. Lower corner speed and higher sharp-turn margin request slower turns; lower braking factor requests earlier braking. Keeps the selected straight-line race pace. Same settings for solo and opted-in online/LAN road races. Online/LAN requires Allow network tools; only your owned local AI car is eligible. Excludes outrun, drag and drift. Online cornering is unverified; follow server rules. Starts off after reload. Observed commands and counters are not proof of better live cornering; high pace can still miss turns.</p>
<label class="row"><span>Custom race pace<small id="race-pace-state">Off · 1.00× is normal</small></span><input id="race-pace" type="checkbox"></label>
<label class="slider"><span>Race target-speed factor <output id="race-pace-value" for="race-pace-factor">1.00×</output></span><input id="race-pace-factor" aria-label="Race and outrun pace factor" type="range" value="1" min="0.75" max="3" step="0.05"></label><p class="fine warn">2–3× pace is especially unstable and may cause crashes or missed turns. Default 1×. Drag and Drift retain native pace.</p>
</details>
<details class="help"><summary>Driver limits &amp; takeover</summary><p id="ai-auto-risk">One switch reconstructs native AI for event changes. Drag behavior is unverified and may stop or crash. The reported v0.11 crash remains undiagnosed; this is not a confirmed fix. Back up progress. Driver starts off after reload. On the two newest reviewed builds, owned native Drift AI also uses guarded native opponent yaw damping. All car models are eligible when its native guards hold; no score or manual-handling changes. Live recovery is unverified.</p><p>Start events yourself. F7 or driving keys outside this panel return control. Pauses in menus and when unfocused. No guaranteed routes, wins or career automation. Online/LAN requires its separate opt-in.</p></details>
</div></details>
<details id="group-power" class="group"><summary><span class="section-icon" aria-hidden="true"></span>Power &amp; speed</summary><div class="group-body">
<label class="row"><span>Unlimited NOS</span><input id="nos" type="checkbox"></label>
<label class="row"><span>Engine power boost<small id="power-state">Off · not a vehicle-speed multiplier</small></span><input id="boost" type="checkbox"></label>
<label class="slider"><span>Power multiplier <output id="power-value" for="power">1.5×</output></span><input id="power" aria-label="Power multiplier" type="range" value="1.5" min="1" max="3" step="0.1"></label>
<label class="row"><span>Remove stock limiter</span><input id="unlimit" type="checkbox"></label>
<details class="help"><summary>Limits</summary><p>Power, limiter and grip reset off after reload. Their concurrent-write guards reduce known races but do not resolve the reported freezes. Test one at a time. More power may worsen wheelspin and handling. Gearing, drag and redline still limit speed. The power status reports field writes, not a measured speed increase. AI pace changes only its target speed and requires Automatic driver; it is separate from engine power. Online use requires Allow network tools. NOS only refills an equipped kit; it does not force AI to activate it.</p></details>
</div></details>
<details id="group-handling" class="group"><summary><span class="section-icon" aria-hidden="true"></span>Handling &amp; collisions</summary><div class="group-body">
<label class="row"><span>Extra grip<small id="grip-state">Start at 1.3×</small></span><input id="grip" type="checkbox"></label>
<label class="slider"><span>Grip multiplier <output id="grip-value" for="grip-factor">1.3×</output></span><input id="grip-factor" aria-label="Grip multiplier" type="range" value="1.3" min="1" max="2" step="0.1"></label>
<label class="row"><span>Drift assist<small id="drift-state">Solo free roam only</small></span><input id="drift" type="checkbox"></label>
<label class="row"><span>Wall pass-through<small id="walls-state">Off · solo only</small></span><input id="walls" type="checkbox" aria-describedby="walls-risk"></label>
<label class="row"><span>Car no-clip<small id="cars-state">Off · other cars only · solo</small></span><input id="cars" type="checkbox" aria-describedby="cars-risk"></label>
<label class="row"><span>Online traffic no-clip<small id="traffic-state">Off · traffic only · online free roam</small></span><input id="traffic" type="checkbox" disabled aria-describedby="traffic-risk"></label>
<label class="row"><span>Online player / race no-clip<small id="players-state">Off · players / online race cars</small></span><input id="players" type="checkbox" disabled aria-describedby="players-risk"></label>
<details class="help"><summary>Handling &amp; collision risks</summary><p id="traffic-risk">Separate opt-in for NPC traffic in online free roam only. Player cars keep native collisions unless Online player no-clip is also enabled. Racers, walls and props remain unchanged; native Ghost settings are unchanged. Races, outruns and LAN are excluded. Latest reviewed build only. Starts off after reload; F9 stops it. Follow server rules. No live network test is claimed.</p><p id="players-risk">Separate opt-in for identified players in online free roam. On the current reviewed build it also filters confirmed Online/LAN race cars when Allow network tools is enabled. Race mode checks both cars against the active race roster. Traffic and walls stay separate. Only local contacts are skipped; another player's view, network corrections and live race behavior are unverified. Native Ghost settings stay unchanged. Starts off after reload; F9 stops it. Turn off only when clear of cars. Follow server rules.</p><p id="cars-risk">Car no-clip is separate from walls and works only with confirmed car bodies. Ground, walls and props keep normal collisions unless wall pass-through is enabled. Turn off only when clear of other cars. It resets after reload.</p><p id="walls-risk">Experimental · solo only. Near-vertical static walls and barriers only. Ground, slopes and movable props remain solid. Cars stay solid unless Car no-clip is also enabled. May leave the map or miss checkpoints. Turn off only when clear of walls. Back up progress. F9 stops it.</p><p>Extra grip resets off after reload. High grip can cause abrupt handling or rollover and pauses in drift. Drift uses the game’s mode, not perfect-drift automation. Wall pass-through starts off after reload.</p></details>
</div></details>
<details id="group-drag" class="group"><summary><span class="section-icon" aria-hidden="true"></span>Drag racing</summary><div class="group-body">
<div class="inline-readout"><strong>Automatic drag AI</strong><span id="drag-ai-state" class="state">Use Automatic driver above</span></div>
<label class="row"><span>Disable Drag engine blowouts<small id="drag-no-blowout-state">Off · current player engine only</small></span><input id="drag-no-blowout" type="checkbox" disabled aria-describedby="drag-no-blowout-help"></label>
<p id="drag-no-blowout-help" class="fine">Stops your current engine overheating during active Drag. Online/LAN also requires Allow network tools; only your local engine is changed. No driving, shifting or NOS changes. Enable before the engine blows; does not restore a lost race.</p>
<label class="row"><span>Manual drag assist<small id="drag-state">Throttle + shifts · you steer</small></span><input id="drag" type="checkbox"></label>
<label class="slider"><span>Shift at RPM <output id="rpm-value" for="rpm">6500</output></span><input id="rpm" aria-label="Shift RPM" type="range" value="6500" min="3000" max="10000" step="100"></label>
<details class="help"><summary>Drag limits &amp; controls</summary><p id="drag-ai-risk">Automatic drag AI is not live-verified. Back up your progress. Starts after GO and full physics; may miss shifts, crash or stop. F7 takes control.</p><p>Manual assist stays paused while automatic AI is requested. It uses Arrow Up / Left Shift / Left Alt. You steer and avoid obstacles. Pick shift RPM for your car. F7 pauses assisted throttle until toggled again.</p></details>
</div></details>
<details id="group-dyno" class="group"><summary><span class="section-icon" aria-hidden="true"></span>Race preset tuner</summary><div class="group-body">
<label class="row"><span>Enable preset tuner<small>Solo · no automatic Stage/save</small></span><input id="dyno-enable" type="checkbox" aria-describedby="dyno-risk"></label>
<p id="dyno-risk" class="fine warn">Back up progress first. Not live-tested.</p>
<p id="dyno-mode" class="fine">Choose a race mode in the game, then open the Dyno main screen.</p>
<label class="row"><span>Measured search</span><select id="dyno-goal" aria-label="Dyno tuning goal"><option value="peakPower">Peak power</option><option value="peakTorque">Peak torque</option><option value="acceleration60">0–60 estimate</option><option value="acceleration100">0–100 estimate</option><option value="topSpeed">Top-speed estimate</option></select></label>
<div class="dyno-buttons"><button id="dyno-find" disabled>Find tune</button><button id="dyno-cancel" disabled>Cancel</button><button id="dyno-apply" disabled>Stage selected preset</button><button id="dyno-restore" disabled>Restore</button></div>
<p id="dyno-state" role="status">Off · original tune kept</p>
<details class="help" id="tune-editor"><summary>Full preset settings</summary>
<p>Edit suspension, gearing, downforce, tires, brakes, nitrous, ECU and turbo for the race preset selected in the game. Values are native slider positions from −100 to +100. Locked settings remain disabled. Drafts and native previews stay in private memory.</p>
<div class="dyno-buttons"><button id="tune-load" disabled>Load settings</button><button id="tune-reset" disabled>Reset draft</button></div>
<label class="row"><span>Category</span><select id="tune-group" aria-label="Tuning category" disabled><option value="suspension">Suspension</option><option value="gearing">Gearing</option><option value="aero">Downforce</option><option value="tires">Tires / brakes</option><option value="nos">Nitrous</option><option value="ecu">ECU</option><option value="turbo">Turbo</option></select></label>
${Array.from({length:9},(_,i)=>`<div id="tune-row-${i}" class="tune-field" hidden><label for="tune-input-${i}"><span id="tune-label-${i}"></span><output id="tune-value-${i}" for="tune-input-${i}"></output></label><input id="tune-input-${i}" type="range" min="-100" max="100" step="1" value="0" disabled></div>`).join('')}
<div class="dyno-buttons"><button id="tune-preview" disabled>Preview changes</button></div><p id="tune-changes">Load settings to begin.</p>
</details>
<details class="help"><summary>How it works</summary><p>Leave the game on the Performance Tuning main screen. The full editor supports all 41 fields. Peak search changes ECU/turbo; acceleration and speed searches include gearing, with up to 48 private trials. Suspension, grip, aero, brakes and nitrous are manual because these estimates do not measure their race benefit. No fastest-lap or automatic handling claim is made.</p><p>Cancel, close menu, blur, hidden tab or F9 stops search. A staged preset stays staged. Test Run refreshes the game’s driving physics. Use native Save Profile to persist; this extension does not confirm disk saves. Restore is only available for the same unchanged car, mode and parts. Driving effects pause during search.</p></details>
</div></details>
<details id="group-diagnostics" class="group"><summary><span class="section-icon" aria-hidden="true"></span>Session &amp; diagnostics</summary><div class="group-body">
<label class="row"><span>Traffic / barrier tester</span><input id="tester" type="checkbox"></label><p id="hazards" hidden></p>
<p class="fine">Read-only, incomplete obstacle detection.</p>
<details class="help"><summary>Crash log</summary><p id="diagnostic-state" role="status">Local diagnostics starting</p><div class="dyno-buttons"><button id="diagnostic-export" type="button">Export crash log</button><button id="diagnostic-clear" type="button">Clear log</button></div><p>Recent tool choices, game mode and errors stay in this tab. Nothing is uploaded. Page scripts can access this storage. Browser/tab crashes may leave no final error; also use the game’s Download log. Export before closing this tab.</p></details>
<details id="group-session" class="help"><summary>Online / LAN opt-in</summary><label class="row"><span>Allow network tools<small id="online-state">Off · resets on reload</small></span><input id="online" type="checkbox" aria-describedby="online-risk"></label><p id="online-risk" class="fine warn">May affect other racers, trigger integrity checks, invalidate results or lead to a ban. Follow server rules. This does not bypass server restrictions.</p><p>Allows selected NOS, power, limiter, grip, AI/pace, road-race corner/braking assistance and drag tools. Wall pass-through and Car no-clip stay solo-only. Online traffic no-clip stays free-roam-only. Online player / race no-clip is a separate opt-in; current-build race filtering also needs this network permission. Drift stays free-roam-only.</p></details>
</div></details>
<details class="status" id="status-details"><summary id="status-summary" title="Show full status and notices"><span id="live" role="status">Waiting for game</span></summary><p id="note" role="status">Experimental. Back up progress before testing.</p><p class="keys"><kbd>F6</kbd> HUD · <kbd>F8</kbd> / <kbd>Shift+Insert</kbd> menu · <kbd>Esc</kbd> close<br>Drift and tester keep their own switches.</p></details>
</div></div>
`;
    note = ui.querySelector('#note'); live = ui.querySelector('#live');
    ui.querySelector('#info-hud-enable').addEventListener('change',e=>setInfoHud(e.target.checked));
    renderInfoHud();
    ui.querySelector('#profile-select').addEventListener('change',selectProfile);
    for(const action of ['save','update','load','delete'])ui.querySelector('#profile-'+action).addEventListener('click',()=>profileAction(action));
    ui.querySelector('#profile-auto').addEventListener('change',()=>profileAction('auto'));
    ui.querySelector('#diagnostic-export').addEventListener('click',exportDiagnostic);
    ui.querySelector('#diagnostic-clear').addEventListener('click',()=>{diagnostics?.clear();message('Local diagnostic history cleared. New activity will be recorded.');});
    ui.querySelector('#race-pace').addEventListener('change',e=>{prefs.racePace=e.target.checked;message(prefs.racePace?'Race / outrun pace enabled independently. Higher pace can worsen corners. Drag, Drift and dyno retain native pace.':'Race / outrun pace returned to normal.');});
    ui.querySelector('#race-corner-assist').addEventListener('change',e=>{prefs.raceCornerAssist=e.target.checked;message(prefs.raceCornerAssist?'Road-race hairpin assist requested. Native race AI and selected straight pace are retained. Live improvement is unverified.':'Road-race hairpin assist off.');});
    ui.querySelector('#corner-assist').addEventListener('change',e=>{prefs.cornerAssist=e.target.checked;message(prefs.cornerAssist?'Free-roam corner assist requested. The native driver will reset before using the new planned speed. This is experimental, not a proven steering fix.':'Free-roam corner assist off. Native driver reset requested.');});
    ui.querySelector('#dyno-enable').addEventListener('change',e=>{dynoEnabled=e.target.checked;dyno?.setEnabled(dynoEnabled);dynoText=dynoEnabled?'Open the solo Performance Tuning main screen.':(dyno?.applied?'OFF · applied tune kept. Re-enable to restore previous.':'OFF · back up progress before testing');updateDynoUI();});
    ui.querySelector('#tune-load').addEventListener('click',()=>runDyno('load'));
    ui.querySelector('#tune-preview').addEventListener('click',()=>runDyno('preview'));
    ui.querySelector('#tune-reset').addEventListener('click',()=>{try{dyno?.resetDraft();dynoText='Draft reset to the loaded baseline. Game settings unchanged.';}catch(e){dynoText=e.message;}updateDynoUI();});
    ui.querySelector('#tune-group').addEventListener('change',()=>updateDynoUI());
    for(let i=0;i<9;i++)ui.querySelector('#tune-input-'+i).addEventListener('input',e=>{try{dyno?.setDraft(Number(e.target.dataset.offset),Number(e.target.value)+100);dynoText='Draft changed. Preview again before Apply.';}catch(error){dynoText=error.message;}updateDynoUI();});
    ui.querySelector('#dyno-find').addEventListener('click',()=>runDyno('find'));
    ui.querySelector('#dyno-apply').addEventListener('click',()=>runDyno('apply'));
    ui.querySelector('#dyno-restore').addEventListener('click',()=>runDyno('restore'));
    ui.querySelector('#dyno-cancel').addEventListener('click',()=>{dyno?.cancel();dynoText='Cancelling · waiting for the game';updateDynoUI();});
    ui.querySelector('#online').addEventListener('change', e => {prefs.online=e.target.checked;if(!prefs.online)suspend();message(prefs.online ? 'Online/LAN tools allowed on this page. Experimental: server checks may flag changes or reject results. F9 disables this mode.' : 'Online/LAN tools paused. Other selections are kept for solo play.');});
    ui.querySelector('#race-only-ai').addEventListener('change',e=>setRaceOnlyAI(e.target.checked));
    ui.querySelector('#ai').addEventListener('change', e => {clearRaceOnlyAI();prefs.ai=e.target.checked;release();if(!prefs.ai){ai?.stop();try{clearPaceEvidence();}catch{}}message(prefs.ai ? 'Automatic AI requested: native AI for other races/free roam, experimental drag AI for drag. Drag waits for GO. Start events yourself. F7 or driving keys take control; online still needs its separate opt-in.' : 'Native AI off.');});
    ui.querySelector('#take-control').addEventListener('click',takeControl);
    ui.querySelector('#adaptive-race').addEventListener('change',e=>{adaptiveRaceEnabled=e.target.checked===true&&supported&&moduleProfile?.capabilities.nativeDragInputHandoff===true&&moduleProfile?.capabilities.corner===true&&moduleProfile?.capabilities.pace===true;e.target.checked=adaptiveRaceEnabled;clearPaceEvidence();message(adaptiveRaceEnabled?'Adaptive road-race speed requested. Native route planning uses the road-corner and braking sliders; Street X keeps its existing controls.':'Adaptive speed off. Existing saved driving settings resume after native handoff.');});
    ui.querySelector('#adaptive-race-ceiling').addEventListener('input',e=>{const n=Number(e.target.value);adaptiveRaceCeiling=Number.isFinite(n)&&e.target.value!==''?Math.round(Math.max(1,Math.min(2,n))*20)/20:1.3;e.target.value=adaptiveRaceCeiling;ui.querySelector('#adaptive-race-value').textContent=adaptiveRaceCeiling.toFixed(2)+'×';e.target.setAttribute('aria-valuetext',adaptiveRaceCeiling.toFixed(2)+' times');clearPaceEvidence();recordDiagnostic('tools',{tools:diagnosticTools()});});
    ui.querySelector('#ai-pace').addEventListener('change', e => { prefs.aiPace=e.target.checked; message(prefs.aiPace ? 'Custom AI pace enabled for native AI only. Higher pace may worsen cornering and cause crashes. Start at 1.00×.' : 'Custom AI pace off. Native AI will use its normal target-speed factor.'); });
    ui.querySelector('#cars').addEventListener('change', e => {prefs.cars=e.target.checked;if(!prefs.cars)cars?.stop();message(prefs.cars?'Car no-clip requested. Other cars only, solo. Keep clear of other cars before switching it off.':'Car no-clip off. Normal car collisions resume.');});
    ui.querySelector('#traffic').disabled=true;
    ui.querySelector('#players').disabled=true;
    ui.querySelector('#players').addEventListener('change', e => {prefs.players=e.target.checked===true&&moduleProfile?.capabilities?.onlinePlayers===true;e.target.checked=prefs.players;if(!prefs.players)cars?.stop();message(prefs.players?'Online player / race no-clip selected. Race filtering also needs Allow network tools and the current reviewed build. Local contacts only; other players may see collisions. Traffic and walls stay separate.':'Online player no-clip off. Native player-car collisions resume.');});
    ui.querySelector('#traffic').addEventListener('change', e => {prefs.traffic=e.target.checked===true&&moduleProfile?.capabilities?.onlineTraffic===true;e.target.checked=prefs.traffic;if(!prefs.traffic)cars?.stop();message(prefs.traffic?'Online traffic no-clip requested for NPC traffic in online free roam only. Player cars need the separate player switch; AI racers keep native collisions. Follow server rules; turn off only when clear of traffic.':'Online traffic no-clip off. Normal traffic collisions resume.');});
    ui.querySelector('#walls').addEventListener('change', e => {prefs.walls=e.target.checked;if(!prefs.walls)wall?.stop();message(prefs.walls?'Wall pass-through requested. Solo only: turn Free roam with others off, or use a solo race. Near-vertical static walls only; keep a save backup.':'Wall pass-through off. Normal wall collisions resume.');});
    ui.querySelector('#drag-no-blowout').addEventListener('change',e=>{prefs.dragNoBlowout=e.target.checked===true&&moduleProfile?.capabilities.nativeDragOverheat===true;e.target.checked=prefs.dragNoBlowout;savePrefs();message(prefs.dragNoBlowout?'Drag engine blowout protection requested for your current car. Online/LAN also needs Allow network tools. Driving and NOS decisions are unchanged.':'Normal Drag engine overheating restored.');});
    ui.querySelector('#nos').addEventListener('change', e => { prefs.nos = e.target.checked; });
    ui.querySelector('#grip').addEventListener('change', e => { prefs.grip=e.target.checked; message(prefs.grip ? 'Extra grip enabled. Start at 1.3×; it pauses during drift. Too much grip can cause abrupt handling or rollover.' : 'Extra grip off. Original wheel factors are restored.'); });
    ui.querySelector('#boost').addEventListener('change', e => { prefs.boost=e.target.checked; message('Power boost is experimental. Start at 1.5×; turn it off if wheelspin or handling gets worse.'); });
    ui.querySelector('#unlimit').addEventListener('change', e => { prefs.unlimit=e.target.checked; });
    ui.querySelector('#drag').addEventListener('change', e => { prefs.drag = e.target.checked; dragTakenOver=false; if (!prefs.drag) release(); else message('Experimental drag assist enabled. You must steer. Default keyboard bindings required.'); });
    ui.querySelector('#tester').addEventListener('change', e => { prefs.tester = e.target.checked; ui.querySelector('#hazards').hidden = !prefs.tester; ui.querySelector('#hazards').textContent = 'Waiting for a supported game and driving state…'; });
    ui.querySelector('#drift').addEventListener('change', e => { const wanted = e.target.checked; profileDriftChoice=false;prefs.drift=wanted;savePrefs();const state=engine && statusPtr ? engine.status(statusPtr) : null;if(!state || (state.drive & 3)!==2){driftNeedsReapply=true;message('Drift choice saved. It will be requested when solo free roam is available.');}else setDrift(wanted); const status=engine && statusPtr ? engine.status(statusPtr) : null; e.target.checked=driftNeedsReapply ? !!prefs.drift : !!(status?.drift & 1); });
    ui.querySelector('#stop').addEventListener('click', () => stop());
    ui.querySelector('#min').addEventListener('click', () => setPanel(!visible));
    const groupIds=['group-profiles','group-driver','group-power','group-handling','group-drag','group-dyno','group-diagnostics'];
    for(const id of groupIds) ui.querySelector('#'+id).addEventListener('toggle',()=>{
      if(ui.querySelector('#'+id).open) for(const other of groupIds) if(other!==id) ui.querySelector('#'+other).open=false;
    });
    for(const id of ['nos','drag','tester','boost','unlimit','grip']) ui.querySelector('#'+id).checked=prefs[id];
    ui.querySelector('#drag-no-blowout').checked=prefs.dragNoBlowout;
    ui.querySelector('#ai-pace').checked=prefs.aiPace;
    for(const [id,name,output,min,max,step,fallback,digits,suffix] of [
      ['race-corner-factor','raceCornerFactor','race-corner-value',0.6,0.95,0.05,0.8,2,'×'],
      ['race-corner-margin','raceCornerMargin','race-corner-margin-value',0,25,5,15,0,'%'],
      ['race-braking','raceBraking','race-braking-value',0.5,1,0.05,0.75,2,'×'],
      ['race-pace-factor','racePaceFactor','race-pace-value',0.75,3,0.05,1,2,'×'],
      ['corner-factor','cornerFactor','corner-value',0.6,0.95,0.05,0.8,2,'×'],
      ['corner-margin','cornerMargin','corner-margin-value',0,25,5,15,0,'%'],
      ['pace-factor','paceFactor','pace-value',0.75,3,0.05,1,2,'×'],
      ['power','power','power-value',1,3,0.1,1.5,1,'×'],
      ['grip-factor','gripFactor','grip-value',1,2,0.1,1.3,1,'×'],
      ['rpm','rpm','rpm-value',3000,10000,100,6500,0,'']
    ]) {
      const input=ui.querySelector('#'+id),value=ui.querySelector('#'+output);
      const update=()=>{
        const raw=Number(input.value),bounded=Number.isFinite(raw)&&input.value!==''?Math.max(min,Math.min(max,raw)):fallback;
        prefs[name]=Number((min+Math.round((bounded-min)/step)*step).toFixed(digits));
        input.value=prefs[name];value.textContent=prefs[name].toFixed(digits)+suffix;
        input.setAttribute('aria-valuetext',prefs[name].toFixed(digits)+(suffix==='%'?' percent':suffix?' times':' RPM'));
      };
      input.value=prefs[name];update();
      input.addEventListener('input',()=>{update();savePrefs();});
      input.addEventListener('change',update);
    }
    if(typeof prefs.drift==='boolean') ui.querySelector('#drift').checked=prefs.drift;
    ui.querySelector('#hazards').hidden=!prefs.tester;
    ui.addEventListener('change',event=>{savePrefs();recordDiagnostic('tools',{tools:diagnosticTools()});if(event.target!==ui.querySelector('#info-hud-enable'))clearInfoHud('Settings changed · waiting for fresh sample');});
    ui.addEventListener('input',event=>{if(event.target?.type==='range')clearInfoHud('Settings changed · waiting for fresh sample');});
    const parent = document.fullscreenElement || document.body; parent.append(host);
    document.addEventListener('fullscreenchange', () => { (document.fullscreenElement || document.body).append(host); });
    // Explicit startup profile is applied only once, after all controls exist.
    if(profileStartup)profileStartup=profileSessionStopped?null:profileStore.startup();
    if(profileStartup){profileSelection=profileStartup.profile;ui.querySelector('#profile-name').value=profileSelection.name;ui.querySelector('#profile-network').checked=profileSelection.networkConsent;applyToolProfile(profileStartup,true);profileStartup=null;}
    renderProfiles();
    updateDynoUI();
    timer = setInterval(tick, 50);
  }
  if (document.body) mount(); else document.addEventListener('DOMContentLoaded', mount, { once: true });
})();

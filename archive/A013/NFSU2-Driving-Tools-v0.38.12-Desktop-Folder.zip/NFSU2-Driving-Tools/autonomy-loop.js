/* Selected hosted-start loop. JOIN is a typed action carrying one exact
 * host/lobby/event tuple. This module has no hosting or generic Enter action. */
(function(root){
'use strict';
const OFF=Object.freeze({raceAI:false,keys:Object.freeze([])}),MAX=16,JOIN_MS=12000,LATE_MS=35000;
const uint=n=>Number.isInteger(n)&&n>0&&n<=0xffffffff;
function semantic(d){return d&&uint(d.eventHash)&&uint(d.markerHash)&&Number.isInteger(d.track)&&d.track>0&&Array.isArray(d.box)&&d.box.length===4&&d.marker?[d.eventHash,d.markerHash,d.track,d.reverse||0,d.laps||0,...d.box,d.marker.x,d.marker.y,d.marker.z].join(':'):null;}
function create({port,drive,clock=()=>performance.now(),onChange=()=>{}}={}){
 let active=false,phase='off',reason='Off; choose race starts',selected=[],order=[],index=0,round=0,completedTrips=0,pending=null,quarantineUntil=0,lastNow=null,waitingAt=null,current=null,world=null,tripSeen=false,raceSeen=false,tripAt=null,driverMissingAt=null,options={absence:'wait',waitMs:60000,soloFallback:false},intent=OFF,stopping=false;
 const status=()=>({active,phase,reason,selected:selected.length,index,round,completedTrips,pending:!!pending,quarantineUntil,current,options:{...options},intent});
 const changed=()=>{onChange(status());return status();};
 function stop(why='Stopped; manual control'){
  if(stopping)return status();stopping=true;active=false;phase='stopped';reason=why;intent=OFF;waitingAt=null;try{drive?.stop(why);}finally{try{port?.release?.();}finally{stopping=false;}}pending=null;return changed();
 }
 function choose(destinations){if(active||!Array.isArray(destinations)||destinations.length>MAX)return false;const keys=destinations.map(semantic);if(keys.some(k=>!k)||new Set(keys).size!==keys.length)return false;selected=JSON.parse(JSON.stringify(destinations));return true;}
 function safe(s){return s?.verified===true&&s.fresh===true&&s.focused===true&&!s.hidden&&!s.manualInput&&!s.tunerBusy&&!s.menu&&(!s.network||s.allowNetwork===true);}
 function available(s,d){const key=semantic(d),rows=s.catalog?.filter(r=>semantic(r)===key);return rows?.length===1?rows[0]:null;}
 function start(s,settings={}){
  if(active)return false;const now=clock(),o={absence:settings.absence??'wait',waitMs:settings.waitMs??60000,soloFallback:settings.soloFallback===true};
  if(!safe(s)||s.inRoam!==true||s.state!==0||!selected.length||selected.length>MAX||now<quarantineUntil||s.standaloneAI||!Number.isFinite(now)||!['wait','rotate'].includes(o.absence)||!Number.isInteger(o.waitMs)||o.waitMs<5000||o.waitMs>3600000||selected.some(d=>!available(s,d))){reason=now<quarantineUntil?'Waiting for late host acceptance quarantine':'Choose current starts in free roam with manual control and network permission';changed();return false;}
  if(o.soloFallback&&port?.supportsSolo!==true){reason='Solo fallback is unavailable for this build';changed();return false;}
  options=o;order=selected.map(semantic);index=0;round=0;completedTrips=0;pending=null;current=null;world=s.world;tripSeen=false;raceSeen=false;lastNow=now;waitingAt=null;active=true;phase='handoff';reason='Waiting for manual handback before travel';intent=OFF;changed();return true;
 }
 function begin(s){
  const d=available(s,selected[index]);if(!d){stop('Selected destination disappeared or changed');return false;}current=JSON.parse(JSON.stringify(d));world=s.world;
  if(s.manual!==true||s.kind!==1||s.aiOwned||s.handbackPending){phase='handoff';reason='Waiting for exact manual handback';return false;}
  let plan;try{plan=port.plan(current,s);}catch{stop('Route planning failed');return false;}if(!plan?.ok){stop('No verified road route to the selected start');return false;}
  if(!drive.start(plan,current,s)){stop('Travel ownership was refused');return false;}phase='travel';reason='Driving to selected race start';waitingAt=null;return true;
 }
 function next(s){try{drive.stop('Owned trip returned');}catch{}index=(index+1)%selected.length;if(index===0)round++;current=null;world=s.world;pending=null;tripSeen=false;raceSeen=false;waitingAt=null;phase='quarantine';reason='Returned; waiting before the next selected start';intent=OFF;}
 function poll(s){
  if(!active)return status();const now=clock();intent=OFF;
  if(!Number.isFinite(now)||now<lastNow||now-lastNow>500)return stop('Session observation stalled');lastNow=now;
  if(!safe(s))return stop('Automation interrupted; manual control');
  if(s.state===1)return stop('A manually hosted lobby is open');
  if(pending){
   if([2,3,4,5].includes(s.state)&&(s.host!==pending.host||s.lobby!==pending.lobby||s.eventHash!==pending.eventHash))return stop('A different lobby or race was entered');
   if([2,3,4].includes(s.state)){pending.observed=true;phase='lobby';reason=s.state===2?'Join sent; waiting for acceptance':s.state===3?'Joined; waiting for host':'Host countdown';return changed();}
   if(s.state===5){pending.observed=true;if(!tripSeen)tripAt=now;tripSeen=true;phase='trip';reason=s.raceActive?'Owned race active':s.raceResults?'Owned race results; waiting for return':'Owned trip; loading or returning';if(s.raceActive){raceSeen=true;intent={raceAI:true,keys:[]};if(s.driverActive===true)driverMissingAt=null;else{if(driverMissingAt===null)driverMissingAt=now;if(now-driverMissingAt>10000)return stop('Owned race driver did not confirm; manual control');}}else{driverMissingAt=null;if(!s.raceResults&&!raceSeen&&now-tripAt>120000)return stop('Owned race loading timed out');}return changed();}
   if(s.state===0&&s.inRoam&&tripSeen){completedTrips++;quarantineUntil=Math.max(quarantineUntil,now+3000);next(s);return changed();}
   if(s.state===0&&pending.observed)return stop('Host outcome changed; check the game before restarting');
   if(now-pending.at>JOIN_MS)return stop('Join outcome is uncertain; wait before restarting');reason='Join requested; waiting for native lobby observation';return changed();
  }
  if(s.raceActive||s.raceResults||s.state!==0||!s.inRoam)return stop('An event outside this session was entered');
  if(phase==='quarantine'){if(now<quarantineUntil)return changed();phase='handoff';}
  if(phase==='handoff'){if(now>=quarantineUntil)begin(s);return changed();}
  if(s.world!==world||!available(s,current))return stop('The world or selected race start changed');
  const motion=drive.update(s);if(!motion.active)return stop(motion.reason||'Travel stopped');intent={raceAI:false,keys:motion.intent.keys||[]};
  if(!motion.joinReady){phase='travel';reason=motion.reason;waitingAt=null;return changed();}
  phase='waiting';reason='Stopped at selected race start; waiting for a fresh host';if(waitingAt===null)waitingAt=now;
  // canJoin rechecks current measured speed/region/identity; a past ready flag
  // is never sufficient, even when a matching host appeared this frame.
  if(!drive.canJoin(s,current))return changed();
  const offers=(s.offers||[]).filter(o=>o.fresh===true&&uint(o.host)&&uint(o.lobby)&&o.host!==s.self&&o.eventHash===current.eventHash&&o.destinationKey===current.key&&o.open===true&&o.eligible===true&&o.players>=1&&o.players<o.maximum&&o.maximum>=2&&o.maximum<=6);
  const offer=offers[0];
  if(offer){
   let sent=false;try{sent=port.join({host:offer.host,lobby:offer.lobby,eventHash:offer.eventHash},current,s)===true;}catch{return stop('Join enqueue outcome is uncertain');}
   if(sent){pending={host:offer.host,lobby:offer.lobby,eventHash:offer.eventHash,at:now,observed:false};quarantineUntil=Math.max(quarantineUntil,now+LATE_MS);drive.stop('Join dispatched');try{port.release();}catch{}intent=OFF;phase='joining';reason='Join requested; waiting for native confirmation';}
   else reason='Offer changed; waiting for a fresh host';return changed();
  }
  if(options.soloFallback&&now-waitingAt>=options.waitMs){
   // Optional adapter must prove this exact native selected card again. No
   // generic key is emitted, and this branch is unreachable by default.
   let sent=false;try{sent=port.startSolo(current,s)===true;}catch{return stop('Solo start outcome is uncertain');}
   if(sent)return stop('Solo start requested; automatic solo lifecycle is not yet installed');reason='Selected solo event could not be confirmed';return changed();
  }
  if(options.absence==='rotate'&&now-waitingAt>=options.waitMs){drive.stop('Configured host wait expired');index=(index+1)%selected.length;if(index===0)round++;phase='handoff';current=null;waitingAt=null;intent=OFF;reason='Moving to the next selected start';}
  return changed();
 }
 return Object.freeze({choose,start,poll,stop,status});
}
const api=Object.freeze({create,semantic,MAX,JOIN_MS,LATE_MS});if(typeof module==='object'&&module.exports)module.exports=api;else root.__NFSU2_AUTONOMY_LOOP__=api;
})(globalThis);

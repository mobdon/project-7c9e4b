(() => {
  'use strict';
  if (location.origin !== 'https://nfsu2.xyz' || window.top !== window || window.__nfsu2DrivingTools) return;
  Object.defineProperty(window, '__nfsu2DrivingTools', { value: true });
  const { Engine, supportedRevision } = globalThis.__NFSU2_DRIVING_CORE__;
  delete globalThis.__NFSU2_DRIVING_CORE__;
  let engine = null, statusPtr = 0, supported = false, revision = '', visible = true;
  let host, ui, note, live, timer, originalGhost = null;
  let lastShift = 0, shiftTimer = 0, lastPulse = 0, lastScan = 0;
  const held = new Set(), physicallyHeld = new Set();
  const prefs = { nos: false, drag: false, rpm: 6500, tester: false };
  const message = text => { if (note) note.textContent = text; };
  const NativeWorker = window.Worker;
  // Observe only the known game worker, without changing its messages or module.
  window.Worker = new Proxy(NativeWorker, {
    construct(Target, args, NewTarget) {
      const worker = Reflect.construct(Target, args, NewTarget);
      let url; try { url = new URL(String(args[0]), location.href); } catch { return worker; }
      if (url.origin !== location.origin || url.pathname !== '/host/game-worker.js') return worker;
      const send = worker.postMessage;
      worker.postMessage = function (m, ...rest) {
        if (m && m.mod instanceof WebAssembly.Module && m.memory instanceof WebAssembly.Memory && m.slot === 0) {
          if (!engine || engine.memory !== m.memory) { engine = new Engine(m.memory); statusPtr = 0; }
        }
        return Reflect.apply(send, this, [m, ...rest]);
      };
      worker.addEventListener('message', event => {
        const m = event.data;
        if (m?.t === 'register' && m.kind === 5 && Number.isSafeInteger(m.ptr)) statusPtr = m.ptr;
        if (m?.t === 'exit' || m?.t === 'trap') stop('Game stopped. Controls released.');
      });
      return worker;
    }
  });
  // A different game revision must be reviewed before writing its memory.
  fetch('/game.json', { cache: 'no-store', credentials: 'omit' }).then(r => {
    if (!r.ok) throw new Error('Build information unavailable');
    return r.json();
  }).then(info => {
    revision = String(info.rev || 'unknown'); supported = revision === supportedRevision;
    if (!supported) message('Game updated: NOS and drag assist disabled until this extension is updated.');
  }).catch(() => message('Could not check game version. Memory tools stay disabled.'));

  function key(code, down) {
    const keyName = { ArrowUp: 'ArrowUp', ShiftLeft: 'Shift', AltLeft: 'Alt' }[code] || code;
    window.dispatchEvent(new KeyboardEvent(down ? 'keydown' : 'keyup', { code, key: keyName,
      location: /Left$/.test(code) ? 1 : 0, bubbles: true, cancelable: true }));
  }
  function hold(code, down) {
    if (down && !held.has(code)) { if (!physicallyHeld.has(code)) { held.add(code); key(code, true); } }
    else if (!down && held.delete(code) && !physicallyHeld.has(code)) key(code, false);
  }
  function release() { clearTimeout(shiftTimer); for (const code of [...held]) hold(code, false); }
  function stop(why = 'Driving controls off.') {
    prefs.nos = false; prefs.drag = false; release();
    if (ui) { ui.querySelector('#nos').checked = false; ui.querySelector('#drag').checked = false; }
    message(why);
  }
  window.addEventListener('keydown', e => {
    if (!e.isTrusted) return;
    physicallyHeld.add(e.code);
    if (e.code === 'F8') { e.preventDefault(); visible = !visible; if (host) host.hidden = !visible; }
    if (e.code === 'F9' || (e.code === 'Escape' && prefs.drag)) { e.preventDefault(); stop(); }
  }, true);
  window.addEventListener('keyup', e => { if (e.isTrusted) physicallyHeld.delete(e.code); }, true);
  window.addEventListener('blur', () => { physicallyHeld.clear(); stop('Focus lost. Driving controls turned off.'); });
  document.addEventListener('visibilitychange', () => { if (document.hidden) stop('Tab hidden. Driving controls turned off.'); });
  window.addEventListener('pagehide', () => { release(); clearInterval(timer); });

  function ghostState() {
    const text = document.querySelector('#menu [data-act="solid"] .menu-val')?.textContent?.trim().toLowerCase();
    return ({ off: 'off', players: 'players', everything: 'everything' })[text] || null;
  }
  function setGhost(wanted) {
    const button = document.querySelector('#menu [data-act="solid"]');
    let current = ghostState();
    if (!button || button.hidden || !current) {
      message('Car ghosting: start free roam, then open the game’s Home menu once. Use English menu labels for this shortcut.');
      return false;
    }
    for (let i = 0; i < 3 && current !== wanted; i++) {
      button.click();
      const next = ghostState();
      if (!next || next === current) { message('The game did not allow this change. Ghost mode is restricted in some worlds and races.'); return false; }
      current = next;
    }
    return current === wanted;
  }
  function setDrift(wanted) {
    const control = document.querySelector('[data-ctl="drift"]');
    if (!control || control.classList.contains('stowed') || !engine || !engine.state().driving || document.querySelector('dialog[open]')) {
      message('Drift assist: drive in free roam and close the game’s menus first.'); return false;
    }
    if (control.classList.contains('lit') === wanted) return true;
    control.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true, cancelable: true, pointerId: 9981, pointerType: 'mouse', button: 0, buttons: 1 }));
    control.dispatchEvent(new PointerEvent('pointerup', { bubbles: true, cancelable: true, pointerId: 9981, pointerType: 'mouse', button: 0, buttons: 0 }));
    message('Requested built-in drift assist. The switch updates when the game confirms it.');
    return true;
  }
  function tick() {
    if (!engine) { if (live) live.textContent = 'Waiting for game. Reload after installing, then press Play.'; return; }
    try {
      const s = engine.state(), counters = statusPtr ? engine.status(statusPtr) : null;
      const driveStatus = counters && Number.isFinite(counters.drive) ? counters.drive & 3 : 0;
      const safe = supported && s.ready && s.driving && !s.network && driveStatus !== 0 && !document.hidden && !document.querySelector('dialog[open]');
      let nos = false;
      if (safe && prefs.nos) nos = engine.refill(s);
      const activeDrag = safe && prefs.drag && s.drag;
      const now = performance.now();
      if (activeDrag) {
        hold('ArrowUp', true);
        if (prefs.nos && nos && s.gear >= 3) hold('AltLeft', true); else hold('AltLeft', false);
        if (s.rpm >= prefs.rpm && s.gear >= 2 && s.gear < 7 && now - lastShift > 650) {
          lastShift = now; hold('ShiftLeft', true);
          shiftTimer = setTimeout(() => hold('ShiftLeft', false), 85);
        }
        // Refresh synthetic held keys after a game's own input-release event.
        if (now - lastPulse > 500) { lastPulse = now; for (const code of held) if (code !== 'ShiftLeft') key(code, true); }
      } else release();
      if (live) live.textContent = !supported ? `Unsupported game build ${revision || '(checking)'}. Memory tools disabled.` : !s.ready ? s.reason : s.network ? 'Online/LAN race: memory tools paused.' : !driveStatus ? 'Waiting for driving HUD.' : `Game linked · ${Math.round(s.rpm)} RPM${prefs.nos ? nos ? ' · NOS refilling' : ' · NOS unavailable/paused' : ''}${prefs.drag ? activeDrag ? ' · Drag assist active' : ' · Drag assist waiting for a drag race' : ''}`;
      if (ui) {
        if (prefs.tester && supported && s.ready && now - lastScan > 250) {
          lastScan = now;
          const h = engine.hazards(s), close = h?.cars[0];
          ui.querySelector('#hazards').textContent = h ? `${h.scannedCars} car objects read. ${close ? `Nearest ahead: ${close.ahead.toFixed(0)} m, side offset ${close.side.toFixed(1)} m.` : 'No nearby car detected ahead.'} ${h.barrierAhead !== null ? `Barrier line ahead: ${h.barrierAhead.toFixed(0)} m.` : 'No crossing barrier line detected.'} Props and general obstacles: NOT detected.` : 'Detector waiting for valid car coordinates.';
        }
        const drift = counters && Number.isFinite(counters.drift) ? !!(counters.drift & 1) : document.querySelector('[data-ctl="drift"]')?.classList.contains('lit');
        if (typeof drift === 'boolean') ui.querySelector('#drift').checked = drift;
        const ghost = ghostState(); if (ghost) ui.querySelector('#ghost').checked = ghost === 'everything';
      }
    } catch { stop('Runtime changed or is unavailable. Reload the game before retrying.'); engine = null; }
  }
  function mount() {
    host = document.createElement('div'); host.id = 'nfsu2-driving-tools'; host.dataset.nfsu2Ui = '';
    Object.assign(host.style, { position: 'fixed', top: '12px', right: '12px', zIndex: '2147483647', width: '306px', maxWidth: 'calc(100vw - 24px)' });
    ui = host.attachShadow({ mode: 'closed' });
    ui.innerHTML = `<style>:host{color-scheme:dark}*{box-sizing:border-box}section{font:13px/1.4 system-ui,sans-serif;background:#10131bef;color:#edf2fc;border:1px solid #364252;border-radius:14px;box-shadow:0 12px 36px #0009;overflow:hidden}header{display:flex;align-items:center;justify-content:space-between;padding:12px 14px;background:#1b2332}h2{font-size:15px;margin:0}button{cursor:pointer;background:#26354b;border:1px solid #516078;border-radius:7px;color:white;padding:6px 9px}main{padding:8px 14px 14px}label.row{display:flex;align-items:center;justify-content:space-between;padding:10px 0;border-bottom:1px solid #2a3342}input[type=checkbox]{width:19px;height:19px;accent-color:#72e0b3}small{display:block;color:#a9b6ca;font-size:11px}p{margin:9px 0;font-size:12px}#live{color:#82e8bd}#note{color:#ffd48b}input[type=number]{width:76px;padding:4px;background:#202938;border:1px solid #516078;border-radius:5px;color:white}.fine{color:#99a8bf;font-size:11px}</style>
    <section><header><h2>NFSU2 Driving Tools</h2><button id="min" title="Collapse panel">−</button></header><main>
    <label class="row"><span>Unlimited NOS<small>Refills your equipped kit · experimental</small></span><input id="nos" type="checkbox"></label>
    <label class="row"><span>No car collisions<small>Built-in ghost mode · free roam only</small></span><input id="ghost" type="checkbox"></label>
    <label class="row"><span>Drift assist<small>Built-in handling, not guaranteed perfect drift</small></span><input id="drift" type="checkbox"></label>
    <label class="row"><span>Drag assist<small>Throttle + shifting; YOU steer/avoid obstacles</small></span><input id="drag" type="checkbox"></label>
    <label class="row"><span>Traffic / barrier tester<small>Read-only, experimental · not full obstacle detection</small></span><input id="tester" type="checkbox"></label><p id="hazards" hidden></p>
    <label class="row">Shift at RPM <input id="rpm" type="number" value="6500" min="3000" max="10000" step="100"></label>
    <p id="live" role="status">Waiting for game…</p><p id="note" role="status">Experimental. Back up saves first. Use driving assists in solo play.</p>
    <button id="stop">Stop driving assists (F9)</button><p class="fine">F8 show/hide. Drag uses default Arrow Up, Left Shift, Left Alt. It cannot change lanes or avoid traffic, obstacles or damage. Ghost mode keeps walls and is saved by the game.</p></main></section>`;
    note = ui.querySelector('#note'); live = ui.querySelector('#live');
    ui.querySelector('#nos').addEventListener('change', e => { prefs.nos = e.target.checked; });
    ui.querySelector('#drag').addEventListener('change', e => { prefs.drag = e.target.checked; if (!prefs.drag) release(); else message('Experimental drag assist enabled. You must steer. Default keyboard bindings required.'); });
    ui.querySelector('#tester').addEventListener('change', e => { prefs.tester = e.target.checked; ui.querySelector('#hazards').hidden = !prefs.tester; ui.querySelector('#hazards').textContent = 'Waiting for a supported game and driving state…'; });
    ui.querySelector('#rpm').addEventListener('change', e => { prefs.rpm = Math.max(3000, Math.min(10000, Number(e.target.value) || 6500)); e.target.value = prefs.rpm; });
    ui.querySelector('#ghost').addEventListener('change', e => {
      const wanted = e.target.checked; if (wanted && originalGhost === null) originalGhost = ghostState();
      if (setGhost(wanted ? 'everything' : originalGhost || 'off')) message('Car ghost mode changed using the game’s setting. Walls are unchanged. The game saves this preference.');
      e.target.checked = ghostState() === 'everything';
    });
    ui.querySelector('#drift').addEventListener('change', e => { const wanted = e.target.checked; setDrift(wanted); e.target.checked = !!document.querySelector('[data-ctl="drift"]')?.classList.contains('lit'); });
    ui.querySelector('#stop').addEventListener('click', () => stop());
    ui.querySelector('#min').addEventListener('click', e => { const main = ui.querySelector('main'); main.hidden = !main.hidden; e.target.textContent = main.hidden ? '+' : '−'; });
    const parent = document.fullscreenElement || document.body; parent.append(host);
    document.addEventListener('fullscreenchange', () => { (document.fullscreenElement || document.body).append(host); });
    timer = setInterval(tick, 50);
  }
  if (document.body) mount(); else document.addEventListener('DOMContentLoaded', mount, { once: true });
})();

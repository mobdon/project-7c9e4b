# NFSU2 Driving Tools — experimental v0.1

A small unpacked Chrome/Edge/Brave extension for **https://nfsu2.xyz/**.

## Install

1. Extract the ZIP to a folder. Keep that folder: the browser loads it from there.
2. Open `chrome://extensions` (Edge: `edge://extensions`).
3. Turn on **Developer mode**, click **Load unpacked**, and select the extracted **NFSU2-Driving-Tools** folder containing `manifest.json`.
4. Reload nfsu2.xyz, then press Play. The panel appears at the upper right.

Chrome 111+ or a current compatible Chromium browser is required. This package is not a mobile-browser or Firefox build. No build command, Node installation or package dependencies are needed to install it.

## Switches

- **Unlimited NOS:** repeatedly refills the equipped nitrous kit while driving. It does not install a missing kit or change its capacity. Experimental memory implementation, pinned to game build `6f4f1e4e`. Paused in Online/LAN races. A new game build disables memory tools instead of trying unknown offsets.
- **No car collisions:** a shortcut for the game's **Ghost mode → Everything**, which covers other players' cars, traffic and tuners in free roam. It keeps the track and wall collisions. It does **not** remove race collisions, and the tuner you race in an outrun stays solid. It honors the game's restrictions, including World 4. Start free roam and open the game's **Home menu once** before using this shortcut. English menu labels are required. The game saves this setting; turn it off in this panel or in the game's own menu to restore it. If it is unavailable, use the game's Online → Ghost mode setting.
- **Drift assist:** toggles the game's own drift mode through its touch-input action. This uses the real drift-event handling and your Drift tuning, its built-in drift assist, camera and scoring. The game restores ordinary tuning when disabled. Free roam only; close game menus first. **This is not perfect-drift automation and does not guarantee a score, line or spin prevention.**
- **Drag assist:** experimental automatic throttle, RPM-threshold upshifts and NOS when the NOS switch is on. Start a solo drag race yourself. It uses default bindings: Arrow Up, Left Shift, Left Alt. Set the shift RPM to suit the car; 6500 is only a starting point, not a learned perfect-shift value. **You must steer. It does not change lanes, avoid traffic/obstacles, prevent damage or finish races by itself.** It waits for an active driving HUD and stops in menus, on loss of focus, when the tab is hidden, or with Escape/F9. It does not handle race selection or restart.
- **Traffic / barrier tester:** opt-in read-only diagnostic using the game's live car objects and enabled barrier-line table. It reports a nearby car ahead and a barrier crossing the car's forward line. It does not alter driving or send diagnostics anywhere. **It is not a complete obstacle detector:** car objects are not classified as traffic versus racers, parked/inactive objects may appear, and scenery, props, trucks' shapes, road geometry, elevation-sensitive barriers and safe lanes are not comprehensively modeled. “No object detected” never means the road is safe.

F8 hides/shows the panel. The minus button collapses it. F9 / Stop turns off NOS and drag inputs; the game's native ghost/drift settings remain under their own switches.

## Testing status and cautions

The site and its public source were inspected. JavaScript syntax checks and nine automated unit tests pass, covering refill logic, missing kits, pause/network guards, invalid/stale pointers, memory growth, read-only hazard extraction, bounded traversal and status-table reading.

**Live gameplay and installation in your browser have not been verified.** The available test browser cannot run this game's WebGPU graphics, and you asked to test it yourself. These are source-backed experimental implementations, not a promise that all functions work in a live race.

Back up your save with the game's Download backup button before trying it. Use driving modifications in solo play and follow the site's rules. The page's main thread writes shared game memory asynchronously for NOS, so crashes or inconsistent behavior remain possible. If anything behaves oddly, disable the extension and reload the game. Memory changes and extension switches do not survive reload; native ghost settings saved by the game do.

This extension only matches `https://nfsu2.xyz/*`. It has no account, browsing-history, storage, debugger or broad website permissions. The only request it creates is a same-origin read of `/game.json` to check compatibility. It does not contain game assets, remote executable code, analytics or an update downloader.

## Source references

Inspected game metadata: https://nfsu2.xyz/game.json, revision `6f4f1e4e`.
Public source: https://github.com/th0mk/nfsu2-web/tree/6f4f1e4e92f5f3ddf6f6d165b7f7075a95ab7fe3

- `runtime/cpu.h`: guest addresses equal WebAssembly linear-memory addresses.
- `runtime/splitscreen_mem.h`: the browser build's player array is at `0x00d00000`.
- `runtime/game.h`: game state, race, car RPM and gear.
- `runtime/roam_game.c` (`nos_left`): nitrous duration, amount left, activation time and game clock.
- `web/src/host/process.ts`: game worker initialization and shared memory.
- `runtime/web/status_proto.h`, `web/src/app/status.ts`: self-describing status counters.
- `web/src/app/shell.ts` (`menuAction`, `ghostWord`), `settings.ts`: native ghost-mode controls and scope.
- `web/src/app/touch.ts`, `runtime/drift.c`: native drift input and full handling/tuning lifecycle.
- `runtime/roam.c` (`log_cars`): world car list and coordinate fields.
- `runtime/walls.c`: enabled barrier lines and their segment coordinates.

No files in the upstream project were modified. This is an unofficial extension, not affiliated with the game's site or Electronic Arts.

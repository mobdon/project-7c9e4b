/* Source-backed offsets: th0mk/nfsu2-web, revision 6f4f1e4e. See README. */
(function (root) {
  'use strict';
  const A = Object.freeze({ FLOW: 0x8654a4, MODE: 0x850078, PLAYER: 0xd00000,
    RACE: 0x890118, DRAG: 0x89e7d8, TICKS: 0x86518c,
    NOS_FULL: 0x454, NOS_LEFT: 0x45c, NOS_SINCE: 0x460, RPM: 0x440, GEAR: 0x434,
    HOST: 0x866a14, CLIENT: 0x8669f4, ONLINE: 0x89cf69 });
  class Engine {
    constructor(memory) { this.memory = memory; this.view = null; }
    refresh() { if (!this.view || this.view.buffer !== this.memory.buffer) this.view = new DataView(this.memory.buffer); }
    ok(p, n = 4) { return Number.isSafeInteger(p) && p >= 0x10000 && p + n <= Math.min(0x28000000, this.view.byteLength); }
    u32(p) { return this.ok(p) ? this.view.getUint32(p, true) : 0; }
    u8(p) { return this.ok(p, 1) ? this.view.getUint8(p) : 0; }
    state() {
      this.refresh();
      if (this.u32(A.FLOW) !== 6) return { ready: false, reason: 'Start driving to use the tools.' };
      const player = this.u32(A.PLAYER), car = this.u32(player + 4), race = this.u32(A.RACE);
      if (!this.ok(player, 0x14) || !this.ok(car, 0x9e4) || !this.ok(race, 0xc44) || this.u32(player + 0x10) !== 0)
        return { ready: false, reason: 'Waiting for a valid player car.' };
      const rpm = this.view.getFloat32(car + A.RPM, true), gear = this.u32(car + A.GEAR);
      if (!Number.isFinite(rpm) || rpm < 0 || rpm > 30000 || gear > 10)
        return { ready: false, reason: 'Car layout not recognized; no memory changed.' };
      const network = !!(this.u32(A.MODE) & 0x208) || !!this.u32(A.HOST) || !!this.u32(A.CLIENT) || !!this.u8(A.ONLINE);
      return { ready: true, car, race, rpm, gear, driving: this.u32(race) === 4, drag: this.u8(A.DRAG) === 1, network };
    }
    refill(s) {
      if (!s.ready || !s.driving || s.network || this.u32(A.FLOW) !== 6 || this.u32(this.u32(A.PLAYER) + 4) !== s.car) return false;
      // Never grant an unequipped kit or change its capacity/tuning.
      const full = this.u32(s.car + A.NOS_FULL);
      if (!full || full >= 10000000) return false;
      const since = this.u32(s.car + A.NOS_SINCE), ticks = this.u32(A.TICKS);
      this.view.setUint32(s.car + A.NOS_LEFT, full, true);
      if (since && since !== 0x7fffffff) this.view.setUint32(s.car + A.NOS_SINCE, ticks || 1, true);
      return true;
    }
    hazards(s) {
      // Read-only tester. These are cars and the track's barrier-line table,
      // not a complete collision mesh, traffic classifier, lane map or autopilot.
      if (!s.ready) return null;
      const f = p => this.ok(p) ? this.view.getFloat32(p, true) : NaN;
      const x = f(s.car + 0x60), y = f(s.car + 0x64), z = f(s.car + 0x68);
      let fx = f(s.car + 0x90), fy = f(s.car + 0x94);
      const fl = Math.hypot(fx, fy);
      if (![x,y,z,fl].every(Number.isFinite) || fl < 0.5 || fl > 1.5) return null;
      fx /= fl; fy /= fl;
      const world = this.u32(0x890080), seen = new Set(); let car = this.u32(world);
      const cars = [];
      while (car && car !== world && seen.size < 96 && this.ok(car, 0x9e4) && !seen.has(car)) {
        seen.add(car);
        if (car !== s.car) {
          const dx = f(car + 0x60) - x, dy = f(car + 0x64) - y, dz = f(car + 0x68) - z;
          const ahead = dx * fx + dy * fy, side = -dx * fy + dy * fx;
          if ([ahead,side,dz].every(Number.isFinite) && ahead > 0 && ahead < 150 && Math.abs(side) < 20 && Math.abs(dz) < 5)
            cars.push({ ahead, side });
        }
        car = this.u32(car);
      }
      cars.sort((a,b) => a.ahead - b.ahead);
      const nb = this.u32(0x88f298 + 0x498), bars = this.u32(0x88f298 + 0x49c);
      let barrierAhead = null, activeBarriers = 0;
      if (nb <= 8192 && this.ok(bars, nb * 0x24)) for (let i = 0; i < nb; i++) {
        const p = bars + i * 0x24; if (!this.u8(p + 0x10)) continue;
        const ax = f(p) - x, ay = f(p+4) - y, bx = f(p+8) - x, by = f(p+12) - y;
        if (![ax,ay,bx,by].every(Number.isFinite)) continue;
        activeBarriers++;
        const al = -ax*fy + ay*fx, bl = -bx*fy + by*fx;
        if ((al > 0) === (bl > 0) || Math.abs(al-bl) < 0.0001) continue;
        const t = al / (al-bl), distance = (ax + (bx-ax)*t)*fx + (ay + (by-ay)*t)*fy;
        if (distance >= 0 && distance < 150 && (barrierAhead === null || distance < barrierAhead)) barrierAhead = distance;
      }
      return { cars, scannedCars: seen.size, activeBarriers, barrierAhead };
    }
    status(ptr) {
      this.refresh();
      if (!Number.isSafeInteger(ptr) || ptr <= 0 || ptr % 4 || ptr + 16 > this.view.byteLength) return null;
      const h = new Int32Array(this.view.buffer, ptr, 4);
      if ((Atomics.load(h, 0) >>> 0) !== 0x31545453) return null;
      const seq = Atomics.load(h, 1), count = Atomics.load(h, 2);
      if (seq & 1 || count < 0 || count > 48 || ptr + 16 + count * 24 > this.view.byteLength) return null;
      const out = {};
      for (let k = 0; k < count; k++) {
        const p = ptr + 16 + 24 * k; let name = '';
        for (let j = 0; j < 16; j++) { const c = this.view.getUint8(p + j); if (!c) break; name += String.fromCharCode(c); }
        out[name] = this.view.getFloat64(p + 16, true);
      }
      return seq === Atomics.load(h, 1) ? out : null;
    }
  }
  const api = Object.freeze({ Engine, A, supportedRevision: '6f4f1e4e' });
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else Object.defineProperty(root, '__NFSU2_DRIVING_CORE__', { value: api, configurable: true });
})(globalThis);

# v0.24.0 · Opted-in online Drag engine blowout protection

- Extends the current-player heat toggle to Online/LAN Drag only when **Allow network tools** is also enabled. Turning network permission off immediately clears the heat request. Solo behavior, current engine ownership, active Drag/full-physics, finite unblown heat, epoch and heartbeat checks remain.
- Keeps the corrected full-runtime CPU address bounds. No changes to native heat instructions, opponents, packets, NOS decisions, shifts, steering, Street X, tuner staging, local race contacts or corner/braking formulas. Does not repair already-blown engines or lost races.
- Native tests cover 600 online redline frames on both pinned modules, including high runtime CPU addresses, and normal heating/blowout after opt-out. Independent review exercises seven network-indicator cases with strict literal permission, all ownership/staleness guards and byte-for-byte native fallthrough. Snapshot tests now take real memory copies instead of aliased views.
- **Final combined suite: 1,669 passed, zero failures/skips/cancellations.** Live multiplayer, browser appearance, successful Drag completion, repeated NOS behavior and user-save persistence remain unverified. Native grip/downforce scaling remains disabled.

# v0.23.0 · Solo Drag engine blowout protection

- Adds **Disable Drag engine blowouts**, independent of automatic/manual driving. Exact93af6ccb and78e2bb69 only; solo active Drag only, even with network permission. Fresh-tab default off, same-tab choice retained, F9 clears.
- Supplies native disabled-heat sentinel only for the current linked player engine after phase, physics, identity, finite/unblown, heartbeat and command checks. Original native heat function/instructions/return remain intact. No restoration of already-blown engines or lost races. Accumulated heat is intentionally discarded; off resumes heating from zero after native setup.
- No changes to shifts, throttle, steering, pace, power, limiter, NOS decisions or opponents. No AI restart from this toggle.600 controlled over-redline native updates are tested, not a live race/win or NOS-cycling fix.
- Reserves AI mailbox+100 under initial occupancy checks. Next-profile builder retains/recomposes the full tuner170-local prefix around this exact reviewed base change, preserving online race contacts and corner/braking settings. No Lap Knockout or unverified native grip/downforce activation.
- **Final combined suite: 1,665 passed, zero failures/skips/cancellations.** Corrected a reviewed CPU-pointer issue: runtime CPU addresses above the emulated guest heap use widened full-state memory bounds; car/engine guest bounds remain strict. High-address exact-native regressions pass. No installation, live multiplayer, browser appearance or user-save persistence was verified.

# v0.22.0 held candidate · Local online race car filtering

- Adds an exact93af6ccb race-specific local-contact path to the existing player no-clip selection. Requires explicit network permission, active Online/LAN race, current local car/body identity, bounded2–6-entry roster membership for both contacted cars, reciprocal racer/body records, pair witnesses, heartbeat and unchanged command sequences.
- Free-roam player/traffic scopes and older profiles are preserved. The race path does not change peers, packets, server rules, Ghost state or walls. UI and sanitized counters state local-only scope; no guarantee of collision-free remote views.
- Retains full preset tuner and online corner/braking parity. Guarded next-profile rebuild preserves the170-local tuner bridge and rejects unexpected base changes. Solo/Street X behavior unchanged; no Lap Knockout, Drag fix or native grip/downforce activation.
- Final combined suite: **1,619 passed, zero failures/skips/cancellations**. No live online gameplay, browser appearance, synchronization or user save/reload verification. Delivery remains held for pending Drag evidence and grip blocker.

# v0.21.0 candidate · Online road-race tuning parity

- Combines v0.20 full per-preset tuner with matching solo/opted-in online road-race corner and braking settings. Uses the existing network permission, strict owned-local-car/private-route/native-caller guards and unchanged solo formulas. Both opt-ins reset off on reload/Stop.
- Corrects an online routing mismatch, not a proven wall-collision cause or a guaranteed driving improvement. Street X, race flags, Drag/Drift/Outrun behavior, collision scope, grip/downforce activation and full tuner transport remain unchanged. No Lap Knockout experiment.
- Held for further review. No installation or live online race/peer/server/browser validation. Combined candidate suite: **1,607 tests passed, zero failures/skips/cancellations**. Canonical ZIP metadata and unchanged source bytes reproduce the same archive.

# v0.20.0 · Full preset tuner and private native preview

## Added together, preserving v0.18 driving behavior

- Exact 93af6ccb gains a 41-field per-preset editor: suspension, gears, NOS, brakes, tires, downforce, ECU and turbo. All five native presets are selected in the game; installed parts/native eligibility remain authoritative. Native setter coupling is shown before staging.
- Preview uses 195 reviewed native functions extracted from the verified downloaded game module into private memory, not temporary live writes. The extractor guards 11,678 native memory operations and 77 loops plus function entries. Bounds, allowed write ranges and fuel stop unsupported execution. No game executable or assets are distributed.
- Native estimates: 0–60, 0–100, top speed, peak power/torque and native NOS duration/torque. Measured search is capped at 48 trials: ECU/turbo for peak goals, gearing plus ECU/turbo for acceleration/top speed. Manual handling/NOS controls are not optimized for laps, corners or race wins.
- Frame-boundary capture and explicit Stage/Restore use a separately owned 16 MiB buffer. Stage writes just current and selected visit tune bytes, with identity/setup/parts/record/staleness/cancellation checks. Restore retains distinct original current/visit copies. Neither operation saves files or calls the unverified live rebuild graph.
- Use native Test Run to refresh physics and Save Profile to persist. The native save may commit all visit presets; readiness warns about other dirty presets. Disk save success is never claimed. Live save/reload remains unverified.
- Read-only corner status clarifies “armed” versus a native observed hit. Street X AI and all existing driver, event, route, pace and corner physics payloads are preserved. Unverified native grip/downforce scaling and host wiring are not activated. Older builds retain their previous dyno tool.

## Validation

**Final aggregate suite: 1,599 tests passed, zero failures, zero skips/cancellations.** Focused exact-WASM tests cover private measurements, native locks/coupling, fuel/cancellation recovery, all five preset contexts, 41-byte-only Stage/Restore and unchanged saved-car records. Real-browser appearance, live race outcomes and disk save/reload have not been verified. The existing crash/freeze report remains unresolved. Back up progress and retain v0.18 for rollback.

# v0.18.0 · Native Drag handoff and solo road-race hairpins

## Added together, preserving v0.17 controls

- Repairs the native Drag input lifecycle on exact 93af6ccb and 78e2bb69. Native input mode4 acquisition and a guarded function19197 prefix retain ownership through native Player update/reconciliation. The extension preserves newer native modes, requested modes and replacement controllers, restoring its saved skill only when still applicable. A real mode change latches reacquisition until OFF; the status now explains the required off/on retry.
- Adds independent, default-off solo Road-race hairpin assist on all four reviewed profiles. Existing curvature helper4653 applies a pace-compensated corner cap; getter4497 requests a more conservative native braking envelope on the owned private route. Settings changes rebuild cached route caps through the existing handback. Selected straight race pace, native route/driver/recovery/opponents and free-roam corner calculations remain separate.
- Race corner command record expands to64 bytes; modern Drag input lease uses two previously reserved AI words. First-handshake occupancy checks cover both changes; occupied memory is not overwritten. Braking hits and stage diagnostics do not masquerade as confirmed corner hits.
- Extends bounded read-only logging with actual skill, native input modes, recognized goals, native behavior controls, pointer-presence/bounds flags and mailbox scalar evidence. No raw pointers or keyboard events are captured. Exporter version remains in the header after startup history rolls off.
- Existing native Drift recovery, NOS decisions, dyno modes, separate online NPC/player no-clip, online AI permission, power/grip/NOS controls, local logger, scanner and compact menu are retained. The unfinished native grip/downforce work is not included.

## Scope and verification limits

Hairpin assist is **solo ordinary road races only**. Online/LAN, Outrun, Drag, Drift and forced Drag/Drift are excluded even with general Online/LAN permission. Existing online collision controls remain online-free-roam-only. Drag acquisition remains GO/full-physics-only; force-only/special Drag is unsupported. No live race, launch, shifting, finish, score improvement, native NOS timing, multiplayer behavior or full opponent equivalence is verified. Native route limits can still produce missed turns. Previously reported freezes and the older page-thread tuning lifetime risk remain unresolved.

The final combined release suite passes **1,555/1,555 tests, zero failures and zero skips**. Independent merged review passed135/135 targeted checks and the exact current native input-lifecycle replay. Authored builders reproduce byte-for-byte; all extension JavaScript syntax checks pass. Constituent and independent focused runs are overlapping evidence, not additive totals. Native probes use controlled boundary dependencies and synthetic routes. Keep v0.17 for rollback, back up progress, start at1× pace with power/grip off and test one option at a time. F7 returns control; F9 stops tools. Only authored extension code is packaged, never original game binaries or extracted native assets.

---

# v0.17.0 · Native race AI with guarded Drift recovery

## Added together, without removing v0.16 controls

- On exact 93af6ccb and 78e2bb69, Automatic driver integrates the reviewed native Drift yaw-damping path. One native player-curve expression selects the existing opponent curve only while ownership, permission, heartbeat, race state, native Drift driver/behavior/input aliases and full physics are valid.
- No model filter or new coefficient: the original car-specific coefficient and native sign/gear conditions remain. The intended difference is near/beyond the 89-degree curve knot. Goals, identity, scores, native opponent behavior, manual handling and global curve data are not edited.
- All three native Drift flags are recognized with drag precedence. Forced Drift still requires the valid owned Drift behavior and full-physics context. This is not an external driver or unrestricted free-roam assist.
- Adds bounded read-only Drift diagnostics to the existing local manual-export logger: native controller/action evidence, speed/target, track, scoring state, pending/banked points, raw rate, route progression and collision-loss latch. Corner hit/cap evidence remains separate from pace. No raw pointers, names, input or network traffic are exported.
- Native race AI and automatic switching, skill 9, drag action, native NOS decisions, dyno modes, adaptive corners, pace, solo collision switches, separate online NPC/player switches, power/grip/NOS controls and menu layout are preserved. The unfinished full tuner is not included.

## Verification and limits

Final combined suite: **1,472/1,472 tests passed, zero failures and zero skips**. Independent focused review: **157 cases passed**, plus native byte/local/section checks on both exact builds. Authored recovery/profile generators reproduce byte-for-byte and all JavaScript syntax checks pass. Fresh public metadata at **2026-11-09 19:23 UTC** still matches the exact 93af6ccb module.

Only one additional native body, function 8871, changes in either newest exact profile. Its original 17 locals are preserved; eight authored locals are appended. The only replaced native expression is the five-byte player-curve constant at offset 2471. Its inline replacement adds no stores or calls. All other native instructions, other bodies and non-code sections are preserved, except the eight existing v0.16 hook bodies. Both complete patched modules validate and compile.

The actual production-patched current body passes 156 native-opponent output comparisons, 45 fail-closed memory comparisons, 46 unchanged-native-opponent cases and six explicit eligibility cases. Native angle and rear-grip dependencies are controlled fixtures, not live physics simulation. Production bridge fixtures test acquisition, immediate stop, heartbeat expiry, stale ownership/physics/behavior and drag handback. Logger tests cover verified-profile gating, manual export, read-only memory invariance and removal of stale telemetry on mode exit.

No installed/live race, actual spin recovery, per-model handling, winning, score improvement or multiplayer synchronization is verified. The guard-installed status is not an observed recovery hit. Previously reported freezes, the page-thread tuning lifetime race and formal scratch-memory reservation remain unresolved. Keep v0.16 for rollback, back up progress, start with 1× pace and power/grip off, and test one feature at a time. F7 returns control and F9 stops tools.

---

# v0.16.0 · Current build and online player no-clip

## Changes

- Adds exact revision **93af6ccb**, size 38,205,596, SHA-256 128e2b5816a8eace4b768aec920318a1613da8235801a361e2009e96550be1d6. Previous exact profiles are retained; unknown binaries still fail closed.
- Maps and recompiles the authored native hooks against the reviewed dispatcher, guest-call ABI and collision helpers. The genuine native status capacity increased from 48 to 64; only the new verified profile enables the 64-entry reader.
- Retains v0.15 native AI/event switching, normal skill 9, guarded opponent drag selection, drift physics choice and native NOS decisions. This is the game's native driver, not an external steering bot.
- Adds **Online player no-clip**, separate from NPC traffic and off by default, on the two newest reviewed profiles. Exact native player-slot matches 0..2 qualify; no-match traffic requires its own switch and driver 4. Online free roam only; races, outruns and LAN remain excluded. Category counters, native ghost behavior and normal collision fallback are preserved.
- Adds the new 34-anchor read-only diagnostic signature set. Matching signatures never enables an unknown module.
- Existing menu layout, five-mode dyno search/Apply/Restore, adaptive corner controls, separate pace, power/grip/NOS controls and local manual-export crash logger remain. The unfinished full tuner and drift-recovery research are not included.

## Verification and limits

The final v0.16 release-folder suite passes **1,430/1,430 tests, zero failures and zero skips**. Independent overlapping review passes **628 scoped cases**. Authored contact/profile generators reproduce byte-for-byte and all extension JavaScript passes syntax checks. Public metadata rechecked at **2026-11-09 19:11 UTC** still identifies revision 93af6ccb and the exact pinned size/module.

The exact new patched module compiles and changes only eight intended bodies: 3174,4653,7395,17404,19277,21213,21263,22508. All other bodies and non-code sections remain byte-identical. Native input/status/NOS execution passes 89 assertions, including all 64 native slots and overflow refusal. Actual gcall 21741 preserves its 344-byte CPU snapshot and guest stack in a controlled dispatcher fixture. Independent production collision tests pass 24 cases with actual current helpers and the compiled contact hook.

Automated tests are isolated fixtures and binary proofs, not live gameplay. No live multiplayer collision/synchronization, full native AI graphs, race outcomes or real-browser export are verified. Reported freezes and the residual page-thread tuning object-lifetime race remain unresolved. The scratch area has exclusion evidence but no formal reservation. Back up the save, keep v0.15 for rollback, start with 1× pace and power/grip off, and enable one feature at a time. F7 returns control; F9 stops tools.

---

# v0.15.0 · Native opponent AI paths

## Changes on exact build 78e2bb69 only

- **Opponent drag action:** allows the native initializer to select actual opponent “Win drag race” action 2 for the extension's requested and owned player car. It does not change racer identity, global difficulty, native action pointers or vtables directly. A confirmed player action 3 may be upgraded once through the initializer; NULL initializes lazily and recovery 11/other actions are left to the game. Status confirms id and vtable; pending is not success.
- **Native drift physics:** corrects normal unmarked player drift events to driver 3/physics 1 through the native setter, preserving drag-first mode precedence. Invalid driver state or failed correction rolls back to manual control. Existing mode/identity/heartbeat/network guards and full event handback remain.
- **Native nitrous decisions:** permits the owned player to reach native request/cancellation logic for recognized drag goal 2, observed road goal 1 in actual race types 1/7, and observed chase goal 5 only in Outrun 7. It never selects chase goal 5 or enables this new path in free roam 0. Native tactical/skill/availability/resource conditions remain intact; no refill or forced activation is added. The separate Unlimited NOS control remains unchanged.
- Cancellation uses the same authorized owned race scope without a new-start goal requirement, so recovery/NULL goal transitions cannot suppress native cancellation. New starts remain strictly goal-gated.

## Limits

**Force-only drag and the special 1099 combination are unsupported by the new opponent path.** It requires the actual native drag flag. This is not full opponent equivalence, a distinct specialist AI for every race, or a fastest-driver claim. No live race benchmark, reliable launch/shift/lane behavior, race completion, winning or crash-freedom is proven. Temporary/recovery actions are not forced. Native full allocator/configuration and cancellation execution, plus the complete skill/resource graph, remain unverified.

The reported freezes remain unresolved. Back up the save, preserve v0.14, enable only one extension version and reload the game. Begin with normal 1× pace and unrelated power/grip changes off. F7 returns control. Unknown game binaries stay disabled, and older exact supported profiles retain their previous behavior.

## Preserved v0.14 features

Guarded five-slot dyno Find/Apply/Restore and Store/Save guidance; adaptive free-roam corner margin and honest hit/status logging; separate online NPC traffic no-clip; solo collision switches; separate free-roam/race pace; NOS refill, power, limiter, grip, manual drag, drift input, read-only tester, signature scanner and sanitized local crash-log export are retained. Corner assistance remains free-roam-only and drag bypasses custom pace. No game assets, extracted binaries or research files are included.

## Verification

The final v0.15 release-folder suite passed **897/897 tests, zero failures and zero skips** after integration and version changes. Independent review passed **390 selected overlapping tests** on the frozen implementation. Authored drag-selector, owned-NOS and latest-profile builders reproduce byte-for-byte; all extension JavaScript passes syntax checks. Production JavaScript matches the frozen reviewed candidate except version labels. Additional bounded native downstream proof passed 56 cases with controlled skill/resource boundaries. These are not live gameplay or full end-to-end native graph benchmarks.

Only eight intended current-build bodies change: 3174, 4653, 7395, 17404, 19277, 21213, 21263 and 22470. All other function bodies and non-code sections remain identical. Older exact profiles retain their existing hooks. Strict-CSP browser visuals remain unverified because Chromium startup was blocked in this environment.

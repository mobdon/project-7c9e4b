/* Pure speed advice for a verified, ordered native query window.
 * This module does not read/write game memory or acquire driving control. */
(function(root){
  'use strict';
  const Geometry=root.__NFSU2_RACE_WINDOW_GEOMETRY__||(typeof require==='function'?require('./race-window-geometry.js'):null);
  const finite=(n,a,b)=>typeof n==='number'&&Number.isFinite(n)&&n>=a&&n<=b;
  const unknown=reason=>({available:false,reason,wholeRaceChecked:false});
  const PIN='ed47e9bdd94a336d8d6bd52bebcc6f130b40ffb6d692f0fc728b8785db02178c';
  // Native f2078 uses the at/after anchor and its predecessor. Under the
  // sampler's pinned CW037f, delta and ratio are stored as float32 before
  // the double multiply/add is rounded to the output float32 vector.
  function interpolate(anchors,distance){
    const index=anchors.findIndex(p=>p.distance>=distance);
    if(index<0||distance<anchors[0].distance)return null;
    if(index===0)return anchors[0].xyz.slice();
    const a=anchors[index-1],b=anchors[index],t=Math.fround((distance-a.distance)/(b.distance-a.distance));
    return a.xyz.map((x,i)=>Math.fround(x+t*Math.fround(b.xyz[i]-x)));
  }
  function windowFromCapture(capture,{spacing=8,maxSamples=24}={}){
    if(capture?.status!=='captured'||capture.moduleHash!==PIN||capture.source!=='owned-native-forward-query-v1'||capture.sampling!=='native-node-anchors-linear-v1'||capture.postConstructionVerified!==true||capture.forwardOrderVerified!==true||capture.horizontalAxes!=='xy'||capture.controlWord!==0x37f||!Number.isInteger(capture.request)||capture.request<=0||(capture.request&1))return unknown('verified-native-anchor-capture-required');
    if(!finite(spacing,1,20)||!Number.isInteger(maxSamples)||maxSamples<3||maxSamples>24)return unknown('bounded-resampling-policy-required');
    const anchors=capture.points,progress=capture.progress,end=capture.end;
    if(!Array.isArray(anchors)||anchors.length<3||anchors.length>24||!finite(progress,-1e6,1e6)||!finite(end,-1e6,1e6)||end<=progress||end-progress>184.01||!anchors.every((p,i)=>p&&finite(p.distance,-1e6,1e6)&&p.distance===Math.fround(p.distance)&&Array.isArray(p.xyz)&&p.xyz.length===3&&p.xyz.every(n=>finite(n,-1e6,1e6)&&n===Math.fround(n))&&(!i||p.distance>anchors[i-1].distance))||progress<anchors[0].distance||end>anchors.at(-1).distance)return unknown('bounded-ordered-native-anchors-required');
    const boundaries=anchors.map(p=>p.distance).filter(d=>d>progress&&d<end);boundaries.push(end);
    const samples=[{distance:0,xyz:interpolate(anchors,progress)}];let current=progress;
    for(const boundary of boundaries){
      const from=current,steps=Math.ceil((boundary-from)/spacing);
      for(let i=1;i<=steps;i++){
        const absolute=i===steps?boundary:Math.fround(from+(boundary-from)*i/steps);
        const relative=Math.fround(absolute-progress);
        if(relative<=samples.at(-1).distance)return unknown('native-distance-resolution-exhausted');
        samples.push({distance:relative,xyz:interpolate(anchors,absolute)});current=absolute;
        if(samples.length===maxSamples)break;
      }
      if(samples.length===maxSamples)break;
    }
    if(samples.length<3||samples.some(p=>!p.xyz||!p.xyz.every(Number.isFinite)))return unknown('insufficient-forward-anchor-window');
    return {available:true,source:capture.source,request:capture.request,pathKind:'selected-road-centerline',unitSystem:'native-world-units-per-second',siCalibrated:false,orderVerified:true,postConstructionVerified:true,horizontalAxes:'xy',nativeUnitScaleVerified:capture.nativeUnitScaleVerified===true,controlWord:0x37f,sampling:capture.sampling,resolutionVerified:false,wholeRaceChecked:false,nativeAnchorCount:anchors.length,progress,samples};
  }
  function plan(window,{lateralAcceleration,brakingDeceleration,cornerFactor=.8,sharpMargin=15,reactionSeconds=.6,marginDistance=8,maxSpacing=20}={}){
    if(!Geometry||window?.source!=='owned-native-forward-query-v1'||window.orderVerified!==true||window.nativeUnitScaleVerified!==true||window.horizontalAxes!=='xy'||window.postConstructionVerified!==true||window.pathKind!=='selected-road-centerline')return unknown('verified-forward-centerline-required');
    if(!finite(lateralAcceleration,.5,12)||!finite(brakingDeceleration,.5,12)||!finite(cornerFactor,.6,.95)||!finite(sharpMargin,0,25)||!finite(reactionSeconds,0,2)||!finite(marginDistance,0,30)||!finite(maxSpacing,1,25))return unknown('bounded-physical-policy-required');
    const samples=window.samples;
    if(!Array.isArray(samples)||samples.length<3||samples.length>24)return unknown('bounded-forward-samples-required');
    if(!samples.every((p,i)=>p&&finite(p.distance,0,10000)&&Array.isArray(p.xyz)&&p.xyz.length===3&&p.xyz.every(n=>finite(n,-1e6,1e6))&&(i===0?p.distance===0:p.distance>samples[i-1].distance&&p.distance-samples[i-1].distance<=maxSpacing)))return unknown('invalid-distance-order-or-spacing');
    // Do not confuse a route coordinate with metres. Both native coordinate
    // distance and actual horizontal chord must agree within a bounded ratio.
    for(let i=1;i<samples.length;i++){
      const a=samples[i-1],b=samples[i],step=b.distance-a.distance,chord=Math.hypot(b.xyz[0]-a.xyz[0],b.xyz[1]-a.xyz[1]);
      if(chord<1e-4||chord>maxSpacing||chord/step<.5||chord/step>1.1)return unknown('unverified-native-unit-spacing');
      if(Math.abs(b.xyz[2]-a.xyz[2])/chord>.25)return unknown('grade-outside-horizontal-policy');
    }
    const points=samples.map(p=>p.xyz.slice(0,2));
    const geometry=Geometry.inspectPolyline({source:'native-race-route',orderVerified:true,coverage:'bounded-forward-window',points},{maxSegmentLength:maxSpacing,maxStraightGap:20});
    if(geometry.status!=='measured'||geometry.corners.some(c=>c.reversal||c.curvature===null))return unknown('incomplete-or-reversing-geometry');
    const priority=new Set(geometry.priorityCorners.flatMap(run=>run.indices));
    const caps=samples.map(()=>60),curveCaps=samples.map(()=>60);
    for(const c of geometry.corners){
      if(c.curvature<=0)continue;
      const speed=Math.sqrt(lateralAcceleration/c.curvature)*cornerFactor*(priority.has(c.index)?1-sharpMargin/100:1);
      caps[c.index]=curveCaps[c.index]=Math.min(60,speed);
    }
    // No geometry beyond the final checked sample is treated as a straight.
    // A moving-window stopping envelope is advisory until native integration.
    const horizon=samples.at(-1).distance;
    for(let i=0;i<samples.length;i++){
      const usable=Math.max(0,horizon-samples[i].distance-marginDistance);
      const stopSpeed=Math.max(0,Math.sqrt((brakingDeceleration*reactionSeconds)**2+2*brakingDeceleration*usable)-brakingDeceleration*reactionSeconds);
      caps[i]=Math.min(caps[i],stopSpeed);
    }
    // A corner can arrive before the end of the measured window. Account for
    // response time and margin to each target too, rather than only to the
    // horizon. A target at the current sample applies its curve cap directly.
    for(let i=0;i<caps.length;i++)for(let j=i+1;j<caps.length;j++){
      if(curveCaps[j]===60)continue;
      const usable=Math.max(0,samples[j].distance-samples[i].distance-marginDistance);
      const delayedEntry=Math.sqrt((brakingDeceleration*reactionSeconds)**2+curveCaps[j]**2+2*brakingDeceleration*usable)-brakingDeceleration*reactionSeconds;
      caps[i]=Math.min(caps[i],Math.max(curveCaps[j],delayedEntry));
    }
    for(let i=caps.length-2;i>=0;i--)caps[i]=Math.min(caps[i],Math.sqrt(caps[i+1]**2+2*brakingDeceleration*(samples[i+1].distance-samples[i].distance)));
    return {available:true,source:window.source,pathKind:window.pathKind,unitSystem:'native-world-units-per-second',siCalibrated:false,advisoryOnly:true,wholeRaceChecked:false,horizonDistance:horizon,priorityTurns:geometry.priorityCorners.length,
      samples:samples.map((p,i)=>({distance:p.distance,curveSpeed:curveCaps[i],entrySpeed:caps[i],priority:priority.has(i)})),
      assumptions:{lateralAcceleration,brakingDeceleration,cornerFactor,sharpMargin,reactionSeconds,marginDistance},
      notice:'Selected road centerline, not the final racing line. Assumed acceleration limits and sampled horizontal geometry; no physical speed-cap, grip, braking or race-result guarantee.'};
  }
  const api=Object.freeze({plan,windowFromCapture});root.__NFSU2_FORWARD_PACING__=api;if(typeof module==='object'&&module.exports)module.exports=api;
})(globalThis);

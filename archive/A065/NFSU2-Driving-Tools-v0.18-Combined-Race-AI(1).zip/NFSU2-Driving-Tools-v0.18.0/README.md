# NFSU2 Driving Tools: experimental v0.18.0

Unpacked Chrome / Edge / Brave extension for https://nfsu2.xyz/. See `CHANGELOG.md` for this release's changes and verification limits.

## v0.18.0: Drag input handoff and solo race hairpin controls

- **Native Drag input handoff, exact 93af6ccb and 78e2bb69:** Automatic driver now enters the native AutoPilot input mode, preserving the owned driver across the verified native Player update and input reconciliation. A narrowly guarded native manual-Drag selector prefix prevents that selector from immediately taking control back. Actual Drag and full driving physics after GO are required. If the game changes control mode, the extension releases its lease and tells you to turn Automatic AI off, then on to retry. It does not fight the new mode or reset a replacement controller.
- **Independent Road-race hairpin assist:** off by default, separate from free-roam corner assist and race pace. This changes the native private-route corner cap and planning braking assumption while retaining the selected straight-line pace. The initial scope is **solo ordinary road races only**. Online/LAN, Outrun, Drag, Drift and forced Drag/Drift are excluded, even when Online/LAN permission is enabled. No new steering, route horizon, grip or nitro behavior is added.
- **More useful local diagnostics:** actual skill, current/requested native input mode, native controls and bounded pointer-presence/validity observations join the existing Drift and corner fields. Raw addresses are never exported; validity flags show readable bounds, not proven object/route semantics. The export header now identifies the exporting extension version. Sampling remains bounded, so export promptly after a short test.

Existing online AI permission and the separate online NPC/player no-clip switches retain their previous scopes. **No native 10× grip or downforce feature is included**; the existing Grip control is unchanged. Keep v0.17 for rollback and start with normal 1× pace and power/grip off.

**Limits:** no live driving or race benchmark has been run. The Drag repair proves bounded native input/ownership retention, not a complete AI action graph, ideal launch, shifts, lanes or finish. Force-only/special Drag is unsupported. Native skill/tactical/NOS resource conditions remain. Hairpin assistance is experimental and may still miss turns or fail to brake early enough; native route horizon and degenerate geometry remain limitations. This is not full opponent equivalence, a freeze fix or a promise of wins.

## Retained v0.17 native Drift recovery

The v0.17 recovery changes remain together in this build. On exact **93af6ccb** and **78e2bb69**, the existing **Automatic driver** switch also enables a guarded native Drift recovery path when the extension owns the car and the game's Drift behavior, full physics, aliases, race state, permissions and heartbeat all agree. There is no extra driver or manual steering script.

The change selects the game's existing opponent yaw-damping curve at one native physics expression. It retains the current car's native coefficient, sign/gear conditions and all subsequent native arithmetic. The curves match through the 89-degree knot; the intended difference is retaining native damping around/beyond 90-degree slip. There is no car-model filter, but every native eligibility guard must hold. Goals, racer identity, score calculation, global curves and manual/non-owned handling are not changed. Automatic mode transitions and F7/F9 handback remain in place.

**This is not a verified live spin-recovery or score improvement.** The status says the recovery guard is installed, not that it observed a successful recovery. Forced Drift and the variant flag follow the native predicate with drag precedence; they are not unrestricted free-roam support. Start at normal 1× pace with power/grip changes off.

The local logger now includes bounded, read-only Drift controller/goal/physics evidence, speed and native target, track, scoring state, pending/banked points, raw rate, route progression and collision-loss latch. Existing corner hit/cap diagnostics remain separate from pace. Moving native values are sampled about every two seconds; discrete changes can record sooner. Native behavior control scalars are recorded, but no raw addresses, names, keyboard events or network traffic are captured. Export promptly after a short test; this remains a bounded recent log, not a complete replay.

### Retained v0.16 compatibility and collision controls

These additions apply **to the exact reviewed 93af6ccb and 78e2bb69 builds**. Existing v0.14 controls, dyno mode handling, adaptive free-roam corners, separate online NPC traffic switch, signature checks and local crash logger remain present. Older supported game profiles retain their previous native behavior.

- **Separate online player no-clip:** opt in independently from NPC traffic. Only the exact native active-player slot classifier can identify another player; driver type alone never qualifies. Online free roam only. Both switches start off; live multiplayer behavior is unverified.

- **Opponent drag action:** the native initializer can select the genuine opponent “Win drag race” action (2), rather than player “Steer player in drag race” action (3), for this extension's requested and owned car. A positively identified existing action 3 may be upgraded once through that same initializer. NULL initializes lazily; native recovery 11 and other temporary actions are not forced. Status confirms the actual action id and vtable, not merely that the checkbox is selected.
- **Native drift physics:** normal unmarked player drift events use the native driver 3 / physics 1 choice through the game's physics setter, retaining native drag-first precedence. Invalid construction or a failed correction uses the existing manual-control and skill rollback. Event changes still require the full OFF/manual/ON handback.
- **Native nitrous decisions:** recognized drag goal 2, observed road goal 1 in native race types 1/7, and observed chase goal 5 only in Outrun 7 can reach their native request/cancellation path. The extension does not select chase goal 5, allow this new path in free roam, bypass native tactical/skill/resource checks, refill NOS or force activation. The existing Unlimited NOS checkbox remains a separate feature. Cancellation can continue after an authorized race's goal changes to recovery or NULL, so strict new-start gates cannot strand active nitrous.

**Limitations:** recognized drag requires the game's actual drag flag. Force-only drag and the special 1099 combination are unsupported by the new opponent path. Native action selection is not complete opponent equivalence. Full allocator/configuration, cancellation, skill and resource behavior have not been executed end-to-end. No live race benchmark, guaranteed shifting, finishing, winning, fastest-driver or crash-freedom claim is made. Reported freezes remain unresolved. Start with normal 1× pace, unrelated power/grip changes off, and a backed-up save. Use F7 to take control.

### Retained current-build support

This release adds the exact game module for revision **93af6ccb** (38,205,596 bytes), while retaining the reviewed **78e2bb69**, **2f0ddd3b** and **6f4f1e4e** profiles. It adapts the new 64-entry native status table; older profiles retain the 48-entry bound. It verifies the downloaded binary, not just its version label. The compact menu uses a constructed stylesheet that works with the site's strict style policy.

**A game crash was reported with v0.11. Its cause remains unresolved. This update is not a confirmed crash fix and has not been live-gameplay tested.** Back up your save, keep the previous extension folder, and test one feature at a time in solo play.

### Available on 93af6ccb, 78e2bb69 and 2f0ddd3b

- Native player autopilot, automatic native event reconstruction, normal racer skill field set to 9, and experimental drag physics handoff.
- Separate free-roam/race pace controls and experimental free-roam corner-speed assist.
- Independent solo-only **Wall pass-through** and **Car no-clip** switches.
- Experimental native dyno search, explicit Apply and guarded Restore.
- **93af6ccb and 78e2bb69 only:** native opponent drag action, drift physics correction and guarded native nitrous decisions, plus separate Online traffic and Online player no-clip, each limited to its native identity category in online free roam.
- Unlimited equipped NOS, power boost, limiter control, grip, manual drag assist, solo drift input and read-only tester.

Automatic AI, both pace opt-ins, both corner assists, all four collision switches, power boost, limiter removal, extra grip, dyno and Online/LAN permission start off after reload. Factors are retained. A future unknown build stays disabled. Both revision and the downloaded module's exact size/SHA-256 must match a reviewed profile before memory tools can run. Native hooks also refuse cold occupied command regions.

### Road-race hairpin setup

Enable Automatic driver in a solo ordinary road race, then enable Road-race hairpin assist. Start at its default corner factor 0.80×, sharp-turn margin 15% and braking factor 0.75×. Lower braking factor requests earlier planning; it does not weaken the physical brakes. Settings or selected race pace changes trigger the existing OFF/manual/ON route reconstruction. A braking-hit count alone never confirms a corner reduction. “Armed” means requested, while an observed cap requires an actual qualifying native helper hit. Both assists start off after reload and Stop.

## Feature status on the exact current build

| Control | Implemented | What was verified / remaining limit |
| --- | --- | --- |
| Native AI + event switching | Yes | On/Off handback, reused-pointer subtype/track transitions and native mappings tested. Not every race's live behavior or opponent-equivalent initialization. |
| Skill 9 | Yes | Actual native skill getter tested; normal field set to 9, sentinels preserved. Drag's decision-time use of the field remains unproved. |
| Automatic drag | Yes, experimental | Native driver 3/physics 1 handoff, guarded opponent action 2 selection and rollback tested. Force-only/special drag unsupported; launching, shifts, lanes and finishing not live-verified. |
| Guarded native Drift recovery | Integrated with Automatic driver on 93af6ccb and 78e2bb69 | Exact production physics splice, native-output parity, fail-closed and bridge handback fixtures pass. No live recovery, per-model handling or score improvement claim. |
| Native drift physics and nitrous decisions | 93af6ccb and 78e2bb69, experimental | Native physics choice, guarded start/cancel acceptance, selected downstream request/consumer fixtures and rollback tested. Full native graphs and live race outcomes unverified. |
| Free-roam / race pace up to 3× | Yes, separate opt-ins | Native hook and 2–3× bounds/non-compounding tested. This is target-speed scaling, not a promised speed multiplier or stable driving. Drag stays neutral. |
| Free-roam corner assist | Yes, experimental | Actual current corner helper, route ownership, guards and output scaling tested. Not a proven steering/avoidance fix. |
| Wall pass-through / Car no-clip | Yes, independent solo-only switches | Current contact wrapper, categories, filter composition and fallback tested. Live map/traffic coverage unverified. |
| Online traffic no-clip | Yes, separate opt-in on 93af6ccb and 78e2bb69 | Exact native online and player-slot helpers tested. Only NPC traffic in online free roam; races, outruns and LAN excluded. Live network behavior unverified. |
| Online player no-clip | Yes, independent opt-in on 93af6ccb and 78e2bb69 | Exact production contact wrapper and native 64-slot classifier tested, separate traffic/player counters and fallback preserved. Online free roam only. Peer/server effects and live collisions unverified. |
| Dyno search / Apply / Restore | Yes, experimental | Current native mappings/calculations, transactional guard/search behavior tested. Full live frontend/save and downstream rebuild behavior unverified. The unfinished full 41-control tuner is not included. |
| NOS / power / limiter / grip | Yes, experimental | Exact mappings, native NOS, bounds, restoration and controlled competing-writer tests. Hardened but not lifetime-synchronized; freezes unresolved. |
| Manual drag / drift toggle / tester | Yes | Input/state and UI tests. Manual drag still requires you to steer; drift is not perfect-drift automation; tester is incomplete. |
| Crash log + manual JSON export | Yes | Sanitization, retention, effective tool state, export simulation and no-tools memory invariance tested. Includes read-only Drift controller/scoring/speed and preserved corner evidence. Real browser export not verified; a freeze may leave no final error. |

Unknown binaries stay disabled. On the older 6f4f1e4e binary, the car no-clip filter is disabled because that hook was only mapped for the current build. No game assets are bundled.

## Signature scanning and build updates

The loader performs a read-only scan against three reviewed sets of 34 typed function fingerprints. It reports unique, ambiguous and missing matches in local diagnostics, plus the actual module hash. The menu retains the full compatibility explanation rather than truncating it. AI and Dyno now give the same explicit unavailable-build reason instead of suggesting the wrong tuning screen.

**Signature matches do not automatically authorize a new game version.** Matching functions alone do not establish callees, dispatch tables, host addresses, scratch ownership or live behavior. Even 34/34 matches on a different binary leave tools disabled until an exact compatibility profile has been reviewed. This is update diagnosis, not a promise that future game updates will work automatically. Scanner failure does not override the independent exact-binary gate.

## Automatic AI race-type switching

Turn on **AI driver → Automatic driver** once per page. It automatically selects:

- **Non-drag races and free roam:** the existing native player autopilot.
- **Drag:** experimental native racer AI with the verified drag physics type. It waits until GO and full driving physics are available.
- **Changing mode:** requests native AI OFF, waits for the game thread to acknowledge it, confirms ownership is released, the human driver is restored and any failed-acquisition latch is cleared, then requests the new mode. Player, car, race, track, drag/drift/URL/StreetX flags, forced native mode flags and race/free-roam changes are checked, including when object pointers are reused.

There is no separate drag-AI checkbox. The main switch explicitly enables automatic selection, including experimental drag. **You still start events yourself. This does not select races, restart them, navigate career menus, buy upgrades or choose a GPS destination.** It includes the separate experimental free-roam corner-speed and dyno-search tools described below. They are off by default.

The extension requests the game's native player autopilot, not a new steering bot. The native constructor chooses a distinct drift behavior and a shared ordinary/drag/StreetX behavior; its update code contains drag-specific branches. Circuit, sprint, URL and outrun do not have separately proven opponent-equivalent implementations here. The player racer identity stays unchanged. “Level 9” means the ordinary native skill field is set to 9; values 254/255 are preserved. We have not proved that drag's launch, shifting or lane decisions consume that field.

**Live drag driving remains unverified.** Correct driver/physics status does not prove that it shifts, steers, avoids traffic or finishes. It may crash, stop or miss checkpoints. Back up your progress and test solo first. No guaranteed routes, perfect drift, wins or completed races.

### Quick start

1. Back up your save with the game's **Download backup** button.
2. Keep your previous extension folder for rollback. Disable its extension card before loading this version.
3. Extract this ZIP. In `chrome://extensions` (Edge: `edge://extensions`), enable Developer mode and choose **Load unpacked**. Select **NFSU2-Driving-Tools-v0.18.0**, containing `manifest.json`.
4. Reload the game and check version **0.18.0**. Only one version should be enabled.
5. Start a solo event yourself. Open Driving tools with **F8**, then enable **Automatic driver** in a non-drag event. For your first drag test, leave power, grip, NOS, custom pace, collision filters and manual Drag assist off.
6. Enter other supported events normally. AI requests native handback/reconstruction automatically when the event changes. Turn AI off before using manual drag assist. Other selected settings are kept.

Chrome 111+ or a compatible current Chromium browser is required. This is not a Firefox or mobile-browser build. No build tools or Node installation are needed to install the extension.

### Take control and pause

- **F7 / Take control:** disables automatic AI until you explicitly turn it on again. Arrow/WASD keys and Space also take control outside the extension menu. This remains off across later race-type changes.
- Controller axes do not trigger takeover; use F7 or the Take control button.
- Taking control also pauses synthetic manual-drag throttle until you toggle manual Drag assist again.
- **F9 / Stop:** clears automatic AI, all four collision switches, Online/LAN permission, custom pace, NOS, power, limiter, grip and manual drag. Slider values are retained. Drift and the read-only tester keep their own switches.
- Menus, loading, unfocused/hidden tabs and unsupported states pause tools without clearing choices. They resume when a supported driving state returns, unless you took manual control.
- **Automatic AI, wall pass-through, solo car no-clip, online traffic no-clip, corner assist, both pace opt-ins, power boost, limiter removal, extra grip, dyno tuner and Online/LAN permission start OFF after every page reload.** Other settings use same-tab session storage. Closing the tab normally ends those saved choices. Storage may be unavailable or affected by browser restore behavior.
- If the page stops updating, native AI hands back within 180 game frames. A frozen game cannot process a handback. Disable the extension and reload if it freezes.

## Compact menu

The menu starts as a **170 × 29 px** collapsed toolbar and opens to a **244 px** drawer with a 390 px maximum scroll panel. **F8** opens/closes it. Sections start folded, only one main section opens at a time, and longer sections scroll. Help and detailed status are tucked away; no control was removed. **F7 / Take control** and **F9 / Stop** remain keyboard shortcuts, with buttons in the open toolbar.

## Independent controls

### AI and pace

The native AI switch uses player-only skill **9**, the highest normal native value. It restores the original value when the same racer still exists. Special sentinels are left unchanged and are not claimed as level 9. It does not alter other racers or commandeer an AI driver the extension did not acquire.

**Free-roam pace:** 0.75×–3.00× for native free roam only, default off / 1.00×. Its factor is saved, but its switch starts off after reload.

**Race / outrun pace:** a separate 0.75×–3.00× opt-in, default off / 1.00×. Its value is saved, but its switch starts off after reload. Your faster free-roam choice does not carry into races.

Both adjust the native target-speed factor, not engine power, steering or road paths. **2–3× pace is especially experimental: severe overspeed, missed turns/checkpoints and instability are possible.** No real driving at those factors has been verified. Drag, dyno and unknown categories use neutral 1.00×. The choices remain selected while ineligible and resume only in their own category. F7 leaves them dormant; F9 clears both switches. They never turn AI on by themselves.

### Free-roam corner-speed assist

A separate, experimental opt-in reduces the native planner's curvature-limited speed for upcoming free-roam corners. It does not replace steering or road paths. Its bounded factor is **0.60–0.95**, starting at **0.80**. Straight/gentle segments retain their native speed cap. This factor is a tuning hypothesis, not a measured optimum.

**Sharp-turn margin** adds 0–25% extra reduction, starting at 15%, according to how far the native corner speed falls below its maximum cap. Tighter upcoming bends receive more margin. The combined formula is `nativeCornerSpeed × baseFactor × (1 − margin/100 × (1 − nativeCornerSpeed/nativeMaximumSpeed))`. At 0%, it follows the v0.13 calculation exactly. With the strongest settings the effective factor can approach 0.45×; it never changes a straight-cap result. This adjusts the original planner’s speed cap, not its steering or proven sampling distance. Begin with normal 1× pace and power/grip changes off, comparing 0% and 15% on the same solo route.

It applies only to the current, owned AI driver's private main route in native free roam. Races, outruns, drag, drift and the Dyno Shop are excluded. Changing its enabled state, factor or sharp-turn margin rebuilds AI through a full native OFF/manual/ON handoff, because the game caches route speed caps. Free-roam/race transitions also rebuild before rearming.

**Corner status:** Armed means a request is present, not that a qualifying native reduction has been confirmed. Straight/gentle calls and guarded calls add no hit. Occupied command memory and observed drift exclusion are reported separately. The crash log now records bounded corner hits, request state, applied factor and those two observable guards. Confirmed pace is a different acknowledgment and does not prove corner assist ran. For diagnosis, use 1× pace; 0.95× corner factor reduces a qualifying corner cap by only 5%. A persistent no-hit result after bends is still unresolved without live telemetry.

It may help turn entry but cannot repair a bad route, prevent crashes, guarantee a clean corner or improve lap times. More power, grip or pace may undermine it. Live braking, route rebuilding and handling improvements remain unverified. Start conservatively and keep F7 available.

### Dyno auto tuner

An independent search tool for the **solo Performance Tuning main screen**, with installed ECU/turbo tuning capability. Start with a backed-up save. The tuner is off on reload and never purchases upgrades, enters events or forces a profile save.

1. Select the race mode in the game first, then open its **Dyno main screen**. The extension shows the selected native tuning slot (1–5). Enable the tuner and choose **peak power (kW)** or **peak torque (Nm)**. It does not choose race modes or provide race-specific handling presets.
2. **Find tune** tests up to 120 bounded coordinate-search trials. Each trial restores your original live setup before returning. The resulting best candidate is not automatically applied.
3. **Apply best** is a separate action and must reproduce the exact measured setup on the same car, mode and installed parts. Use the game's own dyno to check it.
4. **Restore** requires the same live car, mode, parts and exact last-applied tune. It restores the prior baseline. Each native mode has its own guarded search/restore state for the current car, so an applied tune in one mode does not block searching another. Replacing the car/ride drops those restore records. Manual tuning or parts changes invalidate stale results without overwriting the change.
5. When leaving through **Mode Select**, answer **Yes** if the game asks to store your tune, then use its **Save Profile** controls to keep the setups. Apply changes the working tune; it does not automatically save all five mode presets or the disk profile.

This maximizes one measured native peak value, not acceleration, usable power band, gearing, cornering, drift or lap time. It is not a global optimum. A larger peak can worsen real driving. Live setup repeatability, Apply/Restore and save/reload behavior remain unverified.

Cancel, F9, closing the panel, blur, a hidden tab, leaving the page or disabling the tuner cancels ongoing work. Driving effects are paused during search/apply/restore, with their selections retained. **F9 does not undo a tune already applied.** Re-enable the tuner and use Restore previous while its guarded baseline remains valid.

Trials are game-thread transactions and restore the copied ride before acknowledgment. Invalid identities, parts, setup or network state fail closed. If acknowledgment times out, further writes stop and the result is explicitly uncertain; reload before retrying. A native trap can interrupt cleanup, so crash-safe save recovery is not promised.

### Power and handling

- **Unlimited NOS:** refills an already equipped kit while driving; does not install a kit or force native AI to activate NOS.
- **Power boost:** 1.0×–3.0× engine and nitrous torque. Starts at 1.5×. Repeated updates do not compound. More power can worsen wheelspin and handling.
- **Remove stock limiter:** removes the stock MPH governor while enabled. Gearing, drag and redline still limit speed. Upgraded cars may already lack that governor.
- **Extra grip:** 1.0×–2.0× all four tyre-force factors. Starts at 1.3×. It is not auto-steering, yaw damping, corner avoidance or guaranteed handling. High grip can cause abrupt behavior or rollover. It pauses in drift mode/races.
- Power and grip restore only fields still owned by the extension. They wait for three matching samples before applying to rebuilt car data. Changed external tuning is preserved rather than overwritten. Pause/off restores owned values when the original live objects remain valid.
- **Drift assist:** uses the game's real drift-event input and waits for its handling confirmation. Solo free roam only, with game menus closed. It is not perfect-drift automation. Power/grip restore before the native tuning rebuild; settings stay selected. Drift uses its own switch, including after F9.

### Wall / barrier pass-through

**Handling & collisions → Wall pass-through** is independent of AI and **solo-only**, even with Online/LAN tools allowed. Turn **Free roam with others** off, or use a solo race.

Only contacts between your car and verified near-vertical static track polygons are skipped, using the native wall threshold `abs(normal.z) < 0.1`. Ground, ceilings, ramps/slopes and movable props retain the original collision path. Cars retain it unless the independent Car no-clip option is enabled. Sloped faces and movable barrier props remain solid. This is not unrestricted flight or universal noclip. The game's native Ghost setting affects cars, not walls; the extension leaves that setting unchanged.

A selected checkbox is not proof of contact filtering. Its status first says Armed, then counts contacts actually skipped by the native hook. Test a plain vertical wall and neon barrier at low speed; verify ground/ramp and car collisions yourself. Coverage has not been live-verified.

You may leave the drivable map, miss checkpoints or get stuck inside scenery. Native recovery may reposition you after a reset. **Turn it off only when clear of a wall.** Off/F9/reload restores the original collision path. It does not change shared map objects or body collision flags.

### Solo Car no-clip

**Handling & collisions → Car no-clip** is separate from Wall pass-through and is solo-only. It matches confirmed native car collision bodies paired with the current local player's car, whether driven manually or by AI. It does not skip collisions between other cars. Walls, ground and props retain their normal path unless the wall option separately applies.

It starts off after reload and reports Armed until a supported contact is actually skipped. Turn it off only once clear of other cars. F9 stops it. No body flags or shared map objects are changed. Native constructor/category and current wrapper tests pass, but real traffic/racer collisions have not been live-verified.

### Online traffic no-clip

**Handling & collisions → Online traffic no-clip** is a separate switch, available only on exact build **78e2bb69**. It requires online free roam and matches native NPC traffic paired with your local car, driven manually or by AI. It excludes native player-slot cars even if they use a traffic model or traffic driver flag, plus ordinary AI racers, every race category, outruns and Online/LAN races. Other players and rejected contacts retain the game's original collision logic, including any native Ghost choice you made. Walls, ground, props, body flags and map objects are unchanged.

This switch starts **off after every reload**, even if previously selected. It needs its own explicit opt-in; **Allow Online/LAN tools** never enables it. That general permission is not required for this narrowly scoped online-free-roam traffic switch. Solo Car no-clip stays independent. The status distinguishes Armed from observed traffic contacts skipped. F9 stops and clears it; blur, hidden tabs, dyno work and unavailable driving state pause it. Turn it off only when clear of traffic.

No live online collisions, peer synchronization or server acceptance have been verified. It changes local contact resolution, not the traffic simulation or server rules. Follow the site's rules and use an explicitly permitted private test. A selected or Armed switch is not proof that a real contact was skipped.

### Manual drag assist

A separate, optional throttle / RPM-threshold shift / NOS helper **while you steer**. Uses default Arrow Up, Left Shift and Left Alt bindings. Set shift RPM for your car; 6500 is only a starting point, not learned perfect shifting.

Manual drag assist never runs while automatic drag AI is requested, including countdown and failed/unavailable AI. It will not silently substitute synthetic inputs. With Automatic AI off, manual drag waits for native ownership to clear and a human driver to be confirmed. Countdown permits throttle only; shifts and NOS wait for GO. It does not choose lanes or avoid obstacles. F7/manual takeover pauses it until its switch is toggled again.

### Diagnostics

#### Local crash log

Open **Driving tools → Session & diagnostics → Crash log → Export crash log**. This downloads `nfsu2-driving-tools-diagnostics.json` on your computer. Nothing is automatically sent or uploaded. **Clear log** removes this tab's retained diagnostic history; recording then continues.

The logger starts when this extension page loads. It records recent tool choices/factors, sampled game mode and driver state, page/game-worker lifecycle, classified errors, numeric WebAssembly function/offset locations and line numbers from known script files. It does not capture raw console logs, error messages, URLs, credentials, names, saves, keyboard input or network traffic. It never changes game memory or enables a tool.

The newest **180 events, limited to 64 KiB of stored JSON**, are kept in same-tab session storage. State is sampled on discrete changes (at most four times a second), moving native scalars about every two seconds, and a baseline snapshot every five seconds while driving; rapid repeated page errors are capped. Older entries are discarded and the file reports the count. Export soon after a problem. Reloading the same tab normally retains the log; closing the tab, clearing site data, browser recovery behavior or blocked/full storage can lose it. The menu reports when the log is memory-only. The site's own scripts can access this same-origin session storage, so it is not an extension-private vault.

**Capture limits:** this cannot recover crashes that happened before the logger was installed. A full browser/tab/GPU crash, freeze or forced close may prevent any final event. This is a history of observations, not a complete crash dump or proof of the crash's cause; the last snapshot may precede the failure. Free-text errors are deliberately omitted for privacy, so unfamiliar errors appear as `other`. Also export the game's own **Download log** for native game details. This logger does not fix the reported crash or establish that the game is safe.


The read-only traffic/barrier tester reads nearby car objects and the enabled barrier-line table. It is incomplete: it does not fully classify traffic/racers, shapes, props, road geometry, elevation or safe lanes. No detected obstacle does not imply a safe road.

## Online / LAN

Online/LAN remains blocked by default for existing tools. The separate **Session mode → Allow Online/LAN tools** switch is per-page and starts off on reload. It does not activate individual tools. It never overrides the solo restrictions on road-race hairpin assist, walls and solo Car no-clip, drag physics requirements, pause checks or one-local-player checks. The separately enabled Online traffic no-clip has its own narrow online-free-roam scope and never opens Online/LAN races.

Online modifications may affect racers, trigger integrity checks, invalidate results or cause moderation/bans. Follow the site's rules and prefer solo play or an explicitly permitted private test. This extension does not bypass server restrictions. Turning off the session switch stops AI/synthetic keys and restores owned tuning when possible, while keeping selections for solo. NOS already refilled is not drained. F9 clears the permission.

## Validation and known limits

**Automated validation:** the final combined v0.18 suite passes **1,555 tests, zero failures and zero skips**. Independent merged review passed135/135 targeted checks and the exact current native input-lifecycle replay. Frozen constituent and independent focused suites are overlapping evidence, not additive totals. See `CHANGELOG.md` for scope and limits. This includes native drag, drift and nitrous gates alongside the retained dyno, corner, online-traffic, UI and packaging regressions. Automated checks cover exact binary identity, exact intended function/section preservation, native handoff and heartbeat behavior, event-subtype transitions, occupied-mailbox refusal, unowned-memory preservation, memory-reuse rejection, restored tuning on replacement, stale-worker events and crashes in secondary game threads. Separate probes execute actual current-build NOS/input/status, native dyno functions, race constructor/skill accessor, catchup, corner helper and contact wrapper code. Many dependencies are stubbed or use synthetic state. These are not a full game simulation or live gameplay.

All four exact supported modules validate and compile after patching. Both modern profiles change11 bodies: **3174, 4497, 4653, 7395, 8871, 17404, 19197, 19277, 21213, 21263**, plus contact wrapper **22508** on93af6ccb or **22470** on78e2bb69. On2f0ddd3b, only **4497, 4653, 21213, 21262 and22430** change; on6f4f1e4e, only **4497, 4653, 21213, 21262 and22720** change. Every other function body and non-code section is preserved byte-for-byte. Original planner instructions and contact-wrapper tails remain preserved. The native Drift recovery expression replacement retains its documented scope. Authored builders reproduce the shipped payloads.

No successful live drag race, wall/car test, cornering improvement, real-car dyno improvement or online race is claimed. The menu passes simulated DOM checks. The strict-CSP Chromium regression test could not run because this environment blocks Chromium startup; no real-browser visual verification is claimed.

The v0.11 crash remains undiagnosed. Controlled interleaving tests did expose stale-state and competing-writer hazards in power, grip and NOS. This release rechecks live state/identity at each field, uses exact-value atomic updates/restoration, rejects out-of-domain power values and avoids unchanged-value rewrites. These are experimental mitigations, not full lifetime synchronization: the native game can still destroy/reuse an object before updating its pointer. No elimination of that residual race or the reported freezes is claimed. The current game-thread gcall ABI, dispatch mapping and hook-local layout match the reviewed native binary; that does not establish the absence of timing, lifetime or gameplay faults. Stop using a feature if the game becomes unstable, preserve the crash log and reload before retesting.

Exact supported profiles:

- **93af6ccb:** 38,205,596 bytes, SHA-256 `128e2b5816a8eace4b768aec920318a1613da8235801a361e2009e96550be1d6`. Newest reviewed profile, with the64-entry native status table and all current controls.
- **78e2bb69:** 38,170,601 bytes, SHA-256 `df7b930bb293ffdf975f0735d93e0797d51bd137d0cbeabcaff87fc5a693c759`. Previous reviewed modern profile. Main hook 21213, dispatch 21726, gcall 21740, pace wrapper 21263, contact wrapper 22470; exact native bodies and relocated wrappers are checked offline.
- **2f0ddd3b:** 36,872,934 bytes, SHA-256 `5e33ad2cb4c4cc6893dee7cbd4d6e9bfb0f59a349d218fddbb5e3331ca69bc34`. Expanded experimental feature support listed above. The native gcall function was mapped from old index 21725 to current index 21739 and verified to preserve the same CPU ABI; actual dispatch tables and native AI bodies were checked independently.
- **6f4f1e4e:** 37,839,055 bytes, SHA-256 `ee5d281a3109240d5db25dc3921e1044672cf6d650eb58c3baa089b54fe2941f`. Retains the older combined experimental feature set.

An independent probe executes actual current-build input/status initialization, status writing and the NOS reader in isolated memory: 22 assertions pass. This verifies the mailbox formats and NOS interpretation, not a real gameplay session. A separate native gcall binary comparison verifies that its only body change is the dispatcher call relocation.

## Privacy, implementation and rollback

The extension matches only `https://nfsu2.xyz/*`. No account, history, debugger or broad website permissions. It stores its own preferences and a bounded, sanitized diagnostic history in namespaced same-tab session-storage entries. Nothing is uploaded. Its only added request is a same-origin `/game.json` compatibility read; it inspects the game's own module response during loading. No analytics, remote code or game assets are bundled.

- AI calls native `Player::AutoPilotOn`, `AutoPilotOff` and `SetInputMode` through the game's existing CPU-preserving game-thread dispatcher. It never invokes native game functions concurrently from the page thread.
- Normal drag opponents use driver type 3 / physics type 1, while player autopilot initially asks for physics type 3. The retained drag handoff corrects only the eligible local car, verifies both types and rolls back on failure.
- The page's automatic AI switch supplies the exact drag-permission word only when drag is detected. The native permission and full-physics checks are still required. The pace hook never modifies drag.
- Mode switching publishes OFF and verifies the native heartbeat acknowledgement, cleared ownership and restored manual driver before rearming. Identity, native subtype/track flags and race/free-roam mode are part of that comparison. Native Off/On rebuilds the private driver route.
- Command memory stays at `0x00d0d100` (100 bytes used on modern Drag-handoff profiles;92 bytes on older profiles) and walls at `0x00d0d180` (40 bytes), under sequence locks. Cars use `0x00d0d1c0` (40 bytes); the existing final word selects the independent online traffic/player modes on 93af6ccb and 78e2bb69. The corner record is at `0x00d0d200` (64 bytes, CNR3), and dyno uses `0x00d0d300..0x00d0d4ff`. These do not overlap. Native scalar-reference/allocator analysis supports using these gaps, but exclusive allocation has not been formally proved and unknown computed writes remain a risk. Cold empty/owned checks and post-attachment ownership guards reduce, not eliminate, that risk. The current-build patch targets the main-loop bridge, player pace, contact resolver, corner/braking helpers, native drag action/input selectors, native Drift damping expression and three guarded nitrous acceptance sites. Original native instructions remain preserved around the scoped changes.
- Wall filtering prefixes `sub_005b2610` and preserves the full original resolver for every rejected contact. Body type/vtable, reciprocal car/face pointers, finite unit normals and pair identities are checked. Native `roam_game_online_here()` always blocks wall filtering during multiplayer free roam. The separate latest-build traffic path also calls the exact native read-only player-slot helper and excludes recognized player cars.

For rollback, disable v0.18.0, enable your preserved previous version and reload. The previous version remains subject to its own build-compatibility checks. Memory effects do not survive reload; saved ordinary preferences may. Never run both versions together.

### Source references

- Public pinned source: https://github.com/th0mk/nfsu2-web/tree/6f4f1e4e92f5f3ddf6f6d165b7f7075a95ab7fe3
- `runtime/career.c`, `runtime/guest.h`: native handoff, return-to-input and game-thread calls.
- `runtime/catchup.c`: native skill, player target-speed calculation.
- `runtime/game.h`, `runtime/web/status_web.c`: driving/countdown/paused states and drag type.
- `runtime/roam.c`, `runtime/roam_game.c`: collision wrapper, native Ghost scope and multiplayer state.
- `runtime/walls.c`: native barrier lines.
- `runtime/mprace.c`, `runtime/drift.c`: per-car torque, limiter, drift and tyre data.
- Reconstructed collision classifications, independently checked against the exact executable: https://github.com/troikoss/speed-re/tree/892e5c31d77c751acd123330eda15c157c4f1b1f/src/Speed/Indep/Src/Physics/Collision

No upstream files were modified. This is unofficial and not affiliated with the site or Electronic Arts. No game executable, assets or reconstructed third-party code are in the ZIP.

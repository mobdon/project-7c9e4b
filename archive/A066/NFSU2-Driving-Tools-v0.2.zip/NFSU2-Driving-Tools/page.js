(() => {
  'use strict';
  if (location.origin !== 'https://nfsu2.xyz' || window.top !== window || window.__nfsu2DrivingTools) return;
  Object.defineProperty(window, '__nfsu2DrivingTools', { value: true });
  const { Engine, supportedRevision } = globalThis.__NFSU2_DRIVING_CORE__;
  delete globalThis.__NFSU2_DRIVING_CORE__;
  let engine = null, statusPtr = 0, inputPtr = 0, supported = false, revision = '', visible = true;
  let host, ui, note, live, timer, driftPending = null;
  let lastShift = 0, shiftTimer = 0, lastPulse = 0, lastScan = 0;
  const held = new Set(), physicallyHeld = new Set();
  const prefs = { nos: false, drag: false, rpm: 6500, tester: false, boost: false, power: 1.5, unlimit: false };
  const message = text => { if (note) note.textContent = text; };
  const NativeWorker = window.Worker;
  // Observe only the known game worker, without changing its messages or module.
  window.Worker = new Proxy(NativeWorker, {
    construct(Target, args, NewTarget) {
      const worker = Reflect.construct(Target, args, NewTarget);
      let url; try { url = new URL(String(args[0]), location.href); } catch { return worker; }
      if (url.origin !== location.origin || url.pathname !== '/host/game-worker.js') return worker;
      const send = worker.postMessage;
      worker.postMessage = function (m, ...rest) {
        if (m && m.mod instanceof WebAssembly.Module && m.memory instanceof WebAssembly.Memory && m.slot === 0) {
          if (!engine || engine.memory !== m.memory) { engine = new Engine(m.memory); statusPtr = 0; inputPtr = 0; driftPending = null; }
        }
        return Reflect.apply(send, this, [m, ...rest]);
      };
      worker.addEventListener('message', event => {
        const m = event.data;
        if (m?.t === 'register' && m.kind === 3 && Number.isSafeInteger(m.ptr)) inputPtr = m.ptr;
        if (m?.t === 'register' && m.kind === 5 && Number.isSafeInteger(m.ptr)) statusPtr = m.ptr;
        if (m?.t === 'exit' || m?.t === 'trap') stop('Game stopped. Controls released.');
      });
      return worker;
    }
  });
  // A different game revision must be reviewed before writing its memory.
  fetch('/game.json', { cache: 'no-store', credentials: 'omit' }).then(r => {
    if (!r.ok) throw new Error('Build information unavailable');
    return r.json();
  }).then(info => {
    revision = String(info.rev || 'unknown'); supported = revision === supportedRevision;
    if (!supported) message('Game updated: memory tools disabled until this extension is updated.');
  }).catch(() => message('Could not check game version. Memory tools stay disabled.'));

  function key(code, down) {
    const keyName = { ArrowUp: 'ArrowUp', ShiftLeft: 'Shift', AltLeft: 'Alt' }[code] || code;
    window.dispatchEvent(new KeyboardEvent(down ? 'keydown' : 'keyup', { code, key: keyName,
      location: /Left$/.test(code) ? 1 : 0, bubbles: true, cancelable: true }));
  }
  function hold(code, down) {
    if (down && !held.has(code)) { if (!physicallyHeld.has(code)) { held.add(code); key(code, true); } }
    else if (!down && held.delete(code) && !physicallyHeld.has(code)) key(code, false);
  }
  function release() { clearTimeout(shiftTimer); for (const code of [...held]) hold(code, false); }
  function stop(why = 'Driving controls off.') {
    prefs.nos = false; prefs.drag = false; prefs.boost = false; prefs.unlimit = false; release();
    try { if (engine) engine.restorePerformance(engine.state()); } catch { /* no stale pointer writes */ }
    if (ui) { ui.querySelector('#nos').checked = false; ui.querySelector('#drag').checked = false; ui.querySelector('#boost').checked = false; ui.querySelector('#unlimit').checked = false; }
    message(why);
  }
  window.addEventListener('keydown', e => {
    if (!e.isTrusted) return;
    physicallyHeld.add(e.code);
    if (e.code === 'F8') { e.preventDefault(); visible = !visible; if (host) host.hidden = !visible; }
    if (e.code === 'F9' || (e.code === 'Escape' && prefs.drag)) { e.preventDefault(); stop(); }
  }, true);
  window.addEventListener('keyup', e => { if (e.isTrusted) physicallyHeld.delete(e.code); }, true);
  window.addEventListener('blur', () => { physicallyHeld.clear(); stop('Focus lost. Driving controls turned off.'); });
  document.addEventListener('visibilitychange', () => { if (document.hidden) stop('Tab hidden. Driving controls turned off.'); });
  window.addEventListener('pagehide', () => { stop(); clearInterval(timer); });

  function setDrift(wanted) {
    if (driftPending) return false;
    const state = engine?.state(), counters = engine && statusPtr ? engine.status(statusPtr) : null;
    if (!supported || !state?.ready || !state.driving || state.network || !counters || (counters.drive & 3) !== 2 || !Number.isFinite(counters.drift) || document.hidden || document.querySelector('dialog[open]')) {
      message('Drift assist only works while driving solo free roam with the game menus closed.'); return false;
    }
    if (!!(counters.drift & 1) === wanted) return true;
    // Rebuilding the native drift setup must not inherit our power multiplier.
    prefs.boost = false; prefs.unlimit = false; engine.restorePerformance(state);
    ui.querySelector('#boost').checked = false; ui.querySelector('#unlimit').checked = false;
    if (!engine.driftTap(inputPtr)) { message('Drift request not sent: the game input mailbox is unavailable, inactive, typing, or full.'); return false; }
    driftPending = { wanted, until: performance.now() + 3000 };
    ui.querySelector('#drift').disabled = true;
    message('Drift request sent. Waiting for the game to confirm its handling state…');
    return true;
  }
  function tick() {
    if (!engine) { if (live) live.textContent = 'Waiting for game. Reload after installing, then press Play.'; return; }
    try {
      const s = engine.state(), counters = statusPtr ? engine.status(statusPtr) : null;
      const driveStatus = counters && Number.isFinite(counters.drive) ? counters.drive & 3 : 0;
      const safe = supported && s.ready && s.driving && !s.network && driveStatus !== 0 && !document.hidden && !document.querySelector('dialog[open]');
      let nos = false;
      if (safe && prefs.nos) nos = engine.refill(s);
      let tune = {active:false};
      if (safe && (prefs.boost || prefs.unlimit)) {
        tune = engine.tunePerformance(s, prefs.boost ? prefs.power : 1, prefs.unlimit);
        if (tune.changed) {
          prefs.boost=false; prefs.unlimit=false;
          ui.querySelector('#boost').checked=false; ui.querySelector('#unlimit').checked=false;
          message(tune.reason);
        }
      } else engine.restorePerformance(s);
      const activeDrag = safe && prefs.drag && s.drag;
      const now = performance.now();
      if (activeDrag) {
        hold('ArrowUp', true);
        if (prefs.nos && nos && s.gear >= 3) hold('AltLeft', true); else hold('AltLeft', false);
        if (s.rpm >= prefs.rpm && s.gear >= 2 && s.gear < 7 && now - lastShift > 650) {
          lastShift = now; hold('ShiftLeft', true);
          shiftTimer = setTimeout(() => hold('ShiftLeft', false), 85);
        }
        // Refresh synthetic held keys after a game's own input-release event.
        if (now - lastPulse > 500) { lastPulse = now; for (const code of held) if (code !== 'ShiftLeft') key(code, true); }
      } else release();
      if (live) live.textContent = !supported ? `Unsupported game build ${revision || '(checking)'}. Memory tools disabled.` : !s.ready ? s.reason : s.network ? 'Online/LAN race: memory tools paused.' : !driveStatus ? 'Waiting for driving HUD.' : `Game linked · ${Math.round(s.rpm)} RPM${prefs.nos ? nos ? ' · NOS refilling' : ' · NOS unavailable/paused' : ''}${tune.active ? ` · Power ${tune.power.toFixed(1)}×${tune.unlimit ? ' · Governor off' : ''}` : (prefs.boost || prefs.unlimit) ? ' · Power controls waiting/unavailable' : ''}${prefs.drag ? activeDrag ? ' · Drag assist active' : ' · Drag assist waiting for a drag race' : ''}`;
      if (ui) {
        if (prefs.tester && supported && s.ready && now - lastScan > 250) {
          lastScan = now;
          const h = engine.hazards(s), close = h?.cars[0];
          ui.querySelector('#hazards').textContent = h ? `${h.scannedCars} car objects read. ${close ? `Nearest ahead: ${close.ahead.toFixed(0)} m, side offset ${close.side.toFixed(1)} m.` : 'No nearby car detected ahead.'} ${h.barrierAhead !== null ? `Barrier line ahead: ${h.barrierAhead.toFixed(0)} m.` : 'No crossing barrier line detected.'} Props and general obstacles: NOT detected.` : 'Detector waiting for valid car coordinates.';
        }
        const driftKnown = counters && Number.isFinite(counters.drift);
        const drift = driftKnown ? !!(counters.drift & 1) : null;
        const driftActive = driftKnown && !!(counters.drift & 2);
        if (driftPending && driftKnown && drift === driftPending.wanted && (!drift || driftActive)) {
          message(drift ? 'Drift assist ON: confirmed by the game’s handling state.' : 'Drift assist OFF: confirmed by the game.'); driftPending=null;
        } else if (driftPending && now > driftPending.until) {
          message('The game did not confirm drift assist. Use solo free roam (not a race or co-op), close menus, then try again.'); driftPending=null;
        }
        ui.querySelector('#drift').disabled = !!driftPending;
        if (driftKnown) ui.querySelector('#drift').checked = drift;
        ui.querySelector('#drift-state').textContent = driftPending ? 'Waiting for confirmation…' : driftActive ? 'Game confirms drift handling ON' : drift ? 'Selected, but not active in this game mode' : 'Free roam only · not perfect-drift automation';
      }
    } catch { stop('Runtime changed or is unavailable. Reload the game before retrying.'); engine = null; }
  }
  function mount() {
    host = document.createElement('div'); host.id = 'nfsu2-driving-tools'; host.dataset.nfsu2Ui = '';
    Object.assign(host.style, { position: 'fixed', top: '12px', right: '12px', zIndex: '2147483647', width: '306px', maxWidth: 'calc(100vw - 24px)' });
    ui = host.attachShadow({ mode: 'closed' });
    ui.innerHTML = `<style>:host{color-scheme:dark}*{box-sizing:border-box}section{font:13px/1.4 system-ui,sans-serif;background:#10131bef;color:#edf2fc;border:1px solid #364252;border-radius:14px;max-height:calc(100vh - 24px);overflow-y:auto;box-shadow:0 12px 36px #0009}header{display:flex;align-items:center;justify-content:space-between;padding:12px 14px;background:#1b2332}h2{font-size:15px;margin:0}button{cursor:pointer;background:#26354b;border:1px solid #516078;border-radius:7px;color:white;padding:6px 9px}main{padding:8px 14px 14px}label.row{display:flex;align-items:center;justify-content:space-between;padding:10px 0;border-bottom:1px solid #2a3342}input[type=checkbox]{width:19px;height:19px;accent-color:#72e0b3}small{display:block;color:#a9b6ca;font-size:11px}p{margin:9px 0;font-size:12px}#live{color:#82e8bd}#note{color:#ffd48b}input[type=number]{width:76px;padding:4px;background:#202938;border:1px solid #516078;border-radius:5px;color:white}.fine{color:#99a8bf;font-size:11px}</style>
    <section><header><h2>NFSU2 Driving Tools</h2><button id="min" title="Collapse panel">−</button></header><main>
    <label class="row"><span>Unlimited NOS<small>Refills your equipped kit · experimental</small></span><input id="nos" type="checkbox"></label>
    <label class="row"><span>Engine power boost<small>Adjustable torque + NOS power · experimental</small></span><input id="boost" type="checkbox"></label>
    <label class="row">Power multiplier <input id="power" type="number" value="1.5" min="1" max="3" step="0.1"></label>
    <label class="row"><span>Remove stock speed limiter<small>Gearing and drag still limit top speed</small></span><input id="unlimit" type="checkbox"></label>
    <label class="row"><span>Drift assist<small id="drift-state">Free roam only · waits for game confirmation</small></span><input id="drift" type="checkbox"></label>
    <label class="row"><span>Drag assist<small>Throttle + shifting; YOU steer/avoid obstacles</small></span><input id="drag" type="checkbox"></label>
    <label class="row"><span>Traffic / barrier tester<small>Read-only, experimental · not full obstacle detection</small></span><input id="tester" type="checkbox"></label><p id="hazards" hidden></p>
    <label class="row">Shift at RPM <input id="rpm" type="number" value="6500" min="3000" max="10000" step="100"></label>
    <p id="live" role="status">Waiting for game…</p><p id="note" role="status">Experimental. Back up saves first. Use driving assists in solo play.</p>
    <button id="stop">Stop driving assists (F9)</button><p class="fine">F8 show/hide. Drag uses default Arrow Up, Left Shift, Left Alt. It cannot change lanes or avoid traffic, obstacles or damage.</p></main></section>`;
    note = ui.querySelector('#note'); live = ui.querySelector('#live');
    ui.querySelector('#nos').addEventListener('change', e => { prefs.nos = e.target.checked; });
    ui.querySelector('#boost').addEventListener('change', e => { prefs.boost=e.target.checked; message('Power boost is experimental. Start at 1.5×; turn it off if wheelspin or handling gets worse.'); });
    ui.querySelector('#unlimit').addEventListener('change', e => { prefs.unlimit=e.target.checked; });
    ui.querySelector('#power').addEventListener('change', e => { prefs.power=Math.round(Math.max(1,Math.min(3,Number(e.target.value)||1.5))*10)/10; e.target.value=prefs.power; });
    ui.querySelector('#drag').addEventListener('change', e => { prefs.drag = e.target.checked; if (!prefs.drag) release(); else message('Experimental drag assist enabled. You must steer. Default keyboard bindings required.'); });
    ui.querySelector('#tester').addEventListener('change', e => { prefs.tester = e.target.checked; ui.querySelector('#hazards').hidden = !prefs.tester; ui.querySelector('#hazards').textContent = 'Waiting for a supported game and driving state…'; });
    ui.querySelector('#rpm').addEventListener('change', e => { prefs.rpm = Math.max(3000, Math.min(10000, Number(e.target.value) || 6500)); e.target.value = prefs.rpm; });
    ui.querySelector('#drift').addEventListener('change', e => { const wanted = e.target.checked; setDrift(wanted); const status=engine && statusPtr ? engine.status(statusPtr) : null; e.target.checked=!!(status?.drift & 1); });
    ui.querySelector('#stop').addEventListener('click', () => stop());
    ui.querySelector('#min').addEventListener('click', e => { const main = ui.querySelector('main'); main.hidden = !main.hidden; e.target.textContent = main.hidden ? '+' : '−'; });
    const parent = document.fullscreenElement || document.body; parent.append(host);
    document.addEventListener('fullscreenchange', () => { (document.fullscreenElement || document.body).append(host); });
    timer = setInterval(tick, 50);
  }
  if (document.body) mount(); else document.addEventListener('DOMContentLoaded', mount, { once: true });
})();

# NFSU2 Driving Tools — experimental v0.2.0

A small unpacked Chrome/Edge/Brave extension for **https://nfsu2.xyz/**.

## Install

1. Extract the ZIP to a folder. Keep that folder: the browser loads it from there.
2. Open `chrome://extensions` (Edge: `edge://extensions`).
3. Turn on **Developer mode**, click **Load unpacked**, and select the extracted **NFSU2-Driving-Tools** folder containing `manifest.json`.
4. Reload nfsu2.xyz, then press Play. The panel appears at the upper right.

Chrome 111+ or a current compatible Chromium browser is required. This package is not a mobile-browser or Firefox build. No build command, Node installation or package dependencies are needed to install it.

Car ghosting is intentionally not included; use the game’s own menu for that.

## Switches

- **Unlimited NOS:** repeatedly refills the equipped nitrous kit while driving. It does not install a missing kit or change its capacity. Experimental memory implementation, pinned to game build `6f4f1e4e`. Paused in Online/LAN races. A new game build disables memory tools instead of trying unknown offsets.
- **Engine power boost:** 1.0×–3.0× engine and nitrous torque, with 1.5× as the starting value. This increases power, not the game clock or the speedometer. The original curve is kept, so repeated updates do not multiply power again. More power can cause wheelspin and worse handling. Pause, losing focus, F9 or disabling it restores fields still owned by the extension. If the game rebuilds the tuning, the switch turns off rather than guessing a new baseline. Enable it again after changing cars, parts or drift mode.
- **Remove stock speed limiter:** removes the stock MPH governor while enabled. Cars with an ECU upgrade may already have no governor, so this can make no difference. Gearing, redline, drag and available power still limit actual top speed. It does not add gears, change ratios or guarantee a particular speed.
- **Drift assist:** sends the game’s dedicated drift key directly through its version-checked input mailbox, replacing the earlier hidden-touch-control click. This uses the real drift-event handling and your Drift tuning, its built-in drift assist, camera and scoring. The game restores ordinary tuning when disabled. Solo free roam only; close game menus first. It now waits up to three seconds for the game’s actual drift-handling flag before reporting ON, and shows a useful failure message if not confirmed. The game’s mode is unavailable in ordinary races and co-op. Power/limiter switches are turned off and restored before a drift toggle so the game can rebuild its tuning cleanly. **This is not perfect-drift automation and does not guarantee a score, line or spin prevention.**
- **Drag assist:** experimental automatic throttle, RPM-threshold upshifts and NOS when the NOS switch is on. Start a solo drag race yourself. It uses default bindings: Arrow Up, Left Shift, Left Alt. Set the shift RPM to suit the car; 6500 is only a starting point, not a learned perfect-shift value. **You must steer. It does not change lanes, avoid traffic/obstacles, prevent damage or finish races by itself.** It waits for an active driving HUD and stops in menus, on loss of focus, when the tab is hidden, or with Escape/F9. It does not handle race selection or restart.
- **Traffic / barrier tester:** opt-in read-only diagnostic using the game's live car objects and enabled barrier-line table. It reports a nearby car ahead and a barrier crossing the car's forward line. It does not alter driving or send diagnostics anywhere. **It is not a complete obstacle detector:** car objects are not classified as traffic versus racers, parked/inactive objects may appear, and scenery, props, trucks' shapes, road geometry, elevation-sensitive barriers and safe lanes are not comprehensively modeled. “No object detected” never means the road is safe.

F8 hides/shows the panel. The minus button collapses it. F9 / Stop turns off NOS, power boost, limiter removal and drag inputs; the game's native drift mode remains under its own switch.

## Testing status and cautions

The site and its public source were inspected. JavaScript syntax checks and sixteen automated unit tests pass, covering refill logic, missing kits, pause/network guards, invalid/stale pointers, memory growth, read-only hazard extraction, bounded traversal, status-table reading, non-compounding power scaling, guarded restoration and drift-input ring formatting/guards.

**You reported that NOS works. The new power/limiter controls and repaired drift path have not been live-verified.** The available test browser cannot run this game's WebGPU graphics, and you asked to test it yourself. These are source-backed experimental implementations, not a promise that all functions work in a live race.

## Updating from an earlier package

Extract this package into your existing extension folder, click Reload on its card in `chrome://extensions`, then reload the game. The card must show version **0.2.0**. If you load a separate new folder, remove/disable the old extension first so two copies cannot run together.

Back up your save with the game's Download backup button before trying it. Use driving modifications in solo play and follow the site's rules. The page's main thread writes shared game memory asynchronously for NOS and power changes, so crashes or inconsistent behavior remain possible. If anything behaves oddly, disable the extension and reload the game. Memory changes and extension switches do not survive reload.

This extension only matches `https://nfsu2.xyz/*`. It has no account, browsing-history, storage, debugger or broad website permissions. The only request it creates is a same-origin read of `/game.json` to check compatibility. It does not contain game assets, remote executable code, analytics or an update downloader.

## Source references

Inspected game metadata: https://nfsu2.xyz/game.json, revision `6f4f1e4e`.
Public source: https://github.com/th0mk/nfsu2-web/tree/6f4f1e4e92f5f3ddf6f6d165b7f7075a95ab7fe3

- `runtime/cpu.h`: guest addresses equal WebAssembly linear-memory addresses.
- `runtime/splitscreen_mem.h`: the browser build's player array is at `0x00d00000`.
- `runtime/game.h`: game state, race, car RPM and gear.
- `runtime/mprace.c` (`perf_info`, `mprace_torque_scale`, `mprace_speed_limit`): the actual per-car torque curve, nitrous torque and MPH governor.
- `runtime/roam_game.c` (`nos_left`): nitrous duration, amount left, activation time and game clock.
- `web/src/host/process.ts`: game worker initialization and shared memory.
- `runtime/web/status_proto.h`, `web/src/app/status.ts`: self-describing status counters.
- `web/src/input/proto.ts`, `runtime/web/input_web.c`: versioned input mailbox and synthetic key-tap event.
- `web/src/app/touch.ts`, `runtime/drift.c`: native drift input and full handling/tuning lifecycle.
- `runtime/roam.c` (`log_cars`): world car list and coordinate fields.
- `runtime/walls.c`: enabled barrier lines and their segment coordinates.

No files in the upstream project were modified. This is an unofficial extension, not affiliated with the game's site or Electronic Arts.

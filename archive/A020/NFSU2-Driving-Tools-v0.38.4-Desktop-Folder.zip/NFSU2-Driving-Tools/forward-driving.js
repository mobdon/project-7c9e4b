/* Session lifecycle for the optional owned native forward sampler and cap.
 * A published request is not a native application acknowledgement. */
(function(root){
  'use strict';
  const Profiles=root.__NFSU2_FORWARD_NATIVE_CONFIG__||(typeof require==='function'?require('./forward-native-config.js'):null);
  const PIN='ed47e9bdd94a336d8d6bd52bebcc6f130b40ffb6d692f0fc728b8785db02178c';
  const finite=(n,a,b)=>typeof n==='number'&&Number.isFinite(n)&&n>=a&&n<=b;
  const local=name=>{if(typeof require!=='function')return null;try{return require('./'+name+'.js');}catch{return null;}};
  const guardCodes=Object.freeze({uninstalled:11,unverified:12,moduleIdentity:13,controllers:14,pacingDependency:15,policy:16,identity:17,pace:18,ownerSequence:19,captureUnavailable:37,requestResult:38,captureIdentity:39,plan:40,publishResult:41,publishException:42,pollException:43,requestException:44,pageException:45});
  const knownGuardCodes=new Set([...Object.values(guardCodes),20,21,22,23,24,25,26,28,29,30,31,32,33,34,35,...Array.from({length:44},(_,i)=>100+i)]);
  const knownGuard=code=>Number.isInteger(code)&&knownGuardCodes.has(code);
  const errorGuard=(error,fallback)=>{try{return knownGuard(error?.forwardGuardCode)?error.forwardGuardCode:fallback;}catch{return fallback;}};
  const snapshot=(forwardState,extra={})=>Object.freeze({forwardState,forwardSamples:0,forwardHorizon:0,forwardPriorityTurns:0,
    forwardRequestedTarget:undefined,forwardFailureCode:undefined,forwardGuardCode:undefined,forwardLeaseTicks:0,forwardCaptured:false,forwardNativeApplied:false,forwardLiveVerified:false,...extra});
  function policySettings(policy,native=false){
    if(!policy||typeof policy!=='object')return null;
    if(native){
      const p={mode:'native',cornerFactor:policy.cornerFactor??.8,sharpMargin:policy.sharpMargin??15,brakingFactor:policy.brakingFactor??.75,reactionSeconds:policy.reactionSeconds??.6,marginDistance:policy.marginDistance??8};
      return finite(p.cornerFactor,.6,.95)&&finite(p.sharpMargin,0,25)&&finite(p.brakingFactor,.5,1)&&finite(p.reactionSeconds,.1,2)&&finite(p.marginDistance,0,30)?p:null;
    }
    const p={lateralAcceleration:policy.lateralAcceleration,brakingDeceleration:policy.brakingDeceleration,
      cornerFactor:policy.cornerFactor??.8,sharpMargin:policy.sharpMargin??15,reactionSeconds:policy.reactionSeconds??.6,
      marginDistance:policy.marginDistance??8,maxSpacing:policy.maxSpacing??20};
    if(!finite(p.lateralAcceleration,.5,12)||!finite(p.brakingDeceleration,.5,12)||!finite(p.cornerFactor,.6,.95)||
      !finite(p.sharpMargin,0,25)||!finite(p.reactionSeconds,.1,2)||!finite(p.marginDistance,0,30)||!finite(p.maxSpacing,1,25))return null;
    return p;
  }
  class Controller{
    constructor(memory,{installed=false,verified=false,moduleHash,moduleIdentity=null,geometry=null,publisher=null}={}){
      this.memory=memory;this.installed=installed===true;this.profile=Profiles?.select?.(moduleHash);this.verified=verified===true&&!!this.profile;this.moduleIdentity=moduleIdentity;
      const Geometry=root.__NFSU2_FORWARD_GEOMETRY__||local('forward-geometry');
      const Clamp=root.__NFSU2_FORWARD_CLAMP__||local('forward-clamp');
      this.pacing=root.__NFSU2_FORWARD_PACING__||local('forward-pacing');
      this.geometry=geometry||(Geometry?.Controller?new Geometry.Controller(memory,{installed:this.installed,verified:this.verified,moduleHash,moduleIdentity}):null);
      this.publisher=publisher||(Clamp?.Publisher&&this.geometry?new Clamp.Publisher(this.geometry,{installed:this.installed,moduleIdentity}):null);
      this.key=null;this.pendingRequest=null;this.published=false;this.ownerSequence=null;
    }
    revoke(){
      // The cap occupies a subordinate part of the geometry claim. Revoke it
      // before clearing the geometry receipt or invalidating that owner.
      try{this.publisher?.stop();}catch{}
      try{this.geometry?.stop();}catch{}
      this.pendingRequest=null;this.published=false;this.ownerSequence=null;
    }
    stop(){this.revoke();this.key=null;return snapshot('off');}
    invalidate(){this.stop();try{this.geometry?.invalidate();}catch{}this.verified=false;return snapshot('off');}
    update({enabled=false,safe=false,offline=false,ordinaryRace=false,allowNetwork=false,applyTarget=true,aiState=null,handbackPending=false,expectedPace,identity,policy}={}){
      const nativeRequested=applyTarget==='native-policy',nativeEnabled=nativeRequested&&this.profile?.capabilities.nativePolicy===true;
      if(applyTarget!==true&&!nativeEnabled)try{this.publisher?.stop();}catch{}
      if(enabled!==true)return this.stop();
      const unknown=(code,guard)=>{this.stop();return snapshot('unknown',{forwardFailureCode:Number.isInteger(code)&&code>=1&&code<=10?code:undefined,forwardGuardCode:knownGuard(guard)?guard:undefined});};
      if(!this.installed)return unknown(undefined,11);
      if(!this.verified)return unknown(undefined,12);
      if(!this.moduleIdentity)return unknown(undefined,13);
      if(!this.geometry||!this.publisher)return unknown(undefined,14);
      if(typeof this.pacing?.windowFromCapture!=='function'||typeof this.pacing?.plan!=='function')return unknown(undefined,15);
      if(safe!==true||(offline!==true&&allowNetwork!==true)||ordinaryRace!==true||aiState?.active!==true||aiState?.owned!==true||
        aiState?.switching===true||handbackPending===true){this.stop();return snapshot('waiting');}
      const settings=policySettings(policy,nativeRequested);
      if(!settings)return unknown(undefined,16);
      if(typeof identity!=='string'||!identity||identity.length>256)return unknown(undefined,17);
      if(!finite(expectedPace,.75,nativeRequested?2:3)||Math.abs(expectedPace*100-Math.round(expectedPace*100))>1e-5)return unknown(undefined,18);
      const key=JSON.stringify([identity,allowNetwork===true,applyTarget,Math.round(expectedPace*100),...Object.values(settings)]);
      if(this.key!==key){this.revoke();this.key=key;}
      // A caller may expose its current command generation. The native probe
      // independently validates it for every request and publication too.
      const observedSequence=aiState.ownerSequence;
      if(observedSequence!==undefined&&(!Number.isInteger(observedSequence)||observedSequence<=0||observedSequence>0xffffffff||(observedSequence&1)))return unknown(undefined,19);
      if(this.ownerSequence!==null&&observedSequence!==undefined&&observedSequence!==this.ownerSequence){this.revoke();this.key=key;}
      let exceptionGuard=44;
      try{
        if(this.pendingRequest!==null){
          exceptionGuard=43;
          const capture=this.geometry.poll();
          if(capture?.status==='waiting')return snapshot('waiting');
          const request=this.pendingRequest;this.pendingRequest=null;
          if(capture?.status!=='captured')return unknown(capture?.code,knownGuard(capture?.forwardGuardCode)?capture.forwardGuardCode:37);
          if(capture.request!==request||capture.pace!==expectedPace||
            !Number.isInteger(capture.ownerSequence)||capture.ownerSequence<=0||capture.ownerSequence>0xffffffff||(capture.ownerSequence&1)||
            (observedSequence!==undefined&&capture.ownerSequence!==observedSequence))return unknown(undefined,39);
          const window=this.pacing.windowFromCapture(capture);
          if(nativeRequested&&!nativeEnabled){this.publisher.stop();this.ownerSequence=capture.ownerSequence;return snapshot('observed',{forwardSamples:window?.samples?.length||0,forwardHorizon:window?.samples?.at(-1)?.distance||0,forwardCaptured:window?.available===true});}
          const plan=window?.available===true?(nativeRequested?this.pacing.planNative?.(capture,capture.nativePolicy,{...settings,pace:expectedPace}):this.pacing.plan(window,settings)):null;
          if(plan?.available!==true||!Array.isArray(window.samples)||window.samples.length<3||window.samples.length>48||
            !finite(plan.horizonDistance,0,(this.profile.runtime.maxHorizon||184)+.01)||!Number.isInteger(plan.priorityTurns)||plan.priorityTurns<0||plan.priorityTurns>24)return unknown(undefined,40);
          if((applyTarget!==true&&!nativeEnabled)||plan.override!==true){
            this.publisher.stop();this.ownerSequence=capture.ownerSequence;
            return snapshot(applyTarget!==true&&!nativeEnabled?'observed':'native-fallback',{forwardSamples:window.samples.length,forwardHorizon:plan.horizonDistance,forwardPriorityTurns:plan.priorityTurns,forwardCaptured:true});
          }
          exceptionGuard=42;
          const result=this.publisher.publish({capture,window,policy:settings});
          if(result?.status!=='armed'||result.request!==request||!finite(result.cap,Number.MIN_VALUE,150)||
            !Number.isInteger(result.maxAgeTicks)||result.maxAgeTicks<1||result.maxAgeTicks>400)return unknown(undefined,41);
          this.published=true;this.ownerSequence=capture.ownerSequence;
          // Do not request another capture here: changing the native request
          // immediately revokes the cap just published. The next update starts
          // a fresh transaction. Lease/fallback gaps are intentionally allowed.
          return snapshot('armed',{forwardSamples:window.samples.length,forwardHorizon:plan.horizonDistance,
            forwardPriorityTurns:plan.priorityTurns,forwardRequestedTarget:result.cap,forwardLeaseTicks:result.maxAgeTicks,forwardCaptured:true});
        }
        if(this.published){this.revoke();this.key=key;}
        const result=this.geometry.request({expectedPace,allowNetwork:allowNetwork===true});
        if(result?.status!=='waiting'||!Number.isInteger(result.request)||result.request<=0||(result.request&1))return unknown(undefined,38);
        this.pendingRequest=result.request;this.ownerSequence=observedSequence??null;
        return snapshot('requested');
      }catch(error){return unknown(undefined,errorGuard(error,exceptionGuard));}
    }
  }
  const api=Object.freeze({Controller,PIN,guardCodes});root.__NFSU2_FORWARD_DRIVING__=api;
  if(typeof module==='object'&&module.exports)module.exports=api;
})(globalThis);

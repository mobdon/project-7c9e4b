/* Private native evaluator. Game instructions are extracted only from the game's
 * exact verified download. This file contains authored instrumentation, not game code. */
(function(root){'use strict';
const U=n=>{n>>>=0;const a=[];do{let x=n&127;n>>>=7;if(n)x|=128;a.push(x);}while(n);return a;};
const S=n=>{n|=0;const a=[];for(;;){let x=n&127;n>>=7;const done=(n===0&&!(x&64))||(n===-1&&(x&64));if(!done)x|=128;a.push(x);if(done)return a;}};
const cat=(...xs)=>{const a=new Uint8Array(xs.reduce((n,x)=>n+x.length,0));let p=0;for(const x of xs){a.set(x,p);p+=x.length;}return a;};
const name=s=>{const b=new TextEncoder().encode(s);return cat(U(b.length),b);};
const section=(id,b)=>cat([id],U(b.length),b),vec=xs=>cat(U(xs.length),...xs),constant=n=>[65,...S(n)];
const reader=(bytes,p=0,end=bytes.length)=>({bytes,p,end});
function u(r){let n=0,shift=0;for(let i=0;i<5;i++){if(r.p>=r.end)throw Error('Truncated native module');const x=r.bytes[r.p++];n+=(x&127)*2**shift;if(!(x&128))return n>>>0;shift+=7;}throw Error('Invalid native integer');}
function parse(bytes){const r=reader(bytes,8),sections=new Map();while(r.p<r.end){const id=bytes[r.p++],n=u(r),start=r.p;r.p+=n;if(r.p>r.end||sections.has(id)&&id)throw Error('Invalid native section');sections.set(id,bytes.subarray(start,r.p));}return sections;}
const opCodes={'i32.load':[40],'i64.load':[41],'f32.load':[42],'f64.load':[43],'i32.load8_s':[44],'i32.load8_u':[45],'i32.load16_u':[47],'i64.load32_s':[52],'i32.store':[54],'i64.store':[55],'f32.store':[56],'f64.store':[57],'i32.store8':[58],'i32.store16':[59],'v128.load32_lane':[253,86],'v128.store':[253,11]};
const valueTypes={i32:127,i64:126,f32:125,f64:124,v128:123};
function helperInfo(op,lane){
 if(!opCodes[op])throw Error('Unsupported native memory opcode '+op);
 const type=op.split('.')[0],store=op.includes('.store'),laneLoad=op.includes('_lane'),wide=store||laneLoad;
 const width=op.includes('8_')||op.endsWith('8')?1:op.includes('16_')||op.endsWith('16')?2:op.includes('32_')||op.endsWith('32')?4:type==='v128'?16:type==='i64'||type==='f64'?8:4;
 const params=wide?[127,valueTypes[type],127,127,127]:[127,127,127,127];
 const offset=wide?2:1,fn=wide?3:2,site=wide?4:3;
 const body=[0,32,0,32,offset,...constant(width),32,fn,32,site,16,store?2:1,32,0,32,offset,106];
 if(wide)body.push(32,1);body.push(...opCodes[op],0,0);if(laneLoad)body.push(lane);body.push(11);
 return {type:[96,...U(params.length),...params,...(store?[0]:[1,valueTypes[type]])],body:Uint8Array.from(body)};
}
function originalElements(data){const r=reader(data),count=u(r),table=new Map();for(let i=0;i<count;i++){
 const flags=u(r);if(flags!==0&&flags!==2)throw Error('Unsupported native elements');if(flags===2&&u(r)!==0)throw Error('Unknown native table');
 if(r.bytes[r.p++]!==65)throw Error('Unsupported native element offset');const start=u(r);if(r.bytes[r.p++]!==11)throw Error('Invalid native offset');if(flags===2&&r.bytes[r.p++]!==0)throw Error('Invalid native elemkind');
 const n=u(r);for(let j=0;j<n;j++)table.set(start+j,u(r));
 }if(r.p!==r.end)throw Error('Invalid native elements tail');return table;}
function firstPassive(data){const r=reader(data);if(u(r)<1||u(r)!==1)throw Error('Unsupported native dispatch metadata');const n=u(r);if(r.p+n>r.end)throw Error('Invalid native data');return data.subarray(r.p,r.p+n);}
async function build(input,meta=root.__NFSU2_DYNO_NATIVE_PROFILE__){
 const bytes=input instanceof Uint8Array?input:new Uint8Array(input);
 if(!meta||bytes.length!==meta.moduleSize)throw Error('Full tuner needs its exact verified game build');
 const hash=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes)),x=>x.toString(16).padStart(2,'0')).join('');
 if(hash!==meta.moduleHash)throw Error('Full tuner module hash mismatch');
 const sections=parse(bytes),typeSection=sections.get(1),tr=reader(typeSection),typeCount=u(tr),ids=Object.keys(meta.functions).map(Number).sort((a,b)=>a-b),mapped=new Map(ids.map((id,i)=>[id,i+5]));
 mapped.set(meta.tail,3);mapped.set(meta.dispatch,4);
 const extraTypes=[[96,2,127,127,0],[96,5,127,127,127,127,127,0]],helpers=new Map();
 for(const id of ids)for(const p of meta.functions[id].patches)if(p.kind==='memory'){
  const key=p.op+':'+(p.lane??'');if(!helpers.has(key)){const h=helperInfo(p.op,p.lane);h.index=5+ids.length+helpers.size;h.typeIndex=typeCount+extraTypes.length;helpers.set(key,h);extraTypes.push(h.type);}
 }
 const types=cat(U(typeCount+extraTypes.length),typeSection.subarray(tr.p),...extraTypes);
 const imports=vec([['fuel',typeCount],['read',typeCount+1],['write',typeCount+1],['tail',0],['dispatch',typeCount]].map(([n,t])=>cat(name('audit'),name(n),[0],U(t))));
 const fnTypes=vec([...ids.map(id=>U(meta.functions[id].type)),...[...helpers.values()].map(h=>U(h.typeIndex))]);
 const bodies=ids.map(id=>{
  const f=meta.functions[id],original=bytes.subarray(f.offset,f.offset+f.length),patches=[{at:f.localsEnd,length:0,kind:'fuel'},...f.patches];let p=0;const chunks=[];
  for(const patch of patches){if(patch.at<p||patch.at+patch.length>original.length)throw Error('Overlapping native instrumentation');chunks.push(original.subarray(p,patch.at));
   if(patch.kind==='fuel')chunks.push(Uint8Array.from([...constant(id),...constant(patch.at),16,0]));
   else if(patch.kind==='call'){const target=mapped.get(patch.target);if(target===undefined)throw Error('Uncaptured direct native target');chunks.push(Uint8Array.from([patch.tail?18:16,...U(target)]));}
   else{const h=helpers.get(patch.op+':'+(patch.lane??''));chunks.push(Uint8Array.from([...constant(patch.offset),...constant(id),...constant(patch.at),16,...U(h.index)]));}
   p=patch.at+patch.length;
  }chunks.push(original.subarray(p));const body=cat(...chunks);return cat(U(body.length),body);
 });
 for(const h of helpers.values())bodies.push(cat(U(h.body.length),h.body));
 const nativeTable=originalElements(sections.get(9)),elements=[];
 for(const [slot,id]of nativeTable)if(mapped.has(id))elements.push(Uint8Array.from([0,...constant(slot),11,1,...U(mapped.get(id))]));
 const exports=vec([cat(name('memory'),[2,0]),...ids.map(id=>cat(name('f'+id),[0],U(mapped.get(id))))]);
 const moduleBytes=cat([0,97,115,109,1,0,0,0],section(1,types),section(2,imports),section(3,fnTypes),section(4,[1,112,0,...U(meta.tableSize)]),section(5,[1,1,...U(meta.memoryPages),...U(32768)]),section(6,sections.get(6)),section(7,exports),section(9,vec(elements)),section(10,cat(U(bodies.length),...bodies)));
 const data=firstPassive(sections.get(11)),dv=new DataView(data.buffer,data.byteOffset,data.byteLength),count=dv.getUint32(0,true),pbase=(16+4*count+15)&~15,guestMap=new Map(),lookup=[];
 if(count>100000||pbase+count*4>data.length)throw Error('Invalid native dispatch map');
 for(let i=0;i<count;i++){const address=dv.getUint32(16+i*4,true),slot=dv.getUint32(pbase+i*4,true),id=nativeTable.get(slot);guestMap.set(address,id);if(address>=4198400&&address<7875312)lookup.push([meta.lookupBase+(address-4198400)*4,slot]);}
 return {module:await WebAssembly.compile(moduleBytes),guestMap,lookup,meta,byteLength:moduleBytes.length};
}
const CPU=0x2b000000,SP=0x2b020000;
async function instantiate(prepared){
 let instance,memory,view,remaining=0,active=false,reads=[],writes=[],journal=new Map(),fuelUsed=0;
 const within=(p,n,regions)=>Number.isInteger(p)&&p>=0&&Number.isInteger(n)&&n>0&&p+n<=memory.buffer.byteLength&&regions.some(([a,b])=>p>=a&&p+n<=b);
 const check=(p,n,regions,label)=>{if(!active||!within(p,n,regions))throw Error(label+':'+(p>>>0).toString(16));};
 const address=(base,offset)=>{const p=(base>>>0)+(offset>>>0);if(p>0xffffffff)throw Error('NATIVE_ADDRESS_OVERFLOW');return p;};
 let lookupRegions=[];
 const lookupContains=(p,n)=>{let lo=0,hi=lookupRegions.length;while(lo<hi){const m=(lo+hi)>>>1;if(lookupRegions[m][0]<=p)lo=m+1;else hi=m;}const r=lookupRegions[lo-1];return !!r&&p>=r[0]&&p+n<=r[1];};
 const audit={fuel:()=>{if(!active||--remaining<0)throw Error('NATIVE_BUDGET');fuelUsed++;},read:(base,offset,n)=>{const p=address(base,offset);if(!active||!within(p,n,reads)&&!lookupContains(p,n))throw Error('NATIVE_UNCAPTURED_READ:'+p.toString(16));},write:(base,offset,n)=>{const p=address(base,offset);check(p,n,writes,'NATIVE_FORBIDDEN_WRITE');for(let i=0;i<n;i++)if(!journal.has(p+i))journal.set(p+i,view.getUint8(p+i));},tail:cpu=>dispatch(cpu,view.getUint32(cpu+32,true)),dispatch:(cpu,a)=>dispatch(cpu,a)};
 function dispatch(cpu,a){if(cpu!==CPU)throw Error('NATIVE_CPU_IDENTITY');const id=prepared.guestMap.get(a),fn=instance.exports['f'+id];if(!fn)throw Error('NATIVE_TARGET_UNAVAILABLE:'+a.toString(16));fn(cpu);}
 instance=await WebAssembly.instantiate(prepared.module,{audit});memory=instance.exports.memory;view=new DataView(memory.buffer);
 for(const [address,slot]of prepared.lookup)view.setUint32(address,slot,true);
 const lookupRanges=prepared.lookup.map(([a])=>[a,a+4]); // Coalesce to keep each instrumented read cheap.
 lookupRanges.sort((a,b)=>a[0]-b[0]);const compact=[];for(const r of lookupRanges){const last=compact[compact.length-1];if(last&&r[0]<=last[1])last[1]=Math.max(last[1],r[1]);else compact.push(r);}
 function hydrate(snapshot){
  if(active)throw Error('Native evaluator busy');if(!snapshot||!Array.isArray(snapshot.ranges)||snapshot.ranges.length>16)throw Error('Invalid native snapshot');
  // The capture bridge verifies the active native guest window and committed
  // pages. Preserve exact source addresses in this separate evaluator memory;
  // never admit the intervening runtime region or its CPU/dispatch scratch.
  const sources=[];let required=memory.buffer.byteLength;
  for(const range of snapshot.ranges){
   const {address,data,writable=false}=range,end=address+(data?.length||0);
   if(!(data instanceof Uint8Array)||!data.length||!Number.isSafeInteger(address)||address<0x10000||!(end<=0x28000000||(address>=0x50000000&&end<=0x7ffe0000&&data.length<=46*0x890)))throw Error('Invalid native snapshot range');
   sources.push([address,end,!!writable]);required=Math.max(required,end);
  }
  if(required>memory.buffer.byteLength){memory.grow(Math.ceil(required/65536)-memory.buffer.byteLength/65536);view=new DataView(memory.buffer);}
  for(const {address,data}of snapshot.ranges)new Uint8Array(memory.buffer,address,data.length).set(data);
  reads=[...sources.map(r=>r.slice(0,2)),[CPU,CPU+344],[SP-16384,SP+128]];lookupRegions=compact;writes=[...sources.filter(r=>r[2]).map(r=>r.slice(0,2)),[CPU,CPU+344],[SP-16384,SP+128],[0x86b620,0x86b620+368]];
  // Dispatch holes remain uncaptured; populated slots are checked by binary search.
 }
 function call(id,args=[],{thisArg,fuel=100000,rollback=false,capture=null}={}){
  if(active||!Number.isInteger(fuel)||fuel<1||fuel>150000)throw Error('Invalid native call budget');
  const fn=instance.exports['f'+id];if(!fn)throw Error('Unsupported native entry');new Uint8Array(memory.buffer,CPU,344).fill(0);view.setUint32(CPU+4,thisArg,true);view.setUint32(CPU+16,SP,true);view.setUint16(CPU+140,0x37f,true);view.setUint32(SP,0xdeadbeef,true);args.forEach((x,i)=>view.setUint32(SP+4+4*i,x,true));
  journal=new Map();remaining=fuel;fuelUsed=0;active=true;let result;
  try{fn(CPU);result={eax:view.getUint32(CPU,true),value:view.getFloat64(CPU+72+8*(view.getUint32(CPU+136,true)&7),true),fuel:fuelUsed};if(capture)result.captured=new Uint8Array(memory.buffer,capture.address,capture.length).slice();return result;}
  finally{active=false;if(rollback)for(const [address,value]of journal)view.setUint8(address,value);journal.clear();}
 }
 return {hydrate,call,get view(){return view;},memory,CPU,SP};
}
const api={build,instantiate,CPU,SP};root.__NFSU2_DYNO_NATIVE__=api;if(typeof module==='object'&&module.exports)module.exports=api;
})(globalThis);

/* Optional Quick Race prototype. No native payload, save, reward or result writes.
 * Source map and unverified transitions: integration/AUTONOMOUS-RACES.md. */
(function(root){
'use strict';
const MODES=Object.freeze([0,1,2,3,4,10]);
const SCREENS=Object.freeze({main:'ui_main.fng',mode:'ui_qrmodeselect.fng',track:'ui_qrtrackselect.fng',options:'ui_qrmodeoptions.fng',car:'ui_qrcarselect.fng',results:'ui_postraceresults.fng'});
const MODE_ITEMS=Object.freeze({[0x790fd4]:0,[0x790fdc]:1,[0x790fe4]:2,[0x790fec]:3,[0x79100c]:4,[0x791004]:10});
const KEYS=Object.freeze({Enter:[0x1c,13],ArrowLeft:[0xcb,37],ArrowRight:[0xcd,39]});
class Reader {
  constructor(engine){this.e=engine;}
  snapshot(verified){
    const e=this.e;e.refresh();const u=p=>e.u32(p),b=p=>e.u8(p),ok=(p,n=4)=>p%4===0&&e.ok(p,n);
    if(!verified)return {ok:false,reason:'Exact supported build required'};
    const flow=u(0x8654a4),gameMode=u(0x850078),network=!!(gameMode&0x208)||!!u(0x866a14)||!!u(0x8669f4)||!!b(0x89cf69);
    if(network||gameMode!==2)return {ok:false,reason:'Solo Quick Race only'};
    if(u(0xd00030)>1)return {ok:false,reason:'Single local player required'};
    const fe=u(0x8384c4),manager=ok(fe,12)?u(fe+8):0;
    if(!ok(manager,0xf8))return {ok:false,reason:'Screen state unavailable'};
    const names=[],nodes=[];
    for(const off of [0xe4,0xf4]){
      const seen=new Set();let p=u(manager+off);
      while(p){
        if(seen.has(p)||seen.size>=64||!ok(p,0x20))return {ok:false,reason:'Screen list is changing'};
        seen.add(p);const at=u(p+12);if(!e.ok(at,64))return {ok:false,reason:'Screen name unavailable'};
        let name='';for(let i=0;i<64;i++){const c=b(at+i);if(!c)break;if(c<32||c>126)return {ok:false,reason:'Screen name unavailable'};name+=String.fromCharCode(c);}
        if(!/^[a-z0-9_]+\.fng$/i.test(name))return {ok:false,reason:'Screen name unavailable'};
        nodes.push(p);names.push(name.toLowerCase());p=u(p+4);
      }
    }
    let top=names[0]||'',mainItem=null,selectedMode=null;
    const menuType=top===SCREENS.main?0x797510:top===SCREENS.mode?0x797734:0;
    if(menuType){
      const head=0x8637b4,seen=new Set();let n=u(head),screen=0;
      while(n&&n!==head){if(seen.has(n)||seen.size>=256||!ok(n,20))return {ok:false,reason:'Menu list is changing'};seen.add(n);const sc=u(n+0x10);if(ok(sc,0xd0)&&u(sc)===menuType){if(screen)return {ok:false,reason:'Ambiguous main menu'};screen=sc;}n=u(n);}
      if(screen){const selected=u(screen+0x58),listHead=screen+0x50,visited=new Set();let node=u(listHead),found=false;
        while(node&&node!==listHead){if(visited.has(node)||visited.size>=32||!ok(node,8)||!ok(node-4,0x48))return {ok:false,reason:'Menu options are changing'};visited.add(node);if(node-4===selected)found=true;node=u(node);}
        if(node===listHead&&found){if(top===SCREENS.main)mainItem=u(selected);else selectedMode=MODE_ITEMS[u(selected)]??null;}
      }
    }
    const dialog=u(0x838974),dialogCount=u(0x838968),messages=[u(0x838944),u(0x83894c)];
    // Only the exact native automatic/manual gearbox question is accepted.
    const transmission=!!dialog&&dialogCount===2&&messages[0]===0x5f5e3886&&messages[1]===0x1a2826e1;
    const modal=names.some(x=>/genericdialog|^mc_main\.|^ui_(pause|engage|sms|sponsor|sponsorship)/.test(x));
    const mode=u(0x83aab4),trackAt=0x83aab4+0x18+20*mode;
    const race=u(0x890118),player=u(0xd00000),car=ok(player,0x14)?u(player+4):0;
    let completion=0;
    if(ok(race,0xc44)&&ok(car,0x9e4)){
      const n=u(race+0x24);if(n>=1&&n<=6){const matches=[];for(let i=0;i<n;i++){const rr=u(race+0xbd0+i*4);if(ok(rr,0x20)&&u(rr)===car)matches.push(rr);}if(matches.length===1)completion=e.view.getUint16(matches[0]+0x10,true);}
    }
    const out={ok:true,flow,gameMode,network,top,names,mainItem,selectedMode,mode,track:MODES.includes(mode)?e.view.getUint16(trackAt,true):0,dialog,transmission,modal,racePhase:ok(race,4)?u(race):0,completion,car};
    out.fingerprint=JSON.stringify([flow,gameMode,top,nodes,mainItem,selectedMode,mode,out.track,dialog,dialogCount,messages,out.racePhase,car]);return out;
  }
  tap(ptr,key,expected,verified){
    const e=this.e,k=KEYS[key];if(!k||this.snapshot(verified).fingerprint!==expected)return false;e.refresh();
    if(!(e.memory.buffer instanceof SharedArrayBuffer)||!Number.isSafeInteger(ptr)||ptr%4||ptr<=0||ptr+20800>e.view.byteLength)return false;
    const h=new Int32Array(e.view.buffer,ptr,64);
    if((Atomics.load(h,0)>>>0)!==0x4e494e50||Atomics.load(h,1)!==2||Atomics.load(h,3)!==1024||Atomics.load(h,7)!==1||Atomics.load(h,27)!==0||Atomics.load(h,34)!==0||Atomics.load(h,14)!==0)return false;
    const w=Atomics.load(h,4),r=Atomics.load(h,5);if(w!==r)return false; // never append behind unknown pending input
    const ev=new Uint8Array(e.view.buffer,ptr+4416+(w&1023)*16,16);ev.fill(0);ev[0]=3;ev[1]=k[0];ev[2]=k[1];ev[3]=32;
    Atomics.store(h,4,(w+1)|0);Atomics.notify(h,4,1);return true;
  }
}
class Session {
  constructor(){this.active=false;this.message='Off · experimental Quick Race loop';this.completed=0;}
  stop(reason='Stopped'){this.active=false;this.message=reason;return {stop:true,message:reason};}
  start(s,now,limit=10){
    if(!s?.ok||s.network||s.gameMode!==2||s.flow!==3||s.top!==SCREENS.mode||s.modal||s.dialog||!MODES.includes(s.selectedMode)||!Number.isInteger(limit)||limit<1||limit>1000||!Number.isFinite(now))return this.stop('Choose a solo Quick Race type first');
    Object.assign(this,{active:true,mode:s.selectedMode,limit,completed:0,stage:'setup',screen:'',screenAt:now,startedAt:now,setupAt:now,next:now+1500,seenRace:false,resultCounted:false,advanceTrack:false,trackMoved:false,attempts:0,transmissionKey:false,message:'Starting selected Quick Race · experimental'});return {started:true};
  }
  tick(s,now,context={}){
    if(!this.active)return {};
    if(!Number.isFinite(now)||now<this.startedAt)return this.stop('Clock changed; start again');
    if(context.interrupted||context.hidden||context.focused===false||context.panel||context.tunerBusy||context.pageDialog||context.gamepad)return this.stop('Stopped for manual control or interruption');
    if(!s?.ok)return this.stop(s?.reason||'Game state unavailable');
    if(s.network||s.gameMode!==2)return this.stop('Stopped outside solo Quick Race');
    if(s.modal&&!s.transmission||s.dialog&&!s.transmission)return this.stop('Unrecognized dialog; manual input required');
    if(now<this.next)return {};
    if(s.flow===4||s.flow===5||s.top==='pc_loading.fng'){
      if(now-this.setupAt>120000)return this.stop('Loading timed out');this.message='Loading selected race';return {};
    }
    if(s.flow===6&&[3,4].includes(s.racePhase)&&!s.transmission&&!s.modal&&!s.top.startsWith('ui_postrace')){
      if(!this.seenRace){this.seenRace=true;this.raceAt=now;this.driverWaitAt=undefined;this.stage='race';}
      if(now-this.raceAt>20*60*1000)return this.stop('Race time limit reached; manual control');
      if(s.racePhase===4){if(context.aiActive===true)this.driverWaitAt=now;else if(this.driverWaitAt===undefined)this.driverWaitAt=now;else if(now-this.driverWaitAt>15000)return this.stop('Native AI did not take control; manual input required');}
      this.message=(context.aiActive===true?'Native AI active':'Requesting native AI')+' · completed '+this.completed+' / '+this.limit;return {drive:true};
    }
    if(s.flow===6&&s.racePhase===6)return this.stop('Game paused; session stopped');
    const screen=s.transmission?'transmission':s.top;
    if(screen!==this.screen){this.screen=screen;this.screenAt=now;this.attempts=0;this.transmissionKey=false;this.next=now+1000;return {};}
    if(this.seenRace&&screen===SCREENS.results){
      if(!s.completion){if(now-this.screenAt>15000)return this.stop('Result did not identify a completed local race');return {};}
      if(!this.resultCounted){this.resultCounted=true;this.completed++;this.message='Finished '+this.completed+' / '+this.limit+' · showing results';}
      if(this.completed>=this.limit)return this.stop('Session complete: '+this.completed+' races finished');
      if(now-this.screenAt<8000)return {};
      return this.action('Enter',now,'Continue from recognized results');
    }
    if(this.seenRace&&screen===SCREENS.main){
      if(!this.resultCounted)return this.stop('Returned to menu without a confirmed finish');
      this.seenRace=false;this.resultCounted=false;this.advanceTrack=true;this.trackMoved=false;this.setupAt=now;this.stage='setup';
    }
    if(this.seenRace){if(now-this.screenAt>10000)return this.stop('Unmapped post-race screen; manual input required');this.message='Waiting for recognized race results';return {};}
    if(now-this.setupAt>120000)return this.stop('Race setup timed out');
    if(screen===SCREENS.main){
      if(s.mainItem===null)return this.stop('Main-menu selection could not be verified');
      return this.action(s.mainItem===0x790c30?'Enter':'ArrowRight',now,'Finding Quick Race');
    }
    if(screen===SCREENS.mode){if(!MODES.includes(s.selectedMode))return this.stop('Race-type selection unavailable');return this.action(s.selectedMode===this.mode?'Enter':'ArrowRight',now,'Selecting same race type');}
    if(screen===SCREENS.track){
      if(this.advanceTrack&&!this.trackMoved){this.trackMoved=true;this.previousTrack=s.track;return this.action('ArrowRight',now,'Choosing next track');}
      return this.action('Enter',now,'Accepting track');
    }
    if(screen===SCREENS.options||screen===SCREENS.car){
      if(s.mode!==this.mode)return this.stop('Accepted race type differs; manual input required');
      if(this.advanceTrack&&s.track===this.previousTrack)return this.stop('Accepted track did not change; manual input required');
      return this.action('Enter',now,'Keeping selected race settings and car');
    }
    if(screen==='transmission'){
      if(!this.transmissionKey){this.transmissionKey=true;return this.action('ArrowRight',now,'Selecting automatic gearbox');}
      return this.action('Enter',now,'Starting race');
    }
    if(now-this.screenAt>10000)return this.stop('Unrecognized screen; manual input required');
    this.message='Waiting for recognized Quick Race screen';return {};
  }
  action(key,now,message){if(++this.attempts>12)return this.stop('Menu did not advance; manual input required');this.next=now+1200;this.message=message;return {key};}
}
const api=Object.freeze({Reader,Session,MODES,SCREENS});
if(typeof module!=='undefined'&&module.exports)module.exports=api;else Object.defineProperty(root,'__NFSU2_AUTONOMOUS_RACES__',{value:api,configurable:true});
})(globalThis);

# Quick Race session prototype

Status: working implementation against fixtures, not a validated gameplay feature. Do not describe this as completed autonomous career racing or package it as a supported release yet.

## What exists

The isolated candidate copies v0.30 and adds `extension/autonomous-races.js`, an optional UI/controller integration in `page.js`, and one script entry in `manifest.json`. Its version remains 0.30.0 because this is not a release. Native AI, Street X, Drag, Drift, corner, tuner, collision, NOS and saved-profile payloads are unchanged byte-for-byte. No changes were made to the v0.31 integration tree.

The experimental Start button is available only under the existing exact supported-module gate for revision 93af6ccb. Start additionally requires the solo Quick Race mode-selection screen with a recognized highlighted race-type item. Circuit, Sprint, Drag, Drift, URL and Street X item types are recognized. This only orchestrates existing native driving; it does not repair any native driver's performance.

The controller accepts current track/options/car screens, selects the automatic gearbox only on the exact native gearbox dialog, waits for loading/countdown, requests the existing native driver, recognizes a local racer's completion and shows results for eight seconds. If the game returns to the main menu after the known results Continue action, it finds the positively identified Quick Race item, chooses the same race type, moves right one track, and confirms that the accepted track actually changed before starting. It attempts at most ten completed races.

An unknown dialog/screen stops it. Known bounds are 12 attempts per menu, two minutes for setup/loading, 15 seconds without native AI acknowledgement while racing, and 20 minutes per race. F7/F9, manual keyboard/gamepad input, clicking the game, opening the extension controls, focus loss, hidden tab, pagehide, worker/module replacement or tuner conflict stop it without automatic resume. No held input is synthesized. At most one normal synthetic key tap is sent; an already published tap cannot be recalled.

The session is never saved to tool profiles or startup preferences. Other extension settings retain their existing scopes. There are no new permissions, requests, servers, account changes, save writes, progress edits, forced finishes, rewards, teleports or native code patches.

## Grounding

Local source mirror `research/upstream`, commit `16b2386`, is supporting documentation, not proof of a live run or a complete match to the target module. The extension's existing module hash gate remains mandatory.

- `runtime/career.c`, front-end helpers around lines 342–379: FEng global 0x8384c4, manager +8, active FNG lists +0xe4/+0xf4, FNGInfo next +4 and name +0xc. Bounded read-only traversal is used.
- `runtime/game.h`: flow 0x8654a4, game mode 0x850078, FE screen-manager list 0x8637b4, race coordinator 0x890118.
- `runtime/splitscreen_mem.h`: relocated local player count 0xd00030, local player pointer table 0xd00000.
- `runtime/splitscreen.c`, `split_count_bar`: common scroller option list at menu+0x50, selected option at +0x58; list nodes are option+4. Selection must be present in a bounded well-formed list.
- Original executable disassembly: UI_Main constructor 0x4df140 installs vtable 0x797510. Quick Race option constructed at 0x4aeead has vtable 0x790c30; its handler 0x4fc050 selects game mode 2 and the Quick Race screens. This avoids choosing an unverified main-menu item with Enter.
- Original executable disassembly: UI_QRModeSelect constructor 0x4e2a60 installs vtable 0x797734. Option vtables 0x790fd4/0x790fdc/0x790fe4/0x790fec/0x79100c/0x791004 map to Circuit 0, Sprint 1, Drag 2, Drift 3, URL 4, Street X 10. Their native handlers call 0x4b2c00 only on the button action. Consequently the selected item is inspected directly; the last accepted mode at 0x83aab4 is NOT used as a proxy for the highlighted icon.
- `runtime/quickrace.c`: accepted track at 0x83aab4+0x18+20*mode. The prototype compares it after accepting a track, not while merely highlighting the next track.
- `tests/scripts/quickrace.txt`, `pad_quickrace.txt`, `damage_quickrace_quit.txt`: documented mode → track → options → car → gearbox → loading screens. Scripts do not establish this prototype's end-to-end success.
- `runtime/mprace.c`: dialog descriptor fields at 0x838944/0x83894c and count 0x838968; dialog handle 0x838974. Original executable 0x497d50 constructs the gearbox question with message pair 0x5f5e3886 and 0x1a2826e1. Native handlers observed at 0x4eb325/0x4eb250 assign manual 1/automatic 0. No other generic question is answered.
- `runtime/career.c`: race +0xbd0 sorted racer entries, entry +0 car, +0x10 native completion. Exactly one entry must identify the current local car. Positive completion is counted as an ended race, NOT a win or evidence of driving quality.
- `runtime/mprace.c`, `step_racing`: Continue on `UI_PostRaceResults.fng` after a reading interval. This is evidence of that specific screen's normal input action, not proof of the entire Quick Race return path.
- `runtime/web/input_proto.h`, `input_web.c`, `keyboard.c`: the main-page event ring protocol v2, single-producer page ownership, KEY_TAP type 3. Native keyboard buffering retains down/up events between game polls. Only Enter/Left/Right taps exist in this implementation. Before publication the scene fingerprint is re-read; the ring must be empty, attached, active and not in text entry. This reduces stale input but does not make page reads atomic with the game thread.

## Blocking gaps

1. **Post-race completion flow is incomplete.** `UI_PostRace.fng` and tournament/reward intermediate screens have not had their exact selected Continue/Exit action mapped for solo Quick Race. The prototype deliberately stops there rather than guessing. Many actual runs may therefore need manual help after the first race. Map positive action identity and add regression tests before claiming a complete loop.
2. **Live browser/game verification has not run.** The local Chromium fixture cannot launch: socket() returns Operation not permitted, and Crash Reports settings are read-only. No manual install, screenshot, completed race, stability benchmark or successful menu-navigation test is claimed. In particular native key-tap processing and active FNG ordering need real verification.
3. **Career event travel/entry is not implemented.** Available career events and start-marker locations are documented, but no target-event navigation route for the existing free-roam AI has been demonstrated. The upstream career bot teleports and calls FinishRacer / edits Drift scores; it is a test fixture, not an acceptable implementation of legitimate racing. It is not used.
4. **Driver reliability remains the existing limitation.** Winning, completing every track, recovering after a crash, Drag success, and uninterrupted multi-hour streaming are not established. The v0.31 Drag fix must be integrated separately if and when this prototype becomes a release.
5. **Shared memory is observational, not atomic.** The page cannot revoke an input already consumed/published. A production-grade native command bridge could validate expected screen and selected object on the game thread before issuing actions. This prototype is intentionally not represented as that stronger guarantee.

## Checks

`node --test tests/autonomous-{races,page}.test.cjs` covers planner transitions, exact selection, read-only observations, typed modal whitelist, result counting, empty-mailbox guard, stale-state refusal, timeouts, stop latch and production-page integration.

`node --test tests/*.test.cjs` is the aggregate regression command. Latest results are in `verification/all-tests.txt`; `verification/preservation.json` records unchanged native assets, and `verification/browser.txt` records the launch blocker. No game-derived binary is included in the extension source directory.

## Merge guidance

Do not overwrite `combined-v031-integration`. Cherry-pick only the authored `autonomous-races.js` and deliberate `page.js`/manifest changes after independent review, retaining the newer Drag integration. Re-run all regression and live tests against that merged code. Assign a new release version consistently only after the remaining flow has been implemented and honestly scoped. Use the fixed-folder update packaging builder only for the reviewed final source, not this partial candidate.

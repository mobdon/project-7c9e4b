'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),os=require('node:os'),{spawnSync}=require('node:child_process');
test('v0.30 combined Drag tuner online package includes referenced docs and refuses to overwrite existing archives',()=>{
 const root=path.resolve(__dirname,'..'),tmp=fs.mkdtempSync(path.join(os.tmpdir(),'combined-release-')),out=path.join(tmp,'release.zip');
 try{
  const manifest=JSON.parse(fs.readFileSync(path.join(root,'extension/manifest.json'),'utf8'));assert.equal(manifest.version,'0.30.0');
  const source=fs.readFileSync(path.join(root,'tools/package-release.py'),'utf8');assert.match(source,/NFSU2-Driving-Tools-v0\.30-Combined-Info-HUD\.zip/);assert.doesNotMatch(source,/v0\.13-Current-Build\.zip/);
  const run=()=>spawnSync('python3',[path.join(root,'tools/package-release.py'),'--output',out],{encoding:'utf8'});
  const first=run();assert.equal(first.status,0,first.stderr);const report=JSON.parse(first.stdout);assert.ok(report.files.includes('CHANGELOG.md'));assert.ok(report.files.includes('README.md'));
  const bytes=fs.readFileSync(out),second=run();assert.notEqual(second.status,0);assert.deepEqual(fs.readFileSync(out),bytes);
  const readme=fs.readFileSync(path.join(root,'extension/README.md'),'utf8');assert.match(readme,/CHANGELOG\.md/);assert.doesNotMatch(readme,/DYNO-RACE-FIX\.md/);
 }finally{fs.rmSync(tmp,{recursive:true,force:true});}
});

test('combined release retains all existing scripts and consistent version metadata',()=>{
 const root=path.resolve(__dirname,'..'),read=f=>fs.readFileSync(path.join(root,'extension',f),'utf8');
 const manifest=JSON.parse(read('manifest.json'));
 assert.deepEqual(manifest.content_scripts[0].js,['diagnostics.js','walls.js','cars.js','current-profile.js','latest-profile.js','next-profile.js','signatures.js','signature-profile.js','signature-profile-latest.js','signature-profile-next.js','dyno-native-profile.js','dyno-native.js','ai.js','core.js','dyno-core.js','dyno.js','dyno-evaluator.js','dyno-full.js','tool-profiles.js','autonomous-races.js','page.js']);
 assert.equal(manifest.version,'0.30.0');assert.match(read('page.js'),/version:'0\.30\.0'/);assert.match(read('page.js'),/class="version">0\.30\.0</);assert.match(read('popup.html'),/class="version">v0\.30\.0</);assert.match(read('diagnostics.js'),/version='0\.30\.0'/);
 assert.match(read('page.js'),/id="dyno-mode"/);assert.match(read('page.js'),/id="corner-margin"/);assert.match(read('page.js'),/id="diagnostic-export"/);assert.match(read('page.js'),/id="tester"/);
});


test('candidate archive uses canonical metadata and reproduces byte-for-byte',()=>{
 const root=path.resolve(__dirname,'..'),tmp=fs.mkdtempSync(path.join(os.tmpdir(),'reproducible-release-'));
 try{
  const outputs=['one.zip','two.zip'].map(n=>path.join(tmp,n));
  for(const out of outputs){const run=spawnSync('python3',[path.join(root,'tools/package-release.py'),'--output',out],{encoding:'utf8'});assert.equal(run.status,0,run.stderr);}
  assert.deepEqual(fs.readFileSync(outputs[0]),fs.readFileSync(outputs[1]));
  const inspect=spawnSync('python3',['-c','import sys,zipfile; z=zipfile.ZipFile(sys.argv[1]); assert all(i.date_time==(1980,1,1,0,0,0) and i.create_system==3 and i.external_attr>>16==0o100644 for i in z.infolist())',outputs[0]],{encoding:'utf8'});assert.equal(inspect.status,0,inspect.stderr);
 }finally{fs.rmSync(tmp,{recursive:true,force:true});}
});

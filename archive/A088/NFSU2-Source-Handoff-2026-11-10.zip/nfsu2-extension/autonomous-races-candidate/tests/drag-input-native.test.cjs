'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),path=require('node:path'),{spawnSync}=require('node:child_process');
test('production Drag input lease survives exact native Player updates and preserves native mode5 replacement',()=>{
 const run=spawnSync(process.execPath,[path.resolve(__dirname,'../research/drag-input-handoff-v018/probe-native-input.cjs')],{encoding:'utf8',maxBuffer:1024*1024,env:{...process.env,NFSU2_EXTENSION_ROOT:path.resolve(__dirname,'..')}});
 assert.equal(run.status,0,run.stderr);const report=JSON.parse(run.stdout);
 assert.equal(report.retainedPlayerUpdates,180);assert.equal(report.productionBridgeNativeCycles,180);assert(report.rejectedGuardsWithByteExactNativeFallback>=32);
 const replacement=report.handbackChecks.find(x=>x.name==='actualNative4To5ReplacementPreserved');assert.deepEqual(replacement.state,{driver:3,physics:3,mode:5,requested:5});
 assert.equal(report.handbackChecks.find(x=>x.name==='interveningSkillPreserved').skill,6);
});

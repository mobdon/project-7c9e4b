# NFSU2 source and unfinished-work handoff

This is a development source handoff, not a new extension release or installation. Extract the ZIP to a short writable local path, then open this `nfsu2-extension` folder in Codex. The original cloud source was `/workspace/scratch/0d6b822176fd/nfsu2-extension`; that path is not automatically available on a different computer. Work from the extracted folder.

## Start here

- `combined-v033-integration/`: frozen v0.33.0 baseline. Full extension source, test files, authored test WASM, tools, integration documents and verification records are included.
- `research/race-geometry-capture/`: route geometry research and its isolated recording candidate. Read `candidate/README.md` and `candidate/extension/RACE-CAPTURE.md`. This is not a complete map or proven all-corners solution.
- `tuner-s42-window-candidate/`: isolated S42 high-guest-window compatibility candidate. Read `integration/tuner-s42-window/HANDOFF.md` and `research/tuner-s42-proof/FINDINGS.md`. Independent review and live S42 retest remain outstanding in the copied handoff.
- `drift-line-telemetry-v034-candidate/`: reviewed read-only diagnostic additions. Read `integration/drift-line/HANDOFF.md`. It is not a driving fix.
- `owned-navigation-v034-work/`: most recent owned-navigation development tree. Begin with `integration/TRAVEL-WORK-IN-PROGRESS.md`, `integration/NAVIGATION-ABI.md`, `integration/DESTINATION-PROOF.md` and the source/tests. Earlier copied handoffs describe earlier checkpoints and are not authoritative over newer source or evidence.
- `hosted-city-v034-candidate/`, `hosted-full-v033-candidate/`, `hosted-travel-v033-candidate/`, `hosted-events-v033-candidate/`, `hosted-race-selector-prototype/`, `autonomous-races-candidate/`: separate experimental checkpoints, not one merged release. Some intentionally retain 0.32.0 or 0.33.0 labels. Do not overwrite the v0.33 baseline or combine candidates blindly.
- `research/`: route/GPS/parking/topology fixtures, event-catalog evidence, tuner proof notes, drift findings and historical handoffs.
- `fixed-folder-updates/`: established desktop-folder update tooling and instructions.

## Portable setup and test limits

Node.js and Python 3 are required. The original WABT dependency was `wabt@1.0.39`; third-party dependency folders are excluded. Some build scripts support `WABT_MODULE`. Others expect the package in `research/compatibility-v011/node_modules/wabt` relative to their project. Install dependencies locally only when needed, for example from the extracted root:

    npm install --prefix research/compatibility-v011 wabt@1.0.39
    python prepare-research.py combined-v033-integration

The original projects used a `research -> ../research` link. Links are excluded for Windows portability. `prepare-research.py PROJECT` copies the curated research folder into one selected project without replacing existing files. This may copy the installed WABT dependency too. Use a short extraction path if Windows path limits apply.

From the baseline folder, a useful self-contained smoke test is:

    node --test tests/core.test.cjs tests/package-release.test.cjs

All test sources are provided, but the complete native test suite cannot run from this ZIP alone. Exact-native tests and some builders require original game modules, native extracts or other artifacts intentionally omitted. Old absolute paths in research scripts/reproduction logs must be reviewed and redirected to local inputs. Historical pass counts describe their original run, not a fresh run on your computer.

## Scope and integrity

No original full game WASM, game asset/data files, raw native research extracts, credentials, dependency folders, screenshots, copied upstream checkout, caches or old release ZIPs are included. Authored hook bodies and small authored test fixtures are retained so the extension sources are complete. Selected research evidence includes metadata/inventories, not game assets. Large generated logs and duplicate historical integration outputs in candidates are omitted. The full shared research directory was approximately 3.8 GB and was deliberately not copied.

`SOURCE-MANIFEST.json` lists SHA-256 and size for every copied source file. Handoff-only README/setup/manifest files are additional. Source files were copied without editing. Packaging did not change live source, install anything, contact a game server, join a race, test a live finish/win, or establish saved-game persistence. Offline/synthetic results must not be described as live proof. Review each candidate and preserve existing features before merging or shipping.

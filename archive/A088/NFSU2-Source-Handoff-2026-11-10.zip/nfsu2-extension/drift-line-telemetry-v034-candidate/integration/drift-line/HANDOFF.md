# Drift line diagnostics handoff

Candidate: `drift-line-telemetry-v034-candidate`, based on frozen `combined-v033-integration`. Version remains 0.33.0. No release bump, installation or deployment.

Patch: `integration/drift-line/drift-line-telemetry.patch`
SHA-256: `621106dac16800c7a1503ecc4c46588d27d536c80b1ebcfe9a5cf4d0a2c48ad2`
`git apply --check` passes against combined-v033-integration.

Four changed files: extension/core.js, extension/diagnostics.js, extension/README.md, tests/drift-line-diagnostics.test.cjs. All 215 other extension/tools/tests files are unchanged in preservation.json. Native payloads, controllers, road/Street X, current power/tuner, scores and driving behavior are unchanged.

The additions are read-only bounded scalar telemetry for a verified native Drift behavior: signed route count/fallback, relative XY target/distance, XY velocity, heading units, and explicitly retained (potentially stale) control slip. No pointers or absolute map coordinates exported. Existing two-second moving sample cadence is preserved. Route-fallback transitions can log sooner. Samples are not frame-coherent and cannot establish wall clearance or catch every brief control cut.

Validation:
- Focused 59 tests passed, including 24 new cases.
- Full suite 1,966 passed, zero failed/cancelled/skipped (full-suite.txt).
- Independent review /root/investigate_drift_ai/review_drift_line_telemetry: no blockers; 301 regression tests passed and 13 additional boundary/mode probes passed, both syntax checks passed. Reviewer made no edits.
- Reviewed core.js SHA cc61eec235faafbb2ebda6f9458cffbb36074a3143cb5cf1f32c5cb72daa1d79; diagnostics.js SHA b14b265e93e72a8bc4471be5f3970c85acc6862b3333832307514e9cff630c18.

Related investigation: `research/drift-line-momentum-v033/FINDINGS.md`. A new exact-native 9,000-tick static-pose probe confirms conditional throttle reduction and handbrake use, not the cause of the user's run. No new Drift throttle floor/lookahead option is implemented. A fresh Drift log is needed to choose the correct intervention; the prior six corner exports were ordinary road races. An export immediately after a failed Drift corner with current settings is useful before changing the test condition. A short clip may be needed because two-second scalar snapshots can miss transient events.

Do not present this as a driving improvement, solved wall impacts, or verified race result. Keep unverified control changes separate and opt-in if future evidence supports one. Do not package research/native bytes or extracts.

# NFSU2 Driving Tools: experimental v0.33.0

Unpacked Chrome / Edge / Brave extension for https://nfsu2.xyz/. See `CHANGELOG.md` for this release's changes and verification limits.

## v0.33.0: Continuous adaptive corner targets

Adaptive road-race speed now has a separate native planning command. Every valid sampled nonzero bend receives a smooth curvature-based target, instead of requiring it to cross the older curvature threshold. Exact straights keep the requested target ceiling; existing native lower/stop results are never increased. The native distance-based braking calculation uses the same pace compensation.

The curve is deliberately conservative and experimental. It does not detect every corner on the map: the native planner may provide no corner records, skip a tail record, report zero curvature or use another route. It does not change steering, physical brakes, route lookahead, NOS or other cars. A hook hit is an observation of a past call, not proof the current corner is safe. Five fresh captures show hook hits despite reported missed turns, so the update is not presented as a proven fix for every failure.

Only adaptive road mode uses this new command. **Street X and existing free-roam/road-corner controls retain their exact prior behavior.** The new command also denies actual/forced Street X and known online Street X in its native guards. AI ownership, native handback, online permission, mode checks and watchdog remain required. This does not bypass an AI failure or acquire control automatically.

The option remains default-off/session-only and uses your current sliders without changing saved values. For the first comparison, try the existing defaults: 1.30× adaptive ceiling, 0.80 corner factor and 0.75 braking factor. Higher targets can still cause missed turns. The latest logs used 1.90×, 0.95 and 1.00 respectively; those settings were confirmed, not shown to be safe. Keep the working Street X setup unchanged.

Corner/braking hit counters now use the existing two-second telemetry sample cadence instead of replacing bounded history every quarter second. Discrete control/mode changes still log promptly. No raw route geometry, memory dump or additional personal data is collected.

Native tests execute the new corner and braking hooks against the pinned game routines, compare legacy commands byte-for-byte, and check protected outputs and guard denials. Live cornering, race results and browser rendering remain unverified. The final combined suite passes **1,942 tests, zero failures/skips/cancellations**. All four supported patched modules compile, with only the two reviewed corner/braking wrapper functions changed from v0.32.

## Retained v0.32.0: Race-only automatic driver

In **AI driver**, enable **Race-only automatic driver** to arm the native driver for races you start or join yourself. It waits for the active race/GO state, includes Street X, Drag and Drift, and requests handback in free roam, outrun, results or other ineligible contexts. It does not find, join, start, replay or vote for events.

The existing **Automatic driver** still includes free roam. Selecting either driver mode turns the other off. The race-only switch is **off by default**, stays armed between races on this page, and resets on page reload or profile Load. It is deliberately not added to saved profiles; existing saved choices and storage remain unchanged.

**F7, F9/Stop, or driving-key takeover during a race disarms race-only AI.** Manual steering in free roam leaves it armed. If driving controls are still physically held when entering a race, acquisition waits until they are released. Turning the switch off requests native handback. A genuine native manual request, finished/totaled state, failed-control latch or watchdog is not forced back to AI.

Online races still need the existing **Allow network tools** permission. Exact build, current ownership, race, focus/menu, native driver and handback guards are retained. A selected switch is not proof of active ownership; the HUD and local log show the effective request and native observations separately.

Optional **Adaptive road-race speed** is also included below. It remains off by default and leaves Street X unchanged. Neither option changes steering, shifting, NOS or game saves. Live race efficacy and browser appearance remain unverified.

**Historical v0.32 verification:** that release passed **1,907 automated tests, zero failures/skips/cancellations**, including race-only eligibility/lifecycle, optional adaptive mode, joint Street X/online/stop behavior and all retained features. Independent tests additionally cover production native handback and cached-route reconstruction. At v0.32, all four supported patched game module outputs were byte-identical to v0.31; v0.33 changes only the two planner wrappers described above.

For an existing installation, replace matching files in the already loaded extension folder, click **Reload** on that extension's browser card, then refresh the game. Verify **0.33.0**. Do not remove/re-add the extension or create a different folder just for this update.

## Optional adaptive road-race speed

A new **default-off, session-only** option coordinates the existing native route planner. Its separate straight-target ceiling defaults to **1.30×** and ranges from 1.00× to 2.00×. The native route uses distance to known corners to lower its target in advance while retaining a higher target on sufficiently long straights. This is a planned target factor, not a physical speed cap or a measured speed increase.

Enable either **Race-only automatic driver** or **Automatic driver**, then **Adaptive road-race speed** in AI driver → Road-race settings. Online use also requires **Allow network tools**. Adaptive mode uses the existing Race corner speed, Race sharp-turn margin and Race braking factor values, even when the separate Road-race hairpin assist switch is off. Lower braking factor requests earlier braking. It overrides the effective custom race pace only in eligible ordinary road races, without changing any saved switch or slider.

**Street X keeps the exact existing pace, corner and braking selections.** Adaptive mode is dormant in actual/forced Street X and the known online Street X mode. Drag, Drift/forced variants, Outrun and free roam are also excluded. Selecting adaptive mode does not turn on Automatic driver or network permission.

The optional ceiling stays constant while driving. The existing native route envelope varies by distance; JavaScript does not switch pace or reconstruct the driver at every corner. A deliberate setting or race-mode change may still require the existing OFF/acknowledgement/ON route reconstruction. Manual takeover, race end, permission withdrawal and the existing watchdog remain in force.

F7/manual driving keys stop AI and leave the optional selection dormant. F9/Stop, profile Load and page reload turn adaptive mode off. It is not added to saved tool profiles or legacy session preferences. Blur, hidden page and menus pause it normally. Turn it off to return to the prior controls after native handoff.

The HUD and local log distinguish a request, matching native pace acknowledgement, and observed corner/braking hook evidence. These counters do not measure braking success, safe corner entry or a clean lap. There is no new steering, obstacle avoidance, NOS control, added route horizon, opponent manipulation or collision protection. Higher targets can still cause crashes. Start at 1.30× and assess one change at a time.

The original v0.32 option used page orchestration only. The v0.33 continuous-corner update changes the two native planner wrappers and teaches the controller a separate adaptive command. Existing planner commands retain their prior behavior; engine tuning, NOS, Drag-retention, tuner and saved-profile implementations are untouched. Exact-native synthetic tests support the route-speed envelope; live racing, lap times, wins and browser layout remain unverified.

## Retained v0.31.0: Keep owned Drag AI through settings refreshes

A reproduced publication race could let the game's manual-Drag selector run while the extension refreshed the same active settings. The new guard retains an **already-owned, currently permitted native Drag AI lease** through that brief write. It does not acquire new control, force a real manual request back to AI, or change steering, shifting, NOS or damage.

A separate fix ensures a pause/end/OFF command is acknowledged by the native game before a quick restart can overwrite it. This also covers consecutive matches that reuse the same player, car and race objects. It does not clear the game's failed-control latch while AI remains continuously requested.

**F7/manual takeover, F9/OFF, native finish/totaled states, permission withdrawal, identity changes and the 180-native-frame watchdog remain effective.** Do not use this as a no-crash, no-damage or guaranteed-win feature. Online use still requires the existing explicit Allow network tools opt-in.

The fresh user log shows a request for manual Drag before the observed handback, matching the reproduced ordering. It does not record the rejecting guard, so this is not proof of that run's exact cause. The log came from v0.28. Live handoff prevention remains unverified.

Only the Drag input guard changes in the two supported modern native profiles. The HUD, tuner/static-ride fix, NOS clock correction, working Street X behavior, Drift isolation, saved profiles, collision/corner settings and engine-blowout protection remain combined. No unrelated lane candidate or unverified grip/downforce activation is included.

**Verification:** the final combined suite passes 1,873 tests with no failures/skips/cancellations. Exact-native tests exercise retained ownership, real manual requests, OFF acknowledgement and watchdog release; the menu shortcut has five focused tests, including closed-shadow paste behavior. Browser appearance and live race efficacy remain unverified.

**Shift+Insert** now toggles the full tools menu, alongside F8. It does not intercept Paste while typing in text/editable controls. Holding the shortcut does not repeatedly toggle it. Closing follows the same existing menu behavior, including cancelling a running tuner operation.

Reload after enabling only v0.31 and verify the **0.31.0** badge. Keep your chosen settings; start the race yourself. If the unwanted handback persists, export a short new crash log immediately after it occurs.

## Retained v0.30.0: Compact driving information HUD

A small, click-through **Info HUD** appears below the upper-right launcher while the tools menu is closed. **F6** toggles it, or open **F8 → Info HUD**. It starts on and remembers only its display choice in this tab, separately from driving-tool profiles. Opening the menu hides the card until you close it. F7 returns control and F9 still stops driving assists; the HUD itself never enables them.

- **Speed:** existing guarded native speed converted to **km/h**. Zero is shown only when sampled as zero. Unknown builds, invalid car data and paused/missing samples show **Unavailable**, never a guessed or multiplied speed. Older supported builds without verified speed telemetry also show Unavailable.
- **Driver:** observed native AI/manual state, pending handoff, or the reason tools are waiting/paused. A selected AI switch is not called active by itself.
- **Pace:** `req` is the current requested AI target factor; `ack` is a matching native acknowledgement, not measured vehicle speed. A newly selected factor does not reuse an old acknowledgement. Selected pace waits for AI; Drag and Drift retain native pace.
- **Power:** `req` is the selected field multiplier; `set` reports guarded power-field application. It is not measured horsepower or a guaranteed speed increase. Paused, rejected and settling states stay distinct from application.

The HUD is read-only and uses existing observations. Stop, manual takeover, blur, hidden tab, game exit, replacement boot and tuner suspension clear old display evidence. No new physics, AI, speed/power formula, native hook, network permission, tuning, game-save or profile-schema change is included. The complete v0.29 tuner/static-ride fix, online NOS correction, Street X, Drift, Drag and online tools remain together.

**Verification:** 1,788 automated tests pass with no failures/skips/cancellations, including 20 focused HUD tests. A strict-CSP browser fixture is included, but Chromium could not launch because this environment disallowed its local process socket, including the elevated retry. Browser layout/fullscreen behavior and live game appearance remain unverified. No screenshot is presented as actual gameplay.

## Retained v0.29.0: Accept verified native car records in the tuner

The S20 report exposed an incorrect assumption: active car data is not always heap-allocated. The native game also embeds it in its fixed racer-record array. The tuner now accepts those exact native slots **only when the current car, record kind, active record count, race table and ride pointer all agree**. Arbitrary low addresses remain rejected; the existing heap path and all other safety checks remain.

Tests capture all 22 native slots and verify selected-preset-only Stage/Restore across all five modes, including the first and last slots. Native private preview/search matches heap-backed fixtures. The private evaluator permits writes only to the exact ride/curve regions, not neighboring racers or the rest of the copied image. No game save is performed by the extension.

This fixes a proven rejection of valid native car storage. **The user's live capture has not yet been retested.** Reload with only v0.29 enabled, verify 0.29.0, then retry Load settings on the solo Performance Tuning main screen. If another check fails, retain its S-code or export the crash log; later layout protections have not been removed.

The power panel also reports whether power fields were applied, are settling, or are blocked by a specific guard. Exported pace acknowledgement is separate from power application. These are observations, **not a measured speed increase**; no speed, power, driver or network setting is changed by this status addition.

The final v0.29 suite passes **1,768 tests, zero failures/skips/cancellations**. Independent checks cover all 22 native slots, selected Stage/Restore in all five presets, private write boundaries, and unchanged driving code. Power/pace confirmation also clears on stop, online opt-out, game exit, tuner suspension and replacement game sessions.

The online NOS clock correction, working Street X behavior, Drift isolation, profiles, Drag protection and online collision/corner controls remain combined. No unrelated Drag lane candidate or unverified grip/downforce scaling is included. Live driving results and game-save persistence remain unverified.

## Retained v0.28.0: Correct the online Unlimited NOS clock

Unlimited NOS now refreshes an already-active NOS timestamp using the same clock the native game selected. The previous version always used the world clock; in an online fixture where the game's real clock was ahead, that made a full kit immediately appear depleted and caused repeated native stop/restart cycles. The corrected code retains the burst in that exact native test.

This is a reproduced timing defect, **not proof of the clock values in your live run or a guarantee that NOS never stops**. Native AI can still cancel NOS for normal driving decisions. This update does not hold Alt, force activation, suppress native stops or change driving, shifting, steering or lane choice. Inactive and sentinel timestamps remain inactive; network permission and current-car/kit checks remain mandatory.

For an online comparison, use the same ordinary driving situation with **Unlimited NOS** and **Allow network tools** enabled. If tapping remains, use **Export crash log** immediately. The new log samples the selected clock, active-since stamp and kit/resource accounting **before refill**; it contains no pointers. The timestamp flag does not prove successful activation, and sampled logs can miss short transitions.

The v0.28 combined suite passed **1,740 tests, zero failures/skips/cancellations**. Saved tool profiles, working Street X behavior, reviewed Drift isolation, Drag protection, online collision/corner settings and the full tuner with snapshot diagnostics remain together. No native game code or profile was changed. v0.28 did not change tuner capture. The v0.29 native-record correction is described above; any remaining rejection still needs its S-code/log. Live NOS behavior and game-save persistence remain unverified.

## Retained v0.27.0: Identify rejected tuner snapshots

This update replaces the generic “Full tuner snapshot layout is unsupported” message with a specific **S-code and component** when the native capture guard rejects a snapshot. The local diagnostic export records only the bounded failure code and applicable counts, never raw pointers or a memory dump. Details are reset for each request so a previous failure is not shown as a new one.

**This is a diagnostic update, not a confirmed fix for the reported capture failure.** The screenshot establishes that a layout guard rejected the capture, but does not identify which guard or justify weakening it. All existing pointer, ownership, overlap, count, selected-preset and stale-state checks remain. Stage/Restore and game saving are unchanged.

After installing, open the solo Performance Tuning main screen and repeat the failed **Load settings** or **Find tune** once. If it fails, retain the complete S-code/message and use **Export crash log** immediately afterward. Buffer/ownership failures ask for a game reload; other layout failures ask for the diagnostic log. A timeout still means the outcome may be uncertain and requires reloading before retrying.

The combined suite passes **1,708 tests, zero failures/skips/cancellations**, with **49 independent diagnostic checks**. The reviewed Drift isolation, saved tool profiles, Street X behavior, online road-race/collision features and Drag protection are retained. No live gameplay, successful capture on the user's car, or disk-save persistence is claimed.

## Retained v0.26.0: Keep custom road settings out of Drift

On exact **93af6ccb** and **78e2bb69**, custom road/free-roam pace now pauses during native Drift modes. The extension preserves the game's own pace factor instead of multiplying it by a saved road pace setting. Your selected switches and numbers remain saved and resume outside Drift. The UI shows “Paused in Drift”; an earlier road pace hit is not reported as current Drift confirmation.

Extra grip also pauses for the additional native Drift variant flag that was previously missed. Its existing ownership and restoration guards remain. Native Drag precedence is retained. The diagnostic log now includes a bounded, read-only native pace-factor observation to help compare runs.

These are two reproduced setting interactions, **not a proven fix for every poor Drift run**. No new steering, throttle, shifting, NOS behavior, score multiplier, opponent logic, recovery curve or race tune is introduced. Engine power and your actual car tune remain selected and can still affect handling. Native grip/downforce scaling remains unverified and disabled.

Saved tool profiles, full preset tuning, online road-race/collision controls and Drag blowout protection remain combined. The combined suite passes **1,698 tests, zero failures/skips/cancellations**. No live Drift run, score improvement, browser installation or game-save persistence is claimed. For a useful comparison, use the same car, track and tune; export a short diagnostic log after a run that reproduces the problem.

## Retained v0.25.0: Saved extension settings profiles

**Saved tool profiles** saves named groups of extension settings in this browser for this game site. Save your current choices, then load them together instead of enabling each tool separately. Update replaces the selected saved configuration; Delete removes it. These profiles are separate from the game's race tuning presets and **Save Profile**. They contain no car setup, game save, dyno draft or diagnostic log.

Automatic loading after reload is **optional and off by default**. Select it explicitly for a saved configuration if you want that configuration to return next time. Network permission has a separate saved-profile opt-in: saved choices do not silently grant Online/LAN access. Read the network warning before permitting automatic network-enabled behavior. Each tool still requires the supported build, valid current car and its normal game-mode checks.

**F9 / Stop keeps saved profiles but pauses automatic loading persistently**, as well as clearing current driving/network choices. A later reload cannot silently undo Stop. Resume deliberately from the profile controls. Saving a profile does not itself enable its settings. Changes from another tab do not automatically activate a configuration in an already-open tab.

Profile loading stops the old controllers and releases synthetic input before changing selections. It does not roll back a staged game tune or save the game. If storage is unavailable or full, the UI reports that the profile was not saved. Profiles stay in this browser; clearing this site's storage removes them, and site scripts can access this storage. Up to 16 profiles and 48 characters per name are supported. Browser-managed locking prevents concurrent tabs from overwriting each other's saves; if locking is unavailable, profile editing is disabled while manual loading remains available.

Saved Drag blowout protection retains its narrow meaning: only the current eligible local engine is protected before it blows; online use also needs network permission. It does not revive an already-blown engine, alter NOS/shifting, or promise a race win. Existing controls keep their normal fresh-page defaults unless you explicitly enable a saved startup profile. Descriptions below that say a control starts off refer to those defaults.

No native AI, Street X, tuning, heat, corner/braking or collision payload was changed for settings profiles. The final suite passes 1,688 tests, with another 44 independent profile checks. A local Chromium fixture could not launch because this environment denied socket creation, so browser appearance and automatic loading in the user's game remain unverified.

## Retained v0.24.0: Opted-in online Drag engine blowout protection

For **online or LAN Drag**, enable both **Drag racing → Disable Drag engine blowouts** and **Online / LAN opt-in → Allow network tools** before the engine blows. Solo Drag needs only the blowout toggle. Exact **93af6ccb** and **78e2bb69** builds are supported. The heat toggle works independently of Automatic driver and Manual drag assist. It starts off for a fresh tab, remembers your choice in the same tab, and F9 clears it. Network permission starts off after reload and F9.

Only the current linked local player's engine is eligible, during active Drag with full physics. Opponent, stale, unowned, invalid and already-blown engines remain excluded. This is local protection, not a change to remote engines, network packets or server rules. Follow server rules; online changes can trigger integrity checks or sanctions.

Enable it **before** the engine blows. It does not repair an already-blown engine or reverse a lost race. While enabled it supplies the game's own disabled-heat sentinel, intentionally discarding accumulated heat. Turning it off resumes normal heating from zero after the next native full-physics setup. It does not change shifts, throttle, steering, pace, power, torque, limiter, NOS decisions or opponents, and does not trigger an AI restart.

The exact native heat routine and its original instructions remain intact. An authored prefix checks active Drag, current player/car/race/engine identity, full physics, finite unblown heat, permission epoch and heartbeat before changing only the current engine's heat field. Online/LAN additionally requires literal network permission. Added diagnostics show bounded heat/blown/limit observations and the requested toggle.

Controlled native tests cover 600 online over-redline updates on each supported module, low and high runtime CPU addresses, opt-out restoring native heating and rejected ownership/stale states. This is **not live online verification**. A fresh race must still confirm the guard is eligible and the engine remains protected; a selected checkbox alone does not prove activation. No successful live Drag race, HUD appearance or win is claimed. Repeated native NOS cycling is unchanged.

This stays combined with the complete preset tuner, opted-in online corner/braking settings and local online race-car filtering. Solo/Street X driving formulas remain unchanged. No Lap Knockout experiment or unverified native grip/downforce multiplier is enabled.

## Retained v0.22.0: Local online race car contacts

On exact **93af6ccb**, **Online player / race no-clip** can also filter local contacts with confirmed participants in a running Online/LAN race. Enable **Allow network tools** and this separate player/race switch. Both reset off on reload/F9. The active race roster must contain the local and contacted cars exactly once, with reciprocal record and body identity; malformed pointers, stale identities, invalid counts and missing/duplicate membership of either contacted car are rejected.

This skips contacts in this browser only. It does not change the remote player's simulation, packets, server rules or Ghost setting, and does not promise both players see collision-free overlap. Walls, props and traffic remain separate. Older supported builds keep free-roam player filtering only. The UI says “Armed” until actual native contact counters confirm a local filtered contact.

The complete preset tuner and opted-in online corner/braking parity remain combined. The contact builder now preserves the full tuner's main-loop prefix and refuses an unexpected base-bridge change. Street X and solo driving formulas remain unchanged. The new Drag heat-only toggle is described above; no Lap Knockout experiment or unverified grip/downforce activation is included.

No live multiplayer, peer synchronization, server acceptance, browser appearance or user save/reload result is claimed. Native grip/downforce multipliers remain unverified and disabled.

## Retained v0.21.0: Matching solo and opted-in online road-race settings

This combined candidate retains the full v0.20 preset tuner. Selected road-race corner speed, sharp-turn margin and braking factor can now apply online/LAN under the existing **Allow network tools** opt-in, matching the selected solo settings for the extension-owned local AI car. Both the road-race assist and network permission start off after reload/Stop. Street X and all solo numerical formulas remain unchanged.

This fixes a proven routing mismatch where online race pace could remain active while corner/braking assistance was disabled. It is not a proven explanation for every collision or a verified online race improvement. Native route/car ownership and safety checks remain. Drag, Drift, Outrun, free-roam behavior, collision-control scope and grip/downforce activation are unchanged. No Lap Knockout experiment is included.

This retained corner/braking patch does not establish improved live cornering. Follow server rules; peer synchronization and server acceptance have not been tested.

## Retained v0.20.0: Full per-preset editor and isolated native preview

- On exact **93af6ccb**, edit all **41 native tuning fields** for the game's five selected race presets: suspension, gearing, nitrous, brakes, tires, downforce, ECU and turbo. Installed-part and native eligibility checks disable unavailable controls. The native setter may couple controls; preview shows the accepted result before you stage it.
- Preview rebuilds and measures a private copy using native game code with bounded execution and guarded memory. It does not temporarily tune your live car. Measurements include native 0–60 and 0–100 estimates, top-speed estimate, peak power and torque, plus native nitrous duration/torque settings.
- Automatic search is limited to measured objectives: peak power/torque searches ECU/turbo; acceleration/top speed searches gearing plus ECU/turbo. Suspension, brakes, tires, downforce and nitrous are manual controls, **not automatic handling or fastest-lap optimization**. Each search uses at most 48 trials and is not a global optimum.
- **Stage selected preset** changes only the current working tune and that preset's visit copy after a game-thread identity/staleness check. **Restore previous** restores both original copies separately. The game must run its native **Test Run** to refresh driving physics, and you must use **Save Profile** for persistence. This extension does not confirm a disk save.
- Retains v0.18 AI and Street X behavior. Adds read-only corner-status clarification without changing corner physics. Unverified native grip/downforce scaling is not activated. Older supported game builds retain the earlier ECU/turbo dyno tool.

Back up your save first. Preview, stage/restore and failure paths have isolated automated coverage; live gameplay, browser appearance and save/reload persistence have not been verified. The private evaluator uses additional WebAssembly memory and may be unavailable on memory-constrained browsers. Failure leaves the full tuner unavailable rather than falling back to live native tuning.

## Retained v0.18.0: Drag input handoff and road-race hairpin controls

- **Native Drag input handoff, exact 93af6ccb and 78e2bb69:** Automatic driver now enters the native AutoPilot input mode, preserving the owned driver across the verified native Player update and input reconciliation. A narrowly guarded native manual-Drag selector prefix prevents that selector from immediately taking control back. Actual Drag and full driving physics after GO are required. If the game changes control mode, the extension releases its lease and tells you to turn Automatic AI off, then on to retry. It does not fight the new mode or reset a replacement controller.
- **Independent Road-race hairpin assist:** off by default, separate from free-roam corner assist and race pace. This changes the native private-route corner cap and planning braking assumption while retaining the selected straight-line pace. The same selected settings apply to ordinary road races in solo and explicitly opted-in Online/LAN play, only for the extension-owned local AI car and its validated private route. Outrun, Drag, Drift and forced Drag/Drift remain excluded. Online/LAN still requires Allow network tools, which starts off after reload. Native network state, server rules, other cars and collision controls are not changed. Online cornering and synchronization are unverified. No new steering, route horizon, grip or nitro behavior is added.
- **More useful local diagnostics:** actual skill, current/requested native input mode, native controls and bounded pointer-presence/validity observations join the existing Drift and corner fields. Raw addresses are never exported; validity flags show readable bounds, not proven object/route semantics. The export header now identifies the exporting extension version. Sampling remains bounded, so export promptly after a short test.

Existing online AI permission now also permits selected road-race corner/braking assistance. NPC traffic filtering remains free-roam-only. Current-build player/race filtering additionally has the guarded local race scope described above. **No native 10× grip or downforce feature is included**; the existing Grip control is unchanged. Keep v0.17 for rollback and start with normal 1× pace and power/grip off.

**Limits:** no live driving or race benchmark has been run. The Drag repair proves bounded native input/ownership retention, not a complete AI action graph, ideal launch, shifts, lanes or finish. Force-only/special Drag is unsupported. Native skill/tactical/NOS resource conditions remain. Hairpin assistance is experimental and may still miss turns or fail to brake early enough; native route horizon and degenerate geometry remain limitations. This is not full opponent equivalence, a freeze fix or a promise of wins.

## Retained v0.17 native Drift recovery

The v0.17 recovery changes remain together in this build. On exact **93af6ccb** and **78e2bb69**, the existing **Automatic driver** switch also enables a guarded native Drift recovery path when the extension owns the car and the game's Drift behavior, full physics, aliases, race state, permissions and heartbeat all agree. There is no extra driver or manual steering script.

The change selects the game's existing opponent yaw-damping curve at one native physics expression. It retains the current car's native coefficient, sign/gear conditions and all subsequent native arithmetic. The curves match through the 89-degree knot; the intended difference is retaining native damping around/beyond 90-degree slip. There is no car-model filter, but every native eligibility guard must hold. Goals, racer identity, score calculation, global curves and manual/non-owned handling are not changed. Automatic mode transitions and F7/F9 handback remain in place.

**This is not a verified live spin-recovery or score improvement.** The status says the recovery guard is installed, not that it observed a successful recovery. Forced Drift and the variant flag follow the native predicate with drag precedence; they are not unrestricted free-roam support. Start at normal 1× pace with power/grip changes off.

The local logger now includes bounded, read-only Drift controller/goal/physics evidence, speed and native target, track, scoring state, pending/banked points, raw rate, route progression and collision-loss latch. Existing corner hit/cap diagnostics remain separate from pace. Moving native values are sampled about every two seconds; discrete changes can record sooner. Native behavior control scalars are recorded, but no raw addresses, names, keyboard events or network traffic are captured. Export promptly after a short test; this remains a bounded recent log, not a complete replay.

### Retained v0.16 compatibility and collision controls

These additions apply **to the exact reviewed 93af6ccb and 78e2bb69 builds**. Existing v0.14 controls, dyno mode handling, adaptive free-roam corners, separate online NPC traffic switch, signature checks and local crash logger remain present. Older supported game profiles retain their previous native behavior.

- **Separate online player / race no-clip:** free roam uses the exact native active-player slot classifier; driver type alone never qualifies. Current93af6ccb also supports local race-roster filtering under network opt-in. Older78e2bb69 remains free-roam-only. Both switches start off; live multiplayer behavior is unverified.

- **Opponent drag action:** the native initializer can select the genuine opponent “Win drag race” action (2), rather than player “Steer player in drag race” action (3), for this extension's requested and owned car. A positively identified existing action 3 may be upgraded once through that same initializer. NULL initializes lazily; native recovery 11 and other temporary actions are not forced. Status confirms the actual action id and vtable, not merely that the checkbox is selected.
- **Native drift physics:** normal unmarked player drift events use the native driver 3 / physics 1 choice through the game's physics setter, retaining native drag-first precedence. Invalid construction or a failed correction uses the existing manual-control and skill rollback. Event changes still require the full OFF/manual/ON handback.
- **Native nitrous decisions:** recognized drag goal 2, observed road goal 1 in native race types 1/7, and observed chase goal 5 only in Outrun 7 can reach their native request/cancellation path. The extension does not select chase goal 5, allow this new path in free roam, bypass native tactical/skill/resource checks, refill NOS or force activation. The existing Unlimited NOS checkbox remains a separate feature. Cancellation can continue after an authorized race's goal changes to recovery or NULL, so strict new-start gates cannot strand active nitrous.

**Limitations:** recognized drag requires the game's actual drag flag. Force-only drag and the special 1099 combination are unsupported by the new opponent path. Native action selection is not complete opponent equivalence. Full allocator/configuration, cancellation, skill and resource behavior have not been executed end-to-end. No live race benchmark, guaranteed shifting, finishing, winning, fastest-driver or crash-freedom claim is made. Reported freezes remain unresolved. Start with normal 1× pace, unrelated power/grip changes off, and a backed-up save. Use F7 to take control.

### Retained current-build support

This release adds the exact game module for revision **93af6ccb** (38,205,596 bytes), while retaining the reviewed **78e2bb69**, **2f0ddd3b** and **6f4f1e4e** profiles. It adapts the new 64-entry native status table; older profiles retain the 48-entry bound. It verifies the downloaded binary, not just its version label. The compact menu uses a constructed stylesheet that works with the site's strict style policy.

**A game crash was reported with v0.11. Its cause remains unresolved. This update is not a confirmed crash fix and has not been live-gameplay tested.** Back up your save, keep the previous extension folder, and test one feature at a time in solo play.

### Available on 93af6ccb, 78e2bb69 and 2f0ddd3b

- Native player autopilot, automatic native event reconstruction, normal racer skill field set to 9, and experimental drag physics handoff.
- Separate free-roam/race pace controls and experimental free-roam corner-speed assist.
- Independent solo-only **Wall pass-through** and **Car no-clip** switches.
- Experimental native dyno search, explicit Apply and guarded Restore.
- **93af6ccb and 78e2bb69 only:** native opponent drag action, drift physics correction and guarded native nitrous decisions, plus separate Online traffic and Online player no-clip, each limited to its native identity category in online free roam.
- Unlimited equipped NOS, power boost, limiter control, grip, manual drag assist, solo drift input and read-only tester.

Automatic AI, both pace opt-ins, both corner assists, all four collision switches, power boost, limiter removal, extra grip, dyno and Online/LAN permission start off after reload. Factors are retained. A future unknown build stays disabled. Both revision and the downloaded module's exact size/SHA-256 must match a reviewed profile before memory tools can run. Native hooks also refuse cold occupied command regions.

### Road-race hairpin setup

Enable Automatic driver in an ordinary road race, then enable Road-race hairpin assist. Online/LAN additionally requires the separate Allow network tools opt-in. Start at its default corner factor 0.80×, sharp-turn margin 15% and braking factor 0.75×. Lower braking factor requests earlier planning; it does not weaken the physical brakes. Settings or selected race pace changes trigger the existing OFF/manual/ON route reconstruction. A braking-hit count alone never confirms a corner reduction. “Armed” means requested, while an observed cap requires an actual qualifying native helper hit. Both assists start off after reload and Stop.

## Feature status on the exact current build

| Control | Implemented | What was verified / remaining limit |
| --- | --- | --- |
| Native AI + event switching | Yes | On/Off handback, reused-pointer subtype/track transitions and native mappings tested. Not every race's live behavior or opponent-equivalent initialization. |
| Skill 9 | Yes | Actual native skill getter tested; normal field set to 9, sentinels preserved. Drag's decision-time use of the field remains unproved. |
| Automatic drag | Yes, experimental | Native driver 3/physics 1 handoff, guarded opponent action 2 selection and rollback tested. Force-only/special drag unsupported; launching, shifts, lanes and finishing not live-verified. |
| Guarded native Drift recovery | Integrated with Automatic driver on 93af6ccb and 78e2bb69 | Exact production physics splice, native-output parity, fail-closed and bridge handback fixtures pass. No live recovery, per-model handling or score improvement claim. |
| Native drift physics and nitrous decisions | 93af6ccb and 78e2bb69, experimental | Native physics choice, guarded start/cancel acceptance, selected downstream request/consumer fixtures and rollback tested. Full native graphs and live race outcomes unverified. |
| Free-roam / race pace up to 3× | Yes, separate opt-ins | Native hook and 2–3× bounds/non-compounding tested. This is target-speed scaling, not a promised speed multiplier or stable driving. Drag stays neutral. |
| Free-roam corner assist | Yes, experimental | Actual current corner helper, route ownership, guards and output scaling tested. Not a proven steering/avoidance fix. |
| Wall pass-through / Car no-clip | Yes, independent solo-only switches | Current contact wrapper, categories, filter composition and fallback tested. Live map/traffic coverage unverified. |
| Online traffic no-clip | Yes, separate opt-in on 93af6ccb and 78e2bb69 | Exact native online and player-slot helpers tested. Only NPC traffic in online free roam; races, outruns and LAN excluded. Live network behavior unverified. |
| Online player / race no-clip | Independent opt-in; race extension on93af6ccb only | Free-roam player-slot identity retained. Current-build local race contacts require both roster memberships, reciprocal identity and network permission. Counters distinguish race scope. Remote peers/server effects/live collisions unverified. |
| Full preset editor / native preview / stage / restore | 93af6ccb only, experimental | All 41 fields, native unlocks/coupling, private measurements, measured gearing/ECU/turbo search and selected-preset writes tested. Manual handling controls are not automatically optimized. Test Run refresh and Save Profile are user actions; live save/reload unverified. Older builds retain ECU/turbo search. |
| NOS / power / limiter / grip | Yes, experimental | Exact mappings, native NOS, bounds, restoration and controlled competing-writer tests. Hardened but not lifetime-synchronized; freezes unresolved. |
| Manual drag / drift toggle / tester | Yes | Input/state and UI tests. Manual drag still requires you to steer; drift is not perfect-drift automation; tester is incomplete. |
| Crash log + manual JSON export | Yes | Sanitization, retention, effective tool state, export simulation and no-tools memory invariance tested. Includes read-only Drift controller/scoring/speed and preserved corner evidence. Real browser export not verified; a freeze may leave no final error. |

Unknown binaries stay disabled. On the older 6f4f1e4e binary, the car no-clip filter is disabled because that hook was only mapped for the current build. No game assets are bundled.

## Signature scanning and build updates

The loader performs a read-only scan against three reviewed sets of 34 typed function fingerprints. It reports unique, ambiguous and missing matches in local diagnostics, plus the actual module hash. The menu retains the full compatibility explanation rather than truncating it. AI and Dyno now give the same explicit unavailable-build reason instead of suggesting the wrong tuning screen.

**Signature matches do not automatically authorize a new game version.** Matching functions alone do not establish callees, dispatch tables, host addresses, scratch ownership or live behavior. Even 34/34 matches on a different binary leave tools disabled until an exact compatibility profile has been reviewed. This is update diagnosis, not a promise that future game updates will work automatically. Scanner failure does not override the independent exact-binary gate.

## Automatic AI race-type switching

Turn on **AI driver → Automatic driver** once per page. It automatically selects:

- **Non-drag races and free roam:** the existing native player autopilot.
- **Drag:** experimental native racer AI with the verified drag physics type. It waits until GO and full driving physics are available.
- **Changing mode:** requests native AI OFF, waits for the game thread to acknowledge it, confirms ownership is released, the human driver is restored and any failed-acquisition latch is cleared, then requests the new mode. Player, car, race, track, drag/drift/URL/StreetX flags, forced native mode flags and race/free-roam changes are checked, including when object pointers are reused.

There is no separate drag-AI checkbox. The main switch explicitly enables automatic selection, including experimental drag. **You still start events yourself. This does not select races, restart them, navigate career menus, buy upgrades or choose a GPS destination.** It includes the separate experimental free-roam corner-speed and dyno-search tools described below. They are off by default.

The extension requests the game's native player autopilot, not a new steering bot. The native constructor chooses a distinct drift behavior and a shared ordinary/drag/StreetX behavior; its update code contains drag-specific branches. Circuit, sprint, URL and outrun do not have separately proven opponent-equivalent implementations here. The player racer identity stays unchanged. “Level 9” means the ordinary native skill field is set to 9; values 254/255 are preserved. We have not proved that drag's launch, shifting or lane decisions consume that field.

**Live drag driving remains unverified.** Correct driver/physics status does not prove that it shifts, steers, avoids traffic or finishes. It may crash, stop or miss checkpoints. Back up your progress and test solo first. No guaranteed routes, perfect drift, wins or completed races.

### Quick start

1. Back up your save with the game's **Download backup** button.
2. Keep your previous extension folder for rollback. Disable its extension card before loading this version.
3. Extract this ZIP. In `chrome://extensions` (Edge: `edge://extensions`), enable Developer mode and choose **Load unpacked**. Select **NFSU2-Driving-Tools-v0.29.0**, containing `manifest.json`.
4. Reload the game and check version **0.29.0**. Only one version should be enabled.
5. Start a solo event yourself. Open Driving tools with **F8**, then enable **Automatic driver** in a non-drag event. For your first drag test, leave power, grip, NOS, custom pace, collision filters and manual Drag assist off.
6. Enter other supported events normally. AI requests native handback/reconstruction automatically when the event changes. Turn AI off before using manual drag assist. Other selected settings are kept.

Chrome 111+ or a compatible current Chromium browser is required. This is not a Firefox or mobile-browser build. No build tools or Node installation are needed to install the extension.

### Take control and pause

- **F7 / Take control:** disables automatic AI until you explicitly turn it on again. Arrow/WASD keys and Space also take control outside the extension menu. This remains off across later race-type changes.
- Controller axes do not trigger takeover; use F7 or the Take control button.
- Taking control also pauses synthetic manual-drag throttle until you toggle manual Drag assist again.
- **F9 / Stop:** clears automatic AI, all four collision switches, Online/LAN permission, custom pace, NOS, power, limiter, grip and manual drag. Slider values are retained. Drift and the read-only tester keep their own switches.
- Menus, loading, unfocused/hidden tabs and unsupported states pause tools without clearing choices. They resume when a supported driving state returns, unless you took manual control.
- **Automatic AI, wall pass-through, solo car no-clip, online traffic no-clip, corner assist, both pace opt-ins, power boost, limiter removal, extra grip, dyno tuner and Online/LAN permission start OFF after every page reload.** Other settings use same-tab session storage. Closing the tab normally ends those saved choices. Storage may be unavailable or affected by browser restore behavior.
- If the page stops updating, native AI hands back within 180 game frames. A frozen game cannot process a handback. Disable the extension and reload if it freezes.

## Compact menu

The menu starts as a **170 × 29 px** collapsed toolbar and opens to a **244 px** drawer with a 390 px maximum scroll panel. **F8** opens/closes it. Sections start folded, only one main section opens at a time, and longer sections scroll. Help and detailed status are tucked away; no control was removed. **F7 / Take control** and **F9 / Stop** remain keyboard shortcuts, with buttons in the open toolbar.

## Independent controls

### AI and pace

The native AI switch uses player-only skill **9**, the highest normal native value. It restores the original value when the same racer still exists. Special sentinels are left unchanged and are not claimed as level 9. It does not alter other racers or commandeer an AI driver the extension did not acquire.

**Free-roam pace:** 0.75×–3.00× for native free roam only, default off / 1.00×. Its factor is saved, but its switch starts off after reload.

**Race / outrun pace:** a separate 0.75×–3.00× opt-in, default off / 1.00×. Its value is saved, but its switch starts off after reload. Your faster free-roam choice does not carry into races.

Both adjust the native target-speed factor, not engine power, steering or road paths. **2–3× pace is especially experimental: severe overspeed, missed turns/checkpoints and instability are possible.** No real driving at those factors has been verified. Drag, dyno and unknown categories use neutral 1.00×. The choices remain selected while ineligible and resume only in their own category. F7 leaves them dormant; F9 clears both switches. They never turn AI on by themselves.

### Free-roam corner-speed assist

A separate, experimental opt-in reduces the native planner's curvature-limited speed for upcoming free-roam corners. It does not replace steering or road paths. Its bounded factor is **0.60–0.95**, starting at **0.80**. Straight/gentle segments retain their native speed cap. This factor is a tuning hypothesis, not a measured optimum.

**Sharp-turn margin** adds 0–25% extra reduction, starting at 15%, according to how far the native corner speed falls below its maximum cap. Tighter upcoming bends receive more margin. The combined formula is `nativeCornerSpeed × baseFactor × (1 − margin/100 × (1 − nativeCornerSpeed/nativeMaximumSpeed))`. At 0%, it follows the v0.13 calculation exactly. With the strongest settings the effective factor can approach 0.45×; it never changes a straight-cap result. This adjusts the original planner’s speed cap, not its steering or proven sampling distance. Begin with normal 1× pace and power/grip changes off, comparing 0% and 15% on the same solo route.

It applies only to the current, owned AI driver's private main route in native free roam. Races, outruns, drag, drift and the Dyno Shop are excluded. Changing its enabled state, factor or sharp-turn margin rebuilds AI through a full native OFF/manual/ON handoff, because the game caches route speed caps. Free-roam/race transitions also rebuild before rearming.

**Corner status:** Armed means a request is present, not that a qualifying native reduction has been confirmed. Straight/gentle calls and guarded calls add no hit. Occupied command memory and observed drift exclusion are reported separately. The crash log now records bounded corner hits, request state, applied factor and those two observable guards. Confirmed pace is a different acknowledgment and does not prove corner assist ran. For diagnosis, use 1× pace; 0.95× corner factor reduces a qualifying corner cap by only 5%. A persistent no-hit result after bends is still unresolved without live telemetry.

It may help turn entry but cannot repair a bad route, prevent crashes, guarantee a clean corner or improve lap times. More power, grip or pace may undermine it. Live braking, route rebuilding and handling improvements remain unverified. Start conservatively and keep F7 available.

### Full per-race preset tuner

Use the **solo Performance Tuning main screen** on exact 93af6ccb. Back up your save, select a race preset in the game, then enable the tuner. It never buys upgrades, switches the game's preset, enters a race or presses Save Profile.

1. **Load selected preset** captures the current car, installed parts, working tune and selected visit tune on the game thread. The editor displays all 41 settings in their native categories and disables fields locked by installed parts/native rules.
2. Change sliders and press **Preview draft**. Native setters and rebuild/measurement functions run only in a separate memory copy. The preview shows accepted values, including native coupled changes, and comparable before/after estimates. Your live setup remains unchanged.
3. Alternatively choose a measured goal and press **Find tune**. Peak power/torque searches ECU/turbo; 0–60, 0–100 and top speed search gearing plus ECU/turbo. Search is capped at 48 trials. It keeps manual suspension, brake, tire, aero and NOS choices, but does not optimize their handling or lap-time effects. A faster estimated acceleration can reduce top speed; inspect all results.
4. **Stage selected preset** is an explicit separate action. It accepts only the last successfully evaluated candidate, on the same car, preset, installed parts and unchanged setup/visit/record. A game-thread transaction copies just the current 41-byte tune and selected 41-byte visit tune. Other presets and the saved-car record are not written by this action.
5. Start the game's own **Test Run** to refresh driving physics and check the tune. Merely exiting the tuning screen is not a verified rebuild. Use the game's **Save Profile** to persist changes. The game's save can commit all five visit presets, so the tuner warns when other visit presets differ from their stored record. “Save ready” is not a successful save confirmation.
6. **Restore previous** needs the same car, preset, parts and exact last-staged tune. It restores the original current and selected visit tunes, even when those originally differed. A known native commit of this exact selected tune is accepted; unrelated record changes are refused. Restore does not undo disk saves. Use Test Run and Save Profile again if you want the restored state refreshed and persisted.

Each car/preset has separate guarded restore state while the page stays open. A car replacement, manual edits, changed parts or an unknown record change invalidates stale results. Reload loses this temporary restore history. Native unlocked gear counts and tuning rules remain authoritative; no sixth gear is invented. Sliders display −100 to +100 around the game's neutral value, stored internally as bytes 0–200. These are normalized settings, not physical units.

The measurements are native estimates, not lap times or on-track benchmarks. Handling controls and NOS expose native settings without a proven per-race optimal objective. There are no claimed “perfect” race presets, global optimum, guaranteed wins or proven save/reload result. The previous peak-only dyno tool remains on older supported builds with its existing guarded Apply/Restore flow.

Cancel, F9, closing the panel, blur, a hidden tab, leaving the page or disabling the tuner cancels ongoing work. Driving effects pause during work, with their selections retained. **F9 does not undo a tune already staged.** Re-enable the tuner and use Restore previous while its baseline remains valid. A timed-out game-thread request has an uncertain outcome and disables further writes until reload; inspect the game rather than blindly retrying.

The private evaluator extracts only reviewed native functions from the exact game module already downloaded by the browser. It has its own memory, checked capture ranges, write allowlist and operation budget. Capture/stage/restore run through a command-gated frame prefix with no native calls and no profile-file writes. This bounds the reviewed path but is not a guarantee against browser exhaustion, unrelated game faults or live object-lifetime races.

### Power and handling

- **Unlimited NOS:** refills an already equipped kit while driving; does not install a kit or force native AI to activate NOS.
- **Power boost:** 1.0×–3.0× engine and nitrous torque. Starts at 1.5×. Repeated updates do not compound. More power can worsen wheelspin and handling.
- **Remove stock limiter:** removes the stock MPH governor while enabled. Gearing, drag and redline still limit speed. Upgraded cars may already lack that governor.
- **Extra grip:** 1.0×–2.0× all four tyre-force factors. Starts at 1.3×. It is not auto-steering, yaw damping, corner avoidance or guaranteed handling. High grip can cause abrupt behavior or rollover. It pauses in drift mode/races.
- Power and grip restore only fields still owned by the extension. They wait for three matching samples before applying to rebuilt car data. Changed external tuning is preserved rather than overwritten. Pause/off restores owned values when the original live objects remain valid.
- **Drift assist:** uses the game's real drift-event input and waits for its handling confirmation. Solo free roam only, with game menus closed. It is not perfect-drift automation. Power/grip restore before the native tuning rebuild; settings stay selected. Drift uses its own switch, including after F9.

### Wall / barrier pass-through

**Handling & collisions → Wall pass-through** is independent of AI and **solo-only**, even with Online/LAN tools allowed. Turn **Free roam with others** off, or use a solo race.

Only contacts between your car and verified near-vertical static track polygons are skipped, using the native wall threshold `abs(normal.z) < 0.1`. Ground, ceilings, ramps/slopes and movable props retain the original collision path. Cars retain it unless the independent Car no-clip option is enabled. Sloped faces and movable barrier props remain solid. This is not unrestricted flight or universal noclip. The game's native Ghost setting affects cars, not walls; the extension leaves that setting unchanged.

A selected checkbox is not proof of contact filtering. Its status first says Armed, then counts contacts actually skipped by the native hook. Test a plain vertical wall and neon barrier at low speed; verify ground/ramp and car collisions yourself. Coverage has not been live-verified.

You may leave the drivable map, miss checkpoints or get stuck inside scenery. Native recovery may reposition you after a reset. **Turn it off only when clear of a wall.** Off/F9/reload restores the original collision path. It does not change shared map objects or body collision flags.

### Solo Car no-clip

**Handling & collisions → Car no-clip** is separate from Wall pass-through and is solo-only. It matches confirmed native car collision bodies paired with the current local player's car, whether driven manually or by AI. It does not skip collisions between other cars. Walls, ground and props retain their normal path unless the wall option separately applies.

It starts off after reload and reports Armed until a supported contact is actually skipped. Turn it off only once clear of other cars. F9 stops it. No body flags or shared map objects are changed. Native constructor/category and current wrapper tests pass, but real traffic/racer collisions have not been live-verified.

### Online traffic no-clip

**Handling & collisions → Online traffic no-clip** is a separate switch, available on exact builds **93af6ccb and 78e2bb69**. It requires online free roam and matches native NPC traffic paired with your local car, driven manually or by AI. It excludes native player-slot cars even if they use a traffic model or traffic driver flag, plus ordinary AI racers, every race category, outruns and Online/LAN races. Other players and rejected contacts retain the game's original collision logic, including any native Ghost choice you made. Walls, ground, props, body flags and map objects are unchanged.

This switch starts **off after every reload**, even if previously selected. It needs its own explicit opt-in; **Allow Online/LAN tools** never enables it. That general permission is not required for this narrowly scoped online-free-roam traffic switch. Solo Car no-clip stays independent. The status distinguishes Armed from observed traffic contacts skipped. F9 stops and clears it; blur, hidden tabs, dyno work and unavailable driving state pause it. Turn it off only when clear of traffic.

No live online collisions, peer synchronization or server acceptance have been verified. It changes local contact resolution, not the traffic simulation or server rules. Follow the site's rules and use an explicitly permitted private test. A selected or Armed switch is not proof that a real contact was skipped.

### Manual drag assist

A separate, optional throttle / RPM-threshold shift / NOS helper **while you steer**. Uses default Arrow Up, Left Shift and Left Alt bindings. Set shift RPM for your car; 6500 is only a starting point, not learned perfect shifting.

Manual drag assist never runs while automatic drag AI is requested, including countdown and failed/unavailable AI. It will not silently substitute synthetic inputs. With Automatic AI off, manual drag waits for native ownership to clear and a human driver to be confirmed. Countdown permits throttle only; shifts and NOS wait for GO. It does not choose lanes or avoid obstacles. F7/manual takeover pauses it until its switch is toggled again.

### Diagnostics

#### Local crash log

Open **Driving tools → Session & diagnostics → Crash log → Export crash log**. This downloads `nfsu2-driving-tools-diagnostics.json` on your computer. Nothing is automatically sent or uploaded. **Clear log** removes this tab's retained diagnostic history; recording then continues.

The logger starts when this extension page loads. It records recent tool choices/factors, sampled game mode and driver state, page/game-worker lifecycle, classified errors, numeric WebAssembly function/offset locations and line numbers from known script files. It does not capture raw console logs, error messages, URLs, credentials, names, saves, keyboard input or network traffic. It never changes game memory or enables a tool.

The newest **180 events, limited to 64 KiB of stored JSON**, are kept in same-tab session storage. State is sampled on discrete changes (at most four times a second), moving native scalars about every two seconds, and a baseline snapshot every five seconds while driving; rapid repeated page errors are capped. Older entries are discarded and the file reports the count. Export soon after a problem. Reloading the same tab normally retains the log; closing the tab, clearing site data, browser recovery behavior or blocked/full storage can lose it. The menu reports when the log is memory-only. The site's own scripts can access this same-origin session storage, so it is not an extension-private vault.

**Capture limits:** this cannot recover crashes that happened before the logger was installed. A full browser/tab/GPU crash, freeze or forced close may prevent any final event. This is a history of observations, not a complete crash dump or proof of the crash's cause; the last snapshot may precede the failure. Free-text errors are deliberately omitted for privacy, so unfamiliar errors appear as `other`. Also export the game's own **Download log** for native game details. This logger does not fix the reported crash or establish that the game is safe.


The read-only traffic/barrier tester reads nearby car objects and the enabled barrier-line table. It is incomplete: it does not fully classify traffic/racers, shapes, props, road geometry, elevation or safe lanes. No detected obstacle does not imply a safe road.

## Online / LAN

Online/LAN remains blocked by default for existing tools. The separate **Session mode → Allow Online/LAN tools** switch is per-page and starts off on reload. It does not activate individual tools. It never overrides the solo restrictions on walls and solo Car no-clip, drag physics requirements, pause checks or one-local-player checks. Online traffic no-clip remains online-free-roam-only. Current-build Online player / race no-clip requires its own selection plus network permission for the race path; only local contacts are affected.

Online modifications may affect racers, trigger integrity checks, invalidate results or cause moderation/bans. Follow the site's rules and prefer solo play or an explicitly permitted private test. This extension does not bypass server restrictions. Turning off the session switch stops AI/synthetic keys and restores owned tuning when possible, while keeping selections for solo. NOS already refilled is not drained. F9 clears the permission.

## Validation and known limits

**Automated validation:** the final v0.28 suite passes **1,740 tests, zero failures/skips/cancellations**, including high-address runtime CPU cases. See `CHANGELOG.md`. The frozen v0.20 tuner baseline passed 1,599 tests. Coverage includes the retained v0.18 regressions, actual native isolated getter/setter/rebuild and metrics, all unlocked control offsets, exact game-thread capture/stage/restore, all five preset leases, stale-state/identity/cancellation/fuel guards, and end-to-end private preview with selected-preset-only writes. The end-to-end harness uses exact native game functions and a constructed car/catalog fixture, not a live user's game. Focused suites overlap and are not additive totals. These checks are not a full game simulation or live gameplay.

All four exact supported modules validate and compile after patching. Both modern profiles change12 bodies: **2459, 3174, 4497, 4653, 7395, 8871, 17404, 19197, 19277, 21213, 21263**, plus contact wrapper **22508** on93af6ccb or **22470** on78e2bb69. On2f0ddd3b, only **4497, 4653, 21213, 21262 and22430** change; on6f4f1e4e, only **4497, 4653, 21213, 21262 and22720** change. Every other function body and non-code section is preserved byte-for-byte. Original planner instructions and contact-wrapper tails remain preserved. The native Drift recovery expression replacement retains its documented scope. Authored builders reproduce the shipped payloads.

No successful live drag race, wall/car test, cornering improvement, real-car dyno improvement or online race is claimed. The menu passes simulated DOM checks. The strict-CSP Chromium regression test could not run because this environment blocks Chromium startup; no real-browser visual verification is claimed.

The v0.11 crash remains undiagnosed. Controlled interleaving tests did expose stale-state and competing-writer hazards in power, grip and NOS. This release rechecks live state/identity at each field, uses exact-value atomic updates/restoration, rejects out-of-domain power values and avoids unchanged-value rewrites. These are experimental mitigations, not full lifetime synchronization: the native game can still destroy/reuse an object before updating its pointer. No elimination of that residual race or the reported freezes is claimed. The current game-thread gcall ABI, dispatch mapping and hook-local layout match the reviewed native binary; that does not establish the absence of timing, lifetime or gameplay faults. Stop using a feature if the game becomes unstable, preserve the crash log and reload before retesting.

Exact supported profiles:

- **93af6ccb:** 38,205,596 bytes, SHA-256 `128e2b5816a8eace4b768aec920318a1613da8235801a361e2009e96550be1d6`. Newest reviewed profile, with the64-entry native status table and all current controls.
- **78e2bb69:** 38,170,601 bytes, SHA-256 `df7b930bb293ffdf975f0735d93e0797d51bd137d0cbeabcaff87fc5a693c759`. Previous reviewed modern profile. Main hook 21213, dispatch 21726, gcall 21740, pace wrapper 21263, contact wrapper 22470; exact native bodies and relocated wrappers are checked offline.
- **2f0ddd3b:** 36,872,934 bytes, SHA-256 `5e33ad2cb4c4cc6893dee7cbd4d6e9bfb0f59a349d218fddbb5e3331ca69bc34`. Expanded experimental feature support listed above. The native gcall function was mapped from old index 21725 to current index 21739 and verified to preserve the same CPU ABI; actual dispatch tables and native AI bodies were checked independently.
- **6f4f1e4e:** 37,839,055 bytes, SHA-256 `ee5d281a3109240d5db25dc3921e1044672cf6d650eb58c3baa089b54fe2941f`. Retains the older combined experimental feature set.

An independent probe executes actual current-build input/status initialization, status writing and the NOS reader in isolated memory: 22 assertions pass. This verifies the mailbox formats and NOS interpretation, not a real gameplay session. A separate native gcall binary comparison verifies that its only body change is the dispatcher call relocation.

## Privacy, implementation and rollback

The extension matches only `https://nfsu2.xyz/*`. No account, history, debugger or broad website permissions. It stores its own preferences and a bounded, sanitized diagnostic history in namespaced same-tab session-storage entries. Nothing is uploaded. Its only added request is a same-origin `/game.json` compatibility read; it inspects the game's own module response during loading. No analytics, remote code or game assets are bundled.

- AI calls native `Player::AutoPilotOn`, `AutoPilotOff` and `SetInputMode` through the game's existing CPU-preserving game-thread dispatcher. It never invokes native game functions concurrently from the page thread.
- Normal drag opponents use driver type 3 / physics type 1, while player autopilot initially asks for physics type 3. The retained drag handoff corrects only the eligible local car, verifies both types and rolls back on failure.
- The page's automatic AI switch supplies the exact drag-permission word only when drag is detected. The native permission and full-physics checks are still required. The pace hook never modifies drag.
- Mode switching publishes OFF and verifies the native heartbeat acknowledgement, cleared ownership and restored manual driver before rearming. Identity, native subtype/track flags and race/free-roam mode are part of that comparison. Native Off/On rebuilds the private driver route.
- Command memory stays at `0x00d0d100` (104 bytes used on modern Drag-heat profiles;92 bytes on older profiles) and walls at `0x00d0d180` (40 bytes), under sequence locks. Cars use `0x00d0d1c0` (40 bytes); the existing final word selects the independent online traffic/player modes on 93af6ccb and 78e2bb69. The corner record is at `0x00d0d200` (64 bytes, CNR3), and dyno uses `0x00d0d300..0x00d0d4ff`. These do not overlap. Native scalar-reference/allocator analysis supports using these gaps, but exclusive allocation has not been formally proved and unknown computed writes remain a risk. Cold empty/owned checks and post-attachment ownership guards reduce, not eliminate, that risk. The current-build patch targets the main-loop bridge, player pace, contact resolver, corner/braking helpers, native drag action/input selectors, native Drift damping expression and three guarded nitrous acceptance sites. Original native instructions remain preserved around the scoped changes.
- The full tuner additionally grows the game memory by an owned 16 MiB snapshot buffer, records its module/memory identity and uses the existing dyno mailbox for commands. Snapshot growth is not undone until reload. Native evaluation runs in separate memory with guarded reads/writes and execution fuel. Staging does not call a game physics rebuild or save helper.
- Wall filtering prefixes `sub_005b2610` and preserves the full original resolver for every rejected contact. Body type/vtable, reciprocal car/face pointers, finite unit normals and pair identities are checked. Native `roam_game_online_here()` always blocks wall filtering during multiplayer free roam. The separate latest-build traffic path also calls the exact native read-only player-slot helper and excludes recognized player cars.

For rollback, disable v0.29.0, enable your preserved previous version and reload. The previous version remains subject to its own build-compatibility checks. Memory effects do not survive reload; saved ordinary preferences may. Never run both versions together.

### Source references

- Public pinned source: https://github.com/th0mk/nfsu2-web/tree/6f4f1e4e92f5f3ddf6f6d165b7f7075a95ab7fe3
- `runtime/career.c`, `runtime/guest.h`: native handoff, return-to-input and game-thread calls.
- `runtime/catchup.c`: native skill, player target-speed calculation.
- `runtime/game.h`, `runtime/web/status_web.c`: driving/countdown/paused states and drag type.
- `runtime/roam.c`, `runtime/roam_game.c`: collision wrapper, native Ghost scope and multiplayer state.
- `runtime/walls.c`: native barrier lines.
- `runtime/mprace.c`, `runtime/drift.c`: per-car torque, limiter, drift and tyre data.
- Reconstructed collision classifications, independently checked against the exact executable: https://github.com/troikoss/speed-re/tree/892e5c31d77c751acd123330eda15c157c4f1b1f/src/Speed/Indep/Src/Physics/Collision

No upstream files were modified. This is unofficial and not affiliated with the site or Electronic Arts. No game executable, assets or reconstructed third-party code are in the ZIP.

### Tuner snapshot rejection diagnostics

A snapshot rejection keeps the original setup and remains fail-closed. Updated errors identify the failed component with a short code such as **S32** (performance-curve sample count) or **S45** (curve data bounds). Export **Crash log** immediately after one failed attempt; the local export retains only the rejection status, fixed guard code, and relevant count/source-pair number, plus ordinary classified script locations. It does not include memory addresses, raw game memory, setups, or saves.

This is a diagnostic improvement, not proof that a previously unsupported live snapshot is now compatible. Capture limits, alias checks, the owned 16 MiB buffer, isolated native evaluation, all 41 settings, and selected-preset-only Stage/Restore are unchanged. Do not disable checks or invent missing curve data to make a capture succeed.

### Drift line diagnostics (read-only candidate)

With an exactly verified native profile and linked Drift behavior, diagnostic exports also retain the signed route-count branch (fallback versus a positive count), relative XY target and distance, velocity XY, heading units, and the native controller's retained slip field. No absolute map coordinates or pointers are exported. The retained slip is last written by the native slide-control branch; it can be stale when another branch runs, so it is not an instantaneous slip sensor. Target values are also last-written native state, not proof that the target was refreshed during the sampled frame.

These values use existing two-second moving-sample cadence, with route fallback changes still recorded promptly. They do not measure wall clearance, actual collision geometry, completed corner success or momentum improvement. Game control, engine power, route construction, Drift recovery, road corner assistance and Street X are unchanged. A fresh export immediately after a bad Drift corner is needed before selecting new Drift-only throttle or line settings.

#!/usr/bin/env python3
from pathlib import Path
import argparse, hashlib, json, zipfile
root = Path(__file__).resolve().parents[1]
source = root / 'extension'
manifest = json.loads((source / 'manifest.json').read_text())
assert manifest['version'] == '0.33.0'
folder = 'NFSU2-Driving-Tools-v0.33.0'
parser = argparse.ArgumentParser()
parser.add_argument('--output', type=Path)
args = parser.parse_args()
out = args.output or root.parent / 'NFSU2-Driving-Tools-v0.33-Combined-Continuous-Corners.zip'
files = ['README.md', 'CHANGELOG.md', 'manifest.json', 'popup.html', *manifest['content_scripts'][0]['js']]
assert len(files) == len(set(files))
assert sorted(files) == sorted(p.name for p in source.iterdir() if p.is_file())
assert all((source / p).is_file() for p in files)
assert manifest['content_scripts'][0]['matches'] == ['https://nfsu2.xyz/*']
assert manifest['content_scripts'][0]['world'] == 'MAIN'
# Exclusive creation keeps any previously delivered archive immutable.
with zipfile.ZipFile(out, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name in files:
        # Canonical metadata makes the same reviewed sources reproduce the same ZIP.
        entry = zipfile.ZipInfo(folder + '/' + name, date_time=(1980, 1, 1, 0, 0, 0))
        entry.create_system = 3
        entry.external_attr = 0o100644 << 16
        entry.compress_type = zipfile.ZIP_DEFLATED
        z.writestr(entry, (source / name).read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
with zipfile.ZipFile(out) as z:
    assert z.testzip() is None
    assert len(z.namelist()) == len(files)
    for name in files:
        assert z.read(folder + '/' + name) == (source / name).read_bytes()
print(json.dumps({'path': str(out), 'size': out.stat().st_size, 'sha256': hashlib.sha256(out.read_bytes()).hexdigest(), 'files': files}, indent=2))

'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),path=require('node:path'),{createRequire}=require('node:module');
const file=path.join(__dirname,'diagnostics-page.test.cjs'),baseRequire=createRequire(file),ctx={require:Object.assign(name=>name==='node:test'?{test(){}}:baseRequire(name),{resolve:baseRequire.resolve}),console,Buffer,WebAssembly,Blob,URL,setImmediate};
vm.runInNewContext(fs.readFileSync(file,'utf8')+'\nthis.fixture=fixture;',ctx,{filename:file});
const fixture=ctx.fixture,copy=f=>Buffer.from(new Uint8Array(f.memory.buffer));
function key(f,extra={}){let prevented=0;const event={type:'keydown',code:'Insert',shiftKey:true,isTrusted:true,composedPath:()=>[],preventDefault(){prevented++;},...extra};f.fire(event);return prevented;}
test('Shift+Insert toggles the same menu as F8 without changing driving selections or memory',async()=>{
 const f=await fixture(null,true);f.change('ai',true);f.change('nos',true);const before=copy(f),prefs=JSON.stringify(f.prefs()),stops=f.aiLog.stops;
 assert.equal(f.nodes['tools-panel'].hidden,true);assert.equal(key(f),1);assert.equal(f.nodes['tools-panel'].hidden,false);assert.equal(f.nodes['info-hud'].hidden,true);
 assert.equal(key(f),1);assert.equal(f.nodes['tools-panel'].hidden,true);assert.equal(f.nodes['info-hud'].hidden,false);
 f.press('F8');assert.equal(f.nodes['tools-panel'].hidden,false);key(f);assert.equal(f.nodes['tools-panel'].hidden,true);f.press('F8');f.press('Escape');assert.equal(f.nodes['tools-panel'].hidden,true);
 assert.equal(JSON.stringify(f.prefs()),prefs);assert.deepEqual(copy(f),before);assert.equal(f.aiLog.stops,stops);assert.deepEqual(Array.from(f.aiLog.keys),[]);
});
test('Shift+Insert preserves paste in text controls and editable shadow ancestors',async()=>{
 const f=await fixture(null,true);
 const targets=[{tagName:'INPUT',type:'text'},{tagName:'INPUT',type:'password'},{tagName:'INPUT',type:'number'},{tagName:'INPUT',type:'search'},{tagName:'INPUT',type:''},{tagName:'TEXTAREA'},{tagName:'SELECT'},{tagName:'DIV',isContentEditable:true},{tagName:'DIV',getAttribute:name=>name==='role'?'textbox':null}];
 for(const target of targets){assert.equal(key(f,{target,composedPath:()=>[{tagName:'SPAN'},target]}),0);assert.equal(f.nodes['tools-panel'].hidden,true);}
 assert.equal(key(f,{target:{tagName:'INPUT',type:'text'},composedPath:undefined}),0);assert.equal(f.nodes['tools-panel'].hidden,true);
});
test('Shift+Insert ignores extra modifiers, untrusted events, composition and repeated toggles',async()=>{
 const f=await fixture(null,true);
 for(const extra of [{shiftKey:false},{ctrlKey:true},{altKey:true},{metaKey:true},{isTrusted:false},{isComposing:true},{defaultPrevented:true},{code:'Numpad0'}]){assert.equal(key(f,extra),0);assert.equal(f.nodes['tools-panel'].hidden,true);}
 assert.equal(key(f),1);assert.equal(f.nodes['tools-panel'].hidden,false);for(let i=0;i<8;i++)assert.equal(key(f,{repeat:true}),1);assert.equal(f.nodes['tools-panel'].hidden,false);key(f);assert.equal(f.nodes['tools-panel'].hidden,true);
});
test('Shift+Insert works on non-editing controls and retains existing close-cancels-tuner behavior',async()=>{
 const f=await fixture(null,true,true);
 for(const type of ['checkbox','radio','range','button']){const target={tagName:'INPUT',type};assert.equal(key(f,{target,composedPath:()=>[target]}),1);assert.equal(f.nodes['tools-panel'].hidden,false);key(f);}
 f.change('dyno-enable',true);f.click('dyno-find');await new Promise(r=>setImmediate(r));assert.equal(f.dynoLog.instance.busy,true);key(f);const before=f.dynoLog.cancels;key(f);assert.equal(f.dynoLog.cancels,before+1);f.dynoLog.instance.finish();await new Promise(r=>setImmediate(r));
});

test('closed-shadow retargeting preserves profile-name paste and editable ancestor focus',async()=>{
 const f=await fixture(null,true);f.press('F8');
 for(const field of [{tagName:'INPUT',type:'text'},{tagName:'TEXTAREA'},{tagName:'SPAN',parentElement:{tagName:'DIV',getAttribute:name=>name==='role'?'textbox':null}}]){
  const host=f.uiFocus(field);assert.equal(key(f,{target:host,composedPath:()=>[host]}),0);assert.equal(f.nodes['tools-panel'].hidden,false);
 }
 const host=f.uiFocus({tagName:'INPUT',type:'range'});assert.equal(key(f,{target:host,composedPath:()=>[host]}),1);assert.equal(f.nodes['tools-panel'].hidden,true);f.uiFocus(null);assert.equal(key(f),1);assert.equal(f.nodes['tools-panel'].hidden,false);
});

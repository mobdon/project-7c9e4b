/* Local, schema-only diagnostics. No console interception, requests or uploads. */
(function (root) {
  'use strict';
  const KEY = 'nfsu2-driving-tools-diagnostics-v1';
  const MAX_EVENTS = 180, MAX_BYTES = 65536, MAX_ERROR_INPUT = 16384;
  const MAX_DRIVING_SAMPLES=12,MAX_DRIVING_BYTES=16384;
  const EVENTS = new Set(['page-start','game-boot','game-register','game-trap','game-exit','worker-error','page-error','promise-rejection','engine-error','identity-change','state','tools','pause','resume','page-hide','manual','stop','export','clear','build','build-error','patch-state','dyno-action','dyno-error']);
  const FLAGS = ['ready','driving','network','safe','hidden','focused','aiActive','aiOwned','handbackPending','dynoBusy','dynoEnabled','wallRequested','carRequested','onlineTrafficRequested','onlinePlayersRequested','onlineRaceCarsRequested','cornerRequested','cornerMemoryBlocked','cornerDriftBlocked','cornerDriverValid','cornerRouteOwned','powerActive','gripActive','limiterRemoved','carChanged','raceChanged','playerChanged','sessionCurrent','supported','signatureExact','signatureFailed','driftRace','forcedDrift','driftVariant','aiDriverVerified','aiGoalPending','nativeDriftBehavior','nativeRoadBehavior'];
  const NUMBERS = {nativePaceFactor:[0,4],dragEngineHeat:[-1,2],dragEngineLimitRpm:[1000,30000],signatureTotal:[0,128],signatureUnique:[0,128],signatureMissing:[0,128],signatureAmbiguous:[0,128],moduleBytes:[0,4294967295],slot:[0,1024],tid:[0,1e6],code:[-2147483648,2147483647],kind:[0,100],generation:[0,1e6],memoryMiB:[0,65536],hud:[0,3],flow:[0,100],raceType:[0,100],racePhase:[0,100],driverKind:[0,100],physicsKind:[0,100],wallHits:[0,1e9],carHits:[0,1e9],trafficHits:[0,1e9],playerHits:[0,1e9],cornerMode:[0,3],cornerPace:[0.5,3],cornerBraking:[0.5,1],brakingHits:[0,4294967295],cornerHits:[0,4294967295],cornerApplied:[0,1],cornerProbeStage:[0,7],cornerRouteNodes:[0,40],cornerPlannerCorners:[0,40],cornerPlannerUsable:[0,5],cornerGuardMask:[0,255],effectivePower:[1,3],effectiveGrip:[1,2],requestedPace:[0.5,3],gameTicks:[0,4294967295],pageHeartbeat:[0,4294967295],nativeHeartbeatAck:[0,4294967295]};
  Object.assign(NUMBERS,{trackId:[0,65535],carRpm:[0,30000],carGear:[0,10],speedMps:[0,500],forwardMps:[-500,500],nativeSkill:[0,255],aiGoalId:[0,255],driftTargetMps:[-200,200]});
  FLAGS.push('dragHeatDisabled','dragEngineBlown','driftScoreLinked','driftCollisionLoss','aiGoalRecognized');
  Object.assign(NUMBERS,{driftScoreState:[0,4],driftMultiplier:[1,5],driftNextPoints:[0,1e9],driftPendingPoints:[0,1e9],driftBankedPoints:[0,1e9],driftRawRate:[0,1e6],driftLatchedSlipRad:[-Math.PI,Math.PI],currentRawRouteProgress:[-1,1e7],driftBestRawRouteProgress:[-1,1e7]});
  // Moving telemetry must not turn ordinary state sampling into per-tick
  // storage writes. Keep native scalar samples at two seconds unless a
  // discrete mode, controller, scoring-state or tool change needs a record.
  const MOVING_FIELDS=['gameTicks','pageHeartbeat','nativeHeartbeatAck','carRpm','speedMps','forwardMps','driftTargetMps','driftPendingPoints','driftBankedPoints','driftRawRate','driftLatchedSlipRad','currentRawRouteProgress','driftBestRawRouteProgress'];
  FLAGS.push('nativeTelemetry','dragRace','forcedDrag','nativeNavigationPresent','nativeNavigationValid','nativeConfigPresent','nativeConfigValid','nativeCompanionPresent','nativeCompanionValid','aiSkillSaved');
  Object.assign(NUMBERS,{nativeInputMode:[0,10],nativeNextInputMode:[0,10],nativeThrottle:[0,1],nativeHandbrake:[0,1],nativeBrake:[0,1],nativeSteering:[-32768,32767],nativeGearCommand:[-1,10],aiRequestedMode:[0,2],aiNativeStatus:[0,3],aiStaleTicks:[0,4294967295],savedNativeSkill:[0,255]});
  MOVING_FIELDS.push('cornerHits','brakingHits');
  MOVING_FIELDS.push('nativeThrottle','nativeHandbrake','nativeBrake','nativeSteering','aiStaleTicks');
  FLAGS.push('nosTelemetry','nosClockNetwork','nosTimestampActive');
  Object.assign(NUMBERS,{nosClockTicks:[0,4294967295],nosSinceTicks:[0,4294967295],nosFullTicks:[0,9999999],nosRemainingTicks:[0,9999999],nosElapsedTicks:[-4294967295,4294967295]});
  MOVING_FIELDS.push('nosClockTicks','nosSinceTicks','nosFullTicks','nosRemainingTicks','nosElapsedTicks');
  FLAGS.push('paceConfirmed','adaptiveRaceRequested','raceOnlyEligible','raceOnlyRequested','raceOnlyInputClear');
  Object.assign(NUMBERS,{paceApplied:[0.75,3],adaptiveRaceCeiling:[1,2],adaptiveRuntimePace:[.75,2],adaptiveClearanceM:[0,150]});
  MOVING_FIELDS.push('adaptiveRuntimePace','adaptiveClearanceM');
  FLAGS.push('forwardCaptured','nativeForwardGeometry','nativeForwardClamp','forwardUnavailable');
  Object.assign(NUMBERS,{forwardSamples:[0,48],forwardHorizon:[0,512.01],forwardPriorityTurns:[0,24],forwardRequestedTarget:[0,150],forwardLeaseTicks:[0,400],forwardFailureCode:[1,10]});
  MOVING_FIELDS.push('forwardState','forwardCaptured','forwardSamples','forwardHorizon','forwardPriorityTurns','forwardRequestedTarget','forwardLeaseTicks','forwardFailureCode');
  const FORWARD_STATES=new Set(['off','waiting','requested','unknown','armed','observed','native-fallback']);
  const PACING_STATES=new Set(['off','invalid','native-route','native-fallback','coverage-unknown','clearance-limited']);
  const ADAPTIVE_STATES=new Set(['off','invalid','unsupported','street-x','mode','network-permission','ai-off','paused','handoff','pace-pending','planner-pending','planner-observed','native-fallback','coverage-unknown','clearance-limited']);
  const POWER_STATUSES=new Set(['off','unsupported','not-ready','not-driving','network-permission','hidden','unfocused','menu','hud','drift-change','layout','settling','applied','neutral','changed','rejected','suspended','tuner-busy']);
  const TOOL_FLAGS = ['ai','raceOnlyAI','aiPace','raceCornerAssist','cornerAssist','racePace','walls','cars','traffic','players','online','nos','drag','dragNoBlowout','tester','boost','unlimit','grip','drift','dynoEnabled','adaptiveRace'];
  const TOOL_NUMBERS = {adaptiveRaceCeiling:[1,2],raceCornerFactor:[0.6,0.95],raceCornerMargin:[0,25],raceBraking:[0.5,1],paceFactor:[0.75,3],racePaceFactor:[0.75,3],cornerFactor:[0.6,0.95],cornerMargin:[0,25],power:[1,3],gripFactor:[1,2],rpm:[3000,10000]};
  const DYNO_STATUSES=new Set([0,1,2,3,4,5,6,8]);
  const DYNO_GUARDS=new Set([0,1,2,3,4,5,10,11,12,13,14,15,20,21,22,23,24,30,31,32,40,41,42,43,44,45,50,60,70,71,72,73,74]);
  const DYNO_SOURCE_PAIRS=new Set([12,13,14,15,23,24,25,34,35,45]);
  const ERROR_KINDS = new Set(['memory-bounds','unreachable','indirect-call','integer-divide','invalid-conversion','stack-overflow','out-of-memory','type-error','reference-error','syntax-error','other']);
  const PHASES = new Set(['idle','preparing','ready','unavailable','waiting','active','failed','unsupported']);
  const PATCH_CODES = new Set(['module-size','module-hash','module-read','module-layout','module-compile']);
  const REASONS = new Set(['blur','hidden','page-hide','manual','stop','game-stopped','build-unavailable','metadata','find','apply','restore','cancel','unknown']);
  const read = (value, key) => { try { return value == null ? undefined : value[key]; } catch { return undefined; } };
  const str = value => typeof value === 'string' ? value.slice(0,MAX_ERROR_INPUT) : '';
  const number = (value, limits) => typeof value === 'number' && Number.isFinite(value) && value >= limits[0] && value <= limits[1] ? Math.round(value*1000)/1000 : undefined;
  function fields(value, flags, numbers) {
    const out = {};
    for (const key of flags) if (typeof read(value,key) === 'boolean') out[key] = read(value,key);
    for (const [key,limits] of Object.entries(numbers)) { const v = number(read(value,key),limits); if (v !== undefined) out[key] = v; }
    return out;
  }
  function errorInfo(error, stack) {
    const message = str(typeof error === 'string' ? error : read(error,'message'));
    const name = str(read(error,'name'));
    const text = `${name} ${message}`.toLowerCase();
    const errorKind = /out of bounds|bounds check|outside.*memory/.test(text) ? 'memory-bounds'
      : /unreachable/.test(text) ? 'unreachable'
      : /indirect call|signature mismatch|null function|table index/.test(text) ? 'indirect-call'
      : /divide by zero|integer overflow/.test(text) ? 'integer-divide'
      : /invalid conversion/.test(text) ? 'invalid-conversion'
      : /call stack|stack overflow/.test(text) ? 'stack-overflow'
      : /out of memory|allocation failed|memory allocation/.test(text) ? 'out-of-memory'
      : /typeerror/.test(text) ? 'type-error'
      : /referenceerror/.test(text) ? 'reference-error'
      : /syntaxerror/.test(text) ? 'syntax-error' : 'other';
    const source = str(stack === undefined ? read(error,'stack') : stack);
    // Keep only numeric wasm locations and known local source basenames/line numbers.
    // Never retain error text, URLs, arguments, file paths, arbitrary function names or query strings.
    const wasmFrames = [...source.matchAll(/wasm-function\[(\d{1,7})\]:(0x[0-9a-f]{1,12}|\d{1,12})(?![\da-f])/gi)].slice(0,12).map(m=>`wasm-function[${m[1]}]:${m[2]}`);
    const jsFrames = [...source.matchAll(/(?:^|[/\\\s(])((?:page|ai|core|diagnostics|current-profile|latest-profile|signatures|signature-profile|signature-profile-latest|dyno|dyno-core|dyno-full|dyno-evaluator|dyno-native|walls|cars|game-worker)\.js):(\d{1,7}):(\d{1,7})(?!\d)/g)].slice(0,8).map(m=>`${m[1]}:${m[2]}:${m[3]}`);
    return {errorKind,wasmFrames,jsFrames};
  }
  function sanitize(value) {
    const out = fields(value,FLAGS,NUMBERS);
    if(!Number.isInteger(read(value,'forwardFailureCode')))delete out.forwardFailureCode;
    if(FORWARD_STATES.has(read(value,'forwardState')))out.forwardState=read(value,'forwardState');
    // There is no native application receipt or live verification for this
    // preview yet. Persisted/page data cannot promote a request into proof.
    for(const key of ['forwardNativeApplied','forwardLiveVerified'])if(read(value,key)===false)out[key]=false;
    if(ADAPTIVE_STATES.has(read(value,'adaptiveRaceState')))out.adaptiveRaceState=read(value,'adaptiveRaceState');
    if(PACING_STATES.has(read(value,'adaptivePacingState')))out.adaptivePacingState=read(value,'adaptivePacingState');
    if(POWER_STATUSES.has(read(value,'powerStatus')))out.powerStatus=read(value,'powerStatus');
    for(const key of ['revision','reportedRevision','candidateRevision','signatureReference']){
      const revision=read(value,key);
      if(typeof revision==='string'&&/^(?:[a-f0-9]{8,40}|unknown)$/.test(revision))out[key]=revision;
    }
    const moduleHash=read(value,'moduleHash');
    if(typeof moduleHash==='string'&&/^[a-f0-9]{64}$/.test(moduleHash))out.moduleHash=moduleHash;
    if(PATCH_CODES.has(read(value,'patchCode')))out.patchCode=read(value,'patchCode');
    const version = read(value,'version');
    if (typeof version === 'string' && /^\d{1,3}\.\d{1,3}\.\d{1,3}$/.test(version)) out.version = version;
    for (const [key,allowed] of [['phase',PHASES],['reason',REASONS],['errorKind',ERROR_KINDS]]) if (allowed.has(read(value,key))) out[key] = read(value,key);
    if (read(value,'tools')) out.tools = fields(read(value,'tools'),TOOL_FLAGS,TOOL_NUMBERS);
    const dynoStatus=read(value,'dynoStatus'),dynoGuard=read(value,'dynoGuard'),dynoObserved=read(value,'dynoObserved');
    if(DYNO_STATUSES.has(dynoStatus))out.dynoStatus=dynoStatus;
    if(dynoStatus===8&&DYNO_GUARDS.has(dynoGuard)){
      out.dynoGuard=dynoGuard;
      if(Number.isInteger(dynoObserved)&&dynoObserved>=0&&dynoObserved<=4294967295&&
        ([30,31,32,70].includes(dynoGuard)||(dynoGuard===50&&DYNO_SOURCE_PAIRS.has(dynoObserved))))out.dynoObserved=dynoObserved;
    }

    if (read(value,'error') !== undefined || read(value,'stack') !== undefined) Object.assign(out,errorInfo(read(value,'error'),read(value,'stack')));
    // Revalidate persisted records too, never trust same-origin storage or its fields.
    else for (const [key,re,max] of [['wasmFrames',/^wasm-function\[\d{1,7}\]:(?:0x[0-9a-f]{1,12}|\d{1,12})$/i,12],['jsFrames',/^(?:page|ai|core|diagnostics|current-profile|latest-profile|signatures|signature-profile|signature-profile-latest|dyno|dyno-core|dyno-full|dyno-evaluator|dyno-native|walls|cars|game-worker)\.js:\d{1,7}:\d{1,7}$/,8]]) {
      const a=read(value,key);if(Array.isArray(a))out[key]=a.slice(0,max).filter(v=>typeof v==='string'&&re.test(v));
    }
    return out;
  }
  function create({storage=null,clock=()=>Date.now(),version='0.38.2'}={}) {
    let events=[],drivingSamples=[],dropped=0,persistence=storage?'same-tab':'memory-only',lastSnapshot='',lastSample=0;
    const bursts=new Map();
    const now=()=>{try{const n=clock();return Number.isFinite(n)&&n>=0?Math.floor(n):0;}catch{return 0;}};
    const isDriving=data=>data.ready===true&&data.driving===true&&data.aiActive===true&&data.aiOwned===true;
    const retainDriving=sample=>{
      if(!isDriving(sample.data))return;
      drivingSamples.push(sample);
      while(drivingSamples.length>MAX_DRIVING_SAMPLES||JSON.stringify(drivingSamples).length>MAX_DRIVING_BYTES)drivingSamples.shift();
    };
    const packed=()=>({schema:1,dropped,events,drivingSamples});
    const bound=()=>{while(events.length>MAX_EVENTS || JSON.stringify(packed()).length>MAX_BYTES){events.shift();dropped++;}};
    const persist=()=>{bound();if(storage)try{storage.setItem(KEY,JSON.stringify(packed()));persistence='same-tab';}catch{persistence='memory-only';}};
    try {
      const raw=storage?.getItem(KEY);
      if(typeof raw==='string'&&raw.length<=MAX_BYTES){
        const saved=JSON.parse(raw);
        if(saved?.schema===1&&Array.isArray(saved.events)){
          dropped=Number.isSafeInteger(saved.dropped)&&saved.dropped>=0?saved.dropped:0;
          events=saved.events.slice(-MAX_EVENTS).filter(e=>EVENTS.has(read(e,'event'))).map(e=>({at:number(read(e,'at'),[0,8640000000000000])??0,event:read(e,'event'),data:sanitize(read(e,'data'))}));
          // Historical driving evidence has its own small budget so a few
          // minutes in the menus cannot replace every useful race sample.
          // Revalidate stored values exactly like ordinary event records.
          if(Array.isArray(saved.drivingSamples))for(const e of saved.drivingSamples.slice(-MAX_DRIVING_SAMPLES))retainDriving({at:number(read(e,'at'),[0,8640000000000000])??0,data:sanitize(read(e,'data'))});
          if(!drivingSamples.length)for(const e of events)if(e.event==='state')retainDriving({at:e.at,data:e.data});
        }
      }
    } catch { persistence='memory-only'; }
    const record=(event,data={})=>{try{if(!EVENTS.has(event))return false;const at=now();if(['page-error','promise-rejection','worker-error','engine-error','dyno-error'].includes(event)){const burst=bursts.get(event);if(burst&&at-burst.at<1000){if(burst.count++>=8){dropped++;return false;}}else bursts.set(event,{at,count:1});}const clean=sanitize(data);events.push({at,event,data:clean});if(event==='state')retainDriving({at,data:clean});persist();return true;}catch{return false;}};
    const snapshot=(data={})=>{try{const clean=sanitize(data),stable={...clean};for(const key of MOVING_FIELDS)delete stable[key];const key=JSON.stringify(stable),t=now(),sampleMs=clean.nativeTelemetry||clean.driftRace||clean.forcedDrift||clean.driftVariant?2000:5000;if(lastSnapshot && t-lastSample < (key===lastSnapshot?sampleMs:250))return;lastSnapshot=key;lastSample=t;record('state',clean);}catch{}};
    const exportText=()=>JSON.stringify({format:'NFSU2 Driving Tools local diagnostics',schema:1,exporterVersion:sanitize({version}).version,exportedAt:now(),persistence,dropped,limits:{maxEvents:MAX_EVENTS,maxStoredBytes:MAX_BYTES,maxHistoricalDrivingSamples:MAX_DRIVING_SAMPLES,maxHistoricalDrivingBytes:MAX_DRIVING_BYTES},capture:'Tool selections, sampled game mode/status, bounded power application status, native pace acknowledgement and session-only adaptive planner request/evidence, bounded native controller/skill/input-mode/speed, Drift scoring, sampled NOS clock/timestamp/resource fields and corner evidence, page and game-worker lifecycle, classified errors, bounded tuner rejection codes/counts, numeric wasm locations and known script line numbers. No raw logs, messages, URLs, credentials, saves, names, keyboard input or network traffic. Same-origin page scripts can access this same-tab storage. Browser/tab/GPU failures may prevent a final event; absence of an error does not show that the game was healthy. Not a game crash dump.',historicalDriving:{historical:true,notice:'Previous sampled driving states; not current ownership, a complete route, or proof of a race result.',samples:drivingSamples},events},null,2)+'\n';
    const clear=()=>{events=[];drivingSamples=[];dropped=0;lastSnapshot='';lastSample=0;bursts.clear();record('clear');};
    record('page-start',{version});
    return Object.freeze({record,snapshot,exportText,clear,status:()=>({events:events.length,dropped,persistence})});
  }
  const api=Object.freeze({create,errorInfo,KEY,MAX_EVENTS,MAX_BYTES});
  root.__NFSU2_DIAGNOSTICS__=api;
  if(typeof module==='object'&&module.exports)module.exports=api;
})(globalThis);

# NFSU2 Driving Tools — experimental v0.6.0

A small unpacked Chrome/Edge/Brave extension for **https://nfsu2.xyz/**.

## Install

1. Extract the ZIP to a folder. Keep that folder: the browser loads it from there.
2. Open `chrome://extensions` (Edge: `edge://extensions`).
3. Turn on **Developer mode**, click **Load unpacked**, and select the extracted **NFSU2-Driving-Tools** folder containing `manifest.json`.
4. Reload nfsu2.xyz, then press Play. The Driving tools dropdown appears at the upper right. Click it or press F8 to open it.

Chrome 111+ or a current compatible Chromium browser is required. This package is not a mobile-browser or Firefox build. No build command, Node installation or package dependencies are needed to install it.

Car ghosting is intentionally not included; use the game’s own menu for that.

## Dropdown and saved choices

Click **Driving tools** or press **F8** to open/close the compact dropdown during play. It uses the DFO admin tool’s square green/blue styling, with a narrower **292px** panel. Session mode, Native driver, Power & speed, Handling, Drag racing and Diagnostics start folded; opening one main section closes the previous one. Help text is tucked into optional details. The panel scrolls on small screens, and F7/F9 buttons stay at the top.

Every switch can be enabled independently. AI pace, power, grip and shift RPM use bounded adjustment bars with live numeric values. Tab moves between controls; Space changes switches and arrow keys adjust a focused bar without taking control from AI. Escape closes the dropdown without clearing the choices.

Enabled choices are kept between races, car reloads and normal same-tab page reloads using this site’s session storage. They pause in menus, loading screens, unsupported modes, hidden tabs and lost focus. Online/LAN races pause them unless you enable the separate session opt-in. They resume when a supported driving state returns. Power/grip wait for three matching samples before applying to a rebuilt car and never repeatedly multiply their own changes. Closing the tab ends this session’s saved choices; browser restore behavior can vary. If storage is unavailable, choices remain only until the page reloads.

**F7 / Take control** returns the native AI car to your input on the next game frame. Arrow/WASD keys and Space also switch AI off. These key checks use physical keyboard events, not controller axes; controller users should use F7 or the Take control button. Taking control also pauses synthetic drag throttle until its switch is changed again.

**F9 / Stop is the explicit off switch** for the Online/LAN opt-in, AI, custom AI pace, NOS, power, limiter removal, grip and drag. Diagnostics and native drift stay under their own switches. F9 clears these enabled switches; their selected slider values are retained for later use.

## Opt-in Online/LAN mode

1. Open **Driving tools → Session mode** and read the warning.
2. Turn on **Allow Online/LAN tools** for this page. It starts **OFF after every page reload**, even if it was selected before.
3. Enable the individual tools you want: NOS refill, power, limiter removal, grip, native AI/pace, or drag assistance. The session switch does not enable them by itself; any already-selected compatible tools can resume immediately.
4. **F9 / Stop** disables the session opt-in and driving tools. Turning off only the session switch immediately stops AI and synthetic keys, restores owned power/grip values when the car still exists, and keeps tool selections for solo play. NOS already refilled is not drained on opt-out.

The UI distinguishes selected settings from actual active effects. Online status says **Online/LAN opt-in** or explains that the tools are paused. F7, manual keyboard takeover, focus/visibility pauses, build checks, memory-layout checks and heartbeat fallback still apply.

**Experimental, not live-verified online.** Performance changes can affect other racers, trigger integrity checks, invalidate results or lead to a ban under the server's rules. This option changes only the extension's own Online/LAN guards. It does not change native online flags, networking, server checks, reports, authentication, permissions or access controls, and it provides no detection-avoidance guarantee.

Native drift mode is still free-roam-only because the game itself limits that toggle. Extra grip still pauses in drift. This extension's player-autopilot handoff remains unavailable in drag; its separate drag assist supplies throttle and shifts, and you must steer.

## Try native AI first

1. Replace the old extension folder, reload its card, then reload nfsu2.xyz. Check version **0.6.0**.
2. Start a solo non-drag race or move into free roam yourself. Open **Driving tools** or press **F8**, then expand **Native driver**.
3. Enable **AI driver · level 9**. Wait for **Native game AI driving · level 9** to confirm the actual driver changed.
4. Press **F7** or **Take control** to return to manual driving. The dropdown can remain open while driving.
5. Start with ordinary power/grip, then try your independent power, NOS and handling switches. Higher power can make native AI crash more often; no win is guaranteed.
6. To experiment with its target speed, enable **Custom AI pace** and adjust **AI pace factor**. Start at **1.00×**. A higher factor may worsen cornering and cause crashes; a lower factor is not a cornering fix. The switch does not enable the AI driver by itself.

Native AI is **off after every page reload**, regardless of saved choices. Within the same page its requested setting can resume after a supported race/car transition. It pauses while unfocused, hidden, in menus or unsupported modes; Online/LAN requires the session opt-in. If the page stops updating the command bridge, it gives control back within 180 game frames. A broken/frozen game cannot process a takeover; disable the extension and reload if necessary.

## Switches

- **AI driver · level 9:** hands the player’s car to the game’s own `Player::AutoPilotOn`, then uses `AutoPilotOff` and `SetInputMode(2)` to return control. Uses the highest normal native skill value, **9**, only for your racer; restores your original skill when the same racer still exists. Special skill sentinels are left unchanged and are not reported as level 9. Non-drag races and free roam, one local player. Online/LAN requires the session opt-in and has not been live-verified. Native free-roam driving is backed by upstream game tests, but route selection and obstacle avoidance are not guaranteed. This does not select events, enter/restart races, buy upgrades, complete career menus or follow a chosen GPS destination. It can become stuck. "Expert" is not claimed as an official name for numeric skill 9. NOS refill, power, limiter and grip remain independently usable. This extension’s player-autopilot handoff is suspended in drag races because that handoff has not been verified there. This does not mean the game lacks drag-opponent AI. If you separately enable drag assist, it waits for native AI to release ownership and for the car’s human driver to be confirmed before sending throttle or shift keys. Native AI chooses its own nitrous use; refilling does not force it to activate NOS.

- **Custom AI pace:** opt-in **0.75×–1.50×** adjustment of the native AI’s freshly calculated target-speed factor, with **1.00×** as the unchanged default. This is not an actual-speed multiplier, an engine-power change or improved steering. Higher values can make corners worse and cause crashes; lower values do not guarantee safe cornering. Applies only while this extension’s native AI is driving. The status distinguishes a selected/requested factor from a factor confirmed by the game hook. The pace choice and value are saved in the same tab, but AI itself still starts off after reload. F7 stops AI while leaving the pace choice dormant; F9 also clears the pace switch. Existing power, grip and NOS controls remain independent.

- **Unlimited NOS:** repeatedly refills the equipped nitrous kit while driving. It does not install a missing kit or change its capacity. Experimental memory implementation, pinned to game build `6f4f1e4e`. Paused in Online/LAN races unless the session opt-in is on. A new game build disables memory tools instead of trying unknown offsets.
- **Engine power boost:** 1.0×–3.0× engine and nitrous torque, with 1.5× as the starting value. This increases power, not the game clock or the speedometer. The original curve is kept, so repeated updates do not multiply power again. More power can cause wheelspin and worse handling. Pause, losing focus, F9 or disabling it restores fields still owned by the extension. If the game rebuilds the tuning, the effect pauses and resumes after the new baseline settles. The selected switch stays enabled.
- **Remove stock speed limiter:** removes the stock MPH governor while enabled. Cars with an ECU upgrade may already have no governor, so this can make no difference. Gearing, redline, drag and available power still limit actual top speed. It does not add gears, change ratios or guarantee a particular speed.
- **Extra grip:** multiplies all four wheels’ actual tyre-force factors by **1.0×–2.0×**, starting at **1.3×**. It can increase cornering traction and reduce sliding, but it does not auto-steer, damp yaw, flatten the car, avoid crashes or guarantee perfect handling. High grip can cause abrupt handling or rollover, especially with extra power. 1.0× restores the baseline. It pauses in drift mode/races because drift deliberately changes rear grip. Changes are restored when paused/off where the original car and wheel objects still exist. No save-file or shared car-type data is edited.
- **Drift assist:** sends the game’s dedicated drift key directly through its version-checked input mailbox, replacing the earlier hidden-touch-control click. This uses the real drift-event handling and your Drift tuning, its built-in drift assist, camera and scoring. The game restores ordinary tuning when disabled. Solo free roam only; close game menus first. It now waits up to three seconds for the game’s actual drift-handling flag before reporting ON, and shows a useful failure message if not confirmed. The game’s mode is unavailable in ordinary races and co-op. Power/limiter/grip effects pause and restore before a drift toggle so the game can rebuild its tuning cleanly; enabled choices are retained. Power can resume afterward, while grip stays paused during drift. **This is not perfect-drift automation and does not guarantee a score, line or spin prevention.**
- **Drag assist:** experimental automatic throttle, RPM-threshold upshifts and NOS when the NOS switch is on. Start a drag race yourself and enable this separate switch; Online/LAN also needs its session opt-in. The native player-autopilot handoff is not verified for drag. Throttle can pre-rev during the countdown once the driving HUD is active. Shifts and NOS wait until racing begins. It uses default bindings: Arrow Up, Left Shift, Left Alt. Set the shift RPM to suit the car; 6500 is only a starting point, not a learned perfect-shift value. **You must steer. It does not change lanes, avoid traffic/obstacles, prevent damage or finish races by itself.** Steering during drag does not disable this assist just because the native-AI switch remains selected for other races. F7 pauses assisted throttle until you toggle drag assist again. It pauses in menus, on loss of focus, and when the tab is hidden. Its switch stays enabled; F9 explicitly turns it off. It does not handle race selection or restart.
- **Traffic / barrier tester:** opt-in read-only diagnostic using the game's live car objects and enabled barrier-line table. It reports a nearby car ahead and a barrier crossing the car's forward line. It does not alter driving or send diagnostics anywhere. **It is not a complete obstacle detector:** car objects are not classified as traffic versus racers, parked/inactive objects may appear, and scenery, props, trucks' shapes, road geometry, elevation-sensitive barriers and safe lanes are not comprehensively modeled. “No object detected” never means the road is safe.

The dropdown can stay open while you drive. Its scroll area keeps all controls reachable on smaller screens.

## Testing status and cautions

The site, its public source and exact served game module were inspected. All 77 v0.6 automated tests passed. The suite includes opt-in/off behavior for every network flag, native AI/pace permission forwarding, opt-out restoration, session-reset behavior, manual stop and online drag key release. Automated tests cover refill logic, missing kits, pause/network guards, invalid/stale pointers, memory growth, read-only hazard extraction, bounded traversal, status-table reading, non-compounding power scaling, guarded restoration drift-input ring formatting/guards, wheel grip restoration, dropdown keyboard/click actions, focus pauses, race/car transitions, rebuild reapplication and same-tab settings restoration. UI tests also cover slider bounds, numeric outputs, opt-in pace forwarding, saved pace choices, F7/F9 behavior and keyboard use within the menu. Additional AI tests validate the actual injected WebAssembly bridge with simulated native calls, highest-skill save/restore, correct return-to-input calls, failed-handoff behavior, stale-heartbeat fallback, unsupported/network guards, car replacement and user takeover. UI tests use a simulated DOM, not live gameplay.

**You reported that NOS and the traffic/barrier tester work, and that native AI drives in free roam but cuts corners and is slow. In drag, it applied throttle and then stopped. The new pace adjustment and drag-routing/countdown fixes have not been live-verified.** New grip/transition behavior, power/limiter controls and the repaired drift path also remain experimental. Pace adjustment is not a verified cornering improvement. The v0.6 browser-layout check could not launch Chromium because this environment denied socket creation; no live gameplay or online race was run. You asked to test gameplay yourself. These are source-backed experimental implementations, not a promise that all functions work in a live race.

## Updating from an earlier package

Extract this package into your existing extension folder, click Reload on its card in `chrome://extensions`, then reload the game. The card must show version **0.6.0**. If you load a separate new folder, remove/disable the old extension first so two copies cannot run together.

Back up your save with the game's Download backup button before trying it. Follow the site's rules; Online/LAN modifications can affect other racers and trigger integrity checks or moderation. Prefer solo play or an explicitly permitted private test. The page's main thread writes shared game memory asynchronously for NOS, power and grip changes, so crashes or inconsistent behavior remain possible. If anything behaves oddly, disable the extension and reload the game. Memory changes do not survive reload; enabled choices are restored from same-tab session storage as described above.

This extension only matches `https://nfsu2.xyz/*`. It has no account, browsing-history, extension-storage, debugger or broad website permissions. It saves only its own switch/number preferences in a namespaced session-storage entry on this site. The only request it creates is a same-origin read of `/game.json` to check compatibility. At game loading, it also inspects the module response the game already fetched, checks its full SHA-256, and adds its own main-loop handoff bridge and player-only AI target-speed hook before compilation. This can add startup time and does not modify the site's files or bypass build checks. The extension package contains no game executable/assets, remote executable code, analytics or update downloader. If the hash or layout is different, it loads the unchanged game and leaves AI disabled.

## Native AI implementation notes

- Supported module revision: `6f4f1e4e`, exact original size `37839055` bytes.
- Required SHA-256: `ee5d281a3109240d5db25dc3921e1044672cf6d650eb58c3baa089b54fe2941f`.
- The handoff bridge runs only at the documented `0x581475` main-loop call of `sub_004022c0`, through the existing CPU-preserving `gcall_main`. It does not invoke game functions concurrently from the page thread or enable the upstream test-script mode.
- The pace hook preserves the port’s `sub_004172d0` wrapper: save the original driver, call `sub_004172d0_orig`, then call `catchup_apply`. Only afterward, for this extension’s still-owned player driver, it multiplies the freshly computed `driver+0x770` target-speed factor by 0.75–1.50. At 1.00 it leaves the field unchanged. Native recomputation prevents compounding. It does not alter `vehicle+0x468` (native power/grip catchup), steering, road paths or other AI cars. Its layout is confirmed by `vehicle+0x2c → driver` and `driver+4 → vehicle`.
- Both game-thread hooks reject the drag-race byte at `0x89e7d8`. Entering drag releases an owned AI driver through the same native Off/SetInputMode calls. The separate page drag assist waits for driver type 1 and cleared AI ownership.
- The page publishes its explicit Online/LAN opt-in as command word `+84`, under the same sequence lock as the other commands. Both native hooks require the exact value `1` to allow network state; other state/layout/ownership checks stay intact. Stop clears that word. The revised handshake rejects older command layouts.
- The exact served module passes validation and compilation after the two-function patch. Tests verify that all other function bodies and module sections remain byte-for-byte unchanged. These are code-level checks, not live gameplay validation.
- An 88-byte command/status area at `0x00d0d100` is in the already committed split-screen scratch region, outside the inspected split-screen, minimap-diagnostic and co-op records. Exact-module hashing guards these assumptions.
- Player-car skill path: `Player+4 → vehicle`, `vehicle+0x14 → racer`, `racer+0x901 → skill byte`. The AI driver’s skill virtual getter (`vtable 0x785370 + 0x78 → 0x402580 → 0x610510`) reads this byte. The global force-skill setting is never modified.
- This is experimental client-side code. Keep your working v0.5 folder/ZIP for rollback. No game binary is included in this package.

## Source references

Inspected game metadata: https://nfsu2.xyz/game.json, revision `6f4f1e4e`.
Public source: https://github.com/th0mk/nfsu2-web/tree/6f4f1e4e92f5f3ddf6f6d165b7f7075a95ab7fe3

- `runtime/career.c`: real native autopilot On/Off and return-to-input calls; main-loop hook.
- `runtime/guest.h`: CPU-preserving `gcall_main`.
- `runtime/racenet.c`, `web/src/net/index.ts`: locally simulated car-state exchange over the virtual LAN.
- `web/server-rs/crates/anticheat`: shared race-integrity checks.
- `tests/scripts/mprace_lobby_a.txt`: player autopilot used in a non-drag LAN test, not proof of live extension compatibility.
- `runtime/catchup.c`: native skill endpoints 0 and 9, AI update wrapper and target-speed factor at driver offset `0x770`.
- `tests/scripts/mprace_drag_a.txt`: uses synthetic input instead of player autopilot for its drag test; it does not establish the absence of drag-opponent AI.
- `runtime/web/status_web.c`: drag’s manual gearbox and race-type byte.
- `runtime/game.h`: race states 3 (countdown), 4 (driving) and 6 (paused).
- `tests/scripts/roam_keepright_a.txt`: native autopilot used in free roam.
- `runtime/cpu.h`: guest addresses equal WebAssembly linear-memory addresses.
- `runtime/splitscreen_mem.h`: the browser build's player array is at `0x00d00000`.
- `runtime/game.h`: game state, race, car RPM and gear.
- `runtime/mprace.c` (`perf_info`, `mprace_torque_scale`, `mprace_speed_limit`): the actual per-car torque curve, nitrous torque and MPH governor.
- `runtime/roam_game.c` (`nos_left`): nitrous duration, amount left, activation time and game clock.
- `web/src/host/process.ts`: game worker initialization and shared memory.
- `runtime/web/status_proto.h`, `web/src/app/status.ts`: self-describing status counters.
- `web/src/input/proto.ts`, `runtime/web/input_web.c`: versioned input mailbox and synthetic key-tap event.
- `web/src/app/touch.ts`, `runtime/drift.c`: native drift input, full handling/tuning lifecycle, wheel-pointer layout and tyre-force multiplier (WH_GRIP).
- `runtime/roam.c` (`log_cars`): world car list and coordinate fields.
- `runtime/walls.c`: enabled barrier lines and their segment coordinates.

No files in the upstream project were modified. This is an unofficial extension, not affiliated with the game's site or Electronic Arts.

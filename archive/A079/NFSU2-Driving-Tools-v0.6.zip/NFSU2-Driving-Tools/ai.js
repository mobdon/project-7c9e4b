/* Native game AI bridge, pinned to one exact module. All injected instructions are
 * authored here; game bytes are obtained only by the game's own normal loader.
 * See tools/ai-bridge.wat and README for the source-backed handoff and skill path. */
(function (root) {
  'use strict';
  if (root.__NFSU2_AI__) return;
  const BASE=0xd0d100, MAGIC=0x3549414e;
  const HASH='ee5d281a3109240d5db25dc3921e1044672cf6d650eb58c3baa089b54fe2941f';
  const SIZE=37839055, TARGET=21213-37, PACE_TARGET=21262-37;
  const BRIDGE=Uint8Array.from([13,4,127,1,125,1,127,1,124,11,127,1,123,3,127,1,124,5,127,1,123,1,127,1,123,10,127,2,64,32,0,40,2,16,40,2,0,65,245,168,224,2,71,13,0,65,156,162,195,6,65,206,130,165,170,3,54,2,0,65,128,162,195,6,40,2,0,65,206,130,165,170,3,71,13,0,65,152,162,195,6,40,2,0,33,37,65,176,162,195,6,40,2,0,65,1,106,33,38,32,37,65,172,162,195,6,40,2,0,71,4,64,65,0,33,38,11,65,172,162,195,6,32,37,54,2,0,65,176,162,195,6,32,38,54,2,0,65,132,162,195,6,40,2,0,33,36,32,36,65,1,113,32,38,65,180,1,73,113,13,0,65,128,128,192,6,40,2,0,33,32,65,152,130,164,4,40,2,0,33,34,65,0,33,33,65,0,33,40,65,0,33,35,2,64,65,164,169,153,4,40,2,0,65,6,71,13,0,32,32,65,128,128,4,79,32,32,65,128,224,255,191,2,73,113,69,13,0,32,32,40,2,4,33,33,32,33,65,128,128,4,79,32,33,65,128,224,255,191,2,73,113,69,13,0,32,33,40,2,36,33,40,32,34,65,128,128,4,79,32,34,65,128,224,255,191,2,73,113,69,13,0,32,32,40,2,16,65,0,71,13,0,65,176,128,192,6,40,2,0,65,1,71,13,0,32,34,40,2,0,65,4,71,13,0,65,212,162,195,6,40,2,0,65,1,71,4,64,65,248,128,148,4,40,2,0,65,136,4,113,13,1,65,148,212,153,4,40,2,0,13,1,65,244,211,153,4,40,2,0,13,1,65,233,158,167,4,45,0,0,13,1,11,65,216,207,167,4,45,0,0,13,0,32,38,65,179,1,75,13,0,32,36,65,1,113,13,0,65,140,162,195,6,40,2,0,32,32,71,13,0,65,144,162,195,6,40,2,0,32,33,71,13,0,65,148,162,195,6,40,2,0,32,34,71,13,0,65,136,162,195,6,40,2,0,65,1,79,65,136,162,195,6,40,2,0,65,2,77,113,33,35,32,36,65,132,162,195,6,40,2,0,71,4,64,65,0,33,35,11,11,65,164,162,195,6,40,2,0,33,39,32,39,4,64,32,35,65,160,162,195,6,40,2,0,32,32,70,32,39,32,33,70,65,168,162,195,6,40,2,0,32,34,70,32,40,65,3,70,113,113,113,113,69,4,64,65,164,169,153,4,40,2,0,65,6,70,32,33,65,128,128,4,79,32,33,65,128,224,255,191,2,73,113,65,160,162,195,6,40,2,0,32,32,70,32,39,32,33,70,113,113,113,4,64,65,192,162,195,6,40,2,0,65,128,128,4,79,65,192,162,195,6,40,2,0,65,128,224,255,191,2,73,113,32,33,40,2,20,65,192,162,195,6,40,2,0,70,113,4,64,65,192,162,195,6,40,2,0,45,0,129,18,65,9,70,4,64,65,192,162,195,6,40,2,0,65,196,162,195,6,40,2,0,58,0,129,18,11,11,32,40,65,3,70,4,64,32,0,65,144,222,254,2,32,32,65,0,65,0,16,221,169,1,65,184,162,195,6,65,2,54,2,0,32,0,65,240,184,129,3,32,32,65,1,65,184,162,195,6,16,221,169,1,11,11,65,160,162,195,6,65,0,54,2,0,65,164,162,195,6,65,0,54,2,0,65,168,162,195,6,65,0,54,2,0,65,192,162,195,6,65,0,54,2,0,65,180,162,195,6,65,0,54,2,0,65,204,162,195,6,65,0,54,2,0,65,208,162,195,6,65,0,54,2,0,65,0,33,40,11,11,65,136,162,195,6,40,2,0,69,4,64,65,200,162,195,6,65,0,54,2,0,11,32,35,65,164,162,195,6,40,2,0,69,113,4,64,32,40,65,1,70,65,200,162,195,6,40,2,0,32,33,71,113,4,64,32,33,40,2,20,33,41,32,41,65,128,128,4,79,32,41,65,128,224,255,191,2,73,113,4,64,32,41,45,0,129,18,65,9,77,4,64,65,192,162,195,6,32,41,54,2,0,65,196,162,195,6,32,41,45,0,129,18,54,2,0,32,41,65,9,58,0,129,18,11,11,32,0,65,160,220,254,2,32,32,65,0,65,0,16,221,169,1,32,33,40,2,36,65,3,70,4,64,65,160,162,195,6,32,32,54,2,0,65,164,162,195,6,32,33,54,2,0,65,168,162,195,6,32,34,54,2,0,65,180,162,195,6,65,1,54,2,0,5,65,192,162,195,6,40,2,0,65,128,128,4,79,65,192,162,195,6,40,2,0,65,128,224,255,191,2,73,113,32,33,40,2,20,65,192,162,195,6,40,2,0,70,113,4,64,65,192,162,195,6,40,2,0,45,0,129,18,65,9,70,4,64,65,192,162,195,6,40,2,0,65,196,162,195,6,40,2,0,58,0,129,18,11,11,65,192,162,195,6,65,0,54,2,0,65,200,162,195,6,32,33,54,2,0,65,180,162,195,6,65,3,54,2,0,11,11,11,11,11]);
  const PACE=Uint8Array.from([2,6,127,1,125,32,0,40,2,4,33,1,32,0,16,154,126,32,1,16,141,166,1,2,64,65,128,162,195,6,40,2,0,65,206,130,165,170,3,71,13,0,65,156,162,195,6,40,2,0,65,206,130,165,170,3,71,13,0,65,132,162,195,6,40,2,0,33,5,32,5,65,1,113,13,0,65,176,162,195,6,40,2,0,65,180,1,79,13,0,65,136,162,195,6,40,2,0,65,1,79,65,136,162,195,6,40,2,0,65,2,77,113,69,13,0,65,180,162,195,6,40,2,0,65,1,71,13,0,65,164,169,153,4,40,2,0,65,6,71,13,0,65,176,128,192,6,40,2,0,65,1,71,13,0,65,212,162,195,6,40,2,0,65,1,71,4,64,65,248,128,148,4,40,2,0,65,136,4,113,13,1,65,148,212,153,4,40,2,0,13,1,65,244,211,153,4,40,2,0,13,1,65,233,158,167,4,45,0,0,13,1,11,65,216,207,167,4,45,0,0,13,0,65,128,128,192,6,40,2,0,33,2,32,2,65,128,128,4,79,32,2,65,128,224,255,191,2,73,32,2,173,63,0,173,66,16,134,66,128,32,125,84,113,113,69,13,0,32,2,65,160,162,195,6,40,2,0,71,13,0,32,2,65,140,162,195,6,40,2,0,71,13,0,32,2,40,2,16,13,0,32,2,40,2,4,33,3,32,3,65,128,128,4,79,32,3,65,128,224,255,191,2,73,32,3,173,63,0,173,66,16,134,66,128,32,125,84,113,113,69,13,0,32,3,65,164,162,195,6,40,2,0,71,13,0,32,3,65,144,162,195,6,40,2,0,71,13,0,32,3,40,2,36,65,3,71,13,0,32,1,65,128,128,4,79,32,1,65,128,224,255,191,2,73,32,1,173,63,0,173,66,16,134,66,128,32,125,84,113,113,69,13,0,32,3,40,2,44,32,1,71,13,0,32,1,40,2,4,32,3,71,13,0,65,152,130,164,4,40,2,0,33,4,32,4,65,128,128,4,79,32,4,65,128,224,255,191,2,73,32,4,173,63,0,173,66,16,134,66,128,32,125,84,113,113,69,13,0,32,4,65,168,162,195,6,40,2,0,71,13,0,32,4,65,148,162,195,6,40,2,0,71,13,0,32,4,40,2,0,65,4,71,13,0,65,188,162,195,6,40,2,0,33,6,32,6,65,203,0,79,32,6,65,150,1,77,113,69,13,0,32,1,42,2,240,14,33,7,32,7,67,0,0,0,0,96,32,7,67,0,0,128,64,95,113,69,13,0,32,5,65,132,162,195,6,40,2,0,71,13,0,32,6,65,228,0,71,4,64,32,1,32,7,32,6,179,67,0,0,200,66,149,148,56,2,240,14,11,65,204,162,195,6,32,6,54,2,0,65,208,162,195,6,65,208,162,195,6,40,2,0,65,1,106,54,2,0,11,11]);
  const patchState={phase:'idle',reason:'Waiting for game module.'};
  const patched=new WeakSet();
  let installed=false;
  const read=(b,p)=>{let value=0,shift=0,x;do{if(p.i>=b.length || shift>28)throw Error('Invalid module integer');x=b[p.i++];value|=(x&127)<<shift;shift+=7;}while(x&128);return value>>>0;};
  const leb=n=>{const a=[];do{let v=n&127;n>>>=7;if(n)v|=128;a.push(v);}while(n);return Uint8Array.from(a);};
  function join(...parts){const out=new Uint8Array(parts.reduce((n,b)=>n+b.length,0));let p=0;for(const b of parts){out.set(b,p);p+=b.length;}return out;}
  function locals(b){const p={i:0},n=read(b,p),types=[];for(let i=0;i<n;i++){const count=read(b,p),type=b[p.i++];if(count>10000)throw Error('Invalid local count');for(let k=0;k<count;k++)types.push(type);}return {end:p.i,types};}
  async function patchBytes(input) {
    const bytes=input instanceof Uint8Array ? input : new Uint8Array(input);
    if(bytes.length!==SIZE)throw Error('Game module size changed. Native AI disabled.');
    const hash=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes)),b=>b.toString(16).padStart(2,'0')).join('');
    if(hash!==HASH)throw Error('Game module changed. Native AI disabled.');
    const p={i:8};let output=null;
    while(p.i<bytes.length){
      const start=p.i,id=bytes[p.i++],size=read(bytes,p),bodyStart=p.i,end=bodyStart+size;
      if(end>bytes.length)throw Error('Invalid module section');
      if(id===10){
        const n=read(bytes,p),pieces=[bytes.subarray(bodyStart,p.i)];let changed=0;
        for(let i=0;i<n;i++){
          const sizeAt=p.i,bodyLen=read(bytes,p),fnStart=p.i,fnEnd=fnStart+bodyLen;
          if(fnEnd>end)throw Error('Invalid game function');
          if(i===TARGET){
            const old=bytes.subarray(fnStart,fnEnd),a=locals(old),b=locals(BRIDGE);
            if(a.types.length!==31 || b.types.length!==41 || a.types.some((v,k)=>v!==b.types[k]) || old[old.length-1]!==11 || BRIDGE[BRIDGE.length-1]!==11)
              throw Error('Native AI hook layout changed.');
            const fn=join(BRIDGE.subarray(0,BRIDGE.length-1),old.subarray(a.end));
            pieces.push(leb(fn.length),fn);changed++;
          }else if(i===PACE_TARGET){
            const old=bytes.subarray(fnStart,fnEnd);
            if(locals(old).types.length!==1 || old[old.length-1]!==11 || PACE[PACE.length-1]!==11)
              throw Error('Native AI pace hook layout changed.');
            pieces.push(leb(PACE.length),PACE);changed++;
          }else pieces.push(bytes.subarray(sizeAt,fnEnd));
          p.i=fnEnd;
        }
        if(changed!==2 || p.i!==end)throw Error('Native AI hooks were not found.');
        const section=join(...pieces);
        output=join(bytes.subarray(0,start),Uint8Array.of(10),leb(section.length),section,bytes.subarray(end));
        break;
      }
      p.i=end;
    }
    if(!output)throw Error('Native AI hook was not found.');
    return output;
  }
  function install() {
    if(installed || typeof WebAssembly.compileStreaming!=='function')return;
    installed=true;
    const nativeStreaming=WebAssembly.compileStreaming, nativeCompile=WebAssembly.compile;
    WebAssembly.compileStreaming=async function(source,options){
      const response=await source;
      let url;try{url=new URL(response.url);}catch{return nativeStreaming.call(WebAssembly,response,options);}
      if(url.origin!==location.origin || url.pathname!=='/game.wasm')return nativeStreaming.call(WebAssembly,response,options);
      patchState.phase='preparing';patchState.reason='Preparing native AI bridge.';
      try{
        const bytes=await response.clone().arrayBuffer();
        const changed=await patchBytes(bytes);
        const module=await nativeCompile.call(WebAssembly,changed,options);
        patched.add(module);patchState.phase='ready';patchState.reason='Native AI bridge loaded.';
        return module;
      }catch(e){
        patchState.phase='unavailable';patchState.reason=String(e?.message || 'Native AI could not be prepared.');
        // Fail open to the unchanged game, closed to AI control. Other tools remain available.
        return nativeStreaming.call(WebAssembly,response,options);
      }
    };
  }
  class Controller {
    constructor(memory,available=false){this.memory=memory;this.available=!!available;this.hb=0;this.words=null;this.view=null;}
    refresh(){const b=this.memory.buffer;if(!this.view || this.view.buffer!==b){this.view=new DataView(b);this.words=new Int32Array(b);}return b.byteLength>=BASE+88;}
    u32(p){return p>=0x10000 && p+4<=Math.min(this.view.byteLength,0x28000000)?this.view.getUint32(p,true):0;}
    read(off){return Atomics.load(this.words,(BASE+off)/4)>>>0;}
    write(off,v){Atomics.store(this.words,(BASE+off)/4,v|0);}
    publish(wanted=0,player=0,car=0,race=0,pace=1,allowNetwork=false){
      if(!this.available || !this.refresh() || this.read(28)!==MAGIC)return false;
      let seq=this.read(4);if(seq&1)seq++;
      this.write(4,seq+1);this.write(0,MAGIC);this.write(8,wanted);this.write(12,player);this.write(16,car);this.write(20,race);
      this.write(60,Number.isFinite(pace) && pace>=0.75 && pace<=1.5 ? Math.round(pace*100) : 100);
      this.write(84,allowNetwork === true ? 1 : 0);this.write(24,++this.hb);this.write(4,seq+2);return true;
    }
    stop(){this.publish(0);return this.status();}
    update({enabled=false,safe=false,state=null,mode=0,pace=1,allowNetwork=false}={}){
      this.refresh();
      const player=this.u32(0xd00000);
      const wanted=!!enabled && !!safe && state?.ready && state.driving && (!state.network || allowNetwork === true) && !state.drag && (mode===1 || mode===2) && this.u32(player+4)===state.car;
      this.publish(wanted?mode:0,player,state?.car||0,state?.race||0,pace,allowNetwork);
      return this.status();
    }
    status(){
      if(!this.available)return {available:false,ready:false,active:false,level:null,status:'unavailable',reason:patchState.reason==='Waiting for game module.'?'Reload the game after updating the extension.':patchState.reason};
      if(!this.refresh() || this.read(28)!==MAGIC)return {available:true,ready:false,active:false,level:null,status:'waiting',reason:'Waiting for the native game loop.'};
      const owned=this.read(36),player=this.u32(0xd00000),car=this.u32(player+4),code=this.read(52);
      const active=!!owned && owned===car && this.read(32)===player && this.u32(car+0x24)===3 && code===1;
      const rec=active?this.u32(car+0x14):0,drag=!!this.view.getUint8(0x89e7d8),manual=!!car && this.u32(car+0x24)===1;
      const level=rec>=0x10000 && rec+0x902<Math.min(this.view.byteLength,0x28000000)?this.view.getUint8(rec+0x901):null;
      return {available:true,ready:true,active,owned:!!owned,manual,dragUnsupported:drag,level,paceRequested:this.read(60)/100,paceApplied:active && this.read(80) && this.read(76)>=75 && this.read(76)<=150 ? this.read(76)/100 : null,status:drag?'unsupported':active?'active':code===3?'failed':'ready',reason:drag?'This player-autopilot handoff is unverified for drag races. Use drag assist and steer.':active?`Native game AI driving${level===9?' · level 9':' · unusual skill value left unchanged'}.`:code===3?'The game did not hand over the car. Turn AI off before retrying.':'Ready for non-drag races or free roam; online needs its own opt-in.'};
    }
  }
  const api={Controller,install,patchState,isPatchedModule:module=>patched.has(module),patchBytes,BASE,MAGIC};
  root.__NFSU2_AI__=api;
  if(typeof module==='object' && module.exports)module.exports=api;
})(globalThis);

(() => {
  'use strict';
  if (location.origin !== 'https://nfsu2.xyz' || window.top !== window || window.__nfsu2DrivingTools) return;
  Object.defineProperty(window, '__nfsu2DrivingTools', { value: true });
  const AI = globalThis.__NFSU2_AI__;
  AI?.install();
  let ai = null, dragTakenOver = false, dragRace = false;
  const { Engine, StableGate, supportedRevision } = globalThis.__NFSU2_DRIVING_CORE__;
  delete globalThis.__NFSU2_DRIVING_CORE__;
  let engine = null, statusPtr = 0, inputPtr = 0, supported = false, revision = '', visible = false;
  let host, ui, note, live, timer, driftPending = null, driftNeedsReapply = false;
  const powerGate=new StableGate(), gripGate=new StableGate();
  let lastShift = 0, shiftTimer = 0, lastPulse = 0, lastScan = 0;
  const held = new Set(), physicallyHeld = new Set();
  const prefs = { online: false, ai: false, aiPace: false, paceFactor: 1, nos: false, drag: false, rpm: 6500, tester: false, boost: false, power: 1.5, unlimit: false, grip: false, gripFactor: 1.3, drift: null };
  const STORAGE_KEY='nfsu2-driving-tools-v1';
  try {
    const saved=JSON.parse(sessionStorage.getItem(STORAGE_KEY)||'null');
    if(saved && typeof saved==='object') {
      for(const name of ['aiPace','nos','drag','tester','boost','unlimit','grip']) if(typeof saved[name]==='boolean') prefs[name]=saved[name];
      for(const [name,min,max] of [['paceFactor',0.75,1.5],['rpm',3000,10000],['power',1,3],['gripFactor',1,2]]) if(Number.isFinite(saved[name])) prefs[name]=Math.max(min,Math.min(max,saved[name]));
      if(typeof saved.drift==='boolean') prefs.drift=saved.drift;
    }
  } catch { /* storage disabled: choices still persist between races in this page */ }
  const savePrefs=()=>{try{sessionStorage.setItem(STORAGE_KEY,JSON.stringify(prefs));}catch{}};
  const message = text => { if (note) note.textContent = text; };
  const NativeWorker = window.Worker;
  // Observe only the known game worker; AI validates its patched module separately.
  window.Worker = new Proxy(NativeWorker, {
    construct(Target, args, NewTarget) {
      const worker = Reflect.construct(Target, args, NewTarget);
      let url; try { url = new URL(String(args[0]), location.href); } catch { return worker; }
      if (url.origin !== location.origin || url.pathname !== '/host/game-worker.js') return worker;
      const send = worker.postMessage;
      worker.postMessage = function (m, ...rest) {
        if (m && m.mod instanceof WebAssembly.Module && m.memory instanceof WebAssembly.Memory && m.slot === 0) {
          if (!engine || engine.memory !== m.memory) { ai?.stop(); ai = AI?.Controller ? new AI.Controller(m.memory, AI.isPatchedModule(m.mod)) : null; engine = new Engine(m.memory); statusPtr = 0; inputPtr = 0; driftPending = null; driftNeedsReapply=typeof prefs.drift==='boolean'; powerGate.reset(); gripGate.reset(); }
        }
        return Reflect.apply(send, this, [m, ...rest]);
      };
      worker.addEventListener('message', event => {
        const m = event.data;
        if (m?.t === 'register' && m.kind === 3 && Number.isSafeInteger(m.ptr)) inputPtr = m.ptr;
        if (m?.t === 'register' && m.kind === 5 && Number.isSafeInteger(m.ptr)) statusPtr = m.ptr;
        if (m?.t === 'exit' || m?.t === 'trap') {suspend('Game stopped. Enabled choices are kept for the next game.');ai=null;engine=null;statusPtr=0;inputPtr=0;}
      });
      return worker;
    }
  });
  // A different game revision must be reviewed before writing its memory.
  fetch('/game.json', { cache: 'no-store', credentials: 'omit' }).then(r => {
    if (!r.ok) throw new Error('Build information unavailable');
    return r.json();
  }).then(info => {
    revision = String(info.rev || 'unknown'); supported = revision === supportedRevision;
    if (!supported) message('Game updated: memory tools disabled until this extension is updated.');
  }).catch(() => message('Could not check game version. Memory tools stay disabled.'));

  function key(code, down) {
    const keyName = { ArrowUp: 'ArrowUp', ShiftLeft: 'Shift', AltLeft: 'Alt' }[code] || code;
    window.dispatchEvent(new KeyboardEvent(down ? 'keydown' : 'keyup', { code, key: keyName,
      location: /Left$/.test(code) ? 1 : 0, bubbles: true, cancelable: true }));
  }
  function hold(code, down) {
    if (down && !held.has(code)) { if (!physicallyHeld.has(code)) { held.add(code); key(code, true); } }
    else if (!down && held.delete(code) && !physicallyHeld.has(code)) key(code, false);
  }
  function release() { clearTimeout(shiftTimer); for (const code of [...held]) hold(code, false); }
  function suspend(why) {
    ai?.stop(); release(); powerGate.reset(); gripGate.reset();
    try {if(engine){const state=engine.state();engine.restorePerformance(state);engine.restoreGrip(state);}} catch { /* no stale pointer writes */ }
    if(why) message(why);
  }
  function stop(why = 'Driving controls off. F9 cleared driving assists and the Online/LAN opt-in.') {
    prefs.online=false;prefs.ai=false;prefs.aiPace=false;prefs.nos=false;prefs.drag=false;prefs.boost=false;prefs.unlimit=false;prefs.grip=false;savePrefs();suspend();
    if(ui) for(const id of ['online','ai','ai-pace','nos','drag','boost','unlimit','grip']) ui.querySelector('#'+id).checked=false;
    message(why);
  }
  function takeControl() {
    prefs.ai=false; ai?.stop(); dragTakenOver=true; release(); savePrefs();
    if(ui) {ui.querySelector('#ai').checked=false;ui.querySelector('#ai-state').textContent='Manual control · native AI off';}
    message('Returning control to you. Native AI is off on the next game frame. Toggle drag assist again if you want assisted throttle.');
  }
  window.addEventListener('keydown', e => {
    if (!e.isTrusted) return;
    // Range controls keep their native arrow/Space behavior without taking over the car.
    if(host && e.composedPath?.().includes(host) && !['F7','F8','F9','Escape'].includes(e.code)) return;
    physicallyHeld.add(e.code);
    if(e.code==='F7') {e.preventDefault();takeControl();}
    else if(prefs.ai && !dragRace && ['ArrowLeft','ArrowRight','ArrowUp','ArrowDown','KeyW','KeyA','KeyS','KeyD','Space'].includes(e.code)) takeControl();
    if (e.code === 'F8') { e.preventDefault(); setPanel(!visible); }
    if (e.code === 'Escape' && visible) setPanel(false);
    if (e.code === 'F9') { e.preventDefault(); stop(); }
  }, true);
  window.addEventListener('keyup', e => { if (e.isTrusted) physicallyHeld.delete(e.code); }, true);
  window.addEventListener('blur', () => { physicallyHeld.clear(); suspend('Paused while unfocused. Enabled tools resume when you return to a supported driving mode.'); });
  document.addEventListener('visibilitychange', () => { if (document.hidden) suspend('Paused while the tab is hidden. Your enabled choices are kept.'); });
  window.addEventListener('pagehide', () => { savePrefs(); suspend(); clearInterval(timer); });

  function setDrift(wanted) {
    if (driftPending) return false;
    const state = engine?.state(), counters = engine && statusPtr ? engine.status(statusPtr) : null;
    if (!supported || !state?.ready || !state.driving || state.network || !counters || (counters.drive & 3) !== 2 || !Number.isFinite(counters.drift) || document.hidden || document.querySelector('dialog[open]')) {
      message('Drift assist only works while driving solo free roam with the game menus closed.'); return false;
    }
    if (!!(counters.drift & 1) === wanted) return true;
    // Rebuilding the native drift setup must not inherit our power multiplier.
    engine.restorePerformance(state);engine.restoreGrip(state);powerGate.reset();gripGate.reset();
    if (!engine.driftTap(inputPtr)) { message('Drift request not sent: the game input mailbox is unavailable, inactive, typing, or full.'); return false; }
    driftPending = { wanted, until: performance.now() + 3000 };
    ui.querySelector('#drift').disabled = true;
    message('Drift request sent. Waiting for the game to confirm its handling state…');
    return true;
  }
  function tick() {
    if (!engine) { if (live) live.textContent = 'Waiting for game. Reload after installing, then press Play.'; return; }
    try {
      const s = engine.state(), counters = statusPtr ? engine.status(statusPtr) : null;
      dragRace=!!(s.ready && s.drag);
      const driveStatus = counters && Number.isFinite(counters.drive) ? counters.drive & 3 : 0;
      const canInput = supported && s.ready && (!s.network || prefs.online) && driveStatus !== 0 && !document.hidden && document.hasFocus() && !document.querySelector('dialog[open]');
      const safe = canInput && s.driving;
      const aiState = ai?.update({enabled:prefs.ai && !dragRace,safe,state:s,mode:driveStatus,pace:prefs.aiPace?prefs.paceFactor:1,allowNetwork:prefs.online}) || {available:false,active:false,status:'Native game AI · experimental',reason:'Reload with the native AI module installed.'};
      let nos = false;
      if (safe && prefs.nos) nos = engine.refill(s,prefs.online);
      let tune={active:false},grip={active:false};
      if(safe && !driftPending && (prefs.boost || prefs.unlimit)) {
        const info=engine.performanceInfo(s),patch=engine.performancePatch;
        if(patch && (!info || patch.car!==s.car || patch.race!==s.race || patch.pi!==info.pi)) {engine.restorePerformance(s);powerGate.reset();}
        if(!info)powerGate.reset();
        if(info && (engine.performancePatch || powerGate.accept([s.car,s.race,info.pi,...info.values]))) {
          tune=engine.tunePerformance(s,prefs.boost?prefs.power:1,prefs.unlimit,prefs.online);
          if(tune.changed){powerGate.reset();message(tune.reason);}
        }
      } else {engine.restorePerformance(s);powerGate.reset();}
      if(safe && !driftPending && prefs.grip) {
        const info=engine.gripInfo(s),patch=engine.gripPatch;
        if(patch && (!info || patch.car!==s.car || patch.race!==s.race || patch.physics!==info.physics || patch.wheels.some((w,i)=>w!==info.wheels[i]))) {engine.restoreGrip(s);gripGate.reset();}
        if(!info)gripGate.reset();
        if(info && (engine.gripPatch || gripGate.accept([s.car,s.race,info.physics,...info.wheels,...info.values]))) {
          grip=engine.tuneGrip(s,prefs.gripFactor,prefs.online);
          if(grip.changed){gripGate.reset();message(grip.reason);}
        }
      } else {engine.restoreGrip(s);gripGate.reset();}
      const manualDriver = s.ready && engine.u32(s.car+0x24)===1 && !aiState.active && (!ai || !aiState.available || (aiState.ready && !aiState.owned));
      const dragCountdown = dragRace && engine.u32(s.race)===3;
      const activeDrag = canInput && (s.driving || dragCountdown) && prefs.drag && dragRace && manualDriver && !dragTakenOver;
      const now = performance.now();
      if (activeDrag) {
        hold('ArrowUp', true);
        if (s.driving && prefs.nos && nos && s.gear >= 3) hold('AltLeft', true); else hold('AltLeft', false);
        if (s.driving && s.rpm >= prefs.rpm && s.gear >= 2 && s.gear < 7 && now - lastShift > 650) {
          lastShift = now; hold('ShiftLeft', true);
          shiftTimer = setTimeout(() => hold('ShiftLeft', false), 85);
        }
        // Refresh synthetic held keys after a game's own input-release event.
        if (now - lastPulse > 500) { lastPulse = now; for (const code of held) if (code !== 'ShiftLeft') key(code, true); }
      } else release();
      if (live) live.textContent = !supported ? `Unsupported game build ${revision || '(checking)'}. Memory tools disabled.` : !s.ready ? s.reason : s.network && !prefs.online ? 'Online/LAN tools paused. Enable Allow Online/LAN tools in Session mode.' : !driveStatus ? 'Waiting for driving HUD.' : `${s.network ? 'Online/LAN opt-in' : 'Game linked'} · ${Math.round(s.rpm)} RPM${prefs.nos ? nos ? ' · NOS refilling' : ' · NOS unavailable/paused' : ''}${tune.active ? ` · Power ${tune.power.toFixed(1)}×${tune.unlimit ? ' · Governor off' : ''}` : (prefs.boost || prefs.unlimit) ? ' · Power controls waiting/unavailable' : ''}${grip.active ? ` · Grip ${grip.factor.toFixed(1)}×` : prefs.grip ? ' · Grip paused/unavailable' : ''}${prefs.drag ? activeDrag ? dragCountdown ? ' · Drag countdown throttle' : ' · Drag throttle/shifting · you steer' : dragTakenOver ? ' · Drag paused for manual control' : dragRace && !manualDriver ? ' · Drag waiting for native handback' : ' · Drag assist paused/waiting' : ''}`;
      if (ui) {
        const enabled=[prefs.ai,prefs.aiPace,prefs.nos,prefs.boost,prefs.unlimit,prefs.grip,prefs.drag,prefs.tester,!!(counters?.drift & 1)].filter(Boolean).length;
        ui.querySelector('#enabled').textContent=enabled ? `${enabled} selected` : 'Ready';
        ui.querySelector('#online-state').textContent = prefs.online ? 'ON this page · experimental · F9 disables' : 'OFF · resets on every page reload';
        ui.querySelector('#ai-state').textContent = prefs.ai && s.network && !prefs.online ? 'Paused online · enable Session mode opt-in' : prefs.ai && dragRace ? 'Paused for drag · use drag assist and steer' : prefs.ai ? [aiState.status || 'Native game AI · experimental', aiState.reason].filter(Boolean).join(' · ') : 'Highest native skill · experimental · off';
        ui.querySelector('#ai-pace-state').textContent = !prefs.aiPace ? 'Off · normal native target speed' : !prefs.ai || !aiState.active ? `${prefs.paceFactor.toFixed(2)}× selected · waiting for native AI` : Number.isFinite(aiState.paceApplied) ? `${aiState.paceApplied.toFixed(2)}× target-speed factor confirmed` : `${prefs.paceFactor.toFixed(2)}× requested · waiting for game confirmation`;
        ui.querySelector('#drag-state').textContent = activeDrag ? dragCountdown ? 'Countdown throttle · shifts wait for GO' : 'Throttle + shifting active · you steer' : prefs.drag ? dragTakenOver ? 'Paused by F7 · toggle to resume' : dragRace && !manualDriver ? 'Waiting for native AI to release the car' : s.network && !prefs.online ? 'Paused online · enable Session mode opt-in' : 'Waiting for drag driving state' : 'Throttle + shifting · you steer';
        ui.querySelector('#grip-state').textContent=grip.active ? `Tyre-force multiplier ${grip.factor.toFixed(1)}× applied` : prefs.grip ? (grip.reason || 'Waiting for driving state') : 'More tyre grip · start at 1.3×';
        if (prefs.tester && supported && s.ready && now - lastScan > 250) {
          lastScan = now;
          const h = engine.hazards(s), close = h?.cars[0];
          ui.querySelector('#hazards').textContent = h ? `${h.scannedCars} car objects read. ${close ? `Nearest ahead: ${close.ahead.toFixed(0)} m, side offset ${close.side.toFixed(1)} m.` : 'No nearby car detected ahead.'} ${h.barrierAhead !== null ? `Barrier line ahead: ${h.barrierAhead.toFixed(0)} m.` : 'No crossing barrier line detected.'} Props and general obstacles: NOT detected.` : 'Detector waiting for valid car coordinates.';
        }
        const driftKnown = counters && Number.isFinite(counters.drift);
        const drift = driftKnown ? !!(counters.drift & 1) : null;
        const driftActive = driftKnown && !!(counters.drift & 2);
        if (driftPending && driftKnown && drift === driftPending.wanted && (!drift || driftActive)) {
          message(drift ? 'Drift assist ON: confirmed by the game’s handling state.' : 'Drift assist OFF: confirmed by the game.'); driftPending=null;
        } else if (driftPending && now > driftPending.until) {
          message('The game did not confirm drift assist. Use solo free roam (not a race or co-op), close menus, then try again.'); driftPending=null;
        }
        ui.querySelector('#drift').disabled = !!driftPending;
        if(driftNeedsReapply && !driftPending && safe && driveStatus===2 && driftKnown) {driftNeedsReapply=false;if(!setDrift(prefs.drift))message('Drift request could not be sent. Toggle it again in free roam.');}
        if(driftKnown && !driftPending && !driftNeedsReapply) {
          ui.querySelector('#drift').checked=drift;
          if(typeof prefs.drift==='boolean' && prefs.drift!==drift){prefs.drift=drift;savePrefs();}
        }
        ui.querySelector('#drift-state').textContent = driftNeedsReapply ? 'Choice saved · waiting for solo free roam' : driftPending ? 'Waiting for confirmation…' : driftActive ? 'Game confirms drift handling ON' : drift ? 'Selected, but not active in this game mode' : 'Free roam only · not perfect-drift automation';
      }
    } catch { stop('Runtime changed or is unavailable. Reload the game before retrying.'); engine = null; }
  }
  function setPanel(open) {
    visible=!!open;
    if(!ui) return;
    ui.querySelector('#tools-panel').hidden=!visible;
    ui.querySelector('#min').setAttribute('aria-expanded',String(visible));
    ui.querySelector('#chevron').textContent=visible ? '▴' : '▾';
  }
  function mount() {
    host = document.createElement('div'); host.id = 'nfsu2-driving-tools'; host.dataset.nfsu2Ui = '';
    host.addEventListener('keydown', e => e.stopPropagation());
    host.addEventListener('keyup', e => e.stopPropagation());
    Object.assign(host.style, { position: 'fixed', top: '12px', right: '12px', zIndex: '2147483647', width: '292px', maxWidth: 'calc(100vw - 24px)' });
    ui = host.attachShadow({ mode: 'closed' });
    ui.innerHTML = `<style>
:host{color-scheme:dark}*{box-sizing:border-box}[hidden]{display:none!important}button,input{font:inherit}button,summary{cursor:pointer}button:focus-visible,input:focus-visible,summary:focus-visible{outline:2px solid #d7ffe9;outline-offset:2px}
.shell{font:11px/1.35 ui-monospace,SFMono-Regular,Consolas,monospace;color:#d7ffe9;filter:drop-shadow(3px 3px 0 #0008)}
.launcher{width:100%;display:flex;align-items:center;gap:6px;padding:7px 8px;border:2px solid #85e6ad;border-radius:2px;background:#151a2b;color:inherit;text-align:left}.mark{color:#85e6ad;font-size:15px}.title{font-size:12px;font-weight:700}.badge{font-size:9px;color:#b6d8cc;margin-left:auto}.arrow{color:#85e6ad}
.panel{margin-top:3px;border:2px solid #658d85;border-radius:2px;background:#151a2b;overflow-y:auto;max-height:calc(100vh - 70px);max-height:min(510px,calc(100dvh - 70px));scrollbar-width:thin;scrollbar-color:#658d85 #151a2b}.intro{padding:5px 8px;display:flex;justify-content:space-between;gap:6px;color:#a2beb7;font-size:9px}.version{color:#85e6ad}.actions{display:flex;gap:5px;padding:0 7px 6px;background:#151a2b;position:sticky;top:0;z-index:1}.actions button{flex:1;min-width:0;padding:5px 3px;border:1px solid #85e6ad;border-radius:1px;background:#253a39;color:#d7ffe9;font-size:10px}.actions .stop{border-color:#dba3a3;background:#3a2835;color:#ffe1e1}
.group{border-top:1px solid #526b70}.group>summary{padding:7px 8px;background:#26374a;font-weight:700;list-style-position:inside}.group[open]>summary{color:#b8ffce;background:#2b424c}.group-body{padding:3px 9px 7px}label.row{display:flex;align-items:center;justify-content:space-between;gap:8px;padding:5px 0}label.row span{font-weight:600}small{display:block;color:#abc1bc;font-size:9px;font-weight:400;margin-top:2px}input[type=checkbox]{appearance:none;flex:0 0 auto;width:27px;height:16px;border:1px solid #658d85;border-radius:2px;background:#26374a;position:relative}input[type=checkbox]:before{content:'';position:absolute;width:10px;height:10px;left:2px;top:2px;background:#abc1bc}input[type=checkbox]:checked{background:#85e6ad;border-color:#85e6ad}input[type=checkbox]:checked:before{transform:translateX(11px);background:#253a39}input:disabled{opacity:.45;cursor:wait}
.slider{display:block;padding:2px 0 5px;color:#b6d8cc;font-size:10px}.slider>span{display:flex;align-items:center;justify-content:space-between;gap:8px}.slider output{color:#d7ffe9;font-weight:700;min-width:42px;text-align:right}input[type=range]{display:block;width:100%;height:18px;margin:1px 0 0;accent-color:#85e6ad;cursor:pointer}.help{margin-top:3px;color:#abc1bc;font-size:9px}.help>summary{padding:3px 0;color:#a6d9cb}.help p,p.fine{font-size:9px;line-height:1.4;margin:4px 0}.status{padding:5px 8px;border-top:1px solid #658d85;background:#111c25}#live,#note{font-size:9px;line-height:1.4;margin:3px 0;overflow-wrap:anywhere;max-height:3.9em;overflow-y:auto}#live{color:#a7eec2}#note{color:#e6c38f}#hazards{font-size:10px;padding:5px;background:#26374a;color:#d0e6e0}.keys{color:#a2beb7;font-size:9px;margin-top:4px}kbd{font:inherit;color:#d7ffe9}
</style><div class="shell"><button id="min" class="launcher" aria-expanded="false" aria-controls="tools-panel" title="Open driving tools (F8)"><span class="mark" aria-hidden="true">⚙</span><span class="title">Driving tools</span><span id="enabled" class="badge">Ready</span><span id="chevron" class="arrow" aria-hidden="true">▾</span></button>
<div id="tools-panel" class="panel" hidden><div class="intro"><span>Driving tools · experimental</span><span class="version">v0.6</span></div>
<div class="actions"><button id="take-control">Take control · F7</button><button id="stop" class="stop">Stop · F9</button></div>
<details id="group-session" class="group"><summary>Session mode</summary><div class="group-body">
<label class="row"><span>Allow Online/LAN tools<small id="online-state">OFF · resets on every page reload</small></span><input id="online" type="checkbox" aria-describedby="online-risk"></label>
<p id="online-risk" class="fine">Online changes are unverified. They can affect other racers, trigger integrity checks, invalidate results or lead to a ban. Follow the server’s rules. This does not bypass server restrictions.</p>
<p class="fine">Allows selected NOS, power, limiter, grip, AI/pace and drag tools. Does not enable them by itself. Drift mode stays free-roam-only.</p>
</div></details>
<details id="group-driver" class="group"><summary>Native driver</summary><div class="group-body">
<label class="row"><span>AI driver · level 9<small id="ai-state">Highest native skill · off</small></span><input id="ai" type="checkbox"></label>
<label class="row"><span>Custom AI pace<small id="ai-pace-state">Off · normal target speed</small></span><input id="ai-pace" type="checkbox" aria-describedby="ai-pace-help"></label>
<label class="slider"><span>AI pace factor <output id="pace-value" for="pace-factor">1.00×</output></span><input id="pace-factor" aria-label="AI pace factor" aria-describedby="ai-pace-help" type="range" value="1" min="0.75" max="1.5" step="0.05"></label>
<p id="ai-pace-help" class="fine">Higher pace may worsen corners and cause crashes. 1.00× is normal; lower pace is not a steering fix.</p>
<details class="help"><summary>AI limits &amp; controls</summary><p>Non-drag races + free roam. Online/LAN needs the Session mode opt-in. Arrow/WASD keys or Space take control outside this menu. Controllers: use F7. Pauses in menus; AI is off after reload. No guaranteed route, wins or career automation.</p><p>Opt-in pace: 0.75×–1.50×. Changes the AI’s target-speed factor, not engine power or actual speed. Drag races need the separate assist below.</p></details>
</div></details>
<details id="group-power" class="group"><summary>Power &amp; speed</summary><div class="group-body">
<label class="row"><span>Unlimited NOS<small>Refills an equipped kit</small></span><input id="nos" type="checkbox"></label>
<label class="row"><span>Engine power boost</span><input id="boost" type="checkbox"></label>
<label class="slider"><span>Power multiplier <output id="power-value" for="power">1.5×</output></span><input id="power" aria-label="Power multiplier" type="range" value="1.5" min="1" max="3" step="0.1"></label>
<label class="row"><span>Remove stock limiter</span><input id="unlimit" type="checkbox"></label>
<details class="help"><summary>Power limits</summary><p>More engine and NOS torque can worsen wheelspin and handling. Gearing, drag and redline still limit top speed. NOS refill does not force native AI to use it.</p></details>
</div></details>
<details id="group-handling" class="group"><summary>Handling</summary><div class="group-body">
<label class="row"><span>Extra grip<small id="grip-state">Start at 1.3×</small></span><input id="grip" type="checkbox"></label>
<label class="slider"><span>Grip multiplier <output id="grip-value" for="grip-factor">1.3×</output></span><input id="grip-factor" aria-label="Grip multiplier" type="range" value="1.3" min="1" max="2" step="0.1"></label>
<label class="row"><span>Drift assist<small id="drift-state">Solo free roam only</small></span><input id="drift" type="checkbox"></label>
<details class="help"><summary>Handling limits</summary><p>Extra grip pauses in drift mode. It does not auto-steer or guarantee perfect handling. High grip can cause abrupt handling or rollover. Drift uses the game’s mode, not perfect-drift automation.</p></details>
</div></details>
<details id="group-drag" class="group"><summary>Drag racing</summary><div class="group-body">
<label class="row"><span>Drag assist<small id="drag-state">Throttle + shifting · you steer</small></span><input id="drag" type="checkbox"></label>
<label class="slider"><span>Shift at RPM <output id="rpm-value" for="rpm">6500</output></span><input id="rpm" aria-label="Shift RPM" type="range" value="6500" min="3000" max="10000" step="100"></label>
<p class="fine">This player-autopilot handoff is unverified for drag. You must steer, change lanes and avoid obstacles.</p>
<details class="help"><summary>Drag controls</summary><p>Uses default Arrow Up / Left Shift / Left Alt bindings. Start the race yourself. Choose shift RPM for your car; 6500 is not a learned perfect-shift value. F7 pauses assisted throttle until you toggle drag assist again.</p></details>
</div></details>
<details id="group-diagnostics" class="group"><summary>Diagnostics</summary><div class="group-body">
<label class="row"><span>Traffic / barrier tester<small>Read-only · incomplete detection</small></span><input id="tester" type="checkbox"></label><p id="hazards" hidden></p>
</div></details>
<div class="status"><p id="live" role="status">Waiting for game…</p><p id="note" role="status">Choices stay enabled between races. Tools pause outside supported modes.</p><div class="keys"><kbd>F8</kbd> menu · <kbd>Esc</kbd> close · drift + tester keep their own switches</div></div>
</div></div>`;
    note = ui.querySelector('#note'); live = ui.querySelector('#live');
    ui.querySelector('#online').addEventListener('change', e => {prefs.online=e.target.checked;if(!prefs.online)suspend();message(prefs.online ? 'Online/LAN tools allowed on this page. Experimental: server checks may flag changes or reject results. F9 disables this mode.' : 'Online/LAN tools paused. Other selections are kept for solo play.');});
    ui.querySelector('#ai').addEventListener('change', e => {prefs.ai=e.target.checked;release();if(!prefs.ai)ai?.stop();message(prefs.ai ? 'Native AI requested. Waiting for a supported driving state; online needs the Session mode opt-in. F7, arrow/WASD keys or Space take control.' : 'Native AI off.');});
    ui.querySelector('#take-control').addEventListener('click',takeControl);
    ui.querySelector('#ai-pace').addEventListener('change', e => { prefs.aiPace=e.target.checked; message(prefs.aiPace ? 'Custom AI pace enabled for native AI only. Higher pace may worsen cornering and cause crashes. Start at 1.00×.' : 'Custom AI pace off. Native AI will use its normal target-speed factor.'); });
    ui.querySelector('#nos').addEventListener('change', e => { prefs.nos = e.target.checked; });
    ui.querySelector('#grip').addEventListener('change', e => { prefs.grip=e.target.checked; message(prefs.grip ? 'Extra grip enabled. Start at 1.3×; it pauses during drift. Too much grip can cause abrupt handling or rollover.' : 'Extra grip off. Original wheel factors are restored.'); });
    ui.querySelector('#boost').addEventListener('change', e => { prefs.boost=e.target.checked; message('Power boost is experimental. Start at 1.5×; turn it off if wheelspin or handling gets worse.'); });
    ui.querySelector('#unlimit').addEventListener('change', e => { prefs.unlimit=e.target.checked; });
    ui.querySelector('#drag').addEventListener('change', e => { prefs.drag = e.target.checked; dragTakenOver=false; if (!prefs.drag) release(); else message('Experimental drag assist enabled. You must steer. Default keyboard bindings required.'); });
    ui.querySelector('#tester').addEventListener('change', e => { prefs.tester = e.target.checked; ui.querySelector('#hazards').hidden = !prefs.tester; ui.querySelector('#hazards').textContent = 'Waiting for a supported game and driving state…'; });
    ui.querySelector('#drift').addEventListener('change', e => { const wanted = e.target.checked; prefs.drift=wanted;savePrefs();const state=engine && statusPtr ? engine.status(statusPtr) : null;if(!state || (state.drive & 3)!==2){driftNeedsReapply=true;message('Drift choice saved. It will be requested when solo free roam is available.');}else setDrift(wanted); const status=engine && statusPtr ? engine.status(statusPtr) : null; e.target.checked=driftNeedsReapply ? !!prefs.drift : !!(status?.drift & 1); });
    ui.querySelector('#stop').addEventListener('click', () => stop());
    ui.querySelector('#min').addEventListener('click', () => setPanel(!visible));
    const groupIds=['group-session','group-driver','group-power','group-handling','group-drag','group-diagnostics'];
    for(const id of groupIds) ui.querySelector('#'+id).addEventListener('toggle',()=>{
      if(ui.querySelector('#'+id).open) for(const other of groupIds) if(other!==id) ui.querySelector('#'+other).open=false;
    });
    for(const id of ['nos','drag','tester','boost','unlimit','grip']) ui.querySelector('#'+id).checked=prefs[id];
    ui.querySelector('#ai-pace').checked=prefs.aiPace;
    for(const [id,name,output,min,max,step,fallback,digits,suffix] of [
      ['pace-factor','paceFactor','pace-value',0.75,1.5,0.05,1,2,'×'],
      ['power','power','power-value',1,3,0.1,1.5,1,'×'],
      ['grip-factor','gripFactor','grip-value',1,2,0.1,1.3,1,'×'],
      ['rpm','rpm','rpm-value',3000,10000,100,6500,0,'']
    ]) {
      const input=ui.querySelector('#'+id),value=ui.querySelector('#'+output);
      const update=()=>{
        const raw=Number(input.value),bounded=Number.isFinite(raw)&&input.value!==''?Math.max(min,Math.min(max,raw)):fallback;
        prefs[name]=Number((min+Math.round((bounded-min)/step)*step).toFixed(digits));
        input.value=prefs[name];value.textContent=prefs[name].toFixed(digits)+suffix;
        input.setAttribute('aria-valuetext',prefs[name].toFixed(digits)+(suffix?' times':' RPM'));
      };
      input.value=prefs[name];update();
      input.addEventListener('input',()=>{update();savePrefs();});
      input.addEventListener('change',update);
    }
    if(typeof prefs.drift==='boolean') ui.querySelector('#drift').checked=prefs.drift;
    ui.querySelector('#hazards').hidden=!prefs.tester;
    ui.addEventListener('change',savePrefs);
    const parent = document.fullscreenElement || document.body; parent.append(host);
    document.addEventListener('fullscreenchange', () => { (document.fullscreenElement || document.body).append(host); });
    timer = setInterval(tick, 50);
  }
  if (document.body) mount(); else document.addEventListener('DOMContentLoaded', mount, { once: true });
})();

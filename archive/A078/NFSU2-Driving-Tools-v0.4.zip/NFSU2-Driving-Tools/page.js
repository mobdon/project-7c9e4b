(() => {
  'use strict';
  if (location.origin !== 'https://nfsu2.xyz' || window.top !== window || window.__nfsu2DrivingTools) return;
  Object.defineProperty(window, '__nfsu2DrivingTools', { value: true });
  const AI = globalThis.__NFSU2_AI__;
  AI?.install();
  let ai = null, dragTakenOver = false;
  const { Engine, StableGate, supportedRevision } = globalThis.__NFSU2_DRIVING_CORE__;
  delete globalThis.__NFSU2_DRIVING_CORE__;
  let engine = null, statusPtr = 0, inputPtr = 0, supported = false, revision = '', visible = false;
  let host, ui, note, live, timer, driftPending = null, driftNeedsReapply = false;
  const powerGate=new StableGate(), gripGate=new StableGate();
  let lastShift = 0, shiftTimer = 0, lastPulse = 0, lastScan = 0;
  const held = new Set(), physicallyHeld = new Set();
  const prefs = { ai: false, nos: false, drag: false, rpm: 6500, tester: false, boost: false, power: 1.5, unlimit: false, grip: false, gripFactor: 1.3, drift: null };
  const STORAGE_KEY='nfsu2-driving-tools-v1';
  try {
    const saved=JSON.parse(sessionStorage.getItem(STORAGE_KEY)||'null');
    if(saved && typeof saved==='object') {
      for(const name of ['nos','drag','tester','boost','unlimit','grip']) if(typeof saved[name]==='boolean') prefs[name]=saved[name];
      for(const [name,min,max] of [['rpm',3000,10000],['power',1,3],['gripFactor',1,2]]) if(Number.isFinite(saved[name])) prefs[name]=Math.max(min,Math.min(max,saved[name]));
      if(typeof saved.drift==='boolean') prefs.drift=saved.drift;
    }
  } catch { /* storage disabled: choices still persist between races in this page */ }
  const savePrefs=()=>{try{sessionStorage.setItem(STORAGE_KEY,JSON.stringify(prefs));}catch{}};
  const message = text => { if (note) note.textContent = text; };
  const NativeWorker = window.Worker;
  // Observe only the known game worker; AI validates its patched module separately.
  window.Worker = new Proxy(NativeWorker, {
    construct(Target, args, NewTarget) {
      const worker = Reflect.construct(Target, args, NewTarget);
      let url; try { url = new URL(String(args[0]), location.href); } catch { return worker; }
      if (url.origin !== location.origin || url.pathname !== '/host/game-worker.js') return worker;
      const send = worker.postMessage;
      worker.postMessage = function (m, ...rest) {
        if (m && m.mod instanceof WebAssembly.Module && m.memory instanceof WebAssembly.Memory && m.slot === 0) {
          if (!engine || engine.memory !== m.memory) { ai?.stop(); ai = AI?.Controller ? new AI.Controller(m.memory, AI.isPatchedModule(m.mod)) : null; engine = new Engine(m.memory); statusPtr = 0; inputPtr = 0; driftPending = null; driftNeedsReapply=typeof prefs.drift==='boolean'; powerGate.reset(); gripGate.reset(); }
        }
        return Reflect.apply(send, this, [m, ...rest]);
      };
      worker.addEventListener('message', event => {
        const m = event.data;
        if (m?.t === 'register' && m.kind === 3 && Number.isSafeInteger(m.ptr)) inputPtr = m.ptr;
        if (m?.t === 'register' && m.kind === 5 && Number.isSafeInteger(m.ptr)) statusPtr = m.ptr;
        if (m?.t === 'exit' || m?.t === 'trap') {suspend('Game stopped. Enabled choices are kept for the next game.');ai=null;engine=null;statusPtr=0;inputPtr=0;}
      });
      return worker;
    }
  });
  // A different game revision must be reviewed before writing its memory.
  fetch('/game.json', { cache: 'no-store', credentials: 'omit' }).then(r => {
    if (!r.ok) throw new Error('Build information unavailable');
    return r.json();
  }).then(info => {
    revision = String(info.rev || 'unknown'); supported = revision === supportedRevision;
    if (!supported) message('Game updated: memory tools disabled until this extension is updated.');
  }).catch(() => message('Could not check game version. Memory tools stay disabled.'));

  function key(code, down) {
    const keyName = { ArrowUp: 'ArrowUp', ShiftLeft: 'Shift', AltLeft: 'Alt' }[code] || code;
    window.dispatchEvent(new KeyboardEvent(down ? 'keydown' : 'keyup', { code, key: keyName,
      location: /Left$/.test(code) ? 1 : 0, bubbles: true, cancelable: true }));
  }
  function hold(code, down) {
    if (down && !held.has(code)) { if (!physicallyHeld.has(code)) { held.add(code); key(code, true); } }
    else if (!down && held.delete(code) && !physicallyHeld.has(code)) key(code, false);
  }
  function release() { clearTimeout(shiftTimer); for (const code of [...held]) hold(code, false); }
  function suspend(why) {
    ai?.stop(); release(); powerGate.reset(); gripGate.reset();
    try {if(engine){const state=engine.state();engine.restorePerformance(state);engine.restoreGrip(state);}} catch { /* no stale pointer writes */ }
    if(why) message(why);
  }
  function stop(why = 'Driving controls off. F9 cleared the enabled driving assists.') {
    prefs.ai=false;prefs.nos=false;prefs.drag=false;prefs.boost=false;prefs.unlimit=false;prefs.grip=false;savePrefs();suspend();
    if(ui) for(const id of ['ai','nos','drag','boost','unlimit','grip']) ui.querySelector('#'+id).checked=false;
    message(why);
  }
  function takeControl() {
    prefs.ai=false; ai?.stop(); dragTakenOver=true; release(); savePrefs();
    if(ui) {ui.querySelector('#ai').checked=false;ui.querySelector('#ai-state').textContent='Manual control · native AI off';}
    message('Returning control to you. Native AI is off on the next game frame. Toggle drag assist again if you want assisted throttle.');
  }
  window.addEventListener('keydown', e => {
    if (!e.isTrusted) return;
    physicallyHeld.add(e.code);
    if(e.code==='F7') {e.preventDefault();takeControl();}
    else if(prefs.ai && ['ArrowLeft','ArrowRight','ArrowUp','ArrowDown','KeyW','KeyA','KeyS','KeyD','Space'].includes(e.code)) takeControl();
    if (e.code === 'F8') { e.preventDefault(); setPanel(!visible); }
    if (e.code === 'Escape' && visible) setPanel(false);
    if (e.code === 'F9') { e.preventDefault(); stop(); }
  }, true);
  window.addEventListener('keyup', e => { if (e.isTrusted) physicallyHeld.delete(e.code); }, true);
  window.addEventListener('blur', () => { physicallyHeld.clear(); suspend('Paused while unfocused. Enabled tools resume when you return to a supported driving mode.'); });
  document.addEventListener('visibilitychange', () => { if (document.hidden) suspend('Paused while the tab is hidden. Your enabled choices are kept.'); });
  window.addEventListener('pagehide', () => { savePrefs(); suspend(); clearInterval(timer); });

  function setDrift(wanted) {
    if (driftPending) return false;
    const state = engine?.state(), counters = engine && statusPtr ? engine.status(statusPtr) : null;
    if (!supported || !state?.ready || !state.driving || state.network || !counters || (counters.drive & 3) !== 2 || !Number.isFinite(counters.drift) || document.hidden || document.querySelector('dialog[open]')) {
      message('Drift assist only works while driving solo free roam with the game menus closed.'); return false;
    }
    if (!!(counters.drift & 1) === wanted) return true;
    // Rebuilding the native drift setup must not inherit our power multiplier.
    engine.restorePerformance(state);engine.restoreGrip(state);powerGate.reset();gripGate.reset();
    if (!engine.driftTap(inputPtr)) { message('Drift request not sent: the game input mailbox is unavailable, inactive, typing, or full.'); return false; }
    driftPending = { wanted, until: performance.now() + 3000 };
    ui.querySelector('#drift').disabled = true;
    message('Drift request sent. Waiting for the game to confirm its handling state…');
    return true;
  }
  function tick() {
    if (!engine) { if (live) live.textContent = 'Waiting for game. Reload after installing, then press Play.'; return; }
    try {
      const s = engine.state(), counters = statusPtr ? engine.status(statusPtr) : null;
      const driveStatus = counters && Number.isFinite(counters.drive) ? counters.drive & 3 : 0;
      const safe = supported && s.ready && s.driving && !s.network && driveStatus !== 0 && !document.hidden && document.hasFocus() && !document.querySelector('dialog[open]');
      const aiState = ai?.update({enabled:prefs.ai,safe,state:s,mode:driveStatus}) || {available:false,active:false,status:'Native game AI · experimental',reason:'Reload with the native AI module installed.'};
      let nos = false;
      if (safe && prefs.nos) nos = engine.refill(s);
      let tune={active:false},grip={active:false};
      if(safe && !driftPending && (prefs.boost || prefs.unlimit)) {
        const info=engine.performanceInfo(s),patch=engine.performancePatch;
        if(patch && (!info || patch.car!==s.car || patch.race!==s.race || patch.pi!==info.pi)) {engine.restorePerformance(s);powerGate.reset();}
        if(!info)powerGate.reset();
        if(info && (engine.performancePatch || powerGate.accept([s.car,s.race,info.pi,...info.values]))) {
          tune=engine.tunePerformance(s,prefs.boost?prefs.power:1,prefs.unlimit);
          if(tune.changed){powerGate.reset();message(tune.reason);}
        }
      } else {engine.restorePerformance(s);powerGate.reset();}
      if(safe && !driftPending && prefs.grip) {
        const info=engine.gripInfo(s),patch=engine.gripPatch;
        if(patch && (!info || patch.car!==s.car || patch.race!==s.race || patch.physics!==info.physics || patch.wheels.some((w,i)=>w!==info.wheels[i]))) {engine.restoreGrip(s);gripGate.reset();}
        if(!info)gripGate.reset();
        if(info && (engine.gripPatch || gripGate.accept([s.car,s.race,info.physics,...info.wheels,...info.values]))) {
          grip=engine.tuneGrip(s,prefs.gripFactor);
          if(grip.changed){gripGate.reset();message(grip.reason);}
        }
      } else {engine.restoreGrip(s);gripGate.reset();}
      const activeDrag = safe && prefs.drag && s.drag && !prefs.ai && !aiState.active && !dragTakenOver;
      const now = performance.now();
      if (activeDrag) {
        hold('ArrowUp', true);
        if (prefs.nos && nos && s.gear >= 3) hold('AltLeft', true); else hold('AltLeft', false);
        if (s.rpm >= prefs.rpm && s.gear >= 2 && s.gear < 7 && now - lastShift > 650) {
          lastShift = now; hold('ShiftLeft', true);
          shiftTimer = setTimeout(() => hold('ShiftLeft', false), 85);
        }
        // Refresh synthetic held keys after a game's own input-release event.
        if (now - lastPulse > 500) { lastPulse = now; for (const code of held) if (code !== 'ShiftLeft') key(code, true); }
      } else release();
      if (live) live.textContent = !supported ? `Unsupported game build ${revision || '(checking)'}. Memory tools disabled.` : !s.ready ? s.reason : s.network ? 'Online/LAN race: memory tools paused.' : !driveStatus ? 'Waiting for driving HUD.' : `Game linked · ${Math.round(s.rpm)} RPM${prefs.nos ? nos ? ' · NOS refilling' : ' · NOS unavailable/paused' : ''}${tune.active ? ` · Power ${tune.power.toFixed(1)}×${tune.unlimit ? ' · Governor off' : ''}` : (prefs.boost || prefs.unlimit) ? ' · Power controls waiting/unavailable' : ''}${grip.active ? ` · Grip ${grip.factor.toFixed(1)}×` : prefs.grip ? ' · Grip paused/unavailable' : ''}${prefs.drag ? activeDrag ? ' · Drag assist active' : prefs.ai ? ' · Drag paused for native AI' : dragTakenOver ? ' · Drag paused for manual control' : ' · Drag assist waiting for a drag race' : ''}`;
      if (ui) {
        const enabled=[prefs.ai,prefs.nos,prefs.boost,prefs.unlimit,prefs.grip,prefs.drag,prefs.tester,!!(counters?.drift & 1)].filter(Boolean).length;
        ui.querySelector('#enabled').textContent=enabled ? `${enabled} enabled` : 'Ready';
        ui.querySelector('#ai-state').textContent = prefs.ai ? [aiState.status || 'Native game AI · experimental', aiState.reason].filter(Boolean).join(' · ') : 'Highest native skill · experimental · off';
        ui.querySelector('#grip-state').textContent=grip.active ? `Tyre-force multiplier ${grip.factor.toFixed(1)}× applied` : prefs.grip ? (grip.reason || 'Waiting for driving state') : 'More tyre grip · start at 1.3×';
        if (prefs.tester && supported && s.ready && now - lastScan > 250) {
          lastScan = now;
          const h = engine.hazards(s), close = h?.cars[0];
          ui.querySelector('#hazards').textContent = h ? `${h.scannedCars} car objects read. ${close ? `Nearest ahead: ${close.ahead.toFixed(0)} m, side offset ${close.side.toFixed(1)} m.` : 'No nearby car detected ahead.'} ${h.barrierAhead !== null ? `Barrier line ahead: ${h.barrierAhead.toFixed(0)} m.` : 'No crossing barrier line detected.'} Props and general obstacles: NOT detected.` : 'Detector waiting for valid car coordinates.';
        }
        const driftKnown = counters && Number.isFinite(counters.drift);
        const drift = driftKnown ? !!(counters.drift & 1) : null;
        const driftActive = driftKnown && !!(counters.drift & 2);
        if (driftPending && driftKnown && drift === driftPending.wanted && (!drift || driftActive)) {
          message(drift ? 'Drift assist ON: confirmed by the game’s handling state.' : 'Drift assist OFF: confirmed by the game.'); driftPending=null;
        } else if (driftPending && now > driftPending.until) {
          message('The game did not confirm drift assist. Use solo free roam (not a race or co-op), close menus, then try again.'); driftPending=null;
        }
        ui.querySelector('#drift').disabled = !!driftPending;
        if(driftNeedsReapply && !driftPending && safe && driveStatus===2 && driftKnown) {driftNeedsReapply=false;if(!setDrift(prefs.drift))message('Drift request could not be sent. Toggle it again in free roam.');}
        if(driftKnown && !driftPending && !driftNeedsReapply) {
          ui.querySelector('#drift').checked=drift;
          if(typeof prefs.drift==='boolean' && prefs.drift!==drift){prefs.drift=drift;savePrefs();}
        }
        ui.querySelector('#drift-state').textContent = driftNeedsReapply ? 'Choice saved · waiting for solo free roam' : driftPending ? 'Waiting for confirmation…' : driftActive ? 'Game confirms drift handling ON' : drift ? 'Selected, but not active in this game mode' : 'Free roam only · not perfect-drift automation';
      }
    } catch { stop('Runtime changed or is unavailable. Reload the game before retrying.'); engine = null; }
  }
  function setPanel(open) {
    visible=!!open;
    if(!ui) return;
    ui.querySelector('#tools-panel').hidden=!visible;
    ui.querySelector('#min').setAttribute('aria-expanded',String(visible));
    ui.querySelector('#chevron').textContent=visible ? '▴' : '▾';
  }
  function mount() {
    host = document.createElement('div'); host.id = 'nfsu2-driving-tools'; host.dataset.nfsu2Ui = '';
    Object.assign(host.style, { position: 'fixed', top: '12px', right: '12px', zIndex: '2147483647', width: '338px', maxWidth: 'calc(100vw - 24px)' });
    ui = host.attachShadow({ mode: 'closed' });
    ui.innerHTML = `<style>
:host{color-scheme:dark}*{box-sizing:border-box}[hidden]{display:none!important}button,input{font:inherit}button{cursor:pointer}button:focus-visible,input:focus-visible{outline:2px solid #70edc5;outline-offset:3px}
.shell{font:13px/1.4 system-ui,-apple-system,sans-serif;color:#eef4ff;filter:drop-shadow(0 12px 24px #0007)}
.launcher{width:100%;display:flex;align-items:center;gap:9px;padding:12px 14px;border:1px solid #486274;border-radius:13px;background:linear-gradient(130deg,#192e39,#151e30);color:inherit;box-shadow:inset 0 1px #ffffff12}.mark{display:grid;place-items:center;width:28px;height:28px;background:#72edc516;border:1px solid #72edc545;border-radius:8px;color:#77ecc5;font-size:18px}.title{font-size:14px;font-weight:750;letter-spacing:.2px}.badge{font-size:10px;padding:3px 6px;background:#ffffff0c;border:1px solid #ffffff15;border-radius:20px;color:#bfd0df;margin-left:auto}.arrow{color:#8feccf;font-size:17px}
.panel{margin-top:8px;border:1px solid #34485c;border-radius:14px;background:#0f1724f5;overflow-y:auto;max-height:calc(100dvh - 94px);box-shadow:inset 0 1px #ffffff0b;scrollbar-width:thin;scrollbar-color:#465369 #14202d}.intro{padding:12px 14px 8px;display:flex;justify-content:space-between;align-items:center;color:#9eb3c9;font-size:11px}.version{color:#71e9bf}.group{padding:6px 14px 10px;border-top:1px solid #263447}.heading{margin:7px 0 5px;color:#7893b0;font-size:10px;letter-spacing:1.3px;font-weight:750;text-transform:uppercase}label.row{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:9px 0}label.row span{font-weight:600}small{display:block;color:#9aadc3;font-size:10.5px;font-weight:400;margin-top:3px;max-width:245px}input[type=checkbox]{appearance:none;flex:0 0 auto;width:34px;height:20px;border:1px solid #4b6178;border-radius:14px;background:#28394c;position:relative;transition:background .15s}input[type=checkbox]:before{content:'';position:absolute;width:14px;height:14px;left:2px;top:2px;border-radius:50%;background:#b3c4d6;transition:transform .15s}input[type=checkbox]:checked{background:#76e4bd;border-color:#76e4bd}input[type=checkbox]:checked:before{transform:translateX(14px);background:#16382d}input:disabled{opacity:.45;cursor:wait}.number{font-size:11px;color:#aebfd2;padding:3px 0 7px!important}input[type=number]{width:72px;text-align:right;padding:5px 7px;background:#1e2b3c;border:1px solid #435970;border-radius:7px;color:#e3fff4}p{font-size:11px;line-height:1.5;margin:7px 0}.status{padding:10px 14px;border-top:1px solid #304055;background:#101c29}#live{color:#83e6c3}#note{color:#e4c58e}#hazards{padding:8px;border-radius:8px;background:#192a3c;color:#b8d1e9}.stop{width:100%;padding:8px;background:#312634;color:#f0bdc3;border:1px solid #715062;border-radius:8px;margin:4px 0 7px}.fine{color:#8c9fb7;font-size:10px}.keys{color:#a8bbcf}kbd{padding:1px 4px;border:1px solid #51647a;border-radius:4px;font:10px system-ui}
</style><div class="shell"><button id="min" class="launcher" aria-expanded="false" aria-controls="tools-panel" title="Open driving tools (F8)"><span class="mark" aria-hidden="true">⚙</span><span class="title">Driving tools</span><span id="enabled" class="badge">Ready</span><span id="chevron" class="arrow" aria-hidden="true">▾</span></button>
<div id="tools-panel" class="panel" hidden><div class="intro"><span>Choices stay enabled between races</span><span class="version">v0.4</span></div>
<div class="group"><h2 class="heading">Native driver</h2>
<label class="row"><span>AI driver · level 9<small id="ai-state">Highest native skill · experimental · off</small></span><input id="ai" type="checkbox"></label>
<button id="take-control" class="stop">Take control · F7</button>
<p class="fine">Solo races + free roam. Arrow/WASD keys or Space take control. For controllers, use F7 or this button. Pauses in menus; off after reload. No guaranteed route, wins or career automation.</p></div>
<div class="group"><h2 class="heading">Power & speed</h2>
<label class="row"><span>Unlimited NOS<small>Refills your equipped kit</small></span><input id="nos" type="checkbox"></label>
<label class="row"><span>Engine power boost<small>Engine + NOS torque · experimental</small></span><input id="boost" type="checkbox"></label>
<label class="row number">Power multiplier <input id="power" aria-label="Power multiplier" type="number" value="1.5" min="1" max="3" step="0.1"></label>
<label class="row"><span>Remove stock limiter<small>Gearing and drag still limit top speed</small></span><input id="unlimit" type="checkbox"></label></div>
<div class="group"><h2 class="heading">Handling</h2>
<label class="row"><span>Extra grip<small id="grip-state">More tyre grip · start at 1.3×</small></span><input id="grip" type="checkbox"></label>
<label class="row number">Grip multiplier <input id="grip-factor" aria-label="Grip multiplier" type="number" value="1.3" min="1" max="2" step="0.1"></label>
<label class="row"><span>Drift assist<small id="drift-state">Free roam only · waits for game confirmation</small></span><input id="drift" type="checkbox"></label>
<p class="fine">Extra grip pauses in drift mode. It does not auto-steer or guarantee perfect handling.</p></div>
<div class="group"><h2 class="heading">Drag racing</h2>
<label class="row"><span>Drag assist<small>Throttle + shifting · you steer and avoid obstacles</small></span><input id="drag" type="checkbox"></label>
<label class="row number">Shift at RPM <input id="rpm" aria-label="Shift RPM" type="number" value="6500" min="3000" max="10000" step="100"></label></div>
<div class="group"><h2 class="heading">Diagnostics</h2>
<label class="row"><span>Traffic / barrier tester<small>Read-only · not full obstacle detection</small></span><input id="tester" type="checkbox"></label><p id="hazards" hidden></p></div>
<div class="status"><p id="live" role="status">Waiting for game…</p><p id="note" role="status">Your choices stay enabled between races. Tools pause outside supported modes. Solo play only.</p><button id="stop" class="stop">Stop driving assists · F9</button><div class="keys"><kbd>F8</kbd> open / close <span aria-hidden="true"> · </span><kbd>Esc</kbd> close</div><p class="fine">F9 stops native AI, NOS, power, limiter, grip and drag. Native drift remains under its own switch. Drag uses default Arrow Up / Left Shift / Left Alt.</p></div>
</div></div>`;
    note = ui.querySelector('#note'); live = ui.querySelector('#live');
    ui.querySelector('#ai').addEventListener('change', e => {prefs.ai=e.target.checked;release();if(!prefs.ai)ai?.stop();message(prefs.ai ? 'Native AI requested. Waiting for a supported solo driving state. F7, arrow/WASD keys or Space take control.' : 'Native AI off.');});
    ui.querySelector('#take-control').addEventListener('click',takeControl);
    ui.querySelector('#nos').addEventListener('change', e => { prefs.nos = e.target.checked; });
    ui.querySelector('#grip').addEventListener('change', e => { prefs.grip=e.target.checked; message(prefs.grip ? 'Extra grip enabled. Start at 1.3×; it pauses during drift. Too much grip can cause abrupt handling or rollover.' : 'Extra grip off. Original wheel factors are restored.'); });
    ui.querySelector('#grip-factor').addEventListener('change', e => { prefs.gripFactor=Math.round(Math.max(1,Math.min(2,Number(e.target.value)||1.3))*10)/10; e.target.value=prefs.gripFactor; });
    ui.querySelector('#boost').addEventListener('change', e => { prefs.boost=e.target.checked; message('Power boost is experimental. Start at 1.5×; turn it off if wheelspin or handling gets worse.'); });
    ui.querySelector('#unlimit').addEventListener('change', e => { prefs.unlimit=e.target.checked; });
    ui.querySelector('#power').addEventListener('change', e => { prefs.power=Math.round(Math.max(1,Math.min(3,Number(e.target.value)||1.5))*10)/10; e.target.value=prefs.power; });
    ui.querySelector('#drag').addEventListener('change', e => { prefs.drag = e.target.checked; dragTakenOver=false; if (!prefs.drag) release(); else message('Experimental drag assist enabled. You must steer. Default keyboard bindings required.'); });
    ui.querySelector('#tester').addEventListener('change', e => { prefs.tester = e.target.checked; ui.querySelector('#hazards').hidden = !prefs.tester; ui.querySelector('#hazards').textContent = 'Waiting for a supported game and driving state…'; });
    ui.querySelector('#rpm').addEventListener('change', e => { prefs.rpm = Math.max(3000, Math.min(10000, Number(e.target.value) || 6500)); e.target.value = prefs.rpm; });
    ui.querySelector('#drift').addEventListener('change', e => { const wanted = e.target.checked; prefs.drift=wanted;savePrefs();const state=engine && statusPtr ? engine.status(statusPtr) : null;if(!state || (state.drive & 3)!==2){driftNeedsReapply=true;message('Drift choice saved. It will be requested when solo free roam is available.');}else setDrift(wanted); const status=engine && statusPtr ? engine.status(statusPtr) : null; e.target.checked=driftNeedsReapply ? !!prefs.drift : !!(status?.drift & 1); });
    ui.querySelector('#stop').addEventListener('click', () => stop());
    ui.querySelector('#min').addEventListener('click', () => setPanel(!visible));
    for(const id of ['nos','drag','tester','boost','unlimit','grip']) ui.querySelector('#'+id).checked=prefs[id];
    for(const [id,name] of [['rpm','rpm'],['power','power'],['grip-factor','gripFactor']]) ui.querySelector('#'+id).value=prefs[name];
    if(typeof prefs.drift==='boolean') ui.querySelector('#drift').checked=prefs.drift;
    ui.querySelector('#hazards').hidden=!prefs.tester;
    ui.addEventListener('change',savePrefs);
    const parent = document.fullscreenElement || document.body; parent.append(host);
    document.addEventListener('fullscreenchange', () => { (document.fullscreenElement || document.body).append(host); });
    timer = setInterval(tick, 50);
  }
  if (document.body) mount(); else document.addEventListener('DOMContentLoaded', mount, { once: true });
})();

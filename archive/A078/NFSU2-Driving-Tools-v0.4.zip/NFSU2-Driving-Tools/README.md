# NFSU2 Driving Tools — experimental v0.4.0

A small unpacked Chrome/Edge/Brave extension for **https://nfsu2.xyz/**.

## Install

1. Extract the ZIP to a folder. Keep that folder: the browser loads it from there.
2. Open `chrome://extensions` (Edge: `edge://extensions`).
3. Turn on **Developer mode**, click **Load unpacked**, and select the extracted **NFSU2-Driving-Tools** folder containing `manifest.json`.
4. Reload nfsu2.xyz, then press Play. The Driving tools dropdown appears at the upper right. Click it or press F8 to open it.

Chrome 111+ or a current compatible Chromium browser is required. This package is not a mobile-browser or Firefox build. No build command, Node installation or package dependencies are needed to install it.

Car ghosting is intentionally not included; use the game’s own menu for that.

## Dropdown and saved choices

Click **Driving tools** or press **F8** to open/close the dropdown during play. It groups Native driver, Power & speed, Handling, Drag racing and Diagnostics. Every switch can be enabled independently. Tab and Space operate the controls; Escape closes the dropdown without clearing them.

Enabled choices are kept between races, car reloads and normal same-tab page reloads using this site’s session storage. They pause in menus, loading screens, unsupported/network modes, hidden tabs and lost focus. They resume when a supported driving state returns. Power/grip wait for three matching samples before applying to a rebuilt car and never repeatedly multiply their own changes. Closing the tab ends this session’s saved choices; browser restore behavior can vary. If storage is unavailable, choices remain only until the page reloads.

**F7 / Take control** returns the native AI car to your input on the next game frame. Arrow/WASD keys and Space also switch AI off. These key checks use physical keyboard events, not controller axes; controller users should use F7 or the Take control button. Taking control also pauses synthetic drag throttle until its switch is changed again.

**F9 / Stop is the explicit off switch** for AI, NOS, power, limiter removal, grip and drag. Diagnostics and native drift stay under their own switches. Since drag’s enabled choice is kept, it resumes in the next supported solo drag race; disable it first if you don’t want that.

## Try native AI first

1. Replace the old extension folder, reload its card, then reload nfsu2.xyz. Check version **0.4.0**.
2. Start a solo race or move into free roam yourself. Open **Driving tools** or press **F8**.
3. Enable **AI driver · level 9**. Wait for **Native game AI driving · level 9** to confirm the actual driver changed.
4. Press **F7** or **Take control** to return to manual driving. The dropdown can remain open while driving.
5. Start with ordinary power/grip, then try your independent power, NOS and handling switches. Higher power can make native AI crash more often; no win is guaranteed.

Native AI is **off after every page reload**, regardless of saved choices. Within the same page its requested setting can resume after a supported race/car transition. It pauses while unfocused, hidden, in menus or unsupported/network modes. If the page stops updating the command bridge, it gives control back within 180 game frames. A broken/frozen game cannot process a takeover; disable the extension and reload if necessary.

## Switches

- **AI driver · level 9:** hands the player’s car to the game’s own `Player::AutoPilotOn`, then uses `AutoPilotOff` and `SetInputMode(2)` to return control. Uses the highest normal native skill value, **9**, only for your racer; restores your original skill when the same racer still exists. Special skill sentinels are left unchanged and are not reported as level 9. Solo races and free roam only, one local player. Native free-roam driving is backed by upstream game tests, but wandering quality, route selection and obstacle avoidance are not live-verified. This does not select events, enter/restart races, buy upgrades, complete career menus or follow a chosen GPS destination. It can become stuck. "Expert" is not claimed as an official name for numeric skill 9. NOS refill, power, limiter and grip remain independently usable. The separate drag-key assist pauses while native AI is requested/active so two drivers do not fight. Native AI chooses its own nitrous use; refilling does not force it to activate NOS.

- **Unlimited NOS:** repeatedly refills the equipped nitrous kit while driving. It does not install a missing kit or change its capacity. Experimental memory implementation, pinned to game build `6f4f1e4e`. Paused in Online/LAN races. A new game build disables memory tools instead of trying unknown offsets.
- **Engine power boost:** 1.0×–3.0× engine and nitrous torque, with 1.5× as the starting value. This increases power, not the game clock or the speedometer. The original curve is kept, so repeated updates do not multiply power again. More power can cause wheelspin and worse handling. Pause, losing focus, F9 or disabling it restores fields still owned by the extension. If the game rebuilds the tuning, the effect pauses and resumes after the new baseline settles. The selected switch stays enabled.
- **Remove stock speed limiter:** removes the stock MPH governor while enabled. Cars with an ECU upgrade may already have no governor, so this can make no difference. Gearing, redline, drag and available power still limit actual top speed. It does not add gears, change ratios or guarantee a particular speed.
- **Extra grip:** multiplies all four wheels’ actual tyre-force factors by **1.0×–2.0×**, starting at **1.3×**. It can increase cornering traction and reduce sliding, but it does not auto-steer, damp yaw, flatten the car, avoid crashes or guarantee perfect handling. High grip can cause abrupt handling or rollover, especially with extra power. 1.0× restores the baseline. It pauses in drift mode/races because drift deliberately changes rear grip. Changes are restored when paused/off where the original car and wheel objects still exist. No save-file or shared car-type data is edited.
- **Drift assist:** sends the game’s dedicated drift key directly through its version-checked input mailbox, replacing the earlier hidden-touch-control click. This uses the real drift-event handling and your Drift tuning, its built-in drift assist, camera and scoring. The game restores ordinary tuning when disabled. Solo free roam only; close game menus first. It now waits up to three seconds for the game’s actual drift-handling flag before reporting ON, and shows a useful failure message if not confirmed. The game’s mode is unavailable in ordinary races and co-op. Power/limiter/grip effects pause and restore before a drift toggle so the game can rebuild its tuning cleanly; enabled choices are retained. Power can resume afterward, while grip stays paused during drift. **This is not perfect-drift automation and does not guarantee a score, line or spin prevention.**
- **Drag assist:** experimental automatic throttle, RPM-threshold upshifts and NOS when the NOS switch is on. Start a solo drag race yourself. It uses default bindings: Arrow Up, Left Shift, Left Alt. Set the shift RPM to suit the car; 6500 is only a starting point, not a learned perfect-shift value. **You must steer. It does not change lanes, avoid traffic/obstacles, prevent damage or finish races by itself.** It waits for an active driving HUD and pauses in menus, on loss of focus, and when the tab is hidden. Its switch stays enabled; F9 explicitly turns it off. It does not handle race selection or restart.
- **Traffic / barrier tester:** opt-in read-only diagnostic using the game's live car objects and enabled barrier-line table. It reports a nearby car ahead and a barrier crossing the car's forward line. It does not alter driving or send diagnostics anywhere. **It is not a complete obstacle detector:** car objects are not classified as traffic versus racers, parked/inactive objects may appear, and scenery, props, trucks' shapes, road geometry, elevation-sensitive barriers and safe lanes are not comprehensively modeled. “No object detected” never means the road is safe.

The dropdown can stay open while you drive. Its scroll area keeps all controls reachable on smaller screens.

## Testing status and cautions

The site, its public source and exact served game module were inspected. JavaScript syntax checks and **48 automated tests** pass, covering refill logic, missing kits, pause/network guards, invalid/stale pointers, memory growth, read-only hazard extraction, bounded traversal, status-table reading, non-compounding power scaling, guarded restoration drift-input ring formatting/guards, wheel grip restoration, dropdown keyboard/click actions, focus pauses, race/car transitions, rebuild reapplication and same-tab settings restoration. Additional AI tests validate the actual injected WebAssembly bridge with simulated native calls, highest-skill save/restore, correct return-to-input calls, failed-handoff behavior, stale-heartbeat fallback, unsupported/network guards, car replacement and user takeover. The exact served game module passes WebAssembly validation and compilation after the single-function bridge addition. UI tests use a simulated DOM, not live gameplay.

**You reported that NOS and the traffic/barrier tester work. Native AI, new grip/transition behavior, power/limiter controls and the repaired drift path have not been live-verified.** The available test browser cannot run this game's WebGPU graphics, and you asked to test it yourself. These are source-backed experimental implementations, not a promise that all functions work in a live race.

## Updating from an earlier package

Extract this package into your existing extension folder, click Reload on its card in `chrome://extensions`, then reload the game. The card must show version **0.4.0**. If you load a separate new folder, remove/disable the old extension first so two copies cannot run together.

Back up your save with the game's Download backup button before trying it. Use driving modifications in solo play and follow the site's rules. The page's main thread writes shared game memory asynchronously for NOS, power and grip changes, so crashes or inconsistent behavior remain possible. If anything behaves oddly, disable the extension and reload the game. Memory changes do not survive reload; enabled choices are restored from same-tab session storage as described above.

This extension only matches `https://nfsu2.xyz/*`. It has no account, browsing-history, extension-storage, debugger or broad website permissions. It saves only its own switch/number preferences in a namespaced session-storage entry on this site. The only request it creates is a same-origin read of `/game.json` to check compatibility. At game loading, it also inspects the module response the game already fetched, checks its full SHA-256, and adds its own small bridge to the existing game-thread frame hook before compilation. This can add startup time and does not modify the site's files or bypass build checks. The extension package contains no game executable/assets, remote executable code, analytics or update downloader. If the hash or layout is different, it loads the unchanged game and leaves AI disabled.

## Native AI implementation notes

- Supported module revision: `6f4f1e4e`, exact original size `37839055` bytes.
- Required SHA-256: `ee5d281a3109240d5db25dc3921e1044672cf6d650eb58c3baa089b54fe2941f`.
- The bridge runs only at the documented `0x581475` main-loop call of `sub_004022c0`, through the existing CPU-preserving `gcall_main`. It does not invoke game functions concurrently from the page thread or enable the upstream test-script mode.
- A small command/status area at `0x00d0d100` is in the already committed split-screen scratch region, outside the inspected split-screen, minimap-diagnostic and co-op records. Exact-module hashing guards these assumptions.
- Player-car skill path: `Player+4 → vehicle`, `vehicle+0x14 → racer`, `racer+0x901 → skill byte`. The AI driver’s skill virtual getter (`vtable 0x785370 + 0x78 → 0x402580 → 0x610510`) reads this byte. The global force-skill setting is never modified.
- This is experimental client-side code. Keep your v0.3 folder/ZIP for rollback. No game binary is included in this package.

## Source references

Inspected game metadata: https://nfsu2.xyz/game.json, revision `6f4f1e4e`.
Public source: https://github.com/th0mk/nfsu2-web/tree/6f4f1e4e92f5f3ddf6f6d165b7f7075a95ab7fe3

- `runtime/career.c`: real native autopilot On/Off and return-to-input calls; main-loop hook.
- `runtime/guest.h`: CPU-preserving `gcall_main`.
- `runtime/catchup.c`: normal native skill endpoints 0 and 9.
- `tests/scripts/roam_keepright_a.txt`: native autopilot used in free roam.
- `runtime/cpu.h`: guest addresses equal WebAssembly linear-memory addresses.
- `runtime/splitscreen_mem.h`: the browser build's player array is at `0x00d00000`.
- `runtime/game.h`: game state, race, car RPM and gear.
- `runtime/mprace.c` (`perf_info`, `mprace_torque_scale`, `mprace_speed_limit`): the actual per-car torque curve, nitrous torque and MPH governor.
- `runtime/roam_game.c` (`nos_left`): nitrous duration, amount left, activation time and game clock.
- `web/src/host/process.ts`: game worker initialization and shared memory.
- `runtime/web/status_proto.h`, `web/src/app/status.ts`: self-describing status counters.
- `web/src/input/proto.ts`, `runtime/web/input_web.c`: versioned input mailbox and synthetic key-tap event.
- `web/src/app/touch.ts`, `runtime/drift.c`: native drift input, full handling/tuning lifecycle, wheel-pointer layout and tyre-force multiplier (WH_GRIP).
- `runtime/roam.c` (`log_cars`): world car list and coordinate fields.
- `runtime/walls.c`: enabled barrier lines and their segment coordinates.

No files in the upstream project were modified. This is an unofficial extension, not affiliated with the game's site or Electronic Arts.

# 0.43.1-a3a9a837-draft.1 candidate

Targets the captured a3a9a837 module. Exact raw and authored adapter chain identities are pinned. Compilation, native gameplay and live-session validation are separate gates.

Award once and Loop synthetic near misses remain available through the verified adapter. The loop confirms one request at a time, waits at full NOS and resumes after consumption; F7/F9 stops it. The removed direct-refill UI remains absent. Legacy session NOS fields are scrubbed and named profile serialization keeps nos:false for schema compatibility. Native amount1 and serial combo progression are retained; immediate/current live x5 NOS gain is not verified.

The d739e631, d396209f and earlier profiles remain registered. Unknown or failed module preparation leaves memory tools disabled. The material below is historical documentation for its named builds.

---

# 0.43.0-d739e631-draft.1 candidate

Targets revision d739e631. Raw module and adapter chain identities are pinned. Native gameplay and live-session validation remain pending.

Synthetic near miss provides Award once and Loop synthetic near misses. The loop tops up NOS through confirmed synthetic awards, one outstanding request at a time. It waits at full and resumes after consumption. F7/F9 stops the loop. The separate unused direct-refill control and its saved preference are removed; the native award routine, normal game NOS use, earned credit and NOS telemetry are preserved.

The material below is retained historical release documentation. Its feature and validation statements apply to the named older builds.

---

# NFSU2 Driving Tools 0.42.9-d396-draft.1

Uninstalled release draft for exact d396209f. Experimental game modification;
not affiliated with the game or its browser platform. No live acceptance is claimed.

The adapter chain is the immutable V10-proven composition:
raw 9d7bf57d -> primary 33a63dbe -> online 90e4084e -> composed 6cc53c4e.
The real manifest has 109 scripts, including the 76-script prefix through ai.js.

V10 completed 192/192 World frames with Controller takeover. Its authored scene,
synthetic road/marker inputs, modeled 60 Hz time and 50 ms publications remain
disclosed. Full startup, recipient observer, client-report and online qualifications
remain open. A compiled capability identifies an installed adapter; it is not a
per-feature runtime verdict.

| d396 feature | Draft availability | Evidence state |
| --- | --- | --- |
| Native AI takeover | Adapter available | V10 sustained offline movement |
| Native pace | Adapter available | Controlled OFF/ON pair pending |
| Stay on rails | Adapter available | Controlled OFF/ON pair pending |
| Paced catch-up | RBA8/RBA9 host registration available | Controlled pair pending |
| Synthetic near-miss NOS top-up | Adapter and host loop included | Native loop pair pending |
| Full tuner / power / limiter / grip tools | Unavailable on this build | Separate native policy work required |
| Online car categories, forward lease, target feedback | Unavailable | No d396 adapter capability granted |

The release validation receipt is written under ../verification after the focused
suite. This folder is a review artifact and has not been installed. Chrome's
numeric version is 0.42.9; version_name and the UI identify the draft.

## Historical 0.42.8 reference

The retained notes below describe their original version, not new verification.

# NFSU2 Driving Tools: experimental v0.42.8 draft

## 0.42.8 — synthetic near-miss awards and optional NOS top-up

Adds **Synthetic near miss → Award once** and a separate **Keep NOS topped up** switch. Both use the verified native award service for the current game module, memory and session. Unsupported builds and failed preparation leave them unavailable. Top-up starts off, is outside saved profiles and must be enabled on the current page.

The synthetic award has no speed threshold. It uses the game's original style-award routine on the current owned car. Mailbox ownership starts after driving initialization; car changes cancel an unclaimed request, and a restarted session receives a new bridge.

Direct automatic NOS refill remains disabled. The optional loop samples effective NOS, including elapsed consumption, before each synthetic request. It waits at full or overfull, resumes after consumption, allows only one outstanding request and waits at least 250 ms after confirmation before another. Missing or invalid resource state prevents dispatch. F7/F9, a changed car/session and uncertain or style-only outcomes turn top-up off; focus and permission loss pause it and request cancellation.

Synthetic awards also change style points and combo multipliers. The result distinguishes the native style award from whole-tick style/NOS changes; those NOS changes are not isolated event-specific credit. A queued award can still finish if native work has already begun. Native overshoot remains visible; page sampling cannot guarantee the resource stays below full until native consumption. Unknown, stale, mismatched or timed-out requests never retry automatically.

This is a working source update. Packaging, installation and live gameplay verification have not been performed. Historical offline results below apply to their original source pins; motion generated by this extension has not yet been cleared by a complete native trajectory test.

## 0.42.7 — automatic NOS refill disabled pending integration

Automatic NOS refill is unavailable while the near-miss integration is developed and tested offline. The refill control stays disabled, and legacy preferences, restored profiles and online permission cannot activate it. The direct `Engine.refill` entry point returns false without changing memory. Normal game-earned NOS and the game's own NOS use remain available.

The bounded near-miss replay showed native credit with flag 0 under controlled phase order, but it did not validate a production extension connection or all client reports. Artificial awards also change style points and multipliers. No near-miss refill is enabled in this release.

The existing native transforms and source/output module pins remain those of 0.42.6. The historical checks below refer to their named versions and fixtures; they do not establish the loaded browser version, multiplayer acceptance or a new upstream game build. Reload the existing extension card and refresh the game after updating the loaded folder.

## 0.42.6 — direct worker loading and scoped 60946132 support

Adds the exact reviewed game build **60946132**. Its scoped native port covers the existing AI bridge, pace/corner hooks, rails, Drag handoff/protection, owned skill and paired catch-up. Online still requires the separate explicit permission. Stop, manual takeover, stale ownership and permission withdrawal retain their native guards.

The production page now supplies a verified compiled module through its existing game-worker startup observer. It leaves WebAssembly.compileStreaming unchanged. Per-worker message order, immediate port transfers, original shared-memory identity and primary/secondary worker consistency are checked offline. A timed-out, unsupported or failed preparation retains the original game module with tools disabled. Memory-port startup stays unverified and has no page memory tools.

The replacement is authorized by freshly read build metadata, an import/export interface check and complete source/output hashes. An opaque original compiled module cannot be hashed through this interface; matching its import/export names is an eligibility check, not proof of its bytes. Only the independently compiled replacement receives a verified tool profile.

On 60946132, **the tuner, leased forward geometry, per-target corner feedback, online car-category controls, race capture and destination travel are unavailable** pending their separate ports. Their implementations and previous build profiles remain included. The full 102c8d92 pipeline retains its exact prior output.

Current game guards, monitoring and report serialization are retained. A positive encoder result means serialization succeeded, including for reports containing observations. The offline checks do not establish multiplayer acceptance, account status or measured driving results.

The offline report check reproduced a selected-car-state observation from the actual NOS refill: one changed frame and observation flag 16 in controlled race and free-roam monitor contexts. Untouched baselines had zero changed frames and zero flags. The observed fields survived local encoding; no report was sent. This uses bounded native fixtures and synthetic session state, not a full game run. A different loader does not establish a report-free refill route.

The exact captured page check returned zero marks through updated startup and four fixture ticks; the frozen 0.42.5 startup produced API-wrapper mark 2. The fixture uses native-callable browser stand-ins, clean settings and default tool selections. Worker instance postMessage remains wrapped and is not selected by that captured check. Report markers and configuration remain unchanged. These page results do not cancel the separate native NOS observation.

Raw 60946132 SHA256: 81d2e32d7ee67bb93a8fafee4dbc17570f8d4980be238d7434e15c791904b945.
Scoped native output SHA256: 8efc4457e895e4992f56a0272f66718d3900901ff7fde95e760b7585fa6f9129.

## 0.42.5 — exact native corner-target feedback

Adds observed native target decisions to the road-race settings and diagnostics on verified game build **102c8d92**. A sample records the actual target before and after the existing corner-limit hook, requested/effective limit, decision outcome, guard reasons, ownership and sample age. These are **uncalibrated native target units**, not mph or m/s.

- The menu can distinguish a geometry reduction, cached reduction, an already-lower native target, a rejected/unresolved guard and a changed publication. This observes the existing driver; it does not change pace, braking, steering, grip, shortcuts or race outcomes.
- Receipts use the game's existing worker registration channel under the site's current security policy. The extension consumes its reserved messages before the game registry sees them. Current primary and secondary workers are bound to their module, memory and session.
- Stop/manual takeover, setting changes, ownership/permission loss, stale samples and route changes clear current evidence. Tick and command-sequence boundaries reject queued records from a previous activation. Existing historical race logs migrate without losing their prior columns.
- The optional observer must match its complete expected binary hash and compile before it receives a capability. Any failure keeps the previously compiled driving, online, tuner and forward-lease module.

Native parity, receiver, loader, page and diagnostic tests passed offline. The actual current worker also delivered a native receipt in isolated Chrome under its current CSP. This is not a live race or a measured driving improvement. Transport samples at most once per 1,000 guest ticks; it is not a lossless record of every setter call.

**Other work remains isolated:** the opponent Drag margin for tracks 4211–4213 passed controlled native tests but needs a proven production control connection; the default-off Drift bend-target experiment sometimes lowers native throttle or increases handbrake and needs a live comparison; destination routing passed controlled topology/GPS checks but has unresolved native queue/allocation, route-installation and parking issues. None of those experiments is activated by this package. A complete hosted travel → join → race → return loop remains unverified.

Saved profiles, stream HUD, radar, Clean View, tuner, Street X limits, Drag engine protection, explicit online permission and Stop/manual takeover keep their existing implementations. The preset tuner remains restricted to solo Performance Tuning; this release does not enable an ECU bypass.

Raw game SHA256: `2ba0b075721d80e75fc3fb9a3b0e4d2acae835d21fcc406d009669b83f81858d`.
Observed native output SHA256: `6005ed0fe49b641542e9e2909cf38d10108959f2d2ed2ac74144866281ad8cfc`.

## Previous release details

## 0.42.4 — clear rails and catch-up controls

This update fixes misleading assistance controls. It does not change the native driving, cornering, grip, power, shortcuts, tuning or network policy from 0.42.3.

- In a permitted rails road race or Street X, the assistance row says **Race pace · rails mode**. Catch-up strength is visibly inactive because paired grip/power assistance is not used there. Its selected value is retained for full physics and Drag.
- Switching rails off restores the strength control. Drag keeps its strength control and neutral paired pace. Recovery continues to show speed-only behavior, including when a stale physics sample still says rails is on.
- Messages, tooltips and accessible labels now distinguish pace targets from paired handling assistance. Online permission, Stop/manual takeover and saved driving preferences retain their existing behavior.

Validation: controlled page/mode regressions cover solo and online road races, Street X, Drag, recovery, permission changes, Stop and preserved settings. No live lap or measured grip/speed improvement is claimed. The existing nativeRoadTarget diagnostic is a sampled value in uncalibrated native units; it is not a per-setter explanation. A new per-setter receipt remains research and is not included.

The route-geometry and cache-lease changes from 0.42.3 remain unchanged. They still require the appropriate active AI, rails and Adaptive road-race speed settings for Circuit/Sprint/URL; live driving verification remains pending.

## Previous release details

## 0.42.3 — route-based corner limits and rails diagnostics

Supports the verified game build **102c8d92**. This update targets intermittent road-race corner control while retaining the existing tuner, Runway 15 loop, saved profiles, streaming displays, Stop/manual takeover and online permission.

- **Corner limits:** enable **Adaptive road-race speed** with **Stay on rails** and an active owned AI driver for Circuit, Sprint and URL. Online also requires **Allow network tools**. The current-build route sampler now supplies a corner-speed limit even when native corner records are empty. Controlled tests cover sharp and gradual bends, including 75-degree and sharper turns; straight targets and lower native targets are preserved. The existing selected pace still applies. Adaptive remains session-only and starts off.
- **Sample renewal:** a validated corner limit can remain usable while the next route sample is captured. The native driver retains and rechecks its original route, ownership, permission and age constraints. Slow or missing sampling does not extend the limit's lifetime. Stop and context loss revoke the request. The new sampler does not operate in Drag, Drift, Street X, free roam, recovery or full physics.
- **Rails recovery:** pause, focus loss and stopped game frames no longer advance recovery timers. Losing the HUD or permission does not reset the same race's two-release allowance. This fixes a reproduced recovery defect; it does not explain every reported wall hit.
- **Diagnostics:** brief rails transitions are retained within existing log budgets. Corner plans survive the shorter sampling callbacks long enough to be logged. The export distinguishes a requested limit, a native cache acknowledgement, renewal and expiry; an acknowledgement is not a claim of continuous application or collision-free driving.

The optional native lease stage is enabled only after its exact output compiles. If it is absent or fails, the previously compiled driving and tuner module remains usable with this new geometry feature disabled. Current raw game hash: `2ba0b075721d80e75fc3fb9a3b0e4d2acae835d21fcc406d009669b83f81858d`. Lease-adapted output: `842f84cdac800f39a292b0d82c3182f4e225a3e1663541473bdc76f10528aae2`.

Validation is offline: controlled actual-native sampling and speed-setter execution, route and permission guards, page scheduling, loader fallbacks and mode-preservation checks. No live driven lap or complete hosted travel → JOIN → race → return has verified this release. These changes do not establish perfect cornering, improved race results or streaming autonomy. The tuner remains solo Performance Tuning only; the ECU clamp-bypass recipe is still unavailable on this build.

## Previous release details

## 0.42.2 — race loop, preset tuner and mode corrections

Supports the verified game build **102c8d92**. Circuit, Sprint and Drag retain their existing driving requests and native paths. Saved profiles, streaming HUD layouts, Stop/manual takeover and explicit online permission are preserved.

- **Race loop:** adds the missing current-build hosted-lobby and race-start mappings. **Runway 15 only** selects the unique normal Runway 15 start, sets Wait here and disables general Drag discovery so the loop stays on that race. It waits for an open host and repeats after the game returns; an absent or ambiguous start is reported. Press Start selected loop after selecting it. In career free roam, enable Allow network tools, choose race locations or open Drag-lobby discovery, and press Start. The loop uses the existing travel, stationary wait, exact JOIN, race and return flow. A missing, stale, full, private or changed host cannot become a create-lobby request. Offline state-machine and native JOIN dispatch checks pass; a complete live trip still needs verification.
- **Street X:** the 1.15× rails ceiling now also applies when a saved Custom race pace is selected. With rails off and paired handling selected, both driver and handling request neutral 1.00× pace so their guards agree. The menu distinguishes the applied request from the saved selection. Street X rails/recovery parks conflicting legacy power/grip. Other race types retain their selected pace.
- **Drift:** parks saved legacy power/limiter overrides while the native Drift driver owns or releases the car. Native Drift steering, scoring and full-physics behavior are unchanged. This removes a conditional interference source; it is not a verified higher-score driving algorithm.
- **Free roam:** current-build contact preview now recognizes cars eligible for the enabled no-clip categories, instead of unnecessarily reducing pace for them. Native corner assist remains eligible during bounded city pace reductions for the same owned car and route. Walls and unproven contacts still count. Free roam retains full physics; this does not put the city driver on rails or establish perfect cornering.
- **Preset tuner:** restores Load settings, all 41 editable fields, private native Preview/search, Stage selected preset and Restore for the current build. Capture can initialize the native policy cache, avoiding a disabled-Load deadlock. Both verified memory windows retain bounds and committed-page checks; invalid snapshots still fail S42. The tuner requires the **solo Performance Tuning main screen**. Online tune writes and the separate ECU clamp-bypass recipe remain unavailable.

For tuning: enable the preset tuner, select the race preset in the game's solo Performance Tuning screen, Load settings, edit or Find tune, review Preview, then Stage selected preset. Use the game's Test Run to refresh driving physics and Save Profile to persist. Estimates are private native calculations, not measured lap times or confirmation of a disk save. Restore requires the same unchanged car, parts and preset.

The combined loader grants tuner capabilities only after both its native bridge and private evaluator compile. A failed optional tuner/city stage retains the last successfully compiled driving module. Current game metadata was rechecked before packaging. Unknown builds remain unsupported until independently verified.

Validation is offline: actual native snippets, private evaluator, controller/state-machine tests, actual-manifest compile/fallback tests and an isolated Chromium panel smoke check. No live race, live tuning session or complete hosted travel → JOIN → race → return was driven for this release. Three older UI/trace assertions also fail on the frozen 0.42.1 baseline; five additional historical tuner tests cannot run because their archived research fixture is absent. These limits are recorded in the workspace handoff rather than presented as passing.

Raw game SHA256: `2ba0b075721d80e75fc3fb9a3b0e4d2acae835d21fcc406d009669b83f81858d`. Combined online + city + tuner output: `3b11494b6824ced9888c5c4a9d3efc2ae86d75d0673544f0602d34a9bacabcfc`. Compared with 0.42.1, only native function 4653 (city corner eligibility) and function 21213's existing tuner prefix change.

## Historical release notes

The entries below describe those releases; the 0.42.5 section above is current.

## 0.42.1 — online native AI and car contacts

This update builds on the installed 0.42.0 package for exact game build 102c8d92. Enable **Online & diagnostics → Online / LAN opt-in → Allow network tools**, then select **Race-only automatic driver** for races or **Automatic driver** for free roam. Network permission starts off unless deliberately restored by a consent-bearing saved profile. F7 takes control; F9 stops tools and clears permission.

- Circuit, Sprint, URL and Street X can use Stay on rails online for the locally owned AI car. The existing 1.30× paired race pace and 1.15× Street X ceiling remain (Custom race pace still overrides Street X). Rails raises speed targets only; Catch-up strength does not supply grip on rails.
- Drag keeps its distinct opponent-driver/shift path and engine protection. Its paired handling boost uses neutral paired pace. Street X with rails off also uses neutral paired pace. Native catch-up inputs, generation/identity guards and explicit network permission still control application; no constant grip or winning claim is made.
- Skill-9 decisions work for the owned AI car online at the same seven reviewed decision sites. The player's saved skill marker is unchanged. The display is current eligibility, not a count of those decisions firing.
- Online car no-clip can select traffic, other players and NPC rivals, including verified current race and Outrun participants. The local contact filter, bounded rosters and per-category switches are retained. It does not change walls or props, and a local skipped contact does not prove a remote client skipped it.
- Current-build online free roam is recognized using the verified host tuple. Missing tuple memory makes this build unready instead of treating it as solo. Free roam keeps its existing native driver; the race rails pin is not enabled there.
- Recovery now counts rails releases across a driver rebuild, while resetting for an actual race/player/context change. It retains the existing two-release maximum. Diagnostics export rails request/current state, pin count, recovery state, online adapter/permission eligibility and skill-9 eligibility, with migration of prior logs.
- Online capabilities are granted only after the exact native online module compiles. Missing, wrong, throwing or invalid adapters retain the verified 0.42.0 solo module. Unsupported forward readers remain disabled rather than being advertised by the native transplant alone.

Offline native, controller, actual-manifest and page checks are recorded in the workspace handoff. These do not establish live online race results, server acceptance, cornering on every track or streaming autonomy. The broad older UI suite retains two pre-existing stale text/style assertions, reproduced on unchanged 0.42.0; behavioral checks pass.

The tuner/dyno/ECU panel, hosted travel/join loop and forward road reader are still unavailable on this exact game build. This update does not port those features. Saved profiles and HUD layouts are not rewritten.

Native pins: raw game SHA256 `2ba0b075721d80e75fc3fb9a3b0e4d2acae835d21fcc406d009669b83f81858d`; original 0.42 transplant `f113eb5dcd1292b6aac0e97837e653c9821b8a0a0efdfa221331d2fbf58fbe29`; adapted output `5bb985a5a7a77efabce919d7c3cd872c94466f3d66522449a106511413434fdf` (39,053,221 bytes). Nine native function bodies change; other bodies and non-code sections remain exact.

## Previous update — new game build and "Stay on rails" (0.42.0)

nfsu2.xyz moved to game build **102c8d92**. 0.42.0 supports it: the whole reviewed native hook set from the previous build is applied to the new one as a single pinned transform (`native-transplant-102c.js`), and the page-side addresses for this build are in `102c-profile.js` and the build registry.

**Stay on rails** (Race / outrun tuning, on by default) is the cornering fix. The game drives opponents on a simplified physics mode and switches a car to full physics after a contact. For your AI-driven car that switch was permanent, and on full physics a raised pace overshoots corners. On rails your race AI car keeps the opponents' mode in solo Circuit, Sprint, URL and Street X.

- On rails, **Race pace + catch-up** only raises speed targets. The **Paired race pace** slider is the multiplier (default **1.30×**; Street X at most 1.15× unless Custom race pace is on). No power or grip boost is applied and Catch-up strength is not used. Drag keeps the paired boost.
- If the car stops for 3 seconds, the rails release so the game's normal physics can recover it, then return once it is moving again (two releases per race at most).
- Turn Stay on rails off to get the 0.41.0 behaviour back.
- This build is **solo/offline only**: Allow network tools is disabled and the online tools are unavailable. The preset tuner / dyno / ECU panel is not ported to this build.
- Offline checks only; nothing was driven live. The Driver line shows "on rails" while the car is on the simplified mode.

## Best-opponent skill for your AI car (0.41.0)

When the native AI drives your car, the game still reads the player's skill marker (254), and its AI code clamps that marker to skill 0, the weakest level. From 0.41.0 the AI's nitrous decisions, Drag launch delay and per-skill decision chances use **skill 9**, the best opponent level, while the extension's native AI owns your car in a solo session. Your racer record and save are not written. Opponents and online sessions are untouched. Where the game already treats the player's car better than any opponent (no random target-speed variance, no off-screen reset), it is left alone.

The Driver line shows "skill 9 …" while it applies. There is no switch: it follows the AI driver. Exact ed8d3359 only. Live racing is unverified. This release also makes the panel show the installed version (it stayed on 0.38.18) and removes a wrong "Game Catch Up is off · matching boost unavailable" line.

## Player-only constant catch-up (0.39.0)

**Race pace + catch-up** now gives your AI car a catch-up boost even when the game's Catch Up option is off and Mods: Rubberbanding is Off. Only your car is boosted; opponents keep the game setting. The boost is constant to the finish line (pace × strength), not gap-based, so it never eases off while leading.

Defaults: paired race pace **1.00×**, catch-up strength **1.50×**. Turn on Race-only automatic driver, open AI driver → Road-race settings, and make sure Race pace + catch-up is on. 0.40.0 adds Drag and Street X (catch-up strength only, pace neutral). Drift is not covered. Never applied online. Exact ed8d3359 only. Live racing is unverified.

## Current update — ed8d3359, November 11, 2026

Adds exact compatibility for game build ed8d3359,38,862,537 bytes, SHA-256 `f9e0002e8a04a88355b3cc62235010e19479e0cf2ab05d8916975d68abf5706b`, together with the preceding b1efa173 build. Native driving/Drag/protection/contact, road/forward/shortcut/catch-up, hosted readers, normal tuner and ECU/turbo recipe use separately checked current native mappings. All fourteen prior complete native outputs remain exact. Unknown hashes still refuse memory tools.

The old scoped numeric-clamp bypass is retained with Measure recipe, Apply recipe and Undo recipe. Original native environment/online policy, evaluation, CPU/stack restoration, car/part ownership, S42 window bounds/commitment, Stop/cancellation, rollback and Undo remain required. An unresolved native policy reports S75. Controlled private estimates and scope-hit receipts do not establish live or saved power gains.

Street X, Drag engine protection, profiles, menu, stats HUD/radar, Clean View and explicit online consent retain their behavior. Offline native execution, complete-loader and package checks are separate from gameplay. Live activation, tuning gains, cornering, shortcuts, online contacts and full travel → JOIN → race → return remain unverified. Automatic Outrun acceptance and unattended streaming autonomy remain unfinished.

## Retained B1 compatibility

Adds exact compatibility for game build b1efa173, 38,854,040 bytes, SHA-256 `3152b96dbd39c9aaac00f47cb63afff46969d88cd7470166478c9663c9abb1bb`. This build retains38 function imports and adds27 defined functions. Current driving/Drag/protection/contact, route/forward/shortcut/catch-up, hosted readers, normal tuner and scoped ECU/turbo recipe have independently checked native mappings. All thirteen older complete native outputs remain unchanged. Unknown hashes still refuse memory tools.

The requested old numeric-clamp bypass remains available during a valid owned solo tuning scope, together with Measure recipe, Apply recipe and Undo recipe. The current native environment/online policy, original evaluation, CPU/stack restoration, part/car identity, S42 window bounds/commitment checks, cancellation and rollback remain required. An unresolved native policy reports S75. Offline private measurements and clamp-scope hits do not establish saved or live driving power.

The existing Street X policy, Drag engine protection, saved profiles, Stop/manual controls, stats HUD/radar and explicit online consent retain their behavior. Offline native execution, complete-loader checks and package audits are separate from gameplay. Live activation, tuner gains, cornering, shortcuts, online contacts and a complete travel → JOIN → race → return remain unverified. Automatic Outrun acceptance and unattended streaming autonomy remain unfinished.

## Retained .16 exact-build and ECU port

Adds exact compatibility for game build bdc9cbc2, 38,839,976 bytes, SHA-256 `395d7d34809be586e9ec80866914179247e96df7cb5729c7b8c7e4650c6dee3e`. This build has an additional native function import and changed native routines. Its driving, Drag/protection, contact controls, road lookahead, shortcuts, paired catch-up, hosted-race readers and tuner use separately checked current mappings. Unknown binaries still refuse memory tools. All twelve older complete native outputs remain unchanged.

The requested old ECU numeric-clamp bypass is ported inside the new wrapper, after its original native evaluation and policy selection. A valid owned, solo Skyline tuning lease skips only the numeric correction. The new environment/online checks, original evaluation, CPU and stack restoration, part/car identity, memory bounds/commitment checks, cancellation and Undo remain required. The normal tuner retains S42 checks for both verified guest-memory windows; an unresolved native environment policy reports S75 instead of assuming permission. Use Measure recipe before Apply recipe. A scope-hit or a private evaluator result does not establish persistent driving power.

The new-build paired catch-up guard also uses the current native catch-up option field; a stale earlier address could reject valid assistance. Its Original-mode check and all ownership/publication checks remain. This is a verified compatibility correction; smoother live pace, grip, cornering and shortcut use remain unverified.

Offline module composition and controlled native execution are checked separately from gameplay. Live activation, tuner use, driving quality, online contacts and a complete travel → JOIN → race → return remain unverified. Automatic Outrun acceptance and unattended streaming autonomy remain unfinished. This update adds no radio/audio or game assets.

## Retained .15 tools, Pitwall and showcase

The larger menu groups Driver, Race loop, Tuner / ECU, HUD / cameras and Advanced controls, with readable driver/loop/tuner feedback and sticky Stop/manual buttons. Legacy manual Drag controls remain available under Advanced; native Drag driving and engine protection retain their existing behavior.

The tuner shows its actual blocked reason and measured original-to-preview power, torque, 0–60 estimate and top-speed estimates. Load settings is outside the collapsed editor. Missing, stale or unavailable measurements stay blank. These are private native evaluator estimates, not measured live acceleration or persistent saves. Solo Performance Tuning main screen and the existing owner, memory-window and commitment checks remain required. Recurring live S42 reports still need an observed reproduction; this update removes no bounds checks.

Optional Pitwall is a visual, movable/resizable HUD widget using existing fresh telemetry, route-preview and rear-radar observations. It clears advice on Stop/manual takeover and invalid context, and hides with Clean View or the tools/hub. It includes no radio or audio. Corner evidence is labelled as captured preview or requested native target; direction, actual braking, gap metres and results are never invented.

Race Hub now includes manual settings by race type through existing saved profiles, bounded local stream-moment markers, a garage comparison and tonight's scorecard. Save creates a new ordinary profile; Load uses existing consent, revision and handback checks. Mode changes apply nothing. Markers are local timestamps and observed speed/mode events, not captured video. The scorecard reports observed driving time, top MPH, places and race segments, not finishes or wins. Garage identity stays unknown when unverified; the exact943 private-capture fallback is explicitly labelled as a tuning snapshot. Comparisons require fresh, matched tuner results.

A reproduced city-clearance defect treated harmless advancing heartbeat ages and unrelated memory-commitment bits as lost no-clip proof, lowering a selected 1.85× pace to .75× in controlled cases. Valid unsigned heartbeat ages below180 and the positively used commitment bits are now checked semantically; exact command, owner, car/slot and memory identities remain required. Native traffic avoidance, steering, paired catch-up formulas and physics are unchanged. This fixes that offline reproduction; it does not establish that all live free-roam braking or wall hits are solved.

Offline combined regressions and independent source/package audits are reported separately from gameplay. Live tuner use, free-roam/corner quality, shortcut choices and a complete travel → JOIN → race → return still need verification. Automatic Outrun acceptance remains unfinished. Unattended streaming autonomy remains unfinished.

## Retained .14 travel and compatibility work

The Drag lobby travel/join update corrects three reproduced offline defects: active automation permanently stopping after a brief torn catalog read, valid native road-table aliases rejecting the road graph, and a lobby becoming full before the final JOIN reread. Only the two catalog-refresh reasons can pause for up to one second. Control is released immediately; recovery requires fresh identity, an advancing game tick and manual handback before travel resumes. Hard stops still cancel the session. A pending JOIN retains its exact target and timers and is never resent during recovery.

The logger now exports fixed autonomy phase/stop codes, bounded waypoint progress, control requests and refresh-pause evidence. It migrates prior trace rows and excludes host/lobby identifiers, positions and key contents. Offline regression tests establish the fixes and guards; live travel → JOIN → race → return remains unverified. Native Drag driving, race physics, Street X policy, saved profiles, streaming displays and online controls are unchanged.

The forward road sampler now recognizes the three verified nearest-rounding native numeric modes on exact943ee537. The previous guard accepted only one, while the current game also initializes other supported modes. Numeric constants, captured mode, ownership and use-time checks remain mandatory. PC24 interpolation mirrors actual native rounding, including tiny values. The sampler reports the observed mode and a bounded failure mask. This fixes a reproduced compatibility defect; live complete-route capture and improved Circuit cornering remain unverified.

City clearance now isolates each car's eligibility proof. A bad or uncommitted car remains solid without cancelling independently verified no-clip cars. Global context changes still restore every raw hazard. Controlled actual-controller fixtures retain selected pace with a verified ghost plus an unrelated bad observation, and still slow for a solid obstacle. This does not establish collision-free live free roam.

The selected race loop has a stable Start presentation during brief catalog refreshes and reports the exact blocked check. Clicking requests a fresh catalog within1.5seconds; cached rows never authorize travel or JOIN. Enable Visit open Drag lobbies to discover exact fresh public Drag offers without selecting static starts. Optionally enable Native AI cruise while finding Drag, then press Start. Both options are session-only and start off. Discovery pins one host/lobby/event/destination; it releases native cruise and waits for a new manual handback before travel. Stationary arrival and typed JOIN4 remain mandatory. A vanished target waits for the same lobby unless the explicit rotate policy chooses a new trip. No replacement lobby is created. Stop/F9, Manual/F7 and driving keys cancel. Live travel and a complete join →race →return loop remain unverified.

The tuner includes experimental ECU / turbo Measure recipe, Apply recipe, Undo recipe and Stop ECU controls inside its existing menu. They require exact943ee537, a solo Skyline and native level3 ECU/turbo parts. Measure uses original native functions in private memory; Apply replays and checks the ordered native slider actions on the game thread. Undo restores the exact captured car and tuning visits while the session remains unchanged. Menu close, blur, hidden tab, Stop, manual takeover, tuner disable and session replacement revoke the scope. The actual game CPU is preserved; callbacks use an owned scratch CPU with an explicit tool numeric mode.

The controlled Skyline fixture measured400.060→406.422kW after rebuild, about1.59%. The proper recipe produced the same gain with and without the scoped current-clamp bypass. A separate excessive control reached a larger transient result; that is not the recipe's result and did not survive rebuild/import. Large persistent power, live driving benefit and saved persistence are not established. The normal S42 second-window tuner checks remain.

Drag AI/protection, Street X policy, saved profiles, compact controls, HUD/radar and online controls retain their existing settings. Auto-Outrun acceptance is still unfinished: native acceptance sites are identified, but no verified automatic transaction is shipped. Unattended streaming remains experimental. Offline regression/native-composition evidence is separate from live-game verification.

## Retained full-physics publication correction

An active automatic driver could stay waiting for handling-input publication because the full-physics hook checked the runtime CPU structure against guest-object bounds. The runtime CPU lives outside that guest region. The v0.38.10 correction gives the CPU its own aligned, full-state check against actual Wasm memory size, while retaining the strict bounds and commitment checks for the car, physics objects and guest stack. The native physics calculation, selected pace and strength formulas remain unchanged.

The focused native regressions exercise the full publisher with a high runtime CPU address and no guest commitment bit for that CPU. Matching handling inputs remain required before extra paired pace is confirmed. A later live v0.38.10 export on 943ee537 recorded full four-tire and simplified combined-input publication with applied handling receipts. That verifies those observed publication paths; it does not establish improved cornering, race wins or complete .11 behavior. Stop, manual takeover, saved profiles, Street X, Drag protection, HUD and the existing controls retain their behavior.

## Handling evidence and selected city pace

Race pace + catch-up pairs a selected extra race pace P (1–2×) with an independent catch-up strength S (1–10×, quarter steps). Strength changes the assistance, not the speed target. The initial selections are pace2× and strength1×; these are authored controls, not a claim about the game's maximum. Loading follows an already selected Automatic/Race-only driver and does not acquire a manual car.

On exact AA/15e/943 builds, paired assistance follows the native physics path already selected by the game. Full physics uses four tire inputs; ordinary simplified AI physics uses its combined-grip input. This update corrects receiver identities and supports those paths separately without forcing a different physics mode. The native driver/car catch-up source caches remain unchanged. From original publication M, the handling scalar/aerodynamic divisor E is f32(f32(M×P)×S), and the nominal grip input is f32(E×P). Native modifiers remain in the combined-grip path. These are handling inputs, not measured engine power, tire grip, speed gains or a guarantee of winning.

Extra pace waits for current matching physical-input evidence. Full and simplified physics use different evidence kinds; requested pace, requested strength and verified application remain separate. The tools panel says requested pace while physical support is waiting. Bounded acknowledgement-rejection and native-stage codes enter the local log to distinguish failed identity/output checks from an unobserved publication. Owner, command, actual physical output, mode or permission changes revoke gain. Raised corner targets retain native use-time checks. When paired support is unavailable, the corner fallback uses the same neutral pace as the final target, avoiding an extra division by the selected pace. The base grade and braking tables remain planning assumptions, not load/contact measurements.

Online city clearance pacing keeps your explicitly selected free-roam factor as its ceiling, including values above 1×. Clear or unavailable observations retain that selection; an observed wall/vehicle hazard can reduce the runtime request and recovery moves back toward your ceiling. Unchanged observations no longer compound the same reduction on every page tick. A timing interruption preserves the current same-owner slowdown and selected ceiling without adding recovery credit. Selected corner-planning pace stays stable while the separate city request changes, so the reduction does not rebuild the native driver. Existing exact-build online detection, current ownership, mode and permission checks remain. These partial observations do not establish route safety or collision avoidance.

Free-roam corner assist now compensates its approach-braking input by pace squared on these same three builds, matching its existing corner-speed compensation. Previously the braking hook skipped ordinary free roam while its target still received the selected extra pace. Actual native getter/approach fixtures at 1/1.5/2/3× prove the corrected approach envelope retains the native braking assumption. Lower/equal pace, race commands and special modes retain their existing paths. Ownership, route, table, mode, permission and use-time checks remain. This fixes a calculation mismatch; it does not prove that it caused an individual crash or change steering, traffic avoidance or recovery.

The streaming HUD and race hub use factual English track names, including Outer Ring, Bayview Plaza and Airport Circuit Track 5, for all 100 primary race IDs. The city is labelled Bayview. Unknown locations display as unavailable instead of internal track numbers. These names are a static factual projection of the user's existing game language table; no game language asset is packaged, and no new live memory reader is needed. Widget positions, sizing and Clean View keep their existing behavior.

The viewer HUD shows MPH, gear, RPM, location, places driven, top speed and driving time. MPH follows the native HUD's float32 conversion and truncation; it is the game's display convention. The session meter starts with this page and includes both manual and automatic free-roam/race driving. It credits only consecutive live samples no more than 500 ms apart, so hidden tabs, menus and invalid observations cannot add an unobserved gap. Saved race-history totals never become session records. Rear radar keeps its nearest distance and dot labels in game-distance coordinates without claiming independent metre calibration. Technical driving status remains in the tools panel.

Rotate camera is a separate toggle, off on reload. It requires Camera bound to C and uses that key at a random interval from 45 to 120 seconds during active driving. Menus, text entry, photo/drone mode, unfocused/hidden pages and changed sessions rearm a fresh interval. Pressing C postpones the next change; F7/F9 switch rotation off and release any automatic key pulse while preserving a real held C key. A current worker error also disables it. The toggle changes no performance settings and requires no online driving-tool permission. Timer and page-input fixtures are distinct from live camera verification.

Stop, manual takeover and profile Load disable paired assistance. Saved profiles retain their schema and custom values. Independent power/grip controls are parked while paired assistance owns an ordinary road race or awaits restoration. Street X, Drag, Drift, Outrun and free roam retain their separate controls. A matching verified handling path, game Catch Up On / Original and explicit online permission are required. Unattended streaming autonomy remains unfinished.

On exact game builds aa2429fb, 15e5958f and 943ee537, selected pace now scales the native speed factor when the racing AI consumes it. It leaves the native driver cache and vehicle catch-up factor untouched. The previous wrapper could multiply its own cached result again before the game's next refresh; actual native fixtures reproduced 1.95 → 3.80 → 7.41. This correction removes that authored cache mutation. Native corner/behavior limits and the optional forward target can still lower the resulting target. Street X uses its existing native tables and corner controls; it receives the cache correction without the ordinary-road shortcut policy.

Adaptive road-race speed also enables a targeted experimental shortcut-choice policy on aa2429fb, 15e5958f and 943ee537. The car's raw player skill marker254/signed−2 stays intact. Only the eligible owned Race action's branch-choice check consumes skill9 instead. Native graph, category, probability, direction, event and checkpoint rules stay in control. It does not force every shortcut, replace pathfinding, or prove that a real shortcut completes correctly. Drag, Drift and Street X remain excluded from that branch policy. Stop prevents further authored branch-choice substitutions; an already cached native decision can persist until the game replaces it.

The 250 ms local driving trace retains separate requested/applied pace, current native driver and car catch-up factors, target/control values, corner-record coverage and planner evidence. The new factor readings are bounded read-only observations. Shortcut installed/requested flags are not branch-use receipts. Previous v0.38.5 trace rows survive a same-tab upgrade with nulls for the new fields. Samples, offline native tests and compiled output checks are distinct from live-game verification.

The preceding v0.38.7 native-calculated mode requested extra pace1 and observed original publication at Off/100. The later paired controls keep pace and strength separate. The traced Original catch-up calculation has no fixed numeric upper clamp; neither pace2× nor strength10× is a native game maximum. Driver/car source caches stay native.

This selection follows eligible Automatic/Race-only road racing by default unless the durable Stop marker is set; loading alone does not acquire a manually driven car. Switching it on arms Race-only AI if needed. The extension reports the native Catch Up flag and does not enable a global setting. There is no claim of perfect grip, automatic wins or live collision-free driving.

## Racing and cornering

- v0.38.7 removes a node-spacing error: inserting redundant straight nodes no longer changes the target for an identical physical bend. Curvature uses canonical bends with bounded physical arms; gradual arcs and accumulated75° priority turns remain included. The lower-only corner target retains priority over added pace and physical requests. These are planning assumptions, not a measured collision-free racing line.
- On AA/15e/943, corrects the authored continuous corner blend that could lower an already suitable native target. Command3 now leaves a tiny, nonlimiting bend at its native ceiling and uses a lower-only curvature target for limiting bends, with pace compensation. Only the authored command3 expression changes; free-roam/Street X corner commands, native branch selection and all publisher/physics paths retain their prior code. Offline native cases include unchanged gentle bends and a curvature-at-limit example improving its requested target from27.55 to38 at a native ceiling40; these are target values, not a live speed measurement.
- Calculated mode removes the stacked80%/15% corner discounts and75% braking assumption from its forward node plan: it uses the native grade-table values, no extra distance reserve and the minimum100ms reaction required by the existing target lease. The native corner-record hook retains its supported95% factor with zero sharp-turn discount and full native braking. Saved custom sliders remain available to explicit Adaptive mode when calculated mode is off. Native factors above4 pass through unchanged but exceed the existing node-adapter eligibility range; node-cap coverage is unavailable there, rather than clamping native catch-up to4.
- Ordinary-race Adaptive keeps your selected native pace when optional corner records are absent. The previous policy could hold a 2× selection at 1×, with repeated partial clearance scans reducing it to 0.75×. Those heading-ray observations remain diagnostic for races; native braking and existing corner controls continue.
- The optional forward planner no longer treats the end of a preview as a stopping obstacle or imposes a fixed straight-road ceiling. A straight or unsupported preview leaves native driving in control. Zero, negative and nonfinite optional caps cannot stop the native target.
- On exact **8abf9be8, 93cfc6e9, aa2429fb, 15e5958f and 943ee537**, node lookahead can use a game-thread receipt of the game's own grade-dependent grip and braking tables. It measures gradual and accumulated 75°+ bends on original checked road anchors, rather than creating extra curvature at interpolation knots. Its maximum horizon is 512 native route units, clipped to the actual checked source and the unchanged 24-anchor/40-node budgets; a short source stays short. A measured bend supplies a braking envelope; passing its anchor alone is not treated as proof of corner exit. The outgoing-heading release rule is authored assistance, not an unchanged native algorithm.
- Corrects two folded native evaluator guard cells in each d2fa4f4c, cd5b74d5 and 8abf9be8 forward adapter. They previously still addressed the older 3bdd9959 lookup. Only that authored slot helper changes in those earlier complete outputs; original native bodies and all other sections stay identical to v0.38.1. The new build uses independently verified current cells. Stale-cell fixtures now leave the older addresses empty.
- The native target lease binds the car, driver, route, request, event, clock, grade, ride/type table, selector, policy constants, committed pages and network permission. Changes revoke the optional target. Native lower, stop and reverse requests remain authoritative. Other supported forward builds retain read-only preview in the production page.
- Free-roam corner assistance now compensates for the selected pace. A 2× boost no longer doubles an assisted corner target. Previously ignored sampled gentle bends are checked when increased pace makes them limiting. Changing a boosted planning pace rebuilds the cached native route once; sub-native runtime changes share the original 1× plan. This still needs a usable native corner sample and does not prove that every free-roam turn is covered.
- Existing Street X corner formulas, Drag AI and engine protection remain. The AA pacing correction changes speed-factor composition without changing the native cache or adding a steering controller. No global skill-sentinel overwrite, lobby creation or opponent manipulation is included.

## Streaming display and rear radar

Shift+Insert hides controls, hub, launcher, Stop buttons, old Info HUD and the game's detailed performance column. Only selected Streaming HUD and rear radar remain. A second Shift+Insert restores the prior controls; F8 opens the menu. F7/manual and F9/Stop remain effective. Text-field paste is preserved.

The stats-only stream widgets and thin transparent rear half-circle have independent positions and 60–160% scales. Enable Edit HUD layout to move/resize them, then leave edit mode for click-through gameplay. Display layout is stored separately from driving profiles.

The radar's native blink-out flag is one byte. Reading four bytes could reject visible cars because neighboring native state was nonzero; both local and peer checks now read the byte. Solo and opted-in online fixtures cover this correction. The radar observes locally loaded cars behind you, shows the nearest eight within the selected 50–500 native-unit range, and retains ownership, commitment, list and freshness guards. It does not identify rivals or guarantee all online cars are loaded. Its live readings remain to be verified.

## Using the update

Keep the existing Desktop\NFSU2-Driving-Tools folder as the single unpacked extension location. Load this version into the existing extension, then refresh the game; a full Chrome restart was previously necessary to replace a retained older content script. Check the displayed version before testing.

For road races, use Automatic driver or Race-only automatic driver. Race pace + catch-up follows that driver by default on its supported builds, enabling the existing ordinary-race shortcut eligibility policy and corrected corner targets. Set pace and strength separately. Native probability, category, direction and checkpoint rules still decide whether a shortcut is taken; installed/requested flags are not evidence of taking one. Turn paired assistance off to use the custom Adaptive ceiling/corner sliders. For boosted free roam, enable Free-roam corner assist so its compensated native targets are requested. Online operation still requires Allow network tools. Stop remains available, and F9 works in Clean View.

The session-only City clearance pacing choice follows the explicit free-roam pace selection, from 0.75× to 3×, through initial acquisition and reacquisition. Current owned observations can lower its runtime request without changing that selection or its corner-planning ceiling. Unknown road coverage keeps the user-selected ceiling and never counts as route proof. It is not a steering or complete route-following system.

Saved profiles/schema, HUD/hub, online controls, car selection and the compact menu are retained. The R34 label identifies observed stock-name data; this update does not select or retune a car or claim a fastest R34. Race Hub reports bounded observed driving segments and native-speed samples, not fabricated finishes, wins or lap times.

## Compatibility and verification limits

Exact supported racing builds are 6f4f1e4e, 2f0ddd3b, 78e2bb69, 93af6ccb, 3bdd9959, d2fa4f4c, cd5b74d5, 8abf9be8, 93cfc6e9, aa2429fb, 15e5958f, 943ee537, bdc9cbc2, b1efa173 and ed8d3359. Unknown binaries refuse memory tools. Native-table lookahead is restricted to its separately verified exact builds. Physical grip, actual braking performance, road banking and complete route coverage are not established by native planning-table parity.

The guarded normal tuner is enabled experimentally for exact943ee537, bdc9cbc2, b1efa173 and ed8d3359, including the verified second guest-memory window; S42 bounds checks remain active and live-game tuning remains unverified. Full-route recorder support remains unavailable on this build. The selected race loop is available experimentally on exact943ee537, bdc9cbc2, b1efa173 and ed8d3359 for travel, stopped arrival and matching-host join → race → return; the complete live loop remains unverified. A disappeared selected host must never create a replacement lobby. No new live grip/downforce, online no-clip or aircraft fix is claimed.

The new forward road policy still excludes Street X. Offline v0.33/current Street X command, corner and skill-sentinel audits establish parity for those tested inputs; they do not explain the user's live collision report. The optional native shortcut-choice policy requires live route/checkpoint testing; it retains existing native eligibility and does not force a link. The experimental current tuner retains the native clamp and uses the verified private evaluator; its live-game workflow remains unverified.

The release verification receipt records the canonical test count and the same eight historical test-file exclusions caused by missing handoff fixtures. Native bodies and sections outside the explicitly authored hooks are compared, and the complete outputs compile. Offline execution is distinguished from live-game verification throughout the diagnostics and release receipts.

Music is supplied separately from extension code. The game's native music importer requests the actual matching MusicSFx.mus and MusicSFx.mpf files from PFData. Other playable audio uses Your music → Choose folder. A PS2 image uses a different layout and must be inspected; renaming unrelated files does not make a compatible PC pair. The seven additional requested songs have not been downloaded or purchased, and the rejected substitute pack remains removed.

## ECU/turbo guide status

The user-supplied Speedrun.com guide by Ewil describes changing installed upgrade stages and redistributing ECU/turbo dyno bars. Its triple variant specifically names the Corolla. Reading this guide does not establish that a variant works on the current browser build or R34. No ECU/turbo glitch has been applied to the user's car by this update. The experimental normal tuner and guarded ECU/turbo recipe are available on exact943ee537, bdc9cbc2, b1efa173 and ed8d3359; live power and saved persistence remain unverified. The guide is https://www.speedrun.com/nfsu2/guides/95lx0 .

## Retained v0.33 reference notes

The following detailed feature explanations are historical. Use the current build table and verification limits above. The packaged Windows guide contains the current same-folder update steps.


Unpacked Chrome / Edge / Brave extension for https://nfsu2.xyz/. See `CHANGELOG.md` for this release's changes and verification limits.

## v0.33.0: Continuous adaptive corner targets

Adaptive road-race speed now has a separate native planning command. Every valid sampled nonzero bend receives a smooth curvature-based target, instead of requiring it to cross the older curvature threshold. Exact straights keep the requested target ceiling; existing native lower/stop results are never increased. The native distance-based braking calculation uses the same pace compensation.

The curve is deliberately conservative and experimental. It does not detect every corner on the map: the native planner may provide no corner records, skip a tail record, report zero curvature or use another route. It does not change steering, physical brakes, route lookahead, NOS or other cars. A hook hit is an observation of a past call, not proof the current corner is safe. Five fresh captures show hook hits despite reported missed turns, so the update is not presented as a proven fix for every failure.

Only adaptive road mode uses this new command. **Street X and existing free-roam/road-corner controls retain their exact prior behavior.** The new command also denies actual/forced Street X and known online Street X in its native guards. AI ownership, native handback, online permission, mode checks and watchdog remain required. This does not bypass an AI failure or acquire control automatically.

The option remains default-off/session-only and uses your current sliders without changing saved values. For the first comparison, try the existing defaults: 1.30× adaptive ceiling, 0.80 corner factor and 0.75 braking factor. Higher targets can still cause missed turns. The latest logs used 1.90×, 0.95 and 1.00 respectively; those settings were confirmed, not shown to be safe. Keep the working Street X setup unchanged.

Corner/braking hit counters now use the existing two-second telemetry sample cadence instead of replacing bounded history every quarter second. Discrete control/mode changes still log promptly. No raw route geometry, memory dump or additional personal data is collected.

Native tests execute the new corner and braking hooks against the pinned game routines, compare legacy commands byte-for-byte, and check protected outputs and guard denials. Live cornering, race results and browser rendering remain unverified. The final combined suite passes **1,942 tests, zero failures/skips/cancellations**. All four supported patched modules compile, with only the two reviewed corner/braking wrapper functions changed from v0.32.

## Retained v0.32.0: Race-only automatic driver

In **AI driver**, enable **Race-only automatic driver** to arm the native driver for races you start or join yourself. It waits for the active race/GO state, includes Street X, Drag and Drift, and requests handback in free roam, outrun, results or other ineligible contexts. It does not find, join, start, replay or vote for events.

The existing **Automatic driver** still includes free roam. Selecting either driver mode turns the other off. The race-only switch is **off by default**, stays armed between races on this page, and resets on page reload or profile Load. It is deliberately not added to saved profiles; existing saved choices and storage remain unchanged.

**F7, F9/Stop, or driving-key takeover during a race disarms race-only AI.** Manual steering in free roam leaves it armed. If driving controls are still physically held when entering a race, acquisition waits until they are released. Turning the switch off requests native handback. A genuine native manual request, finished/totaled state, failed-control latch or watchdog is not forced back to AI.

Online races still need the existing **Allow network tools** permission. Exact build, current ownership, race, focus/menu, native driver and handback guards are retained. A selected switch is not proof of active ownership; the HUD and local log show the effective request and native observations separately.

Optional **Adaptive road-race speed** is also included below. It remains off by default and leaves Street X unchanged. Neither option changes steering, shifting, NOS or game saves. Live race efficacy and browser appearance remain unverified.

**Historical v0.32 verification:** that release passed **1,907 automated tests, zero failures/skips/cancellations**, including race-only eligibility/lifecycle, optional adaptive mode, joint Street X/online/stop behavior and all retained features. Independent tests additionally cover production native handback and cached-route reconstruction. At v0.32, all four supported patched game module outputs were byte-identical to v0.31; v0.33 changes only the two planner wrappers described above.

For an existing installation, replace matching files in the already loaded extension folder, click **Reload** on that extension's browser card, then refresh the game. Verify **0.33.0**. Do not remove/re-add the extension or create a different folder just for this update.

## Optional adaptive road-race speed

A new **default-off, session-only** option coordinates the existing native route planner. Its separate straight-target ceiling defaults to **1.30×** and ranges from 1.00× to 2.00×. The native route uses distance to known corners to lower its target in advance while retaining a higher target on sufficiently long straights. This is a planned target factor, not a physical speed cap or a measured speed increase.

Enable either **Race-only automatic driver** or **Automatic driver**, then **Adaptive road-race speed** in AI driver → Road-race settings. Online use also requires **Allow network tools**. Adaptive mode uses the existing Race corner speed, Race sharp-turn margin and Race braking factor values, even when the separate Road-race hairpin assist switch is off. Lower braking factor requests earlier braking. It overrides the effective custom race pace only in eligible ordinary road races, without changing any saved switch or slider.

**Street X keeps the exact existing pace, corner and braking selections.** Adaptive mode is dormant in actual/forced Street X and the known online Street X mode. Drag, Drift/forced variants, Outrun and free roam are also excluded. Selecting adaptive mode does not turn on Automatic driver or network permission.

The optional ceiling stays constant while driving. The existing native route envelope varies by distance; JavaScript does not switch pace or reconstruct the driver at every corner. A deliberate setting or race-mode change may still require the existing OFF/acknowledgement/ON route reconstruction. Manual takeover, race end, permission withdrawal and the existing watchdog remain in force.

F7/manual driving keys stop AI and leave the optional selection dormant. F9/Stop, profile Load and page reload turn adaptive mode off. It is not added to saved tool profiles or legacy session preferences. Blur, hidden page and menus pause it normally. Turn it off to return to the prior controls after native handoff.

The HUD and local log distinguish a request, matching native pace acknowledgement, and observed corner/braking hook evidence. These counters do not measure braking success, safe corner entry or a clean lap. There is no new steering, obstacle avoidance, NOS control, added route horizon, opponent manipulation or collision protection. Higher targets can still cause crashes. Start at 1.30× and assess one change at a time.

The original v0.32 option used page orchestration only. The v0.33 continuous-corner update changes the two native planner wrappers and teaches the controller a separate adaptive command. Existing planner commands retain their prior behavior; engine tuning, NOS, Drag-retention, tuner and saved-profile implementations are untouched. Exact-native synthetic tests support the route-speed envelope; live racing, lap times, wins and browser layout remain unverified.

## Retained v0.31.0: Keep owned Drag AI through settings refreshes

A reproduced publication race could let the game's manual-Drag selector run while the extension refreshed the same active settings. The new guard retains an **already-owned, currently permitted native Drag AI lease** through that brief write. It does not acquire new control, force a real manual request back to AI, or change steering, shifting, NOS or damage.

A separate fix ensures a pause/end/OFF command is acknowledged by the native game before a quick restart can overwrite it. This also covers consecutive matches that reuse the same player, car and race objects. It does not clear the game's failed-control latch while AI remains continuously requested.

**F7/manual takeover, F9/OFF, native finish/totaled states, permission withdrawal, identity changes and the 180-native-frame watchdog remain effective.** Do not use this as a no-crash, no-damage or guaranteed-win feature. Online use still requires the existing explicit Allow network tools opt-in.

The fresh user log shows a request for manual Drag before the observed handback, matching the reproduced ordering. It does not record the rejecting guard, so this is not proof of that run's exact cause. The log came from v0.28. Live handoff prevention remains unverified.

Only the Drag input guard changes in the two supported modern native profiles. The HUD, tuner/static-ride fix, NOS clock correction, working Street X behavior, Drift isolation, saved profiles, collision/corner settings and engine-blowout protection remain combined. No unrelated lane candidate or unverified grip/downforce activation is included.

**Verification:** the final combined suite passes 1,873 tests with no failures/skips/cancellations. Exact-native tests exercise retained ownership, real manual requests, OFF acknowledgement and watchdog release; the menu shortcut has five focused tests, including closed-shadow paste behavior. Browser appearance and live race efficacy remain unverified.

**Shift+Insert** now toggles the full tools menu, alongside F8. It does not intercept Paste while typing in text/editable controls. Holding the shortcut does not repeatedly toggle it. Closing follows the same existing menu behavior, including cancelling a running tuner operation.

Reload after enabling only v0.31 and verify the **0.31.0** badge. Keep your chosen settings; start the race yourself. If the unwanted handback persists, export a short new crash log immediately after it occurs.

## Retained v0.30.0: Compact driving information HUD

A small, click-through **Info HUD** appears below the upper-right launcher while the tools menu is closed. **F6** toggles it, or open **F8 → Info HUD**. It starts on and remembers only its display choice in this tab, separately from driving-tool profiles. Opening the menu hides the card until you close it. F7 returns control and F9 still stops driving assists; the HUD itself never enables them.

- **Speed:** existing guarded native speed converted to **km/h**. Zero is shown only when sampled as zero. Unknown builds, invalid car data and paused/missing samples show **Unavailable**, never a guessed or multiplied speed. Older supported builds without verified speed telemetry also show Unavailable.
- **Driver:** observed native AI/manual state, pending handoff, or the reason tools are waiting/paused. A selected AI switch is not called active by itself.
- **Pace:** `req` is the current requested AI target factor; `ack` is a matching native acknowledgement, not measured vehicle speed. A newly selected factor does not reuse an old acknowledgement. Selected pace waits for AI; Drag and Drift retain native pace.
- **Power:** `req` is the selected field multiplier; `set` reports guarded power-field application. It is not measured horsepower or a guaranteed speed increase. Paused, rejected and settling states stay distinct from application.

The HUD is read-only and uses existing observations. Stop, manual takeover, blur, hidden tab, game exit, replacement boot and tuner suspension clear old display evidence. No new physics, AI, speed/power formula, native hook, network permission, tuning, game-save or profile-schema change is included. The complete v0.29 tuner/static-ride fix, online NOS correction, Street X, Drift, Drag and online tools remain together.

**Verification:** 1,788 automated tests pass with no failures/skips/cancellations, including 20 focused HUD tests. A strict-CSP browser fixture is included, but Chromium could not launch because this environment disallowed its local process socket, including the elevated retry. Browser layout/fullscreen behavior and live game appearance remain unverified. No screenshot is presented as actual gameplay.

## Retained v0.29.0: Accept verified native car records in the tuner

The S20 report exposed an incorrect assumption: active car data is not always heap-allocated. The native game also embeds it in its fixed racer-record array. The tuner now accepts those exact native slots **only when the current car, record kind, active record count, race table and ride pointer all agree**. Arbitrary low addresses remain rejected; the existing heap path and all other safety checks remain.

Tests capture all 22 native slots and verify selected-preset-only Stage/Restore across all five modes, including the first and last slots. Native private preview/search matches heap-backed fixtures. The private evaluator permits writes only to the exact ride/curve regions, not neighboring racers or the rest of the copied image. No game save is performed by the extension.

This fixes a proven rejection of valid native car storage. **The user's live capture has not yet been retested.** Reload with only v0.29 enabled, verify 0.29.0, then retry Load settings on the solo Performance Tuning main screen. If another check fails, retain its S-code or export the crash log; later layout protections have not been removed.

The power panel also reports whether power fields were applied, are settling, or are blocked by a specific guard. Exported pace acknowledgement is separate from power application. These are observations, **not a measured speed increase**; no speed, power, driver or network setting is changed by this status addition.

The final v0.29 suite passes **1,768 tests, zero failures/skips/cancellations**. Independent checks cover all 22 native slots, selected Stage/Restore in all five presets, private write boundaries, and unchanged driving code. Power/pace confirmation also clears on stop, online opt-out, game exit, tuner suspension and replacement game sessions.

The online NOS clock correction, working Street X behavior, Drift isolation, profiles, Drag protection and online collision/corner controls remain combined. No unrelated Drag lane candidate or unverified grip/downforce scaling is included. Live driving results and game-save persistence remain unverified.

## Retained v0.28.0: Correct the online Unlimited NOS clock

Unlimited NOS now refreshes an already-active NOS timestamp using the same clock the native game selected. The previous version always used the world clock; in an online fixture where the game's real clock was ahead, that made a full kit immediately appear depleted and caused repeated native stop/restart cycles. The corrected code retains the burst in that exact native test.

This is a reproduced timing defect, **not proof of the clock values in your live run or a guarantee that NOS never stops**. Native AI can still cancel NOS for normal driving decisions. This update does not hold Alt, force activation, suppress native stops or change driving, shifting, steering or lane choice. Inactive and sentinel timestamps remain inactive; network permission and current-car/kit checks remain mandatory.

For an online comparison, use the same ordinary driving situation with **Unlimited NOS** and **Allow network tools** enabled. If tapping remains, use **Export crash log** immediately. The new log samples the selected clock, active-since stamp and kit/resource accounting **before refill**; it contains no pointers. The timestamp flag does not prove successful activation, and sampled logs can miss short transitions.

The v0.28 combined suite passed **1,740 tests, zero failures/skips/cancellations**. Saved tool profiles, working Street X behavior, reviewed Drift isolation, Drag protection, online collision/corner settings and the full tuner with snapshot diagnostics remain together. No native game code or profile was changed. v0.28 did not change tuner capture. The v0.29 native-record correction is described above; any remaining rejection still needs its S-code/log. Live NOS behavior and game-save persistence remain unverified.

## Retained v0.27.0: Identify rejected tuner snapshots

This update replaces the generic “Full tuner snapshot layout is unsupported” message with a specific **S-code and component** when the native capture guard rejects a snapshot. The local diagnostic export records only the bounded failure code and applicable counts, never raw pointers or a memory dump. Details are reset for each request so a previous failure is not shown as a new one.

**This is a diagnostic update, not a confirmed fix for the reported capture failure.** The screenshot establishes that a layout guard rejected the capture, but does not identify which guard or justify weakening it. All existing pointer, ownership, overlap, count, selected-preset and stale-state checks remain. Stage/Restore and game saving are unchanged.

After installing, open the solo Performance Tuning main screen and repeat the failed **Load settings** or **Find tune** once. If it fails, retain the complete S-code/message and use **Export crash log** immediately afterward. Buffer/ownership failures ask for a game reload; other layout failures ask for the diagnostic log. A timeout still means the outcome may be uncertain and requires reloading before retrying.

The combined suite passes **1,708 tests, zero failures/skips/cancellations**, with **49 independent diagnostic checks**. The reviewed Drift isolation, saved tool profiles, Street X behavior, online road-race/collision features and Drag protection are retained. No live gameplay, successful capture on the user's car, or disk-save persistence is claimed.

## Retained v0.26.0: Keep custom road settings out of Drift

On exact **93af6ccb** and **78e2bb69**, custom road/free-roam pace now pauses during native Drift modes. The extension preserves the game's own pace factor instead of multiplying it by a saved road pace setting. Your selected switches and numbers remain saved and resume outside Drift. The UI shows “Paused in Drift”; an earlier road pace hit is not reported as current Drift confirmation.

Extra grip also pauses for the additional native Drift variant flag that was previously missed. Its existing ownership and restoration guards remain. Native Drag precedence is retained. The diagnostic log now includes a bounded, read-only native pace-factor observation to help compare runs.

These are two reproduced setting interactions, **not a proven fix for every poor Drift run**. No new steering, throttle, shifting, NOS behavior, score multiplier, opponent logic, recovery curve or race tune is introduced. Engine power and your actual car tune remain selected and can still affect handling. Native grip/downforce scaling remains unverified and disabled.

Saved tool profiles, full preset tuning, online road-race/collision controls and Drag blowout protection remain combined. The combined suite passes **1,698 tests, zero failures/skips/cancellations**. No live Drift run, score improvement, browser installation or game-save persistence is claimed. For a useful comparison, use the same car, track and tune; export a short diagnostic log after a run that reproduces the problem.

## Retained v0.25.0: Saved extension settings profiles

**Saved tool profiles** saves named groups of extension settings in this browser for this game site. Save your current choices, then load them together instead of enabling each tool separately. Update replaces the selected saved configuration; Delete removes it. These profiles are separate from the game's race tuning presets and **Save Profile**. They contain no car setup, game save, dyno draft or diagnostic log.

Automatic loading after reload is **optional and off by default**. Select it explicitly for a saved configuration if you want that configuration to return next time. Network permission has a separate saved-profile opt-in: saved choices do not silently grant Online/LAN access. Read the network warning before permitting automatic network-enabled behavior. Each tool still requires the supported build, valid current car and its normal game-mode checks.

**F9 / Stop keeps saved profiles but pauses automatic loading persistently**, as well as clearing current driving/network choices. A later reload cannot silently undo Stop. Resume deliberately from the profile controls. Saving a profile does not itself enable its settings. Changes from another tab do not automatically activate a configuration in an already-open tab.

Profile loading stops the old controllers and releases synthetic input before changing selections. It does not roll back a staged game tune or save the game. If storage is unavailable or full, the UI reports that the profile was not saved. Profiles stay in this browser; clearing this site's storage removes them, and site scripts can access this storage. Up to 16 profiles and 48 characters per name are supported. Browser-managed locking prevents concurrent tabs from overwriting each other's saves; if locking is unavailable, profile editing is disabled while manual loading remains available.

Saved Drag blowout protection retains its narrow meaning: only the current eligible local engine is protected before it blows; online use also needs network permission. It does not revive an already-blown engine, alter NOS/shifting, or promise a race win. Existing controls keep their normal fresh-page defaults unless you explicitly enable a saved startup profile. Descriptions below that say a control starts off refer to those defaults.

No native AI, Street X, tuning, heat, corner/braking or collision payload was changed for settings profiles. The final suite passes 1,688 tests, with another 44 independent profile checks. A local Chromium fixture could not launch because this environment denied socket creation, so browser appearance and automatic loading in the user's game remain unverified.

## Retained v0.24.0: Opted-in online Drag engine blowout protection

For **online or LAN Drag**, enable both **Drag racing → Disable Drag engine blowouts** and **Online / LAN opt-in → Allow network tools** before the engine blows. Solo Drag needs only the blowout toggle. Exact **93af6ccb** and **78e2bb69** builds are supported. The heat toggle works independently of Automatic driver and Manual drag assist. It starts off for a fresh tab, remembers your choice in the same tab, and F9 clears it. Network permission starts off after reload and F9.

Only the current linked local player's engine is eligible, during active Drag with full physics. Opponent, stale, unowned, invalid and already-blown engines remain excluded. This is local protection, not a change to remote engines, network packets or server rules. Follow server rules; online changes can trigger integrity checks or sanctions.

Enable it **before** the engine blows. It does not repair an already-blown engine or reverse a lost race. While enabled it supplies the game's own disabled-heat sentinel, intentionally discarding accumulated heat. Turning it off resumes normal heating from zero after the next native full-physics setup. It does not change shifts, throttle, steering, pace, power, torque, limiter, NOS decisions or opponents, and does not trigger an AI restart.

The exact native heat routine and its original instructions remain intact. An authored prefix checks active Drag, current player/car/race/engine identity, full physics, finite unblown heat, permission epoch and heartbeat before changing only the current engine's heat field. Online/LAN additionally requires literal network permission. Added diagnostics show bounded heat/blown/limit observations and the requested toggle.

Controlled native tests cover 600 online over-redline updates on each supported module, low and high runtime CPU addresses, opt-out restoring native heating and rejected ownership/stale states. This is **not live online verification**. A fresh race must still confirm the guard is eligible and the engine remains protected; a selected checkbox alone does not prove activation. No successful live Drag race, HUD appearance or win is claimed. Repeated native NOS cycling is unchanged.

This stays combined with the complete preset tuner, opted-in online corner/braking settings and local online race-car filtering. Solo/Street X driving formulas remain unchanged. No Lap Knockout experiment or unverified native grip/downforce multiplier is enabled.

## Retained v0.22.0: Local online race car contacts

On exact **93af6ccb**, **Online player / race no-clip** can also filter local contacts with confirmed participants in a running Online/LAN race. Enable **Allow network tools** and this separate player/race switch. Both reset off on reload/F9. The active race roster must contain the local and contacted cars exactly once, with reciprocal record and body identity; malformed pointers, stale identities, invalid counts and missing/duplicate membership of either contacted car are rejected.

This skips contacts in this browser only. It does not change the remote player's simulation, packets, server rules or Ghost setting, and does not promise both players see collision-free overlap. Walls, props and traffic remain separate. Older supported builds keep free-roam player filtering only. The UI says “Armed” until actual native contact counters confirm a local filtered contact.

The complete preset tuner and opted-in online corner/braking parity remain combined. The contact builder now preserves the full tuner's main-loop prefix and refuses an unexpected base-bridge change. Street X and solo driving formulas remain unchanged. The new Drag heat-only toggle is described above; no Lap Knockout experiment or unverified grip/downforce activation is included.

No live multiplayer, peer synchronization, server acceptance, browser appearance or user save/reload result is claimed. Native grip/downforce multipliers remain unverified and disabled.

## Retained v0.21.0: Matching solo and opted-in online road-race settings

This combined candidate retains the full v0.20 preset tuner. Selected road-race corner speed, sharp-turn margin and braking factor can now apply online/LAN under the existing **Allow network tools** opt-in, matching the selected solo settings for the extension-owned local AI car. Both the road-race assist and network permission start off after reload/Stop. Street X and all solo numerical formulas remain unchanged.

This fixes a proven routing mismatch where online race pace could remain active while corner/braking assistance was disabled. It is not a proven explanation for every collision or a verified online race improvement. Native route/car ownership and safety checks remain. Drag, Drift, Outrun, free-roam behavior, collision-control scope and grip/downforce activation are unchanged. No Lap Knockout experiment is included.

This retained corner/braking patch does not establish improved live cornering. Follow server rules; peer synchronization and server acceptance have not been tested.

## Retained v0.20.0: Full per-preset editor and isolated native preview

- On exact **93af6ccb**, edit all **41 native tuning fields** for the game's five selected race presets: suspension, gearing, nitrous, brakes, tires, downforce, ECU and turbo. Installed-part and native eligibility checks disable unavailable controls. The native setter may couple controls; preview shows the accepted result before you stage it.
- Preview rebuilds and measures a private copy using native game code with bounded execution and guarded memory. It does not temporarily tune your live car. Measurements include native 0–60 and 0–100 estimates, top-speed estimate, peak power and torque, plus native nitrous duration/torque settings.
- Automatic search is limited to measured objectives: peak power/torque searches ECU/turbo; acceleration/top speed searches gearing plus ECU/turbo. Suspension, brakes, tires, downforce and nitrous are manual controls, **not automatic handling or fastest-lap optimization**. Each search uses at most 48 trials and is not a global optimum.
- **Stage selected preset** changes only the current working tune and that preset's visit copy after a game-thread identity/staleness check. **Restore previous** restores both original copies separately. The game must run its native **Test Run** to refresh driving physics, and you must use **Save Profile** for persistence. This extension does not confirm a disk save.
- Retains v0.18 AI and Street X behavior. Adds read-only corner-status clarification without changing corner physics. Unverified native grip/downforce scaling is not activated. Older supported game builds retain the earlier ECU/turbo dyno tool.

Back up your save first. Preview, stage/restore and failure paths have isolated automated coverage; live gameplay, browser appearance and save/reload persistence have not been verified. The private evaluator uses additional WebAssembly memory and may be unavailable on memory-constrained browsers. Failure leaves the full tuner unavailable rather than falling back to live native tuning.

## Retained v0.18.0: Drag input handoff and road-race hairpin controls

- **Native Drag input handoff, exact 93af6ccb and 78e2bb69:** Automatic driver now enters the native AutoPilot input mode, preserving the owned driver across the verified native Player update and input reconciliation. A narrowly guarded native manual-Drag selector prefix prevents that selector from immediately taking control back. Actual Drag and full driving physics after GO are required. If the game changes control mode, the extension releases its lease and tells you to turn Automatic AI off, then on to retry. It does not fight the new mode or reset a replacement controller.
- **Independent Road-race hairpin assist:** off by default, separate from free-roam corner assist and race pace. This changes the native private-route corner cap and planning braking assumption while retaining the selected straight-line pace. The same selected settings apply to ordinary road races in solo and explicitly opted-in Online/LAN play, only for the extension-owned local AI car and its validated private route. Outrun, Drag, Drift and forced Drag/Drift remain excluded. Online/LAN still requires Allow network tools, which starts off after reload. Native network state, server rules, other cars and collision controls are not changed. Online cornering and synchronization are unverified. No new steering, route horizon, grip or nitro behavior is added.
- **More useful local diagnostics:** actual skill, current/requested native input mode, native controls and bounded pointer-presence/validity observations join the existing Drift and corner fields. Raw addresses are never exported; validity flags show readable bounds, not proven object/route semantics. The export header now identifies the exporting extension version. Sampling remains bounded, so export promptly after a short test.

Existing online AI permission now also permits selected road-race corner/braking assistance. NPC traffic filtering remains free-roam-only. Current-build player/race filtering additionally has the guarded local race scope described above. **No native 10× grip or downforce feature is included**; the existing Grip control is unchanged. Keep v0.17 for rollback and start with normal 1× pace and power/grip off.

**Limits:** no live driving or race benchmark has been run. The Drag repair proves bounded native input/ownership retention, not a complete AI action graph, ideal launch, shifts, lanes or finish. Force-only/special Drag is unsupported. Native skill/tactical/NOS resource conditions remain. Hairpin assistance is experimental and may still miss turns or fail to brake early enough; native route horizon and degenerate geometry remain limitations. This is not full opponent equivalence, a freeze fix or a promise of wins.

## Retained v0.17 native Drift recovery

The v0.17 recovery changes remain together in this build. On exact **93af6ccb** and **78e2bb69**, the existing **Automatic driver** switch also enables a guarded native Drift recovery path when the extension owns the car and the game's Drift behavior, full physics, aliases, race state, permissions and heartbeat all agree. There is no extra driver or manual steering script.

The change selects the game's existing opponent yaw-damping curve at one native physics expression. It retains the current car's native coefficient, sign/gear conditions and all subsequent native arithmetic. The curves match through the 89-degree knot; the intended difference is retaining native damping around/beyond 90-degree slip. There is no car-model filter, but every native eligibility guard must hold. Goals, racer identity, score calculation, global curves and manual/non-owned handling are not changed. Automatic mode transitions and F7/F9 handback remain in place.

**This is not a verified live spin-recovery or score improvement.** The status says the recovery guard is installed, not that it observed a successful recovery. Forced Drift and the variant flag follow the native predicate with drag precedence; they are not unrestricted free-roam support. Start at normal 1× pace with power/grip changes off.

The local logger now includes bounded, read-only Drift controller/goal/physics evidence, speed and native target, track, scoring state, pending/banked points, raw rate, route progression and collision-loss latch. Existing corner hit/cap diagnostics remain separate from pace. Moving native values are sampled about every two seconds; discrete changes can record sooner. Native behavior control scalars are recorded, but no raw addresses, names, keyboard events or network traffic are captured. Export promptly after a short test; this remains a bounded recent log, not a complete replay.

### Retained v0.16 compatibility and collision controls

These additions apply **to the exact reviewed 93af6ccb and 78e2bb69 builds**. Existing v0.14 controls, dyno mode handling, adaptive free-roam corners, separate online NPC traffic switch, signature checks and local crash logger remain present. Older supported game profiles retain their previous native behavior.

- **Separate online player / race no-clip:** free roam uses the exact native active-player slot classifier; driver type alone never qualifies. Current93af6ccb also supports local race-roster filtering under network opt-in. Older78e2bb69 remains free-roam-only. Both switches start off; live multiplayer behavior is unverified.

- **Opponent drag action:** the native initializer can select the genuine opponent “Win drag race” action (2), rather than player “Steer player in drag race” action (3), for this extension's requested and owned car. A positively identified existing action 3 may be upgraded once through that same initializer. NULL initializes lazily; native recovery 11 and other temporary actions are not forced. Status confirms the actual action id and vtable, not merely that the checkbox is selected.
- **Native drift physics:** normal unmarked player drift events use the native driver 3 / physics 1 choice through the game's physics setter, retaining native drag-first precedence. Invalid construction or a failed correction uses the existing manual-control and skill rollback. Event changes still require the full OFF/manual/ON handback.
- **Native nitrous decisions:** recognized drag goal 2, observed road goal 1 in native race types 1/7, and observed chase goal 5 only in Outrun 7 can reach their native request/cancellation path. The extension does not select chase goal 5, allow this new path in free roam, bypass native tactical/skill/resource checks, refill NOS or force activation. The existing Unlimited NOS checkbox remains a separate feature. Cancellation can continue after an authorized race's goal changes to recovery or NULL, so strict new-start gates cannot strand active nitrous.

**Limitations:** recognized drag requires the game's actual drag flag. Force-only drag and the special 1099 combination are unsupported by the new opponent path. Native action selection is not complete opponent equivalence. Full allocator/configuration, cancellation, skill and resource behavior have not been executed end-to-end. No live race benchmark, guaranteed shifting, finishing, winning, fastest-driver or crash-freedom claim is made. Reported freezes remain unresolved. Start with normal 1× pace, unrelated power/grip changes off, and a backed-up save. Use F7 to take control.

### Retained current-build support

This release adds the exact game module for revision **93af6ccb** (38,205,596 bytes), while retaining the reviewed **78e2bb69**, **2f0ddd3b** and **6f4f1e4e** profiles. It adapts the new 64-entry native status table; older profiles retain the 48-entry bound. It verifies the downloaded binary, not just its version label. The compact menu uses a constructed stylesheet that works with the site's strict style policy.

**A game crash was reported with v0.11. Its cause remains unresolved. This update is not a confirmed crash fix and has not been live-gameplay tested.** Back up your save, keep the previous extension folder, and test one feature at a time in solo play.

### Available on 93af6ccb, 78e2bb69 and 2f0ddd3b

- Native player autopilot, automatic native event reconstruction, normal racer skill field set to 9, and experimental drag physics handoff.
- Separate free-roam/race pace controls and experimental free-roam corner-speed assist.
- Independent solo-only **Wall pass-through** and **Car no-clip** switches.
- Experimental native dyno search, explicit Apply and guarded Restore.
- **93af6ccb and 78e2bb69 only:** native opponent drag action, drift physics correction and guarded native nitrous decisions, plus separate Online traffic and Online player no-clip, each limited to its native identity category in online free roam.
- Unlimited equipped NOS, power boost, limiter control, grip, manual drag assist, solo drift input and read-only tester.

Automatic AI, both pace opt-ins, both corner assists, all four collision switches, power boost, limiter removal, extra grip, dyno and Online/LAN permission start off after reload. Factors are retained. A future unknown build stays disabled. Both revision and the downloaded module's exact size/SHA-256 must match a reviewed profile before memory tools can run. Native hooks also refuse cold occupied command regions.

### Road-race hairpin setup

Enable Automatic driver in an ordinary road race, then enable Road-race hairpin assist. Online/LAN additionally requires the separate Allow network tools opt-in. Start at its default corner factor 0.80×, sharp-turn margin 15% and braking factor 0.75×. Lower braking factor requests earlier planning; it does not weaken the physical brakes. Settings or selected race pace changes trigger the existing OFF/manual/ON route reconstruction. A braking-hit count alone never confirms a corner reduction. “Armed” means requested, while an observed cap requires an actual qualifying native helper hit. Both assists start off after reload and Stop.

## Feature status on the exact current build

| Control | Implemented | What was verified / remaining limit |
| --- | --- | --- |
| Native AI + event switching | Yes | On/Off handback, reused-pointer subtype/track transitions and native mappings tested. Not every race's live behavior or opponent-equivalent initialization. |
| Skill 9 | Yes | Actual native skill getter tested; normal field set to 9, sentinels preserved. On ed8d3359 (0.41.0) the AI driver's GetSkill answers 9 for the player's marker at the seven clamp sites while the car is owned in a solo session, including the Drag launch delay and nitrous decisions. Live effect unverified. |
| Automatic drag | Yes, experimental | Native driver 3/physics 1 handoff, guarded opponent action 2 selection and rollback tested. Force-only/special drag unsupported; launching, shifts, lanes and finishing not live-verified. |
| Guarded native Drift recovery | Integrated with Automatic driver on 93af6ccb and 78e2bb69 | Exact production physics splice, native-output parity, fail-closed and bridge handback fixtures pass. No live recovery, per-model handling or score improvement claim. |
| Native drift physics and nitrous decisions | 93af6ccb and 78e2bb69, experimental | Native physics choice, guarded start/cancel acceptance, selected downstream request/consumer fixtures and rollback tested. Full native graphs and live race outcomes unverified. |
| Free-roam / race pace up to 3× | Yes, separate opt-ins | Native hook and 2–3× bounds/non-compounding tested. This is target-speed scaling, not a promised speed multiplier or stable driving. Drag stays neutral. |
| Free-roam corner assist | Yes, experimental | Actual current corner helper, route ownership, guards and output scaling tested. Not a proven steering/avoidance fix. |
| Wall pass-through / Car no-clip | Yes, independent solo-only switches | Current contact wrapper, categories, filter composition and fallback tested. Live map/traffic coverage unverified. |
| Online traffic no-clip | Yes, separate opt-in on 93af6ccb and 78e2bb69 | Exact native online and player-slot helpers tested. Only NPC traffic in online free roam; races, outruns and LAN excluded. Live network behavior unverified. |
| Online player / race no-clip | Independent opt-in; race extension on93af6ccb only | Free-roam player-slot identity retained. Current-build local race contacts require both roster memberships, reciprocal identity and network permission. Counters distinguish race scope. Remote peers/server effects/live collisions unverified. |
| Full preset editor / native preview / stage / restore | 93af6ccb,943ee537,bdc9cbc2, b1efa173 and ed8d3359, experimental | All 41 fields, native unlocks/coupling, private measurements, measured gearing/ECU/turbo search and selected-preset writes tested. Manual handling controls are not automatically optimized. Test Run refresh and Save Profile are user actions; live save/reload unverified. Older builds retain ECU/turbo search. |
| NOS / power / limiter / grip | Yes, experimental | Exact mappings, native NOS, bounds, restoration and controlled competing-writer tests. Hardened but not lifetime-synchronized; freezes unresolved. |
| Manual drag / drift toggle / tester | Yes | Input/state and UI tests. Manual drag still requires you to steer; drift is not perfect-drift automation; tester is incomplete. |
| Crash log + manual JSON export | Yes | Sanitization, retention, effective tool state, export simulation and no-tools memory invariance tested. Includes read-only Drift controller/scoring/speed and preserved corner evidence. Real browser export not verified; a freeze may leave no final error. |

Unknown binaries stay disabled. On the older 6f4f1e4e binary, the car no-clip filter is disabled because that hook was only mapped for the current build. No game assets are bundled.

## Signature scanning and build updates

The loader performs a read-only scan against three reviewed sets of 34 typed function fingerprints. It reports unique, ambiguous and missing matches in local diagnostics, plus the actual module hash. The menu retains the full compatibility explanation rather than truncating it. AI and Dyno now give the same explicit unavailable-build reason instead of suggesting the wrong tuning screen.

**Signature matches do not automatically authorize a new game version.** Matching functions alone do not establish callees, dispatch tables, host addresses, scratch ownership or live behavior. Even 34/34 matches on a different binary leave tools disabled until an exact compatibility profile has been reviewed. This is update diagnosis, not a promise that future game updates will work automatically. Scanner failure does not override the independent exact-binary gate.

## Automatic AI race-type switching

Turn on **AI driver → Automatic driver** once per page. It automatically selects:

- **Non-drag races and free roam:** the existing native player autopilot.
- **Drag:** experimental native racer AI with the verified drag physics type. It waits until GO and full driving physics are available.
- **Changing mode:** requests native AI OFF, waits for the game thread to acknowledge it, confirms ownership is released, the human driver is restored and any failed-acquisition latch is cleared, then requests the new mode. Player, car, race, track, drag/drift/URL/StreetX flags, forced native mode flags and race/free-roam changes are checked, including when object pointers are reused.

There is no separate drag-AI checkbox. The main switch explicitly enables automatic selection, including experimental drag. **You still start events yourself. This does not select races, restart them, navigate career menus, buy upgrades or choose a GPS destination.** It includes the separate experimental free-roam corner-speed and dyno-search tools described below. They are off by default.

The extension requests the game's native player autopilot, not a new steering bot. The native constructor chooses a distinct drift behavior and a shared ordinary/drag/StreetX behavior; its update code contains drag-specific branches. Circuit, sprint, URL and outrun do not have separately proven opponent-equivalent implementations here. The player racer identity stays unchanged. “Level 9” means the ordinary native skill field is set to 9; values 254/255 are preserved. The Drag launch delay and the nitrous decisions do read it through the AI driver's GetSkill, where the player's marker is clamped to 0; 0.41.0 answers 9 there on ed8d3359. Shift quality comes from the car's own set-up for the player's racer and is not changed.

**Live drag driving remains unverified.** Correct driver/physics status does not prove that it shifts, steers, avoids traffic or finishes. It may crash, stop or miss checkpoints. Back up your progress and test solo first. No guaranteed routes, perfect drift, wins or completed races.

### Quick start

**First installation:** extract the ZIP, then drag the extracted
`NFSU2-Driving-Tools` folder onto your Desktop. `manifest.json` must be directly
inside it. The ZIP itself does not run the extension. In `chrome://extensions`,
enable Developer mode, use **Load unpacked** once, and select that Desktop folder.

**Later updates:** keep that exact folder. Extract the next ZIP elsewhere, open
its `NFSU2-Driving-Tools` folder, and copy all files **inside** into your existing
loaded folder, replacing matching files. Do not nest, rename or move the folder.
Click **Reload** on the existing extension card, then refresh the game and verify
**0.38.18**. Game refresh alone is not enough. Do not remove/re-add the extension.

If Chrome already loads a different folder, keep updating that path instead;
placing another copy on Desktop does not change the path Chrome loads. Keep only
one copy enabled. See `UPDATE-WINDOWS.txt` for full steps, safety and rollback.
Edge uses `edge://extensions`; Brave uses `brave://extensions`.

Finish the event and use the game's save/backup controls before refreshing;
unsaved in-memory changes are lost. Settings and safety rules below are unchanged.
Chrome 111+ or a compatible current desktop Chromium browser is required.
No build tools, installer or Node installation are needed.

### Take control and pause

- **F7 / Take control:** disables automatic AI until you explicitly turn it on again. Arrow/WASD keys and Space also take control outside the extension menu. This remains off across later race-type changes.
- Controller axes do not trigger takeover; use F7 or the Take control button.
- Taking control also pauses synthetic manual-drag throttle until you toggle manual Drag assist again.
- **F9 / Stop:** clears automatic AI, all four collision switches, Online/LAN permission, custom pace, NOS, power, limiter, grip and manual drag. Slider values are retained. Drift and the read-only tester keep their own switches.
- Menus, loading, unfocused/hidden tabs and unsupported states pause tools without clearing choices. They resume when a supported driving state returns, unless you took manual control.
- **Automatic AI, wall pass-through, solo car no-clip, online traffic no-clip, corner assist, both pace opt-ins, power boost, limiter removal, extra grip, dyno tuner and Online/LAN permission start OFF after every page reload.** Other settings use same-tab session storage. Closing the tab normally ends those saved choices. Storage may be unavailable or affected by browser restore behavior.
- If the page stops updating, native AI hands back within 180 game frames. A frozen game cannot process a handback. Disable the extension and reload if it freezes.

## Compact menu

The menu starts as a **170 × 29 px** collapsed toolbar and opens to a **244 px** drawer with a 390 px maximum scroll panel. **F8** opens/closes it. Sections start folded, only one main section opens at a time, and longer sections scroll. Help and detailed status are tucked away; no control was removed. **F7 / Take control** and **F9 / Stop** remain keyboard shortcuts, with buttons in the open toolbar.

## Independent controls

### AI and pace

The native AI switch uses player-only skill **9**, the highest normal native value. It restores the original value when the same racer still exists. Special sentinels are left unchanged in the record. On ed8d3359, 0.41.0 answers 9 for the player's marker inside the AI's own skill reads while the car is owned in a solo session. It does not alter other racers or commandeer an AI driver the extension did not acquire.

**Free-roam pace:** 0.75×–3.00× for native free roam only, default off / 1.00×. Its factor is saved, but its switch starts off after reload.

**Race / outrun pace:** a separate 0.75×–3.00× opt-in, default off / 1.00×. Its value is saved, but its switch starts off after reload. Your faster free-roam choice does not carry into races.

Both adjust the native target-speed factor, not engine power, steering or road paths. **2–3× pace is especially experimental: severe overspeed, missed turns/checkpoints and instability are possible.** No real driving at those factors has been verified. Drag, dyno and unknown categories use neutral 1.00×. The choices remain selected while ineligible and resume only in their own category. F7 leaves them dormant; F9 clears both switches. They never turn AI on by themselves.

### Free-roam corner-speed assist

A separate, experimental opt-in reduces the native planner's curvature-limited speed for upcoming free-roam corners. It does not replace steering or road paths. Its bounded factor is **0.60–0.95**, starting at **0.80**. Straight/gentle segments retain their native speed cap. This factor is a tuning hypothesis, not a measured optimum.

**Sharp-turn margin** adds 0–25% extra reduction, starting at 15%, according to how far the native corner speed falls below its maximum cap. Tighter upcoming bends receive more margin. The combined formula is `nativeCornerSpeed × baseFactor × (1 − margin/100 × (1 − nativeCornerSpeed/nativeMaximumSpeed))`. At 0%, it follows the v0.13 calculation exactly. With the strongest settings the effective factor can approach 0.45×; it never changes a straight-cap result. This adjusts the original planner’s speed cap, not its steering or proven sampling distance. Begin with normal 1× pace and power/grip changes off, comparing 0% and 15% on the same solo route.

It applies only to the current, owned AI driver's private main route in native free roam. Races, outruns, drag, drift and the Dyno Shop are excluded. Changing its enabled state, factor or sharp-turn margin rebuilds AI through a full native OFF/manual/ON handoff, because the game caches route speed caps. Free-roam/race transitions also rebuild before rearming.

**Corner status:** Armed means a request is present, not that a qualifying native reduction has been confirmed. Straight/gentle calls and guarded calls add no hit. Occupied command memory and observed drift exclusion are reported separately. The crash log now records bounded corner hits, request state, applied factor and those two observable guards. Confirmed pace is a different acknowledgment and does not prove corner assist ran. For diagnosis, use 1× pace; 0.95× corner factor reduces a qualifying corner cap by only 5%. A persistent no-hit result after bends is still unresolved without live telemetry.

It may help turn entry but cannot repair a bad route, prevent crashes, guarantee a clean corner or improve lap times. More power, grip or pace may undermine it. Live braking, route rebuilding and handling improvements remain unverified. Start conservatively and keep F7 available.

### Full per-race preset tuner

Use the **solo Performance Tuning main screen** on exact93af6ccb,943ee537,bdc9cbc2,b1efa173 or ed8d3359. Back up your save, select a race preset in the game, then enable the tuner. It never buys upgrades, switches the game's preset, enters a race or presses Save Profile.

1. **Load selected preset** captures the current car, installed parts, working tune and selected visit tune on the game thread. The editor displays all 41 settings in their native categories and disables fields locked by installed parts/native rules.
2. Change sliders and press **Preview draft**. Native setters and rebuild/measurement functions run only in a separate memory copy. The preview shows accepted values, including native coupled changes, and comparable before/after estimates. Your live setup remains unchanged.
3. Alternatively choose a measured goal and press **Find tune**. Peak power/torque searches ECU/turbo; 0–60, 0–100 and top speed search gearing plus ECU/turbo. Search is capped at 48 trials. It keeps manual suspension, brake, tire, aero and NOS choices, but does not optimize their handling or lap-time effects. A faster estimated acceleration can reduce top speed; inspect all results.
4. **Stage selected preset** is an explicit separate action. It accepts only the last successfully evaluated candidate, on the same car, preset, installed parts and unchanged setup/visit/record. A game-thread transaction copies just the current 41-byte tune and selected 41-byte visit tune. Other presets and the saved-car record are not written by this action.
5. Start the game's own **Test Run** to refresh driving physics and check the tune. Merely exiting the tuning screen is not a verified rebuild. Use the game's **Save Profile** to persist changes. The game's save can commit all five visit presets, so the tuner warns when other visit presets differ from their stored record. “Save ready” is not a successful save confirmation.
6. **Restore previous** needs the same car, preset, parts and exact last-staged tune. It restores the original current and selected visit tunes, even when those originally differed. A known native commit of this exact selected tune is accepted; unrelated record changes are refused. Restore does not undo disk saves. Use Test Run and Save Profile again if you want the restored state refreshed and persisted.

Each car/preset has separate guarded restore state while the page stays open. A car replacement, manual edits, changed parts or an unknown record change invalidates stale results. Reload loses this temporary restore history. Native unlocked gear counts and tuning rules remain authoritative; no sixth gear is invented. Sliders display −100 to +100 around the game's neutral value, stored internally as bytes 0–200. These are normalized settings, not physical units.

The measurements are native estimates, not lap times or on-track benchmarks. Handling controls and NOS expose native settings without a proven per-race optimal objective. There are no claimed “perfect” race presets, global optimum, guaranteed wins or proven save/reload result. The previous peak-only dyno tool remains on older supported builds with its existing guarded Apply/Restore flow.

Cancel, F9, closing the panel, blur, a hidden tab, leaving the page or disabling the tuner cancels ongoing work. Driving effects pause during work, with their selections retained. **F9 does not undo a tune already staged.** Re-enable the tuner and use Restore previous while its baseline remains valid. A timed-out game-thread request has an uncertain outcome and disables further writes until reload; inspect the game rather than blindly retrying.

The private evaluator extracts only reviewed native functions from the exact game module already downloaded by the browser. It has its own memory, checked capture ranges, write allowlist and operation budget. Capture/stage/restore run through a command-gated frame prefix with no native calls and no profile-file writes. This bounds the reviewed path but is not a guarantee against browser exhaustion, unrelated game faults or live object-lifetime races.

### Power and handling

- **Automatic NOS refill:** unavailable while near-miss integration is tested offline. Saved selections cannot enable it. Game-earned NOS and native NOS use remain available.
- **Power boost:** 1.0×–3.0× engine and nitrous torque. Starts at 1.5×. Repeated updates do not compound. More power can worsen wheelspin and handling.
- **Remove stock limiter:** removes the stock MPH governor while enabled. Gearing, drag and redline still limit speed. Upgraded cars may already lack that governor.
- **Extra grip:** 1.0×–2.0× all four tyre-force factors. Starts at 1.3×. It is not auto-steering, yaw damping, corner avoidance or guaranteed handling. High grip can cause abrupt behavior or rollover. It pauses in drift mode/races.
- Power and grip restore only fields still owned by the extension. They wait for three matching samples before applying to rebuilt car data. Changed external tuning is preserved rather than overwritten. Pause/off restores owned values when the original live objects remain valid.
- **Drift assist:** uses the game's real drift-event input and waits for its handling confirmation. Solo free roam only, with game menus closed. It is not perfect-drift automation. Power/grip restore before the native tuning rebuild; settings stay selected. Drift uses its own switch, including after F9.

### Wall / barrier pass-through

**Handling & collisions → Wall pass-through** is independent of AI and **solo-only**, even with Online/LAN tools allowed. Turn **Free roam with others** off, or use a solo race.

Only contacts between your car and verified near-vertical static track polygons are skipped, using the native wall threshold `abs(normal.z) < 0.1`. Ground, ceilings, ramps/slopes and movable props retain the original collision path. Cars retain it unless the independent Car no-clip option is enabled. Sloped faces and movable barrier props remain solid. This is not unrestricted flight or universal noclip. The game's native Ghost setting affects cars, not walls; the extension leaves that setting unchanged.

A selected checkbox is not proof of contact filtering. Its status first says Armed, then counts contacts actually skipped by the native hook. Test a plain vertical wall and neon barrier at low speed; verify ground/ramp and car collisions yourself. Coverage has not been live-verified.

You may leave the drivable map, miss checkpoints or get stuck inside scenery. Native recovery may reposition you after a reset. **Turn it off only when clear of a wall.** Off/F9/reload restores the original collision path. It does not change shared map objects or body collision flags.

### Solo Car no-clip

**Handling & collisions → Car no-clip** is separate from Wall pass-through and is solo-only. It matches confirmed native car collision bodies paired with the current local player's car, whether driven manually or by AI. It does not skip collisions between other cars. Walls, ground and props retain their normal path unless the wall option separately applies.

It starts off after reload and reports Armed until a supported contact is actually skipped. Turn it off only once clear of other cars. F9 stops it. No body flags or shared map objects are changed. Native constructor/category and current wrapper tests pass, but real traffic/racer collisions have not been live-verified.

### Online traffic no-clip

**Handling & collisions → Online traffic no-clip** is a separate switch, available on exact builds **93af6ccb and 78e2bb69**. It requires online free roam and matches native NPC traffic paired with your local car, driven manually or by AI. It excludes native player-slot cars even if they use a traffic model or traffic driver flag, plus ordinary AI racers, every race category, outruns and Online/LAN races. Other players and rejected contacts retain the game's original collision logic, including any native Ghost choice you made. Walls, ground, props, body flags and map objects are unchanged.

This switch starts **off after every reload**, even if previously selected. It needs its own explicit opt-in; **Allow Online/LAN tools** never enables it. That general permission is not required for this narrowly scoped online-free-roam traffic switch. Solo Car no-clip stays independent. The status distinguishes Armed from observed traffic contacts skipped. F9 stops and clears it; blur, hidden tabs, dyno work and unavailable driving state pause it. Turn it off only when clear of traffic.

No live online collisions, peer synchronization or server acceptance have been verified. It changes local contact resolution, not the traffic simulation or server rules. Follow the site's rules and use an explicitly permitted private test. A selected or Armed switch is not proof that a real contact was skipped.

### Manual drag assist

A separate, optional throttle / RPM-threshold shift helper **while you steer**. Uses the default Arrow Up and Left Shift bindings. Its extension-driven NOS helper is unavailable while automatic refill is disabled. Set shift RPM for your car; 6500 is only a starting point, not learned perfect shifting.

Manual drag assist never runs while automatic drag AI is requested, including countdown and failed/unavailable AI. It will not silently substitute synthetic inputs. With Automatic AI off, manual drag waits for native ownership to clear and a human driver to be confirmed. Countdown permits throttle only; shifts wait for GO. It does not choose lanes or avoid obstacles. F7/manual takeover pauses it until its switch is toggled again.

### Diagnostics

#### Local crash log

Open **Driving tools → Session & diagnostics → Crash log → Export crash log**. This downloads `nfsu2-driving-tools-diagnostics.json` on your computer. Nothing is automatically sent or uploaded. **Clear log** removes this tab's retained diagnostic history; recording then continues.

The logger starts when this extension page loads. It records recent tool choices/factors, sampled game mode and driver state, page/game-worker lifecycle, classified errors, numeric WebAssembly function/offset locations and line numbers from known script files. It does not capture raw console logs, error messages, URLs, credentials, names, saves, keyboard input or network traffic. It never changes game memory or enables a tool.

The newest **180 events, limited to 64 KiB of stored JSON**, are kept in same-tab session storage. State is sampled on discrete changes (at most four times a second), moving native scalars about every two seconds, and a baseline snapshot every five seconds while driving; rapid repeated page errors are capped. Older entries are discarded and the file reports the count. Export soon after a problem. Reloading the same tab normally retains the log; closing the tab, clearing site data, browser recovery behavior or blocked/full storage can lose it. The menu reports when the log is memory-only. The site's own scripts can access this same-origin session storage, so it is not an extension-private vault.

**Capture limits:** this cannot recover crashes that happened before the logger was installed. A full browser/tab/GPU crash, freeze or forced close may prevent any final event. This is a history of observations, not a complete crash dump or proof of the crash's cause; the last snapshot may precede the failure. Free-text errors are deliberately omitted for privacy, so unfamiliar errors appear as `other`. Also export the game's own **Download log** for native game details. This logger does not fix the reported crash or establish that the game is safe.


The read-only traffic/barrier tester reads nearby car objects and the enabled barrier-line table. It is incomplete: it does not fully classify traffic/racers, shapes, props, road geometry, elevation or safe lanes. No detected obstacle does not imply a safe road.

## Online / LAN

Online/LAN remains blocked by default for existing tools. The separate **Session mode → Allow Online/LAN tools** switch is per-page and starts off on reload. It does not activate individual tools. It never overrides the solo restrictions on walls and solo Car no-clip, drag physics requirements, pause checks or one-local-player checks. Online traffic no-clip remains online-free-roam-only. Current-build Online player / race no-clip requires its own selection plus network permission for the race path; only local contacts are affected.

Online modifications may affect racers, trigger integrity checks, invalidate results or cause moderation/bans. Follow the site's rules and prefer solo play or an explicitly permitted private test. This extension does not bypass server restrictions. Turning off the session switch stops AI/synthetic keys and restores owned tuning when possible, while keeping selections for solo. NOS already refilled is not drained. F9 clears the permission.

## Validation and known limits

**Automated validation:** the final v0.28 suite passes **1,740 tests, zero failures/skips/cancellations**, including high-address runtime CPU cases. See `CHANGELOG.md`. The frozen v0.20 tuner baseline passed 1,599 tests. Coverage includes the retained v0.18 regressions, actual native isolated getter/setter/rebuild and metrics, all unlocked control offsets, exact game-thread capture/stage/restore, all five preset leases, stale-state/identity/cancellation/fuel guards, and end-to-end private preview with selected-preset-only writes. The end-to-end harness uses exact native game functions and a constructed car/catalog fixture, not a live user's game. Focused suites overlap and are not additive totals. These checks are not a full game simulation or live gameplay.

All four exact supported modules validate and compile after patching. Both modern profiles change12 bodies: **2459, 3174, 4497, 4653, 7395, 8871, 17404, 19197, 19277, 21213, 21263**, plus contact wrapper **22508** on93af6ccb or **22470** on78e2bb69. On2f0ddd3b, only **4497, 4653, 21213, 21262 and22430** change; on6f4f1e4e, only **4497, 4653, 21213, 21262 and22720** change. Every other function body and non-code section is preserved byte-for-byte. Original planner instructions and contact-wrapper tails remain preserved. The native Drift recovery expression replacement retains its documented scope. Authored builders reproduce the shipped payloads.

No successful live drag race, wall/car test, cornering improvement, real-car dyno improvement or online race is claimed. The menu passes simulated DOM checks. The strict-CSP Chromium regression test could not run because this environment blocks Chromium startup; no real-browser visual verification is claimed.

The v0.11 crash remains undiagnosed. Controlled interleaving tests did expose stale-state and competing-writer hazards in power, grip and NOS. This release rechecks live state/identity at each field, uses exact-value atomic updates/restoration, rejects out-of-domain power values and avoids unchanged-value rewrites. These are experimental mitigations, not full lifetime synchronization: the native game can still destroy/reuse an object before updating its pointer. No elimination of that residual race or the reported freezes is claimed. The current game-thread gcall ABI, dispatch mapping and hook-local layout match the reviewed native binary; that does not establish the absence of timing, lifetime or gameplay faults. Stop using a feature if the game becomes unstable, preserve the crash log and reload before retesting.

Historical profile notes (the current supported-build list is above):

- **93af6ccb:** 38,205,596 bytes, SHA-256 `128e2b5816a8eace4b768aec920318a1613da8235801a361e2009e96550be1d6`. Retained reviewed profile with the64-entry native status table.
- **78e2bb69:** 38,170,601 bytes, SHA-256 `df7b930bb293ffdf975f0735d93e0797d51bd137d0cbeabcaff87fc5a693c759`. Previous reviewed modern profile. Main hook 21213, dispatch 21726, gcall 21740, pace wrapper 21263, contact wrapper 22470; exact native bodies and relocated wrappers are checked offline.
- **2f0ddd3b:** 36,872,934 bytes, SHA-256 `5e33ad2cb4c4cc6893dee7cbd4d6e9bfb0f59a349d218fddbb5e3331ca69bc34`. Expanded experimental feature support listed above. The native gcall function was mapped from old index 21725 to current index 21739 and verified to preserve the same CPU ABI; actual dispatch tables and native AI bodies were checked independently.
- **6f4f1e4e:** 37,839,055 bytes, SHA-256 `ee5d281a3109240d5db25dc3921e1044672cf6d650eb58c3baa089b54fe2941f`. Retains the older combined experimental feature set.

An independent probe executes actual current-build input/status initialization, status writing and the NOS reader in isolated memory: 22 assertions pass. This verifies the mailbox formats and NOS interpretation, not a real gameplay session. A separate native gcall binary comparison verifies that its only body change is the dispatcher call relocation.

## Privacy, implementation and rollback

The extension matches only `https://nfsu2.xyz/*`. No account, history, debugger or broad website permissions. It stores its own preferences and a bounded, sanitized diagnostic history in namespaced same-tab session-storage entries. Nothing is uploaded. Its only added request is a same-origin `/game.json` compatibility read; it inspects the game's own module response during loading. No analytics, remote code or game assets are bundled.

- AI calls native `Player::AutoPilotOn`, `AutoPilotOff` and `SetInputMode` through the game's existing CPU-preserving game-thread dispatcher. It never invokes native game functions concurrently from the page thread.
- Normal drag opponents use driver type 3 / physics type 1, while player autopilot initially asks for physics type 3. The retained drag handoff corrects only the eligible local car, verifies both types and rolls back on failure.
- The page's automatic AI switch supplies the exact drag-permission word only when drag is detected. The native permission and full-physics checks are still required. The pace hook never modifies drag.
- Mode switching publishes OFF and verifies the native heartbeat acknowledgement, cleared ownership and restored manual driver before rearming. Identity, native subtype/track flags and race/free-roam mode are part of that comparison. Native Off/On rebuilds the private driver route.
- Command memory stays at `0x00d0d100` (104 bytes used on modern Drag-heat profiles;92 bytes on older profiles) and walls at `0x00d0d180` (40 bytes), under sequence locks. Cars use `0x00d0d1c0` (40 bytes); the existing final word selects the independent online traffic/player modes on 93af6ccb and 78e2bb69. The corner record is at `0x00d0d200` (64 bytes, CNR3), and dyno uses `0x00d0d300..0x00d0d4ff`. These do not overlap. Native scalar-reference/allocator analysis supports using these gaps, but exclusive allocation has not been formally proved and unknown computed writes remain a risk. Cold empty/owned checks and post-attachment ownership guards reduce, not eliminate, that risk. The current-build patch targets the main-loop bridge, player pace, contact resolver, corner/braking helpers, native drag action/input selectors, native Drift damping expression and three guarded nitrous acceptance sites. Original native instructions remain preserved around the scoped changes.
- The full tuner additionally grows the game memory by an owned 16 MiB snapshot buffer, records its module/memory identity and uses the existing dyno mailbox for commands. Snapshot growth is not undone until reload. Native evaluation runs in separate memory with guarded reads/writes and execution fuel. Staging does not call a game physics rebuild or save helper.
- Wall filtering prefixes `sub_005b2610` and preserves the full original resolver for every rejected contact. Body type/vtable, reciprocal car/face pointers, finite unit normals and pair identities are checked. Native `roam_game_online_here()` always blocks wall filtering during multiplayer free roam. The separate latest-build traffic path also calls the exact native read-only player-slot helper and excludes recognized player cars.

For rollback, copy your complete previous extension files into the same loaded folder, Reload its existing extension card, then refresh the game. Keep the backup outside the loaded folder and never enable both copies. The previous release remains subject to its build-compatibility checks. This restores extension code, not game progress or changed settings. See `UPDATE-WINDOWS.txt`.

### Source references

- Public pinned source: https://github.com/th0mk/nfsu2-web/tree/6f4f1e4e92f5f3ddf6f6d165b7f7075a95ab7fe3
- `runtime/career.c`, `runtime/guest.h`: native handoff, return-to-input and game-thread calls.
- `runtime/catchup.c`: native skill, player target-speed calculation.
- `runtime/game.h`, `runtime/web/status_web.c`: driving/countdown/paused states and drag type.
- `runtime/roam.c`, `runtime/roam_game.c`: collision wrapper, native Ghost scope and multiplayer state.
- `runtime/walls.c`: native barrier lines.
- `runtime/mprace.c`, `runtime/drift.c`: per-car torque, limiter, drift and tyre data.
- Reconstructed collision classifications, independently checked against the exact executable: https://github.com/troikoss/speed-re/tree/892e5c31d77c751acd123330eda15c157c4f1b1f/src/Speed/Indep/Src/Physics/Collision

No upstream files were modified. This is unofficial and not affiliated with the site or Electronic Arts. No game executable, assets or reconstructed third-party code are in the ZIP.

### Tuner snapshot rejection diagnostics

A snapshot rejection keeps the original setup and remains fail-closed. Updated errors identify the failed component with a short code such as **S32** (performance-curve sample count) or **S45** (curve data bounds). Export **Crash log** immediately after one failed attempt; the local export retains only the rejection status, fixed guard code, and relevant count/source-pair number, plus ordinary classified script locations. It does not include memory addresses, raw game memory, setups, or saves.

This is a diagnostic improvement, not proof that a previously unsupported live snapshot is now compatible. Capture limits, alias checks, the owned 16 MiB buffer, isolated native evaluation, all 41 settings, and selected-preset-only Stage/Restore are unchanged. Do not disable checks or invent missing curve data to make a capture succeed.
